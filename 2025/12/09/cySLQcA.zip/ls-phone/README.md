# LS-PHONE


https://lquensdocs.gitbook.io/lquens/ls-core/installation
https://lquensdocs.gitbook.io/lquens/ls-phone/installation

https://github.com/LquenS/ls-core
https://github.com/Xogy/xsound
https://github.com/citizenfx/screenshot-basic
https://github.com/LquenS/ls-crypto