export default /* glsl */`
#ifdef USE_FOG

	varying float fogDepth;

#endif
`;
