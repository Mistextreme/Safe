// Define a configuration object
Config = {};

/**
 * Whether or not to use debug mode.
 * @type {boolean}
 */
Config.Debug = true

/**
 * The language used for the phone.
 * @type {string}
 */
Config.Language = "en-US";

/**
 * Whether or not to use battery phone.
 * @type {boolean}
 */
Config.UseBattery = false;

/**
 * The network settings for the app.
 * @type {Object}
 */
Config.Network = {}

/**
 * The list of apps that require a network connection.
 * @type {Array<string>}
 */
Config.Network.RequiresApp = [
    "instagram",
    "twitter",
    "darkchat",
    "whatsapp",
    "yellowpages",
    "news",
    "snapchat",
]

/**
 * Whether or not to use the internet.
 * @type {boolean}
 */
Config.Network.UseInternet = true

Config.Blips = {
    [59]: {
        icon: 'fa-solid fa-basket-shopping',
        background: "#bd1f1f",
    },
    [73]: {
        icon: 'fa-solid fa-shirt',
        background: "#e6af50",
    },
    [108]: {
        icon: 'fa-solid fa-building-columns',
        background: "#8d47de",
    },
}

Config.NewsJob = "news"

Config.Refresh = {}
Config.Refresh.WeatherSet = 120000
Config.Refresh.WeatherAdjust = 120000
Config.Refresh.TimerAdjust = 15000
Config.Refresh.NearbyConnections = 15000
Config.Refresh.SetupIcon = 15000
Config.Refresh.RemoveBattery = 60000
Config.Refresh.StartDownload = 100


Locales = {}
APPBuilder = "0RESMON"

ApplicationList = {
    "whatsapp": {
        app: "whatsapp",
        color: "transparent",
        icon: false,
        photo: "whatsapp.png",
        label: "WhatsApp",
        slot: 6,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.3,        
        downloadsize: 72,
        apptype: "app",
        appbuild: "Whatsapp LLC",
    },
    "map": {
        app: "map",
        color: "transparent",
        icon: false,
        photo: "map.png",
        label: "Map",
        slot: 11,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.9,        
        downloadsize: 45,
        apptype: "app",
        appbuild: "LOS",
    },
    "notes": {
        app: "notes",
        color: "transparent",
        icon: false,
        photo: "notes.png",
        label: "Notes",
        slot: 15,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.7,        
        downloadsize: 17,
        apptype: "app",
        appbuild: "LOS",
    },
    "calendar": {
        app: "calendar",
        color: "transparent",
        photo: "system_calendar_1.png",
        label: "Calendar",
        slot: 9,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 2.9,        
        downloadsize: 21,
        apptype: "app",
        appbuild: "LOS",
    },
    "instagram": {
        app: "instagram",
        color: "transparent",
        icon: false,
        photo: "instagram.png",
        label: "Instagram",
        slot: 6,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 3.9,
        downloadsize: 110,
        apptype: "app",
        appbuild: "Meta Inc.",
    },
    "twitter": {
        app: "twitter",
        color: "transparent",
        icon: false,
        photo: "twitter.png",
        label: "Twitter",
        slot: 7,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.1,
        downloadsize: 70,
        apptype: "app",
        appbuild: "Twitter Inc.",
    },

    "darkchat": {
        app: "darkchat",
        color: "transparent",
        icon: false,
        photo: "darkchat.png",
        label: "Telegram",
        slot: 17,
        page: 1,
        currentPage: null,
        pageDetails: {},
        rating: 4.3,
        downloadsize: 76,
        apptype: "app",
        appbuild: "Telegram FZ-LLC",
    },
    "mail": {
        app: "mail",
        color: "transparent",
        icon: false,
        photo: "mail.png",
        label: "Mail",
        slot: 18,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.2,
        downloadsize: 30,
        apptype: "app",
        appbuild: "LOS",
    },
    "wallet": {
        app: "wallet",
        color: "transparent",
        icon: false,
        photo: "wallet.png",
        label: "Wallet",
        slot: 19,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.9,
        downloadsize: 34,
        apptype: "app",
        appbuild: "LOS",
    },
    "crypto": {
        app: "crypto",
        color: "transparent",
        icon: false,
        photo: "crypto.png",
        label: "Crypto",
        slot: 20,
        page: 1,
        currentPage: null,
        pageDetails: {},
        rating: 4.4,
        downloadsize: 44,
        apptype: "app",
        appbuild: "Crypto Inc.",
    },
    "yellowpages": {
        app: "yellowpages",
        color: "transparent",
        icon: false,
        photo: "yellowpages.png",
        label: "Yellow Pages",
        slot: 21,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.2,
        downloadsize: 102,
        apptype: "app",
        appbuild: "Yellow Pages Inc.",
    },
    "services": {
        app: "services",
        color: "transparent",
        icon: false,
        photo: "services.png",
        label: "Business",
        slot: 22,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.0,
        downloadsize: 21,
        apptype: "app",
        appbuild: "Goverment",
    },
    "garage": {
        app: "garage",
        color: "transparent",
        icon: false,
        photo: "garage.png",
        label: "Garage",
        slot: 23,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 3.4,
        downloadsize: 42,
        apptype: "app",
        appbuild: "LOS",
    },
    "uber": {
        app: "uber",
        color: "transparent",
        icon: false,
        photo: "uber.png",
        label: "Uber",
        slot: 24,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.7,
        downloadsize: 81,
        apptype: "app",
        appbuild: "Uber Tech Inc.",
    },
    "ubereats": {
        app: "ubereats",
        color: "transparent",
        icon: false,
        photo: "ubereats.png",
        label: "Uber Eats",
        slot: 5,
        page: 2,
        currentPage: null,
        pageDetails: {},

        rating: 4.5,
        downloadsize: 67,
        apptype: "app",
        appbuild: "Uber Tech Inc.",
    },
    "music": {
        app: "music",
        color: "transparent",
        icon: false,
        photo: "music.png",
        label: "iTunes",
        slot: 6,
        page: 2,
        currentPage: null,
        pageDetails: {},

        rating: 4.5,
        downloadsize: 25,
        apptype: "app",
        appbuild: "LOS",
    },
    "youtube": {
        app: "youtube",
        color: "transparent",
        icon: false,
        photo: "youtube.png",
        label: "YouTube",
        slot: 7,
        page: 2,
        currentPage: null,
        pageDetails: {},

        rating: 4.2,
        downloadsize: 120,
        apptype: "app",
        appbuild: "Google LLC",
    },
    // "snapchat": {
    //     app: "snapchat",
    //     color: "transparent",
    //     icon: false,
    //     photo: "snapchat.png",
    //     label: "Snapchat",
    //     slot: 8,
    //     page: 2,
    //     currentPage: null,
    //     pageDetails: {},

    //     rating: 4.2,
    //     downloadsize: 108,
    //     apptype: "app",
    //     appbuild: "Snap Inc.",
    // },
    "news": {
        app: "news",
        color: "transparent",
        icon: false,
        photo: "news.png",
        label: "News",
        slot: 7,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.2,        
        downloadsize: 32,
        apptype: "app",
        appbuild: "Weazel News Inc.",
    },
    "spotify": {
        app: "spotify",
        color: "transparent",          //------------------------- yputum
        icon: false,
        photo: "spotify.png",
        label: "You Music",
        slot: 6,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 4.9,        
        downloadsize: 15,
        apptype: "app",
        appbuild: "Youtube Music Inc.",
    },
    // "doodlejump": {
    //     app: "doodlejump",
    //     color: "transparent",
    //     icon: false,
    //     photo: "doodlejump.png",
    //     label: "Doodle Jump",
    //     slot: 13,
    //     page: 1,
    //     currentPage: null,
    //     pageDetails: {},

    //     rating: 4.4,
    //     downloadsize: 62,
    //     apptype: "games",
    //     appbuild: "Lima Sky LLC",
    // },
    // "pacman": {
    //     app: "pacman",
    //     color: "transparent",
    //     icon: false,
    //     photo: "pacman.png",
    //     label: "Pacman",
    //     slot: 14,
    //     page: 1,
    //     currentPage: null,
    //     pageDetails: {},

    //     rating: 4.2,
    //     downloadsize: 48,
    //     apptype: "games",
    //     appbuild: "BANDAI Ent Inc.",
    // },
    // "flappybird": {
    //     app: "flappybird",
    //     color: "transparent",
    //     icon: false,
    //     photo: "flappybird.png",
    //     label: "Flappy Bird",
    //     slot: 7,
    //     page: 1,
    //     currentPage: null,
    //     pageDetails: {},

    //     rating: 3.2,        
    //     downloadsize: 18,
    //     apptype: "games",
    //     appbuild: "GEARS Studios",
    // },
    // "kong": {
    //     app: "kong",
    //     color: "transparent",
    //     icon: false,
    //     photo: "kong.png",
    //     label: "Kong",
    //     slot: 9,
    //     page: 1,
    //     currentPage: null,
    //     pageDetails: {},

    //     rating: 3.0,        
    //     downloadsize: 12,
    //     apptype: "games",
    //     appbuild: "Nintendo",
    // },
    "tower": {
        app: "tower",
        color: "transparent",
        icon: false,
        photo: "tower.png",
        label: "Tower",
        slot: 11,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 2,        
        downloadsize: 23,
        apptype: "games",
        appbuild: "LOS",
    },
    "labyrinth": {
        app: "labyrinth",
        color: "transparent",
        icon: false,
        photo: "labyrinth.png",
        label: "Labyrinth",
        slot: 13,
        page: 1,
        currentPage: null,
        pageDetails: {},

        rating: 1.0,        
        downloadsize: 25,
        apptype: "games",
        appbuild: "LOS",
    },
}
