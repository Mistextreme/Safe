Config.Server = {}

Config.Server.GetFramework = function()
    return exports["es_extended"]:getSharedObject()
end

Config.Server.LS_CORE = exports["ls-core"]:GetCoreObject()

Config.Server.GetPlayer = function(src, isLSCORE)
    if isLSCORE == nil then isLSCORE = false end
    if not isLSCORE then
        return Config.Server.Framework.GetPlayerFromId(src)
    else
        return exports["ls-core"]:GetPlayer(src)
    end
end

Config.Server.GetPlayerIdentifier = function(src)
    return Config.Server.GetPlayer(src).identifier 
end 

Config.Server.GetPlayerFromIdentifier = function(src)
    return Config.Server.Framework.GetPlayerFromIdentifier(src)
end

Config.Server.UseMetadata = false

Config.Server.SavePhoneData = function(src, newData, serialNumer)
    if not Config.Server.UseMetadata then
        if GetUserDataSQL(src) ~= nil then
            Config.Server.LS_CORE.Config.DATABASE( Config.Server.LS_CORE.Config.DATABASE_NAME, 'execute', 'UPDATE `phone_metadata` SET `data` = @data WHERE `identifier` = @identifier', {
                ["@identifier"] = Config.Server.GetPlayer(src, true).DATA.identifier,
                ["@data"] = json.encode(newData),
            })
        else
            Config.Server.LS_CORE.Config.DATABASE( Config.Server.LS_CORE.Config.DATABASE_NAME, 'execute', 'INSERT INTO `phone_metadata` (identifier, data) VALUES (@identifier, @data)', {
                ["@identifier"] = Config.Server.GetPlayer(src, true).DATA.identifier,
                ["@data"] = json.encode(newData),
            })
        end
        return true
    else
        local item
        if GetResourceState("ls-inventoryhud") == "started" then
            for k,v in pairs( exports["ls-inventoryhud"]:GetItems(src) ) do
                if serialNumer ~= nil then
                    if v.info ~= nil and v.info.MetaData ~= nil then
                        if v.info.MetaData.serialnumber == serialNumer then
                            item = v
                            break
                        end
                    end
                else
                    if v.info == nil or v.info.MetaData == nil then
                        item = v
                        break
                    end
                end
            end
            if item then
                exports["ls-inventoryhud"]:UpdateItem(src, item.slot, newData)
                return true
            end
        elseif GetResourceState("ox_inventory") == "started" then
            local playerItems = exports.ox_inventory:GetInventoryItems(src)
            for k,v in pairs(playerItems) do
                if serialNumer ~= nil then
                    if v.metadata ~= nil and v.metadata.MetaData ~= nil then
                        if v.metadata.MetaData.serialnumber == serialNumer then
                            item = v
                            break
                        end
                    end
                else
                    if v.metadata == nil or v.metadata.MetaData == nil then
                        item = v
                        break
                    end
                end
            end

            if item then
                item.metadata = newData
                exports.ox_inventory:SetMetadata(src, item.slot, item.metadata)
                return true
            end
        elseif GetResourceState("qb-inventory") == "started" then
            local Player = Config.Server.Framework.Functions.GetPlayer(src)
            for k,v in pairs(Player.PlayerData.items) do
                if serialNumer ~= nil then
                    if v.info ~= nil and v.info.MetaData ~= nil then
                        if v.info.MetaData.serialnumber == serialNumer then
                            item = v
                            break
                        end
                    end
                else
                    if v.info == nil or v.info.MetaData == nil then
                        item = v
                        break
                    end
                end
            end

            if item then
                Player.PlayerData.items[item.slot].info = newData
                
                Player.Functions.SetInventory(Player.PlayerData.items, true)
                return true
            end
        elseif GetResourceState("qs-inventory") == "started" then
            local playerItems = exports['qs-inventory']:GetInventory(src)
            for k,v in pairs(playerItems) do
                if serialNumer ~= nil then
                    if v.info ~= nil and v.info.MetaData ~= nil then
                        if v.info.MetaData.serialnumber == serialNumer then
                            item = v
                            break
                        end
                    end
                else
                    if v.info == nil or v.info.MetaData == nil then
                        item = v
                        break
                    end
                end
            end

            if item then
                exports['qs-inventory']:SetItemMetadata(src, item.slot, newData)
                return true
            end
        end
    end
    return false
end

Config.BillingCommissions = { -- This is a percentage (0.10) == 10%
    mechanic = 0.10
}

Config.ValetCost = 10

Config.Server.PayBilling = function(Ply, society, amount, invoiceId, sendercitizenid) 
    TriggerEvent("esx_billing:payBill", Ply, invoiceId)
    return true
end

Config.Server.Framework = Config.Server.GetFramework()

Config.Server.Webhook = "https://discord.com/api/webhooks/1171905847450943618/2TrJX6Tsvsdpd63lB13R2NgGmozGHF27ljm_GDNYxKl4xmJ-Ahto6RvcUldCzk7aAC41"
