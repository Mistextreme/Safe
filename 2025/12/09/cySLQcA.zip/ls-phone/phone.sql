SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE IF NOT EXISTS `contact_messsages` (
  `identifier` varchar(255) NOT NULL,
  `persons` mediumtext NOT NULL,
  `messages` longtext NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `darkchat_chats` (
  `chatname` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `joinedUsers` mediumtext NOT NULL,
  `messages` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `darkchat_users` (
  `identifier` varchar(255) NOT NULL,
  `profileimage` text NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `instagram_dm` (
  `identifier` varchar(255) NOT NULL,
  `persons` text NOT NULL,
  `messages` longtext NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `instagram_post` (
  `identifier` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `time` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL DEFAULT '{}',
  `whosent` varchar(255) NOT NULL,
  `likedusers` mediumtext NOT NULL DEFAULT '[]',
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `instagram_users` (
  `identifier` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `bioghrapy` varchar(255) DEFAULT NULL,
  `profileimage` text DEFAULT NULL,
  `followers` mediumtext NOT NULL DEFAULT '[]',
  `following` mediumtext DEFAULT '[]',
  `password` text NOT NULL,
  `posts` mediumtext NOT NULL DEFAULT '{}',
  `likedposts` mediumtext DEFAULT '{}',
  `messages` longtext NOT NULL DEFAULT '{}',
  `story` mediumtext DEFAULT '{}',
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `player_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `read` tinyint(4) DEFAULT 0,
  `mailid` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `button` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `citizenid` (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `news_new` (
  `identifier` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `time` int(11) NOT NULL,
  `attachments` mediumtext NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `phone_invoices` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT 0,
  `society` tinytext DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `sendercitizenid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `citizenid` (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `snapchat_messages` (
  `identifier` varchar(255) NOT NULL,
  `persons` text NOT NULL,
  `messages` text NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `snapchat_users` (
  `identifier` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `profileimage` varchar(255) NOT NULL,
  `friends` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `friendrequests` text NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `twitter_tweets` (
  `identifier` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `attachment` text NOT NULL,
  `time` varchar(255) NOT NULL,
  `likedusers` mediumtext NOT NULL DEFAULT '[]',
  `comments` mediumtext NOT NULL DEFAULT '{}',
  `whosent` varchar(255) NOT NULL,
  `retweets` mediumtext NOT NULL DEFAULT '{}',
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `twitter_users` (
  `identifier` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bioghrapy` varchar(255) NOT NULL,
  `profileimage` text NOT NULL,
  `followers` mediumtext NOT NULL DEFAULT '[]',
  `following` mediumtext NOT NULL DEFAULT '[]',
  `password` varchar(255) NOT NULL,
  `tweets` longtext NOT NULL DEFAULT '[]',
  `likedtweet` longtext NOT NULL DEFAULT '[]',
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `whatsapp_messages` (
  `identifier` varchar(255) NOT NULL,
  `persons` text NOT NULL,
  `messages` mediumtext NOT NULL,
  `isGroup` text NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `whatsapp_users` (
  `identifier` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `profileimage` text NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `crypto_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `message` varchar(50) DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `citizenid` (`citizenid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `yellowpage_advert` (
  `identifier` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `time` int(11) NOT NULL,
  `phonenumber` int(22) NOT NULL,
  `attachments` text NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
