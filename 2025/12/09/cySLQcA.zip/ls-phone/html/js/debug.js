Debug = false
DebugPhoneData = {}
    function DebugSetUp() {
        Debug = true
    
    let Phone = {
        "MetaData": {
            "phonenumber": 3252154822,
            "owner": "Jack Dean",
            "serialnumber": "ACAS5124",
            "profilepicture": "img/default.png",
            "background": "img/backgrounds/iphone.png",
            "wallpapers": { "img/backgrounds/iphone.png": true, "https://cdn.discordapp.com/attachments/702195467961761865/1009453555066884116/05b09470-0825-4b53-9ef2-cc73053321e4.jpg": false },
            "brightness": 100.0,
            "volumeprogress": 100.0,
            "layout": "4-6",
            "widgetApp" : {
                "test1": {
                    identifier: "test1",
                    widgetSize: { x: 4, y: 2 },
                    widgetApp: "spotifywid",
                    widgetSlots: { slotphone: 13, page:2 }
                }
            },
            "phonePages": { 1: true, 2: true },
            "phonePage": 1,
            "notifications": {},
            "oldConnections": {},
            "Password": false,

            "instagramUser": false, //"kYhhcRslhDjFMBwfSGYE"
            "twitterUser": false, //"zYhhcRslhDjFMBwfSGYE"
            "snapchatUser": "lquens", //"lquens",
            "darkchatUser": "xsSffsaFKfd",

            "snapchatFriendRequests": [ "salakoc" ],

            //y == -171
            "phoneLocation": { x: 94, y: 100},
            "phoneZoom": 100,
            "bluetooth": false,
            "locationInfo": true,
            "LockScreen": false,
            "PhonePet": "fox",

            "beforeApps": [],

            "spotifySongs": { "favorites": [], "history": [ "https://www.youtube.com/watch?v=nyuo9-OjNNg&ab_channel=ArcticMonkeys-Topic" ], },

            "talkHistory": {},

            "isInstalled": true,

            "transactions": [
                    {
                        "type": "Bank",
                        "time": 1682174438,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682175038,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682175638,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682176238,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682176838,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682177438,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682178039,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682178639,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682179239,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682180439,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682181039,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682181639,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682182239,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682182839,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682183439,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682184039,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682184638,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682185238,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682185838,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682186438,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682187038,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682187638,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682188238,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682188838,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682189438,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682190038,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682241607,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682242207,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682242807,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682243407,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682244007,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682244607,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682245207,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682245807,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682246407,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682247007,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682247608,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682248208,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682248808,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682249408,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682250008,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682250608,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682251208,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682253608,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682254208,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682416332,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682416932,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682417532,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682424132,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682424732,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 10
                    },
                    {
                        "type": "Bank",
                        "time": 1682449933,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682450534,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682451134,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682451734,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682452334,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682452934,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682453534,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682454134,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682454734,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682455334,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682455934,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682456534,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682457134,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682457734,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682458334,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682458934,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682459534,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682460134,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682460734,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682461334,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682461934,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682518755,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682519355,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682519955,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682520555,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682521155,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682521755,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682522355,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682522955,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682523555,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682524155,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682524755,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682525355,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682525955,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682526555,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682527155,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682527755,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682528355,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682528955,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682529555,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682530155,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682530755,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682531355,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682531955,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682532555,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682533155,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682533756,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682534356,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682534956,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682535556,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682536156,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682536756,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682537356,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682537956,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682538556,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682539156,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682539756,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682595455,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682596055,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682596655,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682597255,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682597855,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682599055,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682599655,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682600255,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682600855,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682601456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682602056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682602656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682603256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682603856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682604456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682605056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682605656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682606256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682606856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682607456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682608056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682608656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682609256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682609856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682610456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682611056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682611656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682612256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682612856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682613456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682614056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682614656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682615256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682615856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682616456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682617056,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682617656,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682618256,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682618856,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682619456,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682620057,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682620657,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682621257,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682621857,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682622457,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682623057,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682623657,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682624257,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682624857,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682625457,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682626057,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682626657,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682627257,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682627857,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682628457,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682629057,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682630857,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682631457,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682632057,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682710239,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682711439,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682712039,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682712639,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682713239,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682713839,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682714439,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682715039,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682762362,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682762962,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682763562,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682764162,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682764762,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682765362,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682765962,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682766562,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682767162,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682767762,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682768362,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682768962,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682769562,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682770162,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682770762,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682771362,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682771962,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682772562,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682773162,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682784814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682785414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682786014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682786614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682787214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682787814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682788414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682789014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682789614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682790214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682790814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682791414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682792014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682792614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682793214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682793814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682794414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682795014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682795614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682796214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682796814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682797414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682798014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682798614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682799214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682799814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682800414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682801014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682801614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682802214,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682802814,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682803414,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682804014,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682804614,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682805215,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682805815,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682962786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682963386,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682963986,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682965186,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682965786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682966386,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682966991,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682967586,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682968186,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682968786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682969386,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682969986,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682970586,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682971186,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682971786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682972386,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682972986,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682973586,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682974186,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682974786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682975386,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682975986,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682976586,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682977186,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682977786,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682978387,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682978987,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682979587,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682980187,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682980787,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682981387,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1682981987,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683022574,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683023174,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683023774,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683024374,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683024974,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683025574,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683026174,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683026774,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683027374,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683027974,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683028574,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683029174,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683029774,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683030374,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683030974,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683031574,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683032174,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683051646,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683127187,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683127787,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683128387,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683128987,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683199091,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683199691,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683201492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683202092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683202692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683203292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683203892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683204492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683205092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683205692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683206292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683206892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683207492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683208092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683208692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683209292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683209892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683210492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683211092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683211692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683212292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683212892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683213492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683214092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683214692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683215292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683215892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683216492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683217092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683217692,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683218292,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683218892,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683219492,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683220092,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683360819,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683361419,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683362019,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683362619,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683363219,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683363819,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683364420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683365020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683365620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683366220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683366820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683367420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683368020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683368620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683369220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683369820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683370420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683371020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683371620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683372220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683372820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683373420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683374020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683374620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683375220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683375820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683376420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683377020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683377620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683378220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683378820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683379420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683380020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683380620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683381220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683381820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683382420,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683383020,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683383620,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683384220,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683384820,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683385421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683386021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683386621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683387221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683387821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683388421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683389021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683389621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683390221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683390821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683391421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683392021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683392621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683393221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683393821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683394421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683395021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683395621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683396221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683396821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683397421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683398021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683398621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683399221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683399821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683400421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683401021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683401621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683402221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683402821,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683403421,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683404021,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683404621,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683405027,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 255
                    },
                    {
                        "type": "Bank",
                        "time": 1683405221,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683405822,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683406422,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683407022,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683407622,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683408222,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683408822,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683409422,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683410022,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683410622,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683411222,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683449901,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 500
                    },
                    {
                        "type": "Bank",
                        "time": 1683449930,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 5e+23
                    },
                    {
                        "type": "Bank",
                        "time": 1683449933,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 5e+23
                    },
                    {
                        "type": "Bank",
                        "time": 1683449935,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 5e+23
                    },
                    {
                        "type": "Bank",
                        "time": 1683449936,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 5e+23
                    },
                    {
                        "type": "Bank",
                        "time": 1683449937,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 5e+23
                    },
                    {
                        "type": "Bank",
                        "time": 1683449947,
                        "desc": "paid-fine",
                        "icon": "remove",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683452950,
                        "desc": "paid-invoice",
                        "icon": "remove",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683453000,
                        "desc": "paid-invoice",
                        "icon": "remove",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683453875,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 2152
                    },
                    {
                        "type": "Bank",
                        "time": 1683453914,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 1076
                    },
                    {
                        "type": "Bank",
                        "time": 1683454277,
                        "desc": "paid-invoice",
                        "icon": "remove",
                        "amount": 50
                    },
                    {
                        "type": "Bank",
                        "time": 1683540888,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683541488,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683542089,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683542689,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683551689,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683552289,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683552889,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683553489,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683554089,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683554689,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683555289,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683555889,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683556489,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683557089,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683557689,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683558289,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683558889,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683559489,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683560090,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683560690,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683631998,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683633198,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683713910,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683714510,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683715110,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683715710,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683716310,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683716910,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683717510,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683718110,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683718710,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683719310,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683719910,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683720510,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683721110,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683721711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683722311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683722911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683723511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683724111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683724711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683725311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683725911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683726511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683727111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683727711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683728311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683728911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683729511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683730111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683730711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683731311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683733111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683733711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683734311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683734911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683735511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683736111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683736711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683737311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683737911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683738511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683739111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683739711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683740311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683740911,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683741511,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683742111,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683742711,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683743311,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683743912,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683744512,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683745112,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683745712,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683746312,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683746912,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683747512,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683748112,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683748712,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683749312,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683749912,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683750512,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683751112,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683751712,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683752312,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683752912,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683753512,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683754112,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683754712,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683755312,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683755912,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683796615,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683797215,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    },
                    {
                        "type": "Bank",
                        "time": 1683798415,
                        "desc": "unknown",
                        "icon": "add",
                        "amount": 75
                    }
                ]
        },

        "Notification": true,
        "DarkMode": false,
        "Airplane": false,
        "MobileData": false,
        "Wifi": false,
        "WifiData": undefined,
        "DND": false,
        "PhoneLocked": true,
        "Battery": 100,
        "PhoneClosed": false,

        "gallery": {
            "1650979603": {from:"Camera", time: 1650979603, img:"https://cdn.discordapp.com/attachments/824330048273252383/1010128526965485678/toystory.jpg"},
            "1660939261": {from:"Camera", time: 1660939261, img:"https://cdn.discordapp.com/attachments/702195467961761865/1010121742309675098/20220819_124308.jpg"},
            "1660979588": {from:"Camera", time: 1660979588, img:"https://cdn.discordapp.com/attachments/702195467961761865/1010121697111842918/20220819_124253.jpg"},
            "1650979605": {from:"Camera", time: 1650979605, img:"https://cdn.discordapp.com/attachments/702195467961761865/1009453555066884116/05b09470-0825-4b53-9ef2-cc73053321e4.jpg"},
            "1647979203": {from:"Camera", time: 1647979203, img:"https://cdn.discordapp.com/attachments/1007595433972989963/1010448443434610748/unknown5.png"},
            "1647979803": {from:"Camera", time: 1647979803, img:"https://cdn.discordapp.com/attachments/1007595433972989963/1010448443434610748/unknown5.png"},
            "1647979804": {from:"Camera", time: 1647979804, img:"https://cdn.discordapp.com/attachments/1007595433972989963/1010448443434610748/unknown5.png"},
            "1647979805": {from:"Camera", time: 1647979805, img:"https://cdn.discordapp.com/attachments/1007595433972989963/1010448443434610748/unknown5.png"},
            "1647979890": {from:"Camera", time: 1647979890, isVideo: true, img:"https://cdn.discordapp.com/attachments/1008065067977281567/1099664023202570280/video.webm"},
            "1647979812": {from:"Whatsapp", time: 1647979812, img:"https://cdn.discordapp.com/attachments/702195467961761865/1010495309123698718/milkgore_.jpg"},
        },

        "clock": {
            "alarms": { },
        },
        "notes": {
            "kkAdayOlmasin": {
                "identifier": "kkAdayOlmasin",
                "title": "Shopping List",
                "note": `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean hendrerit dui vel lorem auctor tincidunt. Nullam eget tempus mi. Cras nisl justo, volutpat at dignissim sed, ultricies vel sapien. Aenean in tempus justo, vel convallis velit. Donec semper vulputate justo, nec aliquam urna posuere id. Aenean in justo pharetra, lacinia nunc id, pharetra risus. Vestibulum imperdiet quis massa ac accumsan. Cras ac pretium ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam pharetra, magna eget maximus egestas, felis risus congue ligula, id ornare mauris urna ac arcu. Morbi vel orci velit. Ut neque felis, rutrum eu nulla nec, mattis iaculis est. Proin varius eget libero quis malesuada.

                Vivamus vitae nisi consequat, pulvinar felis a, ornare ipsum. Nullam id sollicitudin lacus. In sed condimentum nibh. Suspendisse nulla ante, scelerisque id risus in, finibus pretium libero. Vestibulum ligula felis, porttitor quis sapien a, congue tincidunt tortor. Integer quam turpis, porta ac purus at, blandit rutrum lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elementum ante dolor, pretium pulvinar ante aliquam et. Nulla at ipsum mollis, pulvinar orci non, posuere eros. Sed eu imperdiet sapien, ut laoreet urna. Sed condimentum ultrices ex, id dignissim est aliquam vitae.`,
                "time": 1679653293,
            },
            "kkAdayOlmasin2": {
                "identifier": "kkAdayOlmasin2",
                "title": "Shopping List",
                "note": `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean hendrerit dui vel lorem auctor tincidunt. Nullam eget tempus mi. Cras nisl justo, volutpat at dignissim sed, ultricies vel sapien. Aenean in tempus justo, vel convallis velit. Donec semper vulputate justo, nec aliquam urna posuere id. Aenean in justo pharetra, lacinia nunc id, pharetra risus. Vestibulum imperdiet quis massa ac accumsan. Cras ac pretium ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam pharetra, magna eget maximus egestas, felis risus congue ligula, id ornare mauris urna ac arcu. Morbi vel orci velit. Ut neque felis, rutrum eu nulla nec, mattis iaculis est. Proin varius eget libero quis malesuada.

                Vivamus vitae nisi consequat, pulvinar felis a, ornare ipsum. Nullam id sollicitudin lacus. In sed condimentum nibh. Suspendisse nulla ante, scelerisque id risus in, finibus pretium libero. Vestibulum ligula felis, porttitor quis sapien a, congue tincidunt tortor. Integer quam turpis, porta ac purus at, blandit rutrum lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elementum ante dolor, pretium pulvinar ante aliquam et. Nulla at ipsum mollis, pulvinar orci non, posuere eros. Sed eu imperdiet sapien, ut laoreet urna. Sed condimentum ultrices ex, id dignissim est aliquam vitae.`,
                "time": 1679653293,
            },
            "kkAdayOlmasin3": {
                "identifier": "kkAdayOlmasin3",
                "title": "Shopping List",
                "note": `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean hendrerit dui vel lorem auctor tincidunt. Nullam eget tempus mi. Cras nisl justo, volutpat at dignissim sed, ultricies vel sapien. Aenean in tempus justo, vel convallis velit. Donec semper vulputate justo, nec aliquam urna posuere id. Aenean in justo pharetra, lacinia nunc id, pharetra risus. Vestibulum imperdiet quis massa ac accumsan. Cras ac pretium ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam pharetra, magna eget maximus egestas, felis risus congue ligula, id ornare mauris urna ac arcu. Morbi vel orci velit. Ut neque felis, rutrum eu nulla nec, mattis iaculis est. Proin varius eget libero quis malesuada.

                Vivamus vitae nisi consequat, pulvinar felis a, ornare ipsum. Nullam id sollicitudin lacus. In sed condimentum nibh. Suspendisse nulla ante, scelerisque id risus in, finibus pretium libero. Vestibulum ligula felis, porttitor quis sapien a, congue tincidunt tortor. Integer quam turpis, porta ac purus at, blandit rutrum lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elementum ante dolor, pretium pulvinar ante aliquam et. Nulla at ipsum mollis, pulvinar orci non, posuere eros. Sed eu imperdiet sapien, ut laoreet urna. Sed condimentum ultrices ex, id dignissim est aliquam vitae.`,
                "time": 1679653293,
            },
            "kkAdayOlmasin4": {
                "identifier": "kkAdayOlmasin4",
                "title": "Shopping List",
                "note": `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean hendrerit dui vel lorem auctor tincidunt. Nullam eget tempus mi. Cras nisl justo, volutpat at dignissim sed, ultricies vel sapien. Aenean in tempus justo, vel convallis velit. Donec semper vulputate justo, nec aliquam urna posuere id. Aenean in justo pharetra, lacinia nunc id, pharetra risus. Vestibulum imperdiet quis massa ac accumsan. Cras ac pretium ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam pharetra, magna eget maximus egestas, felis risus congue ligula, id ornare mauris urna ac arcu. Morbi vel orci velit. Ut neque felis, rutrum eu nulla nec, mattis iaculis est. Proin varius eget libero quis malesuada.

                Vivamus vitae nisi consequat, pulvinar felis a, ornare ipsum. Nullam id sollicitudin lacus. In sed condimentum nibh. Suspendisse nulla ante, scelerisque id risus in, finibus pretium libero. Vestibulum ligula felis, porttitor quis sapien a, congue tincidunt tortor. Integer quam turpis, porta ac purus at, blandit rutrum lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elementum ante dolor, pretium pulvinar ante aliquam et. Nulla at ipsum mollis, pulvinar orci non, posuere eros. Sed eu imperdiet sapien, ut laoreet urna. Sed condimentum ultrices ex, id dignissim est aliquam vitae.`,
                "time": 1679653293,
            },
        },

        "mails": {
            "ohaOrospu": {
                identifier: "ohaOrospu",
                sender: "lquens@hotmail.com",
                title: "ls-phone",
                mail: "Here’s a small preview from an email that came in. This preview is usually only between 1 and 3 lines tall.",
                time: 1679653823,
                attachments: {},
                isRead: false,
            },
            "ohaOrospu2": {
                identifier: "ohaOrospu2",
                sender: "lquens@hotmail.com",
                title: "ls-phone",
                mail: "Here’s a small preview from an email that came in. This preview is usually only between 1 and 3 lines tall.",
                time: 1679643823,
                attachments: {},
                isRead: true,
            },
            "ohaOrospu3": {
                identifier: "ohaOrospu3",
                sender: "lquens@hotmail.com",
                title: "ls-phone",
                mail: "Here’s a small preview from an email that came in. This preview is usually only between 1 and 3 lines tall.",
                time: 1679633823,
                attachments: {},
                isRead: true,
            },
        },

        "contacts": {
            "7267018559": {
                "history": {},
                "profileimage": "img/default.png",
                "firstname": "Enayi",
                "lastname": "Sengoz",
                "isGroup": false,
                "messages": { 
                    "1678904947": { time: "1678904947", sender: "3252154822", message:"Can i have a job?" },
                    "1678905099": { time: "1678905099", sender: "7267018559", message:"No, i dont want to give you a job!" },
                },
            },

            "0903341243": {
                "history": { 
                    "1678904947": { started: "1678904947", ended: "1678905099", who: "0903341243" }
                },
                "profileimage": "img/default.png",
                "firstname": "Meshur",
                "lastname": "Oc",
                "isGroup": false,
                "messages": { 
                    "1678904947": { time: "1678904947", sender: "3252154822", message:"Can i have a job?" },
                    "1678905099": { time: "1678905099", sender: "0903341243", message:"No, i dont want to give you a job!" },
                },
            },
        },
        "beforeApps": {},

        "applications": {
            "settings": {
                app: "settings",
                color: "transparent",
                icon: false,
                photo: "settings.png",
                label: "Settings",
                style: "padding-right: .08vh; font-size: 2.3vh",
                job: false,
                blockedjobs: {},
                slot: 1,
                page: 0,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "gallery": {
                app: "gallery",
                color: "transparent",
                icon: false,
                photo: "gallery.png",
                label: "Gallery",
                job: false,
                blockedjobs: {},
                slot: 4,
                page: 0,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "appstore": {
                app: "appstore",
                color: "transparent",
                icon: false,
                photo: "appstore.png",
                label: "App Store",
                job: false,
                blockedjobs: {},
                slot: 5,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },

            "camera": {
                app: "camera",
                color: "transparent",
                icon: false,
                photo: "camera.png",
                label: "Camera",
                job: false,
                blockedjobs: {},
                slot: 6,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "clock": {
                app: "clock",
                color: "transparent",
                icon: false,
                photo: "clock.png",
                label: "Clock",
                job: false,
                blockedjobs: {},
                slot: 7,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "messages": {
                app: "messages",
                color: "transparent",
                icon: false,
                photo: "messages.png",
                label: "Messages",
                job: false,
                blockedjobs: {},
                slot: 2,
                page: 0,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "contacts": {
                app: "contacts",
                color: "transparent",
                icon: false,
                photo: "contacts2.png",
                label: "Phone",
                job: false,
                blockedjobs: {},
                slot: 3,
                page: 0,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "phonecontacts": {
                app: "phonecontacts",
                color: "transparent",
                icon: false,
                photo: "contacts.png",
                label: "Contacts",
                job: false,
                blockedjobs: {},
                slot: 9,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
            },
            "calculator": {
                app: "calculator",
                color: "transparent",
                icon: false,
                photo: "calculator.png",
                label: "Calculator",
                job: false,
                blockedjobs: {},
                slot: 8,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 3.2,        
                downloadsize: 15,
                apptype: "app",
                appbuild: "LOS",
            },















































            "map": {
                app: "map",
                color: "transparent",
                icon: false,
                photo: "map.png",
                label: "Map",
                job: false,
                blockedjobs: {},
                slot: 11,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.9,        
                downloadsize: 45,
                apptype: "app",
                appbuild: "LOS",
            },
            "notes": {
                app: "notes",
                color: "transparent",
                icon: false,
                photo: "notes.png",
                label: "Notes",
                job: false,
                blockedjobs: {},
                slot: 15,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.7,        
                downloadsize: 17,
                apptype: "app",
                appbuild: "LOS",
            },
            "calendar": {
                app: "calendar",
                color: "transparent",
                icon: false,
                photo: "system_calendar_1.png",
                label: "Calendar",
                job: false,
                blockedjobs: {},
                slot: 11,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 2.9,        
                downloadsize: 21,
                apptype: "app",
                appbuild: "LOS",
            },
            "instagram": {
                app: "instagram",
                color: "transparent",
                icon: false,
                photo: "instagram.png",
                label: "Instagram",
                job: false,
                blockedjobs: {},
                slot: 5,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 3.9,
                downloadsize: 110,
                apptype: "app",
                appbuild: "Meta Inc.",
            },
            "twitter": {
                app: "twitter",
                color: "transparent",
                icon: false,
                photo: "twitter.png",
                label: "Twitter",
                job: false,
                blockedjobs: {},
                slot: 8,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.1,
                downloadsize: 70,
                apptype: "app",
                appbuild: "Twitter Inc.",
            },
        
            "darkchat": {
                app: "darkchat",
                color: "transparent",
                icon: false,
                photo: "darkchat.png",
                label: "Telegram",
                job: false,
                blockedjobs: {},
                slot: 17,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
                
                rating: 4.3,
                downloadsize: 76,
                apptype: "app",
                appbuild: "Telegram FZ-LLC",
            },
            "mail": {
                app: "mail",
                color: "transparent",
                icon: false,
                photo: "mail.png",
                label: "Mail",
                job: false,
                blockedjobs: {},
                slot: 18,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,
                downloadsize: 30,
                apptype: "app",
                appbuild: "LOS",
            },
            "wallet": {
                app: "wallet",
                color: "transparent",
                icon: false,
                photo: "wallet.png",
                label: "Wallet",
                job: false,
                blockedjobs: {},
                slot: 19,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.9,
                downloadsize: 34,
                apptype: "app",
                appbuild: "LOS",
            },
            "crypto": {
                app: "crypto",
                color: "transparent",
                icon: false,
                photo: "crypto.png",
                label: "Crypto",
                job: false,
                blockedjobs: {},
                slot: 20,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
                
                rating: 4.4,
                downloadsize: 44,
                apptype: "app",
                appbuild: "Crypto Inc.",
            },
            "yellowpages": {
                app: "yellowpages",
                color: "transparent",
                icon: false,
                photo: "yellowpages.png",
                label: "Yellow Pages",
                job: false,
                blockedjobs: {},
                slot: 21,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,
                downloadsize: 102,
                apptype: "app",
                appbuild: "Yellow Pages Inc.",
            },
            "services": {
                app: "services",
                color: "transparent",
                icon: false,
                photo: "services.png",
                label: "Business",
                job: false,
                blockedjobs: {},
                slot: 22,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.0,
                downloadsize: 21,
                apptype: "app",
                appbuild: "Goverment",
            },
            "garage": {
                app: "garage",
                color: "transparent",
                icon: false,
                photo: "garage.png",
                label: "Garage",
                job: false,
                blockedjobs: {},
                slot: 23,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 3.4,
                downloadsize: 42,
                apptype: "app",
                appbuild: "LOS",
            },
            "uber": {
                app: "uber",
                color: "transparent",
                icon: false,
                photo: "uber.png",
                label: "Uber",
                job: false,
                blockedjobs: {},
                slot: 24,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.7,
                downloadsize: 81,
                apptype: "app",
                appbuild: "Uber Tech Inc.",
            },
            "ubereats": {
                app: "ubereats",
                color: "transparent",
                icon: false,
                photo: "ubereats.png",
                label: "Uber Eats",
                job: false,
                blockedjobs: {},
                slot: 12,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.5,
                downloadsize: 67,
                apptype: "app",
                appbuild: "Uber Tech Inc.",
            },
            "music": {
                app: "music",
                color: "transparent",
                icon: false,
                photo: "music.png",
                label: "iTunes",
                job: false,
                blockedjobs: {},
                slot: 6,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.5,
                downloadsize: 25,
                apptype: "app",
                appbuild: "LOS",
            },
            "youtube": {
                app: "youtube",
                color: "transparent",
                icon: false,
                photo: "youtube.png",
                label: "YouTube",
                job: false,
                blockedjobs: {},
                slot: 7,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,
                downloadsize: 120,
                apptype: "app",
                appbuild: "Google LLC",
            },
            "snapchat": {
                app: "snapchat",
                color: "transparent",
                icon: false,
                photo: "snapchat.png",
                label: "Snapchat",
                job: false,
                blockedjobs: {},
                slot: 16,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,
                downloadsize: 108,
                apptype: "app",
                appbuild: "Snap Inc.",
            },
            "news": {
                app: "news",
                color: "transparent",
                icon: false,
                photo: "news.png",
                label: "News",
                job: false,
                blockedjobs: {},
                slot: 9,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,        
                downloadsize: 32,
                apptype: "app",
                appbuild: "Weazel News Inc.",
            },
            "spotify": {
                app: "spotify",
                color: "transparent",
                icon: false,
                photo: "spotify.png",
                label: "Spotify",
                job: false,
                blockedjobs: {},
                slot: 10,
                page: 2,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.9,        
                downloadsize: 15,
                apptype: "app",
                appbuild: "Spotify Inc.",
            },
        
        
        
        
        
        
            "doodlejump": {
                app: "doodlejump",
                color: "transparent",
                icon: false,
                photo: "doodlejump.png",
                label: "Doodle Jump",
                job: false,
                blockedjobs: {},
                slot: 13,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.4,
                downloadsize: 62,
                apptype: "games",
                appbuild: "Lima Sky LLC",
            },
            "pacman": {
                app: "pacman",
                color: "transparent",
                icon: false,
                photo: "pacman.png",
                label: "Pacman",
                job: false,
                blockedjobs: {},
                slot: 14,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.2,
                downloadsize: 48,
                apptype: "games",
                appbuild: "BANDAI Ent Inc.",
            },
            "flappybird": {
                app: "flappybird",
                color: "transparent",
                icon: false,
                photo: "flappybird.png",
                label: "Flappy Bird",
                job: false,
                blockedjobs: {},
                slot: 25,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 3.2,        
                downloadsize: 18,
                apptype: "games",
                appbuild: "GEARS Studios",
            },
            "kong": {
                app: "kong",
                color: "transparent",
                icon: false,
                photo: "kong.png",
                label: "Kong",
                job: false,
                blockedjobs: {},
                slot: 26,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 3.0,        
                downloadsize: 12,
                apptype: "games",
                appbuild: "Nintendo",
            },
            "tower": {
                app: "tower",
                color: "transparent",
                icon: false,
                photo: "tower.png",
                label: "Tower",
                job: false,
                blockedjobs: {},
                slot: 27,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 2,        
                downloadsize: 23,
                apptype: "games",
                appbuild: "LOS",
            },
            "labyrinth": {
                app: "labyrinth",
                color: "transparent",
                icon: false,
                photo: "labyrinth.png",
                label: "Labyrinth",
                job: false,
                blockedjobs: {},
                slot: 28,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 1.0,        
                downloadsize: 25,
                apptype: "games",
                appbuild: "LOS",
            },

            "whatsapp": {
                app: "whatsapp",
                color: "transparent",
                icon: false,
                photo: "whatsapp.png",
                label: "Whatsapp",
                job: false,
                blockedjobs: {},
                slot: 10,
                page: 1,
                notify: 0,
                currentPage: null,
                pageDetails: {},
        
                rating: 4.3,        
                downloadsize: 72,
                apptype: "app",
                appbuild: "Whatsapp LLC",
            },
        }
    }

    DebugPhoneData = Phone

    SetupPhone(Phone)
    

    setTimeout(function() {
        OpenApp("settings", true)
        // LeftSlideDown($(`.page-message`), 250, 0)

        // $(".call-outgoing").show()
        // $(".phone-call-ongoing").css("display", "none")
        // $(".phone-currentcall-container").css("display", "none")
        // $(".phone-call-videocall").css("display", "block")
        // setTimeout(function() {
        //     OpenInstagramPage("discover")

        //     for (i=0; i<5000; i++) {
        //         $(`.discover-page-list`).append(`<div class="img-p-item">
        //             <img src="https://media.discordapp.net/attachments/1008065067977281567/1101109966309437480/screenshot.jpg?width=1510&height=849" data-igpostid="abcd-${i}" class="ig-post-table"> 
        //             <div class="img-bottom-ig" style="display: none;">
        //                 <div class="button-list">
        //                     <i class="fa-solid fa-heart like-post"></i>
        //                     <i class="fa-solid fa-comments comment-post"></i>
        //                 </div>
        //                 <div class="post-like">0 likes</div>
        //             </div>
        //         </div>`)
        //     }
        // }, 300)

        // SetupLockScreen()
        // AddToDynamicIsland(`<div class="music-dynamic">
        //     <img class="current-song-img" src="img/default.png">
        //     <div class="dynamic-sat">Bir derdim var</div>
        //     <img class="current-song-gif" src="https://media0.giphy.com/media/XaejLonqk19jDugJbq/giphy.gif?cid=ecf05e47nsu96nutauk72wb9qzr283ycs85wfix1zyt0kvvi&rid=giphy.gif&ct=s">
        // </div>`)
        // AddToDynamicIsland(`<i class="fas fa-lock" 
        //     onclick="seggs(this)" 
        //     style="color: white; margin-left: 1vh; padding-right: 16vh; height: 100%; display: flex; align-items: center;">
        // </i>`);
        //RestartApps()
        // AddNotification("messages", '<span class="app-notify-desc"><b>'+ "User User 2"  + '</b><br>Hallo</span>', true, 'OpenApp("messages")', 1250, true)
    }, 500)

    $(`body`).append(`
    <button onclick="RestartApps()">Start Song</button>
    <button onclick="ReCharge()">Re Charge</button>
    <button onclick="Cspeed()">Check Connection</button>
    <button onclick="BatteryDel()">Set Battery 0</button>
    <button onclick="ClosePhone2()">Close Phone</button>
    <button onclick="SendMessageFromDebug()">Send Message</button>
    <button onclick="SendMessageTelegram()">Start Capture</button>
    <button onclick="CaptureImageDBG()">Open Phone</button>
    <button onclick="DarkChange()">Change Dark</button>
    <button onclick="SaveLocs()">Save Locations</button>`)
}

//let isClicked = false;
//let recorder;
async function SendMessageTelegram() {
    if (!isClicked) {
        isClicked = true;
        recorder = await recordAudio();
        recorder.start();
            //const audio = await recorder.stop();
            //audio.play();
    } else {
        console.log(recorder)
        isClicked = false;
        const audio = await recorder.stop();
        console.log(audio)
        audio.play(); 
    }

    //AddNotification("messages", '<span class="app-notify-desc"><b>'+ "User User 2"  + '</b><br>Hallo</span>', true, 'OpenApp("messages")', 1250, true)
}

function SaveLocs() {
    console.log(JSON.stringify(locs))
}

function CaptureImageDBG() {
    SetupPhone(DebugPhoneData)
    OpenPhone()
}

function SendMessageFromDebug() {
    var time = Math.floor(new Date().getTime()/1000.0)
    PhoneData.contacts[7267018559].messages[time] = { time: time, sender: "7267018559", message: "selam" }

    AddMessage(PhoneData.contacts[7267018559].messages[time], true)
}

function RestartApps() {
    StartPlayingSong("https://www.youtube.com/watch?v=sADmwWhU5ZM&ab_channel=%EF%BC%B4%EF%BC%B2%EF%BC%A1%EF%BC%B3%EF%BC%A8%E6%96%B0%E3%83%89%E3%83%A9%E3%82%B4%E3%83%B3")
}


function Cspeed() {
    console.log(ConnectionData)
}

function ReCharge() {
    StartRecharge() 
}

function BatteryDel() {
    PhoneData.Battery = 21
}

function ClosePhone2() {
    TopSlideDown('#phone-case', 150, 200);
    PhoneData.IsOpen = false;
}

function DeepCompare() {
    SavePhone()
}

function CleanSCRequests() {
    //PhoneData.MetaData.sendedRequests = []

    $.get('https://docs.fivem.net/docs/game-references/blips/', function(data) {
        var blipClassNames = $(data).find('.blip').map(function() {
            return this.className;
        }).get();
        
        console.log(blipClassNames);
    });
}

function DarkChange() {
    PhoneData.MetaData.DarkMode = !PhoneData.MetaData.DarkMode

    DarkMode(PhoneData.MetaData.DarkMode)
}


setTimeout(function() {
    // $(`body`).append(`
    // <button onclick="RestartApps()">Restart APPS</button>
    // <button onclick="ReCharge()">Re Charge</button>
    // <button onclick="Cspeed()">Check Connection</button>
    // <button onclick="BatteryDel()">Set Battery 0</button>
    // <button onclick="ClosePhone2()">Close Phone</button>
    // <button onclick="SendMessageFromDebug()">Send Message</button>
    // <button onclick="SendMessageTelegram()">Send Message DARKCHAT1</button>
    // <button onclick="CaptureImageDBG()">Add Image</button>
    // <button onclick="DeepCompare()">DeepCompare</button>
    // <button onclick="CleanSCRequests()">Clean Snapchat Requests</button>
    // <button onclick="DarkChange()">Change Dark</button>`)
    
    // var person = PhoneData.contacts[31] || { profileimage: "img/default.png", firtname: 31, lastname: ""}
    // AddToDynamicIsland(`<div class="airpod-dynamic"">,
    //     <img class="airpod-img" src="img/app_details/airpods.png">
    //     <div class="dynamic-amount">75%<img src="img/app_details/ic_battery_${Math.round(92/10)}.png"></div>
    // </div>`, true)

    // OpenPopup(`<div class="popup-generic">
    //                 <div class="popup-gen-title">Airdrop</div>
    //                 <div class="popup-gen-desc">${"Test"} would like to share a photo</div>
    //                 <img class="popup-image-gen" src="${"https://cdn.discordapp.com/attachments/702195467961761865/1010121742309675098/20220819_124308.jpg"}">
    //                 <div class="popup-gen-button" onclick="ActionToDo('dec')">Decline</div>
    //                 <div class="popup-gen-button" onclick="ActionToDo('acc')">Accept</div>
    //                 </div>
    //                 `)
}, 500)

//DebugSetUp()