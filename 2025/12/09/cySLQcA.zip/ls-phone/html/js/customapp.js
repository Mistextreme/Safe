CustomApp = function(Application) {
    if (Application == "custom") {
        console.log("Hello world")
    }
}