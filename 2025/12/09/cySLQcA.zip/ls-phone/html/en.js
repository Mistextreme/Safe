Locales["en-US"] = {
    "months": {
        "January": "January",
        "February": "February",
        "March": "March",
        "April": "April",
        "May": "May",
        "June": "June",
        "July": "July",
        "August": "August",
        "September": "September",
        "October": "October",
        "November": "November",
        "December": "December"
    },

    "days": {
        "Sunday": "Sunday",
        "Monday": "Monday",
        "Tuesday": "Tuesday",
        "Wednesday": "Wednesday",
        "Thursday": "Thursday",
        "Friday": "Friday",
        "Saturday": "Saturday"
    },

    "months_short": {
        "January": "Jan",
        "February": "Feb",
        "March": "Mar",
        "April": "Apr",
        "May": "May",
        "June": "Jun",
        "July": "Jul",
        "August": "Aug",
        "September": "Sep",
        "October": "Oct",
        "November": "Nov",
        "December": "Dec"
    },

    "weather": {
        "CLEAR": "Clear",
        "CLOUDS": "Clouds",
        "RAIN": "Rain",
        "SNOWLIGHT": "Snowlight",
        "THUNDER": "Thunder",
        "BLIZARD": "Blizzard",
        "SMOG": "Smog",
        "FOGGY": "Foggy",
        "EXTRASUNNY": "Extrasunny",
        "OVERCAST": "Overcast",
        "CLEARING": "Clearing",
        "XMAS": "Christmas",
        "UNKNOWN": "Unknown",
    },

    "days_short": {
        "Sunday": "Sun",
        "Monday": "Mon",
        "Tuesday": "Tue",
        "Wednesday": "Wed",
        "Thursday": "Thu",
        "Friday": "Fri",
        "Saturday": "Sat"
    },

    "time": {
        "TODAY": "Today",
        "YESTERDAY": "Yesterday",
    },

    "labels": {
        // SETTINGS \\
        "WALLPAPER_WIDGET": "Wallpapers",
        "WIDGETS_WID": "Widgets",
        "SETTINGS_WID": "Settings",
        "WIDGETS_CLOCK": "Clock",
        "WIDGETS_WEATHER": "Weather",
        "AIRPLANE_MODE": "Airplane Mode",
        "CELLULAR": "Cellular",
        "WIFI": "Wi-Fi",
        "DARK_MODE": "Dark Mode",
        "NOTIFICATIONS": "Notifications",
        "RINGTONE": "Ringtone",
        "PASSWORD": "Password",
        "SHARE_NUMBER": "Share number",
        "WALLPAPERS": "Wallpapers",
        "BLUETOOTH": "Bluetooth",
        "LOCATION": "Location",
        "LOCKSCREEN": "Lockscreen",
        "FACEID": "Face ID",
        "MOVE": "Move",
        "ZOOM": "Zoom",
        "MOVE_PHONE": "Move Phone Location",
        "RESET_PHONE": "Reset Phone Location",
        "DESC_SETTINGS": "Phone Number, Picture, Data & More",
        "PASSWORD_DESC": "Never forget your password, if you forget none can help you!",
        "PASSWORD_ENTER": "Enter Password",
        "PASSWORD_RESET": "Reset Password",
        "MY_NETWORKS": "My Networks",
        "OTHER_NETWORKS": "Other Networks",
        "ABOUT_PHONE": "About Phone",
        "STNG": "Settings",
        "USER_INFORMATION": "User Information",
        "USER_OWNER": "User Owner",
        "USER_NUMBER": "User Number",
        "USER_AVATAR": "User Avatar",
        "PHONE_INFORMATION": "Phone Information",
        "PHONE_VERSION": "Phone Version",
        "PHONE_SERIAL": "Phone Serial",
        "PHONE_WIFI": "Phone Wi-Fi",
        "PHONE_CONNECTION_SPEED": "Connection Speed",

        "INFORMATION": "Information",
        "ENTER_WIFI_PASSCODE": "Enter a wi-fi password for",
        "NOT_CONNECTED": "Not Connected",

        "PASSCODE": "Passcode",
        "PASSCODE_ENTER": "Enter a PIN code for lock your phone",

        "AVATAR": "Avatar",
        "AVATAR_ENTER": "Enter an photo link for your avatar picture",

        "DELETE": "Delete",
        "DELETE_ENTER": "You will delete the selected photo, are you sure to do this?",

        "NO": "No",
        "YES": "Yes",
        "OFF": "Off",
        "ON": "On",

        "AIRPODS_PLUGGED": "AirPods plugged in",
        "AIRPODS_UNPLUGGED": "AirPods plugged out.",

        // GALLERY \\
        "CANCEL": "Cancel",
        "PHOTOS": "Photos",
        "DETAILS": "Details",
        "LIBRARY": "Library",
        "ALBUMS": "Albums",
        "SHARE_IMAGE": "Share image",
        "IMAGE_SELECTED": "image selected",

        // APP STORE \\
        "APPS": "Apps",
        "GAMES": "Games",
        "CLEAR": "Clear",
        "SEARCH": "Search",

        // MESSAGES \\
        "MESSAGES": "Messages",
        "LOCATION_SENT": "Location sent",
        "CASH_TAKEN": "Cash taken",

        // CONTACT \\
        "CONTACTS": "Contacts",
        "HISTORY": "History",
        "RECENT": "Recent",
        "KEYPAD": "Keypad",
        "SUGGESTED": "Suggested",

        "NEW_CONTACT": "New Contact",
        "DONE": "Done",
        "ADD_PHOTO": "Add Photo",
        "EDIT_CONTACT": "Edit Contact",

        // NOTES \\
        "NOTES": "Notes",
        "EDIT_NOTE": "Edit Note",
        "NO_DESC_NOTE": "No description for this title.",

        // MAILS \\
        "MAILS": "Mails",
        "SEND_MAIL": "Send Mail",
        "READ_MAIL": "Read Mail",
        "UNREAD_MAILS": "Unread Mails",

        "UPDATED_JUST_NOW": "Updated just now",

        // CALLS \\
        "DIALING": "Dialing",
        "INCOMING_CALL": "Incoming Call",

        // CLOCK \\
        "DAILY": "Daily",
        "WEEKDAYS": "Weekdays",
        "ONE_TIME": "One Time Only",
        "DELETE_ALARM": "Delete Alarm",
        "STOP": "Stop",
        "RESTART": "Restart",
        "START": "Start",
        "PAUSE": "Pause",
        "ALARM": "Alarm",
        "STOPWATCH": "Stopwatch",
        "TIMER": "Timer",
        "LAP": "Lap",

        // INSTAGRAM \\
        "INSTAGRAM": "Instagram",
        "LOGIN": "Login",
        "LOGIN_DESC": "If you have an account, login to continue.",
        "CREATE_ACCOUNT": "Create Account",
        "CREATE_ACCOUNT_DESC": "No account? Create an account to continue.",
        "CREATE": "Create",
        "STORY": "Story",
        "POST": "Post",

        "POSTS": "Posts",
        "FOLLOWERS": "Followers",
        "FOLLOWING": "Following",

        "UNFOLLOW": "Unfollow",
        "FOLLOW": "Follow",
        "SEND_MESSAGE": "Send Message",
        "EDIT_PROFILE": "Edit Profile",

        "CHANGE_PROFILE_PICTURE": "Change Picture",

        "LOGOUT": "Logout",
        "LIKES": "likes",
        "YOUR_STORY": "Your Story",
        "DISCOVER": "Discover",

        // TWITTER \\
        "TRENDS": "Trends",
        "NOTHING_FOUND": "Nothing found",
        "NOTHING_FOUND_DESC": "This place seems like empty, anyway you can search people from here.",
        "ADD_ATTACHMENT": "Add Attachment",

        // SNAPCHAT \\
        "MAP": "Map",
        "PROFILE": "Profile",
        "CHATS": "Chats",
        "REMOVE_FRIEND": "Remove Friend",
        "SEARCH_FRIENDS": "Search Friends",

        "PENDING_REQUESTS": "Pending Requests",
        "PEOPLE_INTERESTED": "People Interested",
        "SEND_SNAP": "Send Snap",

        "ME": "Me",
        "SNAP": "Snap",
        "DELIVERED": "Delivered",
        "NEW_SNAP": "New Snap",
        "NEW_MESSAGE": "New Message",
        "OPENED": "Opened",

        // WALLET \\
        "WALLET": "Wallet",
        "ENTER_AMOUNT": "Enter an amount to send money",
        "CLICK": "Click",
        "ACCOUNT_DETAILS": "Account Details",
        "CARD_BALANCE": "Card Balance",
        "SEND": "Send",
        "BALANCE": "Balance",
        "CASH": "Cash",
        "TRANSACTIONS": "Transactions",
        "INVOICES": "Invoices",

        "BILLING": "Billing",

        "ENTER_PERSON_TO_SEND": "Enter the person to send money",


        "INCOME": "Income",
        "EXPENSES": "Expenses",

        // CAMERA \\
        "PHOTO": "Photo",
        "VIDEO": "Video",

        // CRYPTO \\
        "CRYPTO": "Crypto",
        "WORTH": "Worth",
        "VOLUME": "Volume",
        "WALLET_ID": "Wallet ID",
        "BUY": "Buy",
        "SELL": "Sell",
        "TRANSFER": "Transfer",
        "BUY_CRYPTO": "Buy Crypto",
        "SELL_CRYPTO": "Sell Crypto",
        "TRANSFER_CRYPTO": "Transfer Crypto",
        "BUYING_WORTH": "Buying Worth",
        "SELLING_WORTH": "Selling Worth",
        "CURRENT_WORTH": "Current Worth",
        "TRANFERING_WORTH": "Transfering Worth",

        "ENTER_WALLET_ID": "Enter transfering Wallet ID",

        "BOUGHT": "Bought",
        "BOUGHT_DESC": "Bought {0} coins, total worth is ${1}",

        "SELL": "Sold",
        "SELL_DESC": "Sold {0} coins, total worth is ${1}",

        "TRANSFERED": "Transferred",
        "TRANSFER_DESC": "Transferred {0} coins to {1}. Total coin worth is ${2}",

        // WHATSAPP \\
        "NEW_GROUP": "New Group",
        "CONTACT_INFO_TEXT": "tap here for contact info",
        "GROUP_INFO_TEXT": "tap here for group info",
        "CREATE_NEW_GROUP": "Create New Group",
        "BIOGRAPHY": "Biography",
        "ADMIN": "Admin",
        "YOURSELF": "Yourself",
        "BIOGRAPHY_CUSTOMIZE": "Customize your biography!",
        "KICKED": "has been kicked from group.",
        "ADDED": "has been added to group.",

        "SHARE_WITH_FRIENDS": "Share with friends",
        "CONTACT_INFO": "CONTACT INFO",
        "IMAGE_VIDEO": "Image, Video",
        "MUTE": "Mute",
        "GROUP": "Group",

        // DARKCHAT \\
        "CHANGE_USERNAME": "Change Username",
        "ENTER_USERNAME": "Enter an username",
        "SET": "Set",

        "LOGOUT_DC": "Logout DarkChat",
        "LOGOUT_DC_DESC": "If you Logout you cannot login again.",

        "JOIN_DARKCHAT": "Join Darkchat",
        "JOIN_DARKCHAT_DESC": "Join an Chat channel or Create new Chat channel.",
        "JOIN": "Join",
        
        // YELLOW PAGES \\
        "YELLOW_PAGES": "Yellow Pages",
        "CREATE_ADVERT": "Create Advert",
        "READ_MORE": "Read More.",

        // NEWS \\
        "NEWS": "News",

        // SERVICES \\
        "SERVICES": "Services",
        "SEND": "Send",

        "TERMS": "You're accepting terms to, send your phone number/adress to send ordering service!",

        // GARAGE \\
        "GARAGE": "Garage",
        "NAME": "Name",
        "MODEL": "Model",
        "PLATE": "Plate",
        "STATUS": "Status",
        "INGARAGE": "In Garage",
        "OUTSIDE": "Outside",

        // UBER \\
        "UBER": "Uber",
        "SEARCH_UBER": "Search Uber driver to takeoff",
        "UBER_DRIVER": "Be an Uber driver",
        "OLD_LOCATIONS": "Old Locations",
        "SELECT_DROP_LOCATION": "Select drop location",
        "ACCEPT_LOCATION": "Accept location",
        "DRIVER_LOCATION": "Driver Location",
        "ACCEPT_REQUEST": "Accept request",
        "UBER_REQUESTS": "Uber Requests",
        "WAITING": "Waiting",
        "METERS": "Meters",

        "UBER_PRICING": "uber to location pricing, {0} and distance {1} Meters.",
        "UBER_TERMS": "Your money will be taken your bank account after Accepting, if you cancel before someone take order your money refunded<",
        "THANKS_FOR_CHOSING": "Thanks for choosing Uber",

        // UBER EATS \\
        "UBER_EATS": "Uber Eats",
        "SEARCH": "Search",

        // MUSIC \\
        "MUSIC": "Music",

        // YOUTUBE \\
        "YOUTUBE": "Youtube",

        // SPOTIFY \\
        "FAVORITES": "Favorites",
        "SPOTIFY": "Spotify",
        "EMPTY_SP": "Oh... Seems like you doesnt have any favorite song. You can add some songs to fill this list.",
        "RECENTLY_PLAYED": "Recently Played",
        "EDITOR_PICKS": "Editor Picks",
        "HOME": "Home",

        "COMMENTS": "Comments",


        // FIRST SETUP \\
        "HELLO": "Hello",
        "CHOOSE_A": "Choose a",
        "WIFI_NETWORK": "Wi-Fi Network",
        "USE_CELLULAR_NETWORK": "Use Cellular Network",

        "CREATE_PASSCODE": "Create a Passcode",
        "CREATE_PASSCODE_DESC": "A passcode protects your data.",

        "LOCATION_SERVICES": "Location Services",
        "LOCATION_SERVICES_DESC": "Location Services allows Maps and other apps and services like Snapchat.",
        "ENABLE": "Enable",
        "DISABLE": "Disable",

        "BLUETOOTH_SERVICES": "Bluetooth Services",
        "BLUETOOTH_SERVICES_DESC": "Bluetooth Services allows share numbers with each other.",

        "WHOS_USING": "Who's using",
        "WHOS_USING_DESC": "Enter your firstname and lastname for everyone sees who are you.",
        
        "DECLINCE": "Decline",
        "ACCEPT": "Accept",
        "SELECT_IMAGE": "Select Image",
        "SELECT_APP": "Select App",

        "AIRDROP_TEXT": "would like to share a photo",

        "YOU": "You",
        "OPEN": "Open",
        "GET": "Get",

        "BANK": "Bank",

        "REMOVE_APP": "Remove App",
        "SWIPE_UP": "Swipe up to Unlock",

        "NOT_PLAYING": "Not Playing",
        "FOCUS": "Focus",

        "SOUND": "Sound",
        "IMAGE": "Image",
        "ATTACHMENT": "Attachment",
    },
    "placeholders": {
        
        "SEARCH": "Search",
        "ADD_WALLPAPER": "Add Wallpaper",
        "ENTER_MESSAGE": "Enter Message",
        
        "FIRST_NAME": "Firstname",
        "LAST_NAME": "Lastname",
        "PHONE_NUMBER": "Phone Number",
        "BIO": "Bio",
    
        "TITLE": "Title",
        "START_TYPING": "Start typing",
        "FROM": "From",
        "TO": "To",

        "PASSWORD": "Password",
        "NICKNAME": "Nickname",
        "USERNAME": "Username",



        "MESSAGE": "Message",
        "SEARCH_FOR_USER": "Search for user",
        "SEND_SERVICE_MESSAGE": "Send message to service",
        "SEND_SERVICE_IMAGE": "Send an image to service",

        "SEARCH_MUSIC": "Search music",
        "SEND_COMMENT": "Send comment",
        "SEARCH_VIDEO": "Search Video",

        "ADVERT_TITLE": "Advert Title",
        "DESCRIPTION": "Description",
        "PRICE": "$ Price",

        "NEW_TITLE": "New Title",
        "CREATE_NEW": "Create New",
    },

    "notifications": {
        "FACE_ID_CHANGED": "Face ID has been changed.",
        "FACE_ID_SAME": "Face ID same person, doesnt changed.",
        "FACE_ID_SET": "Face ID adjusted.",

        "LOW_BATTERY_20": "Low battery, battery lower than %20.",
        "LOW_BATTERY_10": "Very low battery, battery very lower than %10.",
        "CHARGING": "Charging",
        "CANNOT_KICK": "You cannot kick yourself",
        "EMPTY_MESSAGE": "You cannot send an empty message",
        "EMPTY_NAME": "You cannot enter an empty name",
        "AIRPLANE_ENABLED": "Airplane mode enabled",
        "WIFI_CANT_ENABLED": "Wi-Fi can't be enabled",
        "CELLULAR_CANT_ENABLED": "Cellular can't be enabled",
        "PAID_BILLING": "You successfully paid your invoice",
        "NOT_ENOUGH_MONEY_BILLING": "You don't have enough money to pay your invoice",
        "SENT_MONEY": "You're send {0}$ amount money to {1} successfully.",
        "SENT_HIMSELF": "You cannot send money to yourself.",
        "NOT_ONLINE": "{0} is not online.",
        "CANNOT_CALLED": "{0} cannot be called.",
        "MONEY_COME": "The money has arrived. Amount: $",


        "BOUGHT_CRYPTO": "You succesfully bought, {0} coins ${1} taken from bank account.",
        "NOT_ENOUGH_MONEY_CRYPTO": "Not enough money to buy {0} coins.",

        "SOLD_COINS": "You succesfully sold {0} coins. ${1} added to your bank account.",
        "NOT_ENOUGH_COINS": "You doesnt own {0} coins.",
        "NOT_ENOUGH_COINS_TO_SELL": "You dont have enough coins to sell.",
        "NOT_VALID_ACCOUNT": "This account not valid.",
        "NOT_ENOUGH_COINS_TO_TRANSFER": "You dont have enough coins to transfer.",
        "SENT_HIMSELF_CRYPTO": "You cannot send crypto to yourself.",

        "TRANSFERED_CRYPTO": "You succesfully transferred {0} coins to ${1}.",
    
        "LOCATION_MARKED": "Location has been marked on your map.",

        "UBER_REQ_DELETED": "Your uber request has been deleted.",
        "UBER_ARRIVED": "Your uber has been arrived your destination.",

        "NO_INTERNET": "No internet connection established, cannot use this app.",
        "DENY_CALL": "Call Denied",
        "VALET_COST": "Taken $10 from account",
        "NUMBER_COPY": "The number has been copied to the telephone keypad.",
        "SHARENUMBER_CORRECT": "Phone numbers were shared with nearby players.",
        "SHARENUMBER_NOPLAYER": "There aren't any players nearby.",
        "SHARENUMBER_OTHER": "Someone shared a phone number with you."

        



    },
}