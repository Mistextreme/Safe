Framework = Config.Server.GetFramework()

RegisterNetEvent('qb-phone:server:AddTransaction', function(data)
    local src = source
    local Player = Config.Server.GetPlayer(src, true)
    MySQL.insert('INSERT INTO crypto_transactions (citizenid, title, message) VALUES (?, ?, ?)', {
        Player.DATA.identifier,
        data.TransactionTitle,
        data.TransactionMessage
    })
end)


LS_CORE.Callback.Functions.CreateCallback("ls-phone:s:getAllBilling", function(source, cb)
    local invoices = LS_CORE.Config.DATABASE(LS_CORE.Config.DATABASE_NAME, 'fetchAll', 'SELECT * FROM billing WHERE identifier = ?', {Config.Server.GetPlayerIdentifier(source)})
    if invoices[1] ~= nil then
        local invoiceData = {}
        for k,v in pairs(invoices) do
            invoiceData[k] = {
                id = v.id,
                citizenid = v.citizenid,
                amount = v.amount,
                sender = v.sender,
                society = v.target_type,
            }
        end
        cb(invoiceData)
    end
end)

CreateThread(function()
    Framework.RegisterUsableItem("phone", function(source, item, item2)
        if Config.Server.UseMetadata then
            item2.info = item2.metadata
            
            UsePhoneItem(source, item2)
        else
            UsePhoneItem2(source, item)

        end
    end)
    Framework.RegisterUsableItem("airpods", function(source, item, item2)
        if Config.Server.UseMetadata then
            item2.info = item2.metadata
            
            UseAirPodsItem(source, item2)
        else
            UseAirPodsItem(source, item)

        end
        
    end)
    Framework.RegisterUsableItem("powerbank", function(source, item, item2)

        if Config.Server.UseMetadata then
            item2.info = item2.metadata
            
            UseBatteryItem(source, item2)
        else
            UseBatteryItem(source, item)

        end
        
    end)
end)

RegisterNetEvent("ls-phone:s:tryOpenPhone", function()
    local src = source
    local Player = Config.Server.GetPlayer(src, true)
    if Player == nil then return end

    local item2 = Player.Functions.GetItem("phone")

    


    if Config.Server.UseMetadata then
       item2.info = item2.metadata or item2.meta or item2.info
    end

   

    if item2.count > 0 then
        UsePhoneItem2(src, item2)
    end
end)

LS_CORE.Callback.Functions.CreateCallback("ls-phone:s:getCars", function(source, cb)
    local Player = Config.Server.GetPlayer(source)
    if not Player then return end
    local result = LS_CORE.Config.DATABASE(LS_CORE.Config.DATABASE_NAME, 'fetchAll', 'SELECT * FROM owned_vehicles WHERE owner = ?', { Config.Server.GetPlayerIdentifier(source) })

    local results = {} 
    for key, value in ipairs(result) do
        table.insert(results, {["garage"] = value["parking"], ["plate"] = value["plate"], ["model"] = json.decode(value["vehicle"])})
    end
    cb(results)
end)

RegisterNetEvent("ls-phone:s:deletePed", function()
    local src = source
    Config.Server.GetPlayer(src, true).Functions.RemoveMoney("bank", Config.ValetCost, "Money taken from bank")

    TriggerClientEvent("ls-phone:c:sendNotification", src, {
        app = "garage",
        message = "VALET_COST",
    })
end)

RegisterNetEvent("ls-phone:s:changeVehicleDatabaseStatus", function(plate)
    LS_CORE.Config.DATABASE( LS_CORE.Config.DATABASE_NAME, 'execute', 'UPDATE `owned_vehicles` SET `stored` = @stored, `parking` = @parking WHERE `plate` = @plate', {
        ["@plate"] = plate,
        ["@stored"] = nil,
        ["@parking"] = nil
    })
end)

LS_CORE.Callback.Functions.CreateCallback("ls-phone:s:getVehicleFromPlate", function(source, cb, plate)
    cb(LS_CORE.Config.DATABASE(LS_CORE.Config.DATABASE_NAME, 'fetchAll', 'SELECT * FROM owned_vehicles WHERE plate = ?', { plate })[1])
end)

-- Framework.RegisterCommand('verifyprofile', 'admin', function(xPlayer, args, showError)
--     if args.platform == "ig" then
--         LS_CORE.Config.DATABASE( LS_CORE.Config.DATABASE_NAME, 'execute', 'UPDATE `instagram_users` SET `verified` = @verify WHERE `username` = @username', {
--             ["@username"] = args.username,
--             ["@verify"] = args.verify,
--         })
--     elseif args.platform == "tw" then
--         LS_CORE.Config.DATABASE( LS_CORE.Config.DATABASE_NAME, 'execute', 'UPDATE `twitter_users` SET `verified` = @verify WHERE `username` = @username', {
--             ["@username"] = args.username,
--             ["@verify"] = args.verify,
--         })
--     end
-- end, true, {help = "Verify Profile", validate = true, arguments = {
--     {name = 'username', help = "Profile Username", type = 'string'},
--     {name = 'platform', help = "Platform (ig, tw)", type = 'string'},
--     {name = 'verify', help = "Verify (0 = false, 1 = true)", type = 'number'}
-- }})


-- #region  EXPORTS
UsePhoneItem2 = function(source, item)
    if Config.Server.UseMetadata then
        if item.info == nil or item.info.MetaData == nil then
            item.info = CreatePhoneLayout()
            Config.Server.SavePhoneData(source, item.info, nil)
        end
        if Config.Server.SavePhoneData(source, item.info, item.info.MetaData.serialnumber) then
            AllPhones[source] = item.info
            TriggerClientEvent("ls-phone:c:openPhone", source, item, Config.Server.Webhook)
        else
            print("Failed to save phone data. ^8Error Code 1^7")
        end
    else
        local metadata = GetUserDataSQL(source)
        local item = {}
        if metadata == nil then
            item.info = CreatePhoneLayout()
            Config.Server.SavePhoneData(source, item.info, nil)
        else
            item.info = json.decode(metadata.data)
        end

        if Config.Server.SavePhoneData(source, item.info, item.info.MetaData.serialnumber) then
            AllPhones[source] = item.info
            TriggerClientEvent("ls-phone:c:openPhone", source, item, Config.Server.Webhook)
        else
            print("Failed to save phone data. ^8Error Code 1^7")
        end
    end
end

AddEventHandler('playerDropped', function (reason)
    AllPhones[source] = nil
end)

UseAirPodsItem = function(source, item)
    if AllPhones[source] == nil then return print(Config.Server.GetPlayer(source, true).DATA.identifier .. ", tried to use airpods without any phone.") end
    TriggerClientEvent("ls-phone:c:airpodsUsed", source)
end
UseBatteryItem = function(source, item)
    local Player = Config.Server.GetPlayer(source, true)
    if Player == nil then return print(source, ", cannot found. ^8Error Code 1^7") end
    if AllPhones[source] == nil then return print(Config.Server.GetPlayer(source, true).DATA.identifier .. ", tried to use powerbank without any phone.") end
    Player.Functions.RemoveItem(item.name, 1, item.slot)
    TriggerClientEvent("ls-phone:c:powerbankUse", source)
end

GetUserDataSQL = function(source)
    local result = LS_CORE.Config.DATABASE(LS_CORE.Config.DATABASE_NAME, 'fetchAll', 'SELECT * FROM phone_metadata WHERE identifier = ?', { Config.Server.GetPlayer(source, true).DATA.identifier })[1]
    return result
end

exports("ReCharge", function(source)
    local Player = Config.Server.GetPlayer(source)
    if Player == nil then return print(source, ", cannot found. ^8Error Code 1^7") end
    if AllPhones[source] == nil then return print(Config.Server.GetPlayer(source, true).DATA.identifier .. ", tried to use powerbank without any phone.") end
    TriggerClientEvent("ls-phone:c:powerbankUse", source)
end)
exports("AirPods", function(source)
    if AllPhones[source] == nil then return print(Config.Server.GetPlayer(source, true).DATA.identifier .. ", tried to use airpods without any phone.") end
    TriggerClientEvent("ls-phone:c:airpodsUsed", source)
end)
-- #endregion