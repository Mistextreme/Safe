local L0_1, L1_1, L2_1, L3_1
LS_CORE = nil
L0_1 = {}
AllPhones = L0_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = Config
  L0_2 = L0_2.Server
  L0_2 = L0_2.Framework
  Framework = L0_2
  L0_2 = {}
  function L1_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = Config
    L1_3 = L1_3.Server
    L1_3 = L1_3.GetPlayer
    L2_3 = A0_3
    L3_3 = true
    L1_3 = L1_3(L2_3, L3_3)
    if nil == L1_3 then
      L2_3 = print
      L3_3 = source
      L4_3 = ", user cannot found."
      L2_3(L3_3, L4_3)
    end
    L2_3 = L1_3.Functions
    L2_3 = L2_3.AddItem
    L3_3 = "phone"
    L4_3 = 1
    L5_3 = nil
    L6_3 = CreatePhoneLayout
    L6_3 = L6_3()
    L2_3(L3_3, L4_3, L5_3, L6_3)
  end
  givePhoneToPlayer = L1_2
  L1_2 = exports
  L2_2 = "GivePhoneToPlayer"
  L3_2 = givePhoneToPlayer
  L1_2(L2_2, L3_2)
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = {}
    L1_3 = {}
    L2_3 = math
    L2_3 = L2_3.random
    L3_3 = 11111111
    L4_3 = 99999999
    L2_3 = L2_3(L3_3, L4_3)
    L1_3.phonenumber = L2_3
    L1_3.owner = "Unknown"
    L2_3 = tostring
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.RandomInt
    L4_3 = 3
    L3_3 = L3_3(L4_3)
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.RandomStr
    L5_3 = 3
    L4_3 = L4_3(L5_3)
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.RandomInt
    L6_3 = 3
    L5_3 = L5_3(L6_3)
    L3_3 = L3_3 .. L4_3 .. L5_3
    L2_3 = L2_3(L3_3)
    L3_3 = L2_3
    L2_3 = L2_3.upper
    L2_3 = L2_3(L3_3)
    L1_3.serialnumber = L2_3
    L1_3.profilepicture = "img/default.png"
    L1_3.background = "img/backgrounds/iphone.png"
    L2_3 = Config
    L2_3 = L2_3.Shared
    L2_3 = L2_3.DefaultWallpapers
    L1_3.wallpapers = L2_3
    L1_3.brightness = 100.0
    L1_3.volumeprogress = 100.0
    L1_3.layout = "4-6"
    L2_3 = {}
    L1_3.widgetApp = L2_3
    L2_3 = {}
    L2_3[1] = true
    L1_3.phonePages = L2_3
    L1_3.phonePage = 1
    L2_3 = {}
    L1_3.notifications = L2_3
    L2_3 = {}
    L1_3.oldConnections = L2_3
    L1_3.Password = 1234
    L1_3.instagramUser = false
    L1_3.twitterUser = false
    L1_3.snapchatUser = false
    L1_3.darkchatUser = false
    L2_3 = {}
    L1_3.snapchatFriendRequests = L2_3
    L2_3 = {}
    L2_3.x = 100
    L2_3.y = 100
    L1_3.phoneLocation = L2_3
    L1_3.phoneZoom = 100
    L1_3.bluetooth = false
    L1_3.LockScreen = false
    L2_3 = {}
    L1_3.beforeApps = L2_3
    L0_3.MetaData = L1_3
    L0_3.Notification = true
    L0_3.DarkMode = false
    L0_3.Airplane = false
    L0_3.MobileData = false
    L0_3.Wifi = false
    L0_3.WifiData = nil
    L0_3.DND = false
    L0_3.PhoneLocked = false
    L0_3.Battery = 100
    L0_3.PhoneClosed = false
    L1_3 = {}
    L0_3.gallery = L1_3
    L1_3 = {}
    L2_3 = {}
    L1_3.alarms = L2_3
    L0_3.clock = L1_3
    L1_3 = {}
    L0_3.notes = L1_3
    L1_3 = {}
    L0_3.mails = L1_3
    L1_3 = {}
    L0_3.contacts = L1_3
    L1_3 = {}
    L2_3 = {}
    L2_3.app = "settings"
    L2_3.color = "transparent"
    L2_3.photo = "settings.png"
    L2_3.label = "Settings"
    L2_3.style = "padding-right = .08vh; font-size = 2.3vh"
    L2_3.slot = 1
    L2_3.page = 0
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.settings = L2_3
    L2_3 = {}
    L2_3.app = "gallery"
    L2_3.color = "transparent"
    L2_3.photo = "gallery.png"
    L2_3.label = "Gallery"
    L2_3.slot = 4
    L2_3.page = 0
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.gallery = L2_3
    L2_3 = {}
    L2_3.app = "appstore"
    L2_3.color = "transparent"
    L2_3.photo = "appstore.png"
    L2_3.label = "App Store"
    L2_3.slot = 5
    L2_3.page = 1
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.appstore = L2_3
    L2_3 = {}
    L2_3.app = "camera"
    L2_3.color = "transparent"
    L2_3.photo = "camera.png"
    L2_3.label = "Camera"
    L2_3.slot = 6
    L2_3.page = 1
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.camera = L2_3
    L2_3 = {}
    L2_3.app = "clock"
    L2_3.color = "transparent"
    L2_3.photo = "clock.png"
    L2_3.label = "Clock"
    L2_3.slot = 7
    L2_3.page = 1
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.clock = L2_3
    L2_3 = {}
    L2_3.app = "messages"
    L2_3.color = "transparent"
    L2_3.photo = "messages.png"
    L2_3.label = "Messages"
    L2_3.slot = 2
    L2_3.page = 0
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.messages = L2_3
    L2_3 = {}
    L2_3.app = "contacts"
    L2_3.color = "transparent"
    L2_3.photo = "contacts2.png"
    L2_3.label = "Phone"
    L2_3.slot = 3
    L2_3.page = 0
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.contacts = L2_3
    L2_3 = {}
    L2_3.app = "phonecontacts"
    L2_3.color = "transparent"
    L2_3.photo = "contacts.png"
    L2_3.label = "Contacts"
    L2_3.slot = 9
    L2_3.page = 1
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L1_3.phonecontacts = L2_3
    L2_3 = {}
    L2_3.app = "calculator"
    L2_3.color = "transparent"
    L2_3.photo = "calculator.png"
    L2_3.label = "Calculator"
    L2_3.slot = 8
    L2_3.page = 1
    L2_3.currentPage = nil
    L3_3 = {}
    L2_3.pageDetails = L3_3
    L2_3.rating = 3.2
    L2_3.downloadsize = 15
    L2_3.apptype = "app"
    L2_3.appbuild = "LOS"
    L1_3.calculator = L2_3
    L0_3.applications = L1_3
    return L0_3
  end
  CreatePhoneLayout = L1_2
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getWebhook"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A1_3
    L3_3 = Config
    L3_3 = L3_3.Server
    L3_3 = L3_3.Webhook
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getInstagramUser"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_users WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllInstagramUsers"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_users "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createInstagramUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `instagram_users` (identifier, nickname, username, bioghrapy, profileimage, followers, following, password, likedposts, messages, story) VALUES (@identifier, @nickname, @username, @bioghrapy, @profileimage, @followers, @following, @password, @likedposts, @messages, @story)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.bioghrapy
    L5_3["@bioghrapy"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.followers
    L6_3 = L6_3(L7_3)
    L5_3["@followers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.following
    L6_3 = L6_3(L7_3)
    L5_3["@following"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.posts
    L6_3 = L6_3(L7_3)
    L5_3["@posts"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedposts
    L6_3 = L6_3(L7_3)
    L5_3["@likedposts"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.story
    L6_3 = L6_3(L7_3)
    L5_3["@story"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateIgUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `instagram_users` SET `nickname` = @nickname, `username` = @username, `bioghrapy` = @bioghrapy, `profileimage` = @profileimage, `followers` = @followers, `following` = @following, `password` = @password, `posts` = @posts, `likedposts` = @likedposts, `messages` = @messages, `story` = @story WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.bioghrapy
    L5_3["@bioghrapy"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.followers
    L6_3 = L6_3(L7_3)
    L5_3["@followers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.following
    L6_3 = L6_3(L7_3)
    L5_3["@following"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.posts
    L6_3 = L6_3(L7_3)
    L5_3["@posts"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedposts
    L6_3 = L6_3(L7_3)
    L5_3["@likedposts"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.story
    L6_3 = L6_3(L7_3)
    L5_3["@story"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateIgPost"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `instagram_post` SET `img` = @img, `time` = @time, `comments` = @comments, `whosent` = @whosent, `likedusers` = @likedusers WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.img
    L5_3["@img"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.comments
    L6_3 = L6_3(L7_3)
    L5_3["@comments"] = L6_3
    L6_3 = A0_3.whosent
    L5_3["@whosent"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedusers
    L6_3 = L6_3(L7_3)
    L5_3["@likedusers"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateIgPost"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getPostData"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_post WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllPostData"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_post "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getInstgaramQuery"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = tostring
    L8_3 = A2_3.query
    L7_3 = L7_3(L8_3)
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createIgPost"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `instagram_post` (identifier, img, time, comments, whosent, likedusers) VALUES (@identifier, @img, @time, @comments, @whosent, @likedusers)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.img
    L5_3["@img"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.comments
    L6_3 = L6_3(L7_3)
    L5_3["@comments"] = L6_3
    L6_3 = A0_3.whosent
    L5_3["@whosent"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedusers
    L6_3 = L6_3(L7_3)
    L5_3["@likedusers"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:deleteIGPost"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.DATABASE
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE_NAME
    L5_3 = "execute"
    L6_3 = "DELETE FROM `instagram_post` WHERE identifier = ?"
    L7_3 = {}
    L8_3 = A2_3.identifier
    L7_3[1] = L8_3
    L3_3(L4_3, L5_3, L6_3, L7_3)
    L3_3 = A1_3
    L4_3 = true
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getDMData"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_dm WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllDM"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM instagram_dm "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createNewDM"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `instagram_dm` (identifier, persons, messages) VALUES (@identifier, @persons, @messages)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateIgDM"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateIgDM"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `instagram_dm` SET `persons` = @persons, `messages` = @messages WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateIgDM"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getTwitterUser"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM twitter_users WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllTwitterUsers"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM twitter_users "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createTwitterUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `twitter_users` (identifier, nickname, username, bioghrapy, profileimage, followers, following, password, likedtweet, tweets) VALUES (@identifier, @nickname, @username, @bioghrapy, @profileimage, @followers, @following, @password, @likedtweet, @tweets)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.bioghrapy
    L5_3["@bioghrapy"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.followers
    L6_3 = L6_3(L7_3)
    L5_3["@followers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.following
    L6_3 = L6_3(L7_3)
    L5_3["@following"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedtweet
    L6_3 = L6_3(L7_3)
    L5_3["@likedtweet"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.tweets
    L6_3 = L6_3(L7_3)
    L5_3["@tweets"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getTweetData"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM twitter_tweets WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllTweetsData"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM twitter_tweets "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateTwUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `twitter_users` SET `nickname` = @nickname, `username` = @username, `bioghrapy` = @bioghrapy, `profileimage` = @profileimage, `followers` = @followers, `following` = @following, `password` = @password, `tweets` = @tweets, `likedtweet` = @likedtweet WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.bioghrapy
    L5_3["@bioghrapy"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.followers
    L6_3 = L6_3(L7_3)
    L5_3["@followers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.following
    L6_3 = L6_3(L7_3)
    L5_3["@following"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedtweet
    L6_3 = L6_3(L7_3)
    L5_3["@likedtweet"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.tweets
    L6_3 = L6_3(L7_3)
    L5_3["@tweets"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createTwTweet"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `twitter_tweets` (identifier, message, attachment, time, comments, whosent, likedusers, retweets) VALUES (@identifier, @message, @attachment, @time, @comments, @whosent, @likedusers, @retweets)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.message
    L5_3["@message"] = L6_3
    L6_3 = A0_3.attachment
    L5_3["@attachment"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.comments
    L6_3 = L6_3(L7_3)
    L5_3["@comments"] = L6_3
    L6_3 = A0_3.whosent
    L5_3["@whosent"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedusers
    L6_3 = L6_3(L7_3)
    L5_3["@likedusers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.retweets
    L6_3 = L6_3(L7_3)
    L5_3["@retweets"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:deleteTWTTweet"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.DATABASE
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE_NAME
    L5_3 = "execute"
    L6_3 = "DELETE FROM `twitter_tweets` WHERE identifier = ?"
    L7_3 = {}
    L8_3 = A2_3.identifier
    L7_3[1] = L8_3
    L3_3(L4_3, L5_3, L6_3, L7_3)
    L3_3 = A1_3
    L4_3 = true
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateTwTweet"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `twitter_tweets` SET `attachment` = @attachment, `message` = @message, `retweets` = @retweets, `time` = @time, `comments` = @comments, `whosent` = @whosent, `likedusers` = @likedusers WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.message
    L5_3["@message"] = L6_3
    L6_3 = A0_3.attachment
    L5_3["@attachment"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.comments
    L6_3 = L6_3(L7_3)
    L5_3["@comments"] = L6_3
    L6_3 = A0_3.whosent
    L5_3["@whosent"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.likedusers
    L6_3 = L6_3(L7_3)
    L5_3["@likedusers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.retweets
    L6_3 = L6_3(L7_3)
    L5_3["@retweets"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateTwTweet"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getPlayerCoords"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3
    L3_3 = {}
    L4_3 = pairs
    L5_3 = A2_3.friendslist
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = pairs
      L11_3 = AllPhones
      L10_3, L11_3, L12_3, L13_3 = L10_3(L11_3)
      for L14_3, L15_3 in L10_3, L11_3, L12_3, L13_3 do
        L16_3 = L15_3.MetaData
        L16_3 = L16_3.snapchatUser
        L17_3 = L9_3.identifier
        if L16_3 == L17_3 then
          L16_3 = L15_3.MetaData
          L16_3 = L16_3.locationInfo
          if L16_3 then
            L16_3 = GetEntityCoords
            L17_3 = GetPlayerPed
            L18_3 = L14_3
            L17_3, L18_3, L19_3, L20_3, L21_3 = L17_3(L18_3)
            L16_3 = L16_3(L17_3, L18_3, L19_3, L20_3, L21_3)
            L17_3 = table
            L17_3 = L17_3.insert
            L18_3 = L3_3
            L19_3 = {}
            L20_3 = L9_3.identifier
            L19_3.identifier = L20_3
            L20_3 = {}
            L21_3 = L16_3.x
            L20_3.x = L21_3
            L21_3 = L16_3.y
            L20_3.y = L21_3
            L21_3 = L16_3.z
            L20_3.z = L21_3
            L19_3.coords = L20_3
            L20_3 = L9_3.profileimage
            L19_3.image = L20_3
            L20_3 = L9_3.nickname
            L19_3.nickname = L20_3
            L17_3(L18_3, L19_3)
          end
        end
      end
    end
    L4_3 = A1_3
    L5_3 = L3_3
    L4_3(L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getSnapchatUser"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM snapchat_users WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getSnapchatUsers"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM snapchat_users "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllChats"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM snapchat_messages "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createSnapchatUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `snapchat_users` (identifier, nickname, username, profileimage, friends, password, friendrequests) VALUES (@identifier, @nickname, @username, @profileimage, @friends, @password, @friendrequests)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.friends
    L6_3 = L6_3(L7_3)
    L5_3["@friends"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.friendrequests
    L6_3 = L6_3(L7_3)
    L5_3["@friendrequests"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateSCUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `snapchat_users` SET `nickname` = @nickname, `username` = @username, `profileimage` = @profileimage, `friends` = @friends, `friendrequests` = @friendrequests, `password` = @password WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.nickname
    L5_3["@nickname"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.friends
    L6_3 = L6_3(L7_3)
    L5_3["@friends"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.friendrequests
    L6_3 = L6_3(L7_3)
    L5_3["@friendrequests"] = L6_3
    L6_3 = A0_3.password
    L5_3["@password"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createNewChat"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `snapchat_messages` (identifier, persons, messages) VALUES (@identifier, @persons, @messages)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateSCChat"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateSCChat"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `snapchat_messages` SET `persons` = @persons, `messages` = @messages WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateSCChat"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAdvert"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM yellowpage_advert WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllAdverts"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM yellowpage_advert "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createNewAdvert"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `yellowpage_advert` (identifier, author, title, description, time, phonenumber, attachments, price) VALUES (@identifier, @author, @title, @description, @time, @phonenumber, @attachments, @price)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.author
    L5_3["@author"] = L6_3
    L6_3 = A0_3.title
    L5_3["@title"] = L6_3
    L6_3 = A0_3.description
    L5_3["@description"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = A0_3.phonenumber
    L5_3["@phonenumber"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.attachments
    L6_3 = L6_3(L7_3)
    L5_3["@attachments"] = L6_3
    L6_3 = A0_3.price
    L5_3["@price"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:createNewAdvert"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getNews"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM news_new WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllNews"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM news_new "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:controlnewsjob"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    L2_3 = L2_3.job
    L2_3 = L2_3.name
    L3_3 = A1_3
    L4_3 = L2_3
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createNewNews"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `news_new` (identifier, author, title, description, time, attachments) VALUES (@identifier, @author, @title, @description, @time, @attachments)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.author
    L5_3["@author"] = L6_3
    L6_3 = A0_3.title
    L5_3["@title"] = L6_3
    L6_3 = A0_3.description
    L5_3["@description"] = L6_3
    L6_3 = A0_3.time
    L5_3["@time"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.attachments
    L6_3 = L6_3(L7_3)
    L5_3["@attachments"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:createNewNews"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getCash"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = A0_3
    L4_3 = true
    L2_3 = L2_3(L3_3, L4_3)
    if nil == L2_3 then
      L3_3 = A1_3
      L4_3 = false
      L3_3(L4_3)
    end
    L3_3 = A1_3
    L4_3 = {}
    L5_3 = L2_3.Functions
    L5_3 = L5_3.GetPlayerMoney
    L6_3 = "bank"
    L5_3 = L5_3(L6_3)
    L4_3.bank = L5_3
    L5_3 = L2_3.Functions
    L5_3 = L5_3.GetPlayerMoney
    L6_3 = "cash"
    L5_3 = L5_3(L6_3)
    L4_3.cash = L5_3
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getDarkchatUser"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM darkchat_users WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllDarkchatUsers"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM darkchat_users "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createDarkchatUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `darkchat_users` (identifier, username, profileimage) VALUES (@identifier, @username, @profileimage)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateDCUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `darkchat_users` SET `username` = @username,`profileimage` = @profileimage WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.username
    L5_3["@username"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getDarkchatChat"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM darkchat_chats WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllDarkchatChat"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM darkchat_chats "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createNewDarkChat"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `darkchat_chats` (chatname, img, joinedUsers, messages) VALUES (@chatname, @img, @joinedUsers, @messages)"
    L5_3 = {}
    L6_3 = A0_3.chatname
    L5_3["@chatname"] = L6_3
    L6_3 = A0_3.img
    L5_3["@img"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.joinedUsers
    L6_3 = L6_3(L7_3)
    L5_3["@joinedUsers"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateDCChat"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateDCChat"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `darkchat_chats` SET `joinedUsers` = @joinedUsers, `messages` = @messages WHERE `chatname` = @chatname"
    L5_3 = {}
    L6_3 = A0_3.chatname
    L5_3["@chatname"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.joinedUsers
    L6_3 = L6_3(L7_3)
    L5_3["@joinedUsers"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateDCChat"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getMessages"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM contact_messsages WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllMessages"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM contact_messsages "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createMessage"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `contact_messsages` (identifier, persons, messages) VALUES (@identifier, @persons, @messages)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateContactMessages"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateContactsMessage"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `contact_messsages` SET `persons` = @persons, `messages` = @messages WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateContactMessages"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getWhatsappMessages"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM whatsapp_messages WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllWhatsappMessages"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM whatsapp_messages "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createWPMessage"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = A0_3.isGroup
    L2_3 = A0_3.isGroup
    if false ~= L2_3 then
      L2_3 = json
      L2_3 = L2_3.encode
      L3_3 = L1_3
      L2_3 = L2_3(L3_3)
      L1_3 = L2_3
    end
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.DATABASE_NAME
    L4_3 = "execute"
    L5_3 = "INSERT INTO `whatsapp_messages` (identifier, persons, messages, isGroup) VALUES (@identifier, @persons, @messages, @isGroup)"
    L6_3 = {}
    L7_3 = A0_3.identifier
    L6_3["@identifier"] = L7_3
    L7_3 = json
    L7_3 = L7_3.encode
    L8_3 = A0_3.persons
    L7_3 = L7_3(L8_3)
    L6_3["@persons"] = L7_3
    L7_3 = json
    L7_3 = L7_3.encode
    L8_3 = A0_3.messages
    L7_3 = L7_3(L8_3)
    L6_3["@messages"] = L7_3
    L6_3["@isGroup"] = L1_3
    L2_3(L3_3, L4_3, L5_3, L6_3)
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:updateWhatsappMessage"
    L4_3 = -1
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateWhatsappMessage"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `whatsapp_messages` SET `persons` = @persons, `messages` = @messages WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.messages
    L6_3 = L6_3(L7_3)
    L5_3["@messages"] = L6_3
    L6_3 = json
    L6_3 = L6_3.encode
    L7_3 = A0_3.persons
    L6_3 = L6_3(L7_3)
    L5_3["@persons"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:updateWhatsappMessage"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getWhatsappUser"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM whatsapp_users WHERE "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L4_3 = L4_3[1]
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = LS_CORE
  L1_2 = L1_2.Callback
  L1_2 = L1_2.Functions
  L1_2 = L1_2.CreateCallback
  L2_2 = "ls-phone:s:getAllWhatsappUsers"
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L3_3 = A1_3
    L4_3 = LS_CORE
    L4_3 = L4_3.Config
    L4_3 = L4_3.DATABASE
    L5_3 = LS_CORE
    L5_3 = L5_3.Config
    L5_3 = L5_3.DATABASE_NAME
    L6_3 = "fetchAll"
    L7_3 = "SELECT * FROM whatsapp_users "
    L8_3 = tostring
    L9_3 = A2_3.query
    L8_3 = L8_3(L9_3)
    L7_3 = L7_3 .. L8_3
    L8_3 = {}
    L9_3 = A2_3.querystring
    L8_3[1] = L9_3
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3, L6_3, L7_3, L8_3)
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:createWPUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "INSERT INTO `whatsapp_users` (identifier, bio, profileimage) VALUES (@identifier, @bio, @profileimage)"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.bio
    L5_3["@bio"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:s:updateWhatsappUser"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Config
    L1_3 = L1_3.DATABASE
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE_NAME
    L3_3 = "execute"
    L4_3 = "UPDATE `whatsapp_users` SET `bio` = @bio, `profileimage` = @profileimage WHERE `identifier` = @identifier"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L6_3 = A0_3.bio
    L5_3["@bio"] = L6_3
    L6_3 = A0_3.profileimage
    L5_3["@profileimage"] = L6_3
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = {}
  L2_2 = LS_CORE
  L2_2 = L2_2.Callback
  L2_2 = L2_2.Functions
  L2_2 = L2_2.CreateCallback
  L3_2 = "ls-phone:s:getAllUberRequests"
  function L4_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3
    L3_3 = A1_3
    L4_3 = L1_2
    L3_3(L4_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:uberRequest"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = source
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = L1_3
    L4_3 = true
    L2_3 = L2_3(L3_3, L4_3)
    L2_3 = L2_3.Functions
    L2_3 = L2_3.RemoveMoney
    L3_3 = "bank"
    L4_3 = math
    L4_3 = L4_3.floor
    L5_3 = A0_3.uberData
    L5_3 = L5_3.CalculatedPrice
    L4_3 = L4_3(L5_3)
    L5_3 = "Uber services used"
    L2_3(L3_3, L4_3, L5_3)
    A0_3.source = L1_3
    A0_3.isTaken = false
    L3_3 = A0_3.identifier
    L2_3 = L1_2
    L2_3[L3_3] = A0_3
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:uberRequest"
    L4_3 = -1
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:deleteUberRequest"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.price
    if nil ~= L1_3 then
      L1_3 = Config
      L1_3 = L1_3.Server
      L1_3 = L1_3.GetPlayer
      L2_3 = source
      L3_3 = true
      L1_3 = L1_3(L2_3, L3_3)
      L1_3 = L1_3.Functions
      L1_3 = L1_3.AddMoney
      L2_3 = "bank"
      L3_3 = math
      L3_3 = L3_3.floor
      L4_3 = A0_3.price
      L3_3 = L3_3(L4_3)
      L4_3 = "Uber request deleted"
      L1_3(L2_3, L3_3, L4_3)
    end
    L1_3 = json
    L1_3 = L1_3.decode
    L2_3 = json
    L2_3 = L2_3.encode
    L3_3 = A0_3.identifier
    L2_3, L3_3, L4_3 = L2_3(L3_3)
    L1_3 = L1_3(L2_3, L3_3, L4_3)
    idtemp = L1_3
    L2_3 = A0_3.identifier
    L1_3 = L1_2
    L1_3 = L1_3[L2_3]
    L1_3.isTaken = true
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:deleteUberRequest"
    L3_3 = -1
    L4_3 = idtemp
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:uberDeleteMap"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:uberDeleteMap"
    L3_3 = A0_3.source
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:acceptedRequest"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = source
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = L1_3
    L4_3 = true
    L2_3 = L2_3(L3_3, L4_3)
    L2_3 = L2_3.Functions
    L2_3 = L2_3.AddMoney
    L3_3 = "bank"
    L4_3 = math
    L4_3 = L4_3.floor
    L6_3 = A0_3.identifier
    L5_3 = L1_2
    L5_3 = L5_3[L6_3]
    L5_3 = L5_3.uberData
    L5_3 = L5_3.CalculatedPrice
    L4_3 = L4_3(L5_3)
    L5_3 = "Uber request deleted"
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:sendNotification"
    L4_3 = A0_3.source
    L5_3 = {}
    L5_3.app = "uber"
    L5_3.message = "Your uber in way"
    L5_3.event = "uberaccept"
    L5_3.data = L1_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:uberDeliver"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = source
    L2_3 = math
    L2_3 = L2_3.random
    L3_3 = Config
    L3_3 = L3_3.Client
    L3_3 = L3_3.UberEats
    L3_3 = L3_3.Pricing
    L3_3 = L3_3.RandomPrice
    L3_3 = L3_3[1]
    L4_3 = Config
    L4_3 = L4_3.Client
    L4_3 = L4_3.UberEats
    L4_3 = L4_3.Pricing
    L4_3 = L4_3.RandomPrice
    L4_3 = L4_3[2]
    L2_3 = L2_3(L3_3, L4_3)
    L3_3 = Config
    L3_3 = L3_3.Client
    L3_3 = L3_3.UberEats
    L3_3 = L3_3.Pricing
    L3_3 = L3_3.DistanceMultiplier
    L3_3 = L3_3.active
    if L3_3 then
      L3_3 = Config
      L3_3 = L3_3.Client
      L3_3 = L3_3.UberEats
      L3_3 = L3_3.Pricing
      L3_3 = L3_3.DistanceMultiplier
      L3_3 = L3_3.multiply
      L3_3 = L3_3 * A0_3
      L2_3 = L2_3 * L3_3
    end
    L3_3 = Config
    L3_3 = L3_3.Server
    L3_3 = L3_3.GetPlayer
    L4_3 = L1_3
    L5_3 = true
    L3_3 = L3_3(L4_3, L5_3)
    L3_3 = L3_3.Functions
    L3_3 = L3_3.AddMoney
    L4_3 = "bank"
    L5_3 = math
    L5_3 = L5_3.floor
    L6_3 = L2_3
    L5_3 = L5_3(L6_3)
    L6_3 = "Uber Eats delivered"
    L3_3(L4_3, L5_3, L6_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:songAction"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = source
    A0_3.songSource = L1_3
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:songAction"
    L4_3 = -1
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:s:callsongAction"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = source
    A0_3.songSource = L1_3
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:callsongAction"
    L4_3 = L1_3
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = json
  L2_2 = L2_2.decode
  L3_2 = json
  L3_2 = L3_2.encode
  L4_2 = Config
  L4_2 = L4_2.Shared
  L4_2 = L4_2.Business
  L3_2, L4_2, L5_2, L6_2, L7_2 = L3_2(L4_2)
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L3_2 = LS_CORE
  L3_2 = L3_2.Callback
  L3_2 = L3_2.Functions
  L3_2 = L3_2.CreateCallback
  L4_2 = "ls-phone:s:getAllBusiness"
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L2_3 = json
    L2_3 = L2_3.decode
    L3_3 = json
    L3_3 = L3_3.encode
    L4_3 = Config
    L4_3 = L4_3.Shared
    L4_3 = L4_3.Business
    L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L3_3(L4_3)
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
    L3_3 = pairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = L2_3[L7_3]
      L9_3.isOnline = false
    end
    L3_3 = pairs
    L4_3 = Framework
    L4_3 = L4_3.GetPlayers
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L4_3()
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = JobNameIsSame
      L10_3 = Config
      L10_3 = L10_3.Server
      L10_3 = L10_3.GetPlayer
      L11_3 = L8_3
      L10_3 = L10_3(L11_3)
      L10_3 = L10_3.getJob
      L10_3 = L10_3()
      L10_3 = L10_3.name
      L9_3 = L9_3(L10_3)
      if L9_3 then
        L10_3 = L2_3[L9_3]
        L10_3.isOnline = true
      end
    end
    L3_3 = A1_3
    L4_3 = L2_3
    L3_3(L4_3)
  end
  L3_2(L4_2, L5_2)
  L3_2 = LS_CORE
  L3_2 = L3_2.Callback
  L3_2 = L3_2.Functions
  L3_2 = L3_2.CreateCallback
  L4_2 = "ls-phone:s:getAllBusinessNotifications"
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    L2_3 = L2_3.getJob
    L2_3 = L2_3()
    L2_3 = L2_3.name
    L3_3 = {}
    L4_3 = pairs
    L5_3 = L2_2
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = L9_3.employeeJob
      if L10_3 == L2_3 then
        L3_3 = L9_3.requests
        break
      end
    end
    L4_3 = A1_3
    L5_3 = L3_3
    L4_3(L5_3)
  end
  L3_2(L4_2, L5_2)
  L3_2 = LS_CORE
  L3_2 = L3_2.Callback
  L3_2 = L3_2.Functions
  L3_2 = L3_2.CreateCallback
  L4_2 = "ls-phone:s:getServiceData"
  function L5_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3
    L3_3 = A1_3
    L4_3 = Config
    L4_3 = L4_3.Shared
    L4_3 = L4_3.Business
    L4_3 = L4_3[A2_3]
    L3_3(L4_3)
  end
  L3_2(L4_2, L5_2)
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = pairs
    L2_3 = Config
    L2_3 = L2_3.Shared
    L2_3 = L2_3.Business
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.employeeJob
      if L7_3 == A0_3 then
        return L5_3
      end
    end
    L1_3 = false
    return L1_3
  end
  JobNameIsSame = L3_2
  L3_2 = RegisterNetEvent
  L4_2 = "ls-phone:s:sendServiceMessage"
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L2_3 = A0_3.service
    L1_3 = L2_2
    L1_3 = L1_3[L2_3]
    L1_3 = L1_3.requests
    L2_3 = A0_3.identifier
    L1_3[L2_3] = A0_3
    L1_3 = Config
    L1_3 = L1_3.Server
    L1_3 = L1_3.GetPlayer
    L2_3 = source
    L1_3 = L1_3(L2_3)
    L1_3 = L1_3.getJob
    L1_3 = L1_3()
    L1_3 = L1_3.name
    A0_3.currentPlayerJob = L1_3
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:s:sendServiceMessage"
    L3_3 = -1
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L3_2(L4_2, L5_2)
  L3_2 = RegisterNetEvent
  L4_2 = "ls-phone:s:savePhone"
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L2_3 = source
    L3_3 = Config
    L3_3 = L3_3.Server
    L3_3 = L3_3.GetPlayer
    L4_3 = L2_3
    L3_3 = L3_3(L4_3)
    if nil == L3_3 then
      return
    end
    L4_3 = AllPhones
    L4_3[L2_3] = A0_3
    L4_3 = Config
    L4_3 = L4_3.Server
    L4_3 = L4_3.SavePhoneData
    L5_3 = L2_3
    L6_3 = A0_3
    L7_3 = A1_3
    L4_3 = L4_3(L5_3, L6_3, L7_3)
    if not L4_3 then
      L4_3 = print
      L5_3 = "Failed to save phone data. ^8Error Code 1^7"
      L4_3(L5_3)
    end
  end
  L3_2(L4_2, L5_2)
  L3_2 = LS_CORE
  L3_2 = L3_2.Callback
  L3_2 = L3_2.Functions
  L3_2 = L3_2.CreateCallback
  L4_2 = "ls-phone:s:getAllMails"
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.DATABASE_NAME
    L4_3 = "fetchAll"
    L5_3 = "SELECT * FROM player_mails WHERE citizenid = ? ORDER BY `date` ASC"
    L6_3 = {}
    L7_3 = Config
    L7_3 = L7_3.Server
    L7_3 = L7_3.GetPlayerIdentifier
    L8_3 = A0_3
    L7_3, L8_3, L9_3, L10_3, L11_3 = L7_3(L8_3)
    L6_3[1] = L7_3
    L6_3[2] = L8_3
    L6_3[3] = L9_3
    L6_3[4] = L10_3
    L6_3[5] = L11_3
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    L3_3 = L2_3[1]
    if nil ~= L3_3 then
      L3_3 = pairs
      L4_3 = L2_3
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = L2_3[L7_3]
        L9_3 = L9_3.button
        if nil ~= L9_3 then
          L9_3 = L2_3[L7_3]
          L10_3 = json
          L10_3 = L10_3.decode
          L11_3 = L2_3[L7_3]
          L11_3 = L11_3.button
          L10_3 = L10_3(L11_3)
          L9_3.button = L10_3
        end
      end
      L3_3 = A1_3
      L4_3 = L2_3
      L3_3(L4_3)
    else
      L3_3 = A1_3
      L4_3 = {}
      L3_3(L4_3)
    end
  end
  L3_2(L4_2, L5_2)
  L3_2 = LS_CORE
  L3_2 = L3_2.Callback
  L3_2 = L3_2.Functions
  L3_2 = L3_2.CreateCallback
  L4_2 = "ls-phone:s:getCryptoTransactions"
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Config
    L2_3 = L2_3.DATABASE
    L3_3 = LS_CORE
    L3_3 = L3_3.Config
    L3_3 = L3_3.DATABASE_NAME
    L4_3 = "fetchAll"
    L5_3 = "SELECT * FROM crypto_transactions WHERE citizenid = ?"
    L6_3 = {}
    L7_3 = Config
    L7_3 = L7_3.Server
    L7_3 = L7_3.GetPlayerIdentifier
    L8_3 = A0_3
    L7_3, L8_3 = L7_3(L8_3)
    L6_3[1] = L7_3
    L6_3[2] = L8_3
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    L3_3 = L2_3[1]
    if nil ~= L3_3 then
      L3_3 = A1_3
      L4_3 = L2_3
      L3_3(L4_3)
    else
      L3_3 = A1_3
      L4_3 = {}
      L3_3(L4_3)
    end
  end
  L3_2(L4_2, L5_2)
  function L3_2()
    local L0_3, L1_3, L2_3
    L0_3 = math
    L0_3 = L0_3.random
    L1_3 = 111111
    L2_3 = 999999
    return L0_3(L1_3, L2_3)
  end
  function L4_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayerFromIdentifier
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    if L2_3 then
      L3_3 = L2_3.PlayerData
      if nil ~= L3_3 then
        L3_3 = L2_3.PlayerData
        L3_3 = L3_3.source
        if L3_3 then
          goto lbl_16
        end
      end
      L3_3 = L2_3.source
      ::lbl_16::
      L4_3 = A1_3.button
      if nil == L4_3 then
        L4_3 = LS_CORE
        L4_3 = L4_3.Config
        L4_3 = L4_3.DATABASE
        L5_3 = LS_CORE
        L5_3 = L5_3.Config
        L5_3 = L5_3.DATABASE_NAME
        L6_3 = "execute"
        L7_3 = "INSERT INTO player_mails (`citizenid`, `sender`, `subject`, `message`, `mailid`, `read`) VALUES (?, ?, ?, ?, ?, ?)"
        L8_3 = {}
        L9_3 = Config
        L9_3 = L9_3.Server
        L9_3 = L9_3.GetPlayerIdentifier
        L10_3 = L3_3
        L9_3 = L9_3(L10_3)
        L10_3 = A1_3.sender
        L11_3 = A1_3.subject
        L12_3 = A1_3.message
        L13_3 = L3_2
        L13_3 = L13_3()
        L14_3 = 0
        L8_3[1] = L9_3
        L8_3[2] = L10_3
        L8_3[3] = L11_3
        L8_3[4] = L12_3
        L8_3[5] = L13_3
        L8_3[6] = L14_3
        L4_3(L5_3, L6_3, L7_3, L8_3)
      else
        L4_3 = LS_CORE
        L4_3 = L4_3.Config
        L4_3 = L4_3.DATABASE
        L5_3 = LS_CORE
        L5_3 = L5_3.Config
        L5_3 = L5_3.DATABASE_NAME
        L6_3 = "execute"
        L7_3 = "INSERT INTO player_mails (`citizenid`, `sender`, `subject`, `message`, `mailid`, `read`, `button`) VALUES (?, ?, ?, ?, ?, ?, ?)"
        L8_3 = {}
        L9_3 = Config
        L9_3 = L9_3.Server
        L9_3 = L9_3.GetPlayerIdentifier
        L10_3 = L3_3
        L9_3 = L9_3(L10_3)
        L10_3 = A1_3.sender
        L11_3 = A1_3.subject
        L12_3 = A1_3.message
        L13_3 = L3_2
        L13_3 = L13_3()
        L14_3 = 0
        L15_3 = json
        L15_3 = L15_3.encode
        L16_3 = A1_3.button
        L15_3, L16_3 = L15_3(L16_3)
        L8_3[1] = L9_3
        L8_3[2] = L10_3
        L8_3[3] = L11_3
        L8_3[4] = L12_3
        L8_3[5] = L13_3
        L8_3[6] = L14_3
        L8_3[7] = L15_3
        L8_3[8] = L16_3
        L4_3(L5_3, L6_3, L7_3, L8_3)
      end
    else
      L3_3 = A1_3.button
      if nil == L3_3 then
        L3_3 = LS_CORE
        L3_3 = L3_3.Config
        L3_3 = L3_3.DATABASE
        L4_3 = LS_CORE
        L4_3 = L4_3.Config
        L4_3 = L4_3.DATABASE_NAME
        L5_3 = "execute"
        L6_3 = "INSERT INTO player_mails (`citizenid`, `sender`, `subject`, `message`, `mailid`, `read`) VALUES (?, ?, ?, ?, ?, ?)"
        L7_3 = {}
        L8_3 = A0_3
        L9_3 = A1_3.sender
        L10_3 = A1_3.subject
        L11_3 = A1_3.message
        L12_3 = L3_2
        L12_3 = L12_3()
        L13_3 = 0
        L7_3[1] = L8_3
        L7_3[2] = L9_3
        L7_3[3] = L10_3
        L7_3[4] = L11_3
        L7_3[5] = L12_3
        L7_3[6] = L13_3
        L3_3(L4_3, L5_3, L6_3, L7_3)
      else
        L3_3 = LS_CORE
        L3_3 = L3_3.Config
        L3_3 = L3_3.DATABASE
        L4_3 = LS_CORE
        L4_3 = L4_3.Config
        L4_3 = L4_3.DATABASE_NAME
        L5_3 = "execute"
        L6_3 = "INSERT INTO player_mails (`citizenid`, `sender`, `subject`, `message`, `mailid`, `read`, `button`) VALUES (?, ?, ?, ?, ?, ?, ?)"
        L7_3 = {}
        L8_3 = A0_3
        L9_3 = A1_3.sender
        L10_3 = A1_3.subject
        L11_3 = A1_3.message
        L12_3 = L3_2
        L12_3 = L12_3()
        L13_3 = 0
        L14_3 = json
        L14_3 = L14_3.encode
        L15_3 = A1_3.button
        L14_3, L15_3, L16_3 = L14_3(L15_3)
        L7_3[1] = L8_3
        L7_3[2] = L9_3
        L7_3[3] = L10_3
        L7_3[4] = L11_3
        L7_3[5] = L12_3
        L7_3[6] = L13_3
        L7_3[7] = L14_3
        L7_3[8] = L15_3
        L7_3[9] = L16_3
        L3_3(L4_3, L5_3, L6_3, L7_3)
      end
    end
  end
  sendNewMailToOffline = L4_2
  L4_2 = exports
  L5_2 = "SendOfflineMail"
  L6_2 = sendNewMailToOffline
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:server:sendNewMail"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = source
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = L1_3
    L2_3 = L2_3(L3_3)
    L3_3 = sendNewMailToOffline
    L4_3 = Config
    L4_3 = L4_3.Server
    L4_3 = L4_3.GetPlayerIdentifier
    L5_3 = L1_3
    L4_3 = L4_3(L5_3)
    L5_3 = A0_3
    L3_3(L4_3, L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = LS_CORE
  L4_2 = L4_2.Callback
  L4_2 = L4_2.Functions
  L4_2 = L4_2.CreateCallback
  L5_2 = "ls-phone:s:GetCallState"
  function L6_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3
    L3_3 = GetUserByPhoneNumber
    L4_3 = A2_3.dialnumber
    L3_3 = L3_3(L4_3)
    if nil ~= L3_3 then
      L4_3 = L3_3.DATA
      L5_3 = L4_3.identifier
      L4_3 = L0_2
      L4_3 = L4_3[L5_3]
      if nil ~= L4_3 then
        L4_3 = L3_3.DATA
        L5_3 = L4_3.identifier
        L4_3 = L0_2
        L4_3 = L4_3[L5_3]
        L4_3 = L4_3.inCall
        if L4_3 then
          L4_3 = A1_3
          L5_3 = false
          L6_3 = true
          L4_3(L5_3, L6_3)
        else
          L4_3 = A1_3
          L5_3 = true
          L6_3 = true
          L4_3(L5_3, L6_3)
        end
      else
        L4_3 = A1_3
        L5_3 = true
        L6_3 = true
        L4_3(L5_3, L6_3)
      end
    else
      L4_3 = A1_3
      L5_3 = false
      L6_3 = false
      L4_3(L5_3, L6_3)
    end
  end
  L4_2(L5_2, L6_2)
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = pairs
    L2_3 = AllPhones
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = tonumber
      L8_3 = L6_3.MetaData
      L8_3 = L8_3.phonenumber
      L7_3 = L7_3(L8_3)
      L8_3 = tonumber
      L9_3 = A0_3
      L8_3 = L8_3(L9_3)
      if L7_3 == L8_3 then
        L7_3 = Config
        L7_3 = L7_3.Server
        L7_3 = L7_3.GetPlayer
        L8_3 = L5_3
        L9_3 = true
        return L7_3(L8_3, L9_3)
      end
    end
    L1_3 = nil
    return L1_3
  end
  GetUserByPhoneNumber = L4_2
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:shareNumber"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = TriggerClientEvent
      L9_3 = "ls-phone:c:shareNumber"
      L10_3 = L7_3
      L11_3 = A1_3
      L8_3(L9_3, L10_3, L11_3)
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = LS_CORE
  L4_2 = L4_2.Callback
  L4_2 = L4_2.Functions
  L4_2 = L4_2.CreateCallback
  L5_2 = "ls-phone:s:getPhoneData"
  function L6_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L3_3 = {}
    L4_3 = pairs
    L5_3 = A2_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = AllPhones
      L10_3 = L10_3[L9_3]
      if nil ~= L10_3 then
        L10_3 = AllPhones
        L10_3 = L10_3[L9_3]
        L10_3 = L10_3.MetaData
        L10_3 = L10_3.bluetooth
        if L10_3 then
          L10_3 = AllPhones
          L10_3 = L10_3[L9_3]
          L11_3 = {}
          L12_3 = L10_3.MetaData
          L12_3 = L12_3.phonenumber
          L11_3.phonenumber = L12_3
          L12_3 = L10_3.MetaData
          L12_3 = L12_3.owner
          L11_3.phoneuser = L12_3
          L12_3 = L10_3.MetaData
          L12_3 = L12_3.profileimage
          L11_3.phoneimage = L12_3
          L3_3[L9_3] = L11_3
        end
      end
    end
    L4_3 = A1_3
    L5_3 = L3_3
    L4_3(L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = LS_CORE
  L4_2 = L4_2.Callback
  L4_2 = L4_2.Functions
  L4_2 = L4_2.CreateCallback
  L5_2 = "ls-phone:s:getBank"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = A0_3
    L4_3 = true
    L2_3 = L2_3(L3_3, L4_3)
    if nil == L2_3 then
      return
    end
    L3_3 = A1_3
    L4_3 = L2_3.Functions
    L4_3 = L4_3.GetPlayerMoney
    L5_3 = "bank"
    L4_3, L5_3 = L4_3(L5_3)
    L3_3(L4_3, L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = LS_CORE
  L4_2 = L4_2.Callback
  L4_2 = L4_2.Functions
  L4_2 = L4_2.CreateCallback
  L5_2 = "ls-phone:s:PayInvoice"
  function L6_2(A0_3, A1_3, A2_3, A3_3, A4_3, A5_3)
    local L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L6_3 = A1_3
    L7_3 = true
    L8_3 = Config
    L8_3 = L8_3.Server
    L8_3 = L8_3.PayBilling
    L9_3 = A0_3
    L10_3 = A2_3
    L11_3 = A3_3
    L12_3 = A4_3
    L13_3 = A5_3
    L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L8_3(L9_3, L10_3, L11_3, L12_3, L13_3)
    L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:removeMoney"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = Config
    L1_3 = L1_3.Server
    L1_3 = L1_3.GetPlayer
    L2_3 = source
    L3_3 = true
    L1_3 = L1_3(L2_3, L3_3)
    if nil == L1_3 then
      return
    end
    L2_3 = L1_3.Functions
    L2_3 = L2_3.RemoveMoney
    L3_3 = "bank"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:addMoney"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = Config
    L1_3 = L1_3.Server
    L1_3 = L1_3.GetPlayer
    L2_3 = source
    L3_3 = true
    L1_3 = L1_3(L2_3, L3_3)
    if nil == L1_3 then
      return
    end
    L2_3 = L1_3.Functions
    L2_3 = L2_3.AddMoney
    L3_3 = "bank"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:sendImgAirdrop"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:sendImgAirdrop"
    L3_3 = A0_3.toUser
    L4_3 = A0_3
    L1_3(L2_3, L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = LS_CORE
  L4_2 = L4_2.Callback
  L4_2 = L4_2.Functions
  L4_2 = L4_2.CreateCallback
  L5_2 = "ls-phone:s:tryToSendMoney"
  function L6_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3
    L3_3 = Config
    L3_3 = L3_3.Server
    L3_3 = L3_3.GetPlayer
    L4_3 = tonumber
    L5_3 = A2_3.person
    L4_3 = L4_3(L5_3)
    L5_3 = true
    L3_3 = L3_3(L4_3, L5_3)
    if nil == L3_3 then
      L4_3 = A1_3
      L5_3 = false
      L4_3(L5_3)
      return
    end
    L4_3 = tonumber
    L5_3 = A2_3.person
    L4_3 = L4_3(L5_3)
    if L4_3 == A0_3 then
      L4_3 = A1_3
      L5_3 = "same"
      L4_3(L5_3)
      return
    end
    L4_3 = L3_3.Functions
    L4_3 = L4_3.AddMoney
    L5_3 = "bank"
    L6_3 = tonumber
    L7_3 = A2_3.amount
    L6_3, L7_3 = L6_3(L7_3)
    L4_3(L5_3, L6_3, L7_3)
    L4_3 = Config
    L4_3 = L4_3.Server
    L4_3 = L4_3.GetPlayer
    L5_3 = A0_3
    L6_3 = true
    L4_3 = L4_3(L5_3, L6_3)
    L4_3 = L4_3.Functions
    L4_3 = L4_3.RemoveMoney
    L5_3 = "bank"
    L6_3 = tonumber
    L7_3 = A2_3.amount
    L6_3, L7_3 = L6_3(L7_3)
    L4_3(L5_3, L6_3, L7_3)
    L4_3 = TriggerClientEvent
    L5_3 = "ls-phone:sendinfowalletother"
    L6_3 = tonumber
    L7_3 = A2_3.person
    L6_3 = L6_3(L7_3)
    L7_3 = A2_3.amount
    L4_3(L5_3, L6_3, L7_3)
    L4_3 = A1_3
    L5_3 = true
    L4_3(L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:CancelCall"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.number
    if nil == L1_3 then
      L1_3 = A0_3.dialnumber
      A0_3.number = L1_3
    end
    L1_3 = GetUserByPhoneNumber
    L2_3 = A0_3.number
    L1_3 = L1_3(L2_3)
    if nil ~= L1_3 then
      L2_3 = TriggerClientEvent
      L3_3 = "ls-phone:c:CancelCall"
      L4_3 = L1_3.Source
      L2_3(L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:AnswerCall"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = GetUserByPhoneNumber
    L2_3 = A0_3.TargetData
    L2_3 = L2_3.number
    L1_3 = L1_3(L2_3)
    if nil ~= L1_3 then
      L2_3 = TriggerClientEvent
      L3_3 = "ls-phone:c:AnswerCall"
      L4_3 = L1_3.Source
      L2_3(L3_3, L4_3)
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:CallContact"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L2_3 = source
    L3_3 = AllPhones
    L3_3 = L3_3[L2_3]
    L3_3 = L3_3.MetaData
    L3_3 = L3_3.phonenumber
    L4_3 = GetUserByPhoneNumber
    L5_3 = A0_3.dialnumber
    L4_3 = L4_3(L5_3)
    if nil ~= L4_3 then
      L5_3 = TriggerClientEvent
      L6_3 = "ls-phone:c:GetCalled"
      L7_3 = L4_3.Source
      L8_3 = L3_3
      L9_3 = A1_3
      L10_3 = A0_3
      L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:s:SetCallState"
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = source
    L2_3 = Config
    L2_3 = L2_3.Server
    L2_3 = L2_3.GetPlayer
    L3_3 = L1_3
    L4_3 = true
    L2_3 = L2_3(L3_3, L4_3)
    if nil ~= L2_3 then
      L3_3 = L2_3.DATA
      if nil ~= L3_3 then
        L3_3 = L2_3.DATA
        L4_3 = L3_3.identifier
        L3_3 = L0_2
        L3_3 = L3_3[L4_3]
        if nil ~= L3_3 then
          L3_3 = L2_3.DATA
          L4_3 = L3_3.identifier
          L3_3 = L0_2
          L3_3 = L3_3[L4_3]
          L3_3.inCall = A0_3
        else
          L3_3 = L2_3.DATA
          L4_3 = L3_3.identifier
          L3_3 = L0_2
          L5_3 = {}
          L3_3[L4_3] = L5_3
          L3_3 = L2_3.DATA
          L4_3 = L3_3.identifier
          L3_3 = L0_2
          L3_3 = L3_3[L4_3]
          L3_3.inCall = A0_3
        end
      end
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = {}
  L5_2 = RegisterNetEvent
  L6_2 = "ls-phone:s:sendData"
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = FindChat
    L2_3 = A0_3.callId
    L1_3 = L1_3(L2_3)
    L2_3 = A0_3.type
    if "store_user" == L2_3 then
      if L1_3 then
        return
      end
      L2_3 = {}
      L3_3 = A0_3.serverId
      L2_3.serverId = L3_3
      L3_3 = A0_3.callId
      L2_3.callId = L3_3
      L3_3 = {}
      L2_3.candidates = L3_3
      L3_3 = table
      L3_3 = L3_3.insert
      L4_3 = L4_2
      L5_3 = L2_3
      L3_3(L4_3, L5_3)
    end
    if L1_3 and nil ~= L1_3 then
      L2_3 = type
      L3_3 = L1_3
      L2_3 = L2_3(L3_3)
      if "table" == L2_3 then
        goto lbl_34
      end
    end
    do return end
    ::lbl_34::
    L2_3 = A0_3.type
    if "store_offer" == L2_3 then
      L2_3 = A0_3.offer
      L1_3.offer = L2_3
    else
      L2_3 = A0_3.type
      if "store_candidate" == L2_3 then
        L2_3 = L1_3.candidates
        if nil == L2_3 then
          L2_3 = {}
          L1_3.candidates = L2_3
        end
        L2_3 = table
        L2_3 = L2_3.insert
        L3_3 = L1_3.candidates
        L4_3 = A0_3.candidate
        L2_3(L3_3, L4_3)
      else
        L2_3 = A0_3.type
        if "send_answer" == L2_3 then
          L2_3 = sendData
          L3_3 = {}
          L3_3.type = "answer"
          L4_3 = A0_3.answer
          L3_3.answer = L4_3
          L4_3 = L1_3.serverId
          L2_3(L3_3, L4_3)
        else
          L2_3 = A0_3.type
          if "send_candidate" == L2_3 then
            L2_3 = sendData
            L3_3 = {}
            L3_3.type = "candidate"
            L4_3 = A0_3.candidate
            L3_3.candidate = L4_3
            L4_3 = L1_3.serverId
            L2_3(L3_3, L4_3)
          else
            L2_3 = A0_3.type
            if "join_call" == L2_3 then
              L2_3 = sendData
              L3_3 = {}
              L3_3.type = "offer"
              L4_3 = L1_3.offer
              L3_3.offer = L4_3
              L4_3 = L1_3.callId
              L2_3(L3_3, L4_3)
              L2_3 = ipairs
              L3_3 = L1_3.candidates
              L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
              for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
                L8_3 = sendData
                L9_3 = {}
                L9_3.type = "candidate"
                L9_3.candidate = L7_3
                L10_3 = L1_3.callId
                L8_3(L9_3, L10_3)
              end
            end
          end
        end
      end
    end
  end
  L5_2(L6_2, L7_2)
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:sendData"
    L4_3 = A1_3
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  sendData = L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = ipairs
    L2_3 = L4_2
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.callId
      if L7_3 == A0_3 then
        return L6_3
      end
    end
    L1_3 = nil
    return L1_3
  end
  FindChat = L5_2
  L5_2 = RegisterNetEvent
  L6_2 = "ls-phone:s:sendCall"
  function L7_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = TriggerClientEvent
    L3_3 = "ls-phone:c:sendCall"
    L4_3 = A0_3
    L5_3 = A0_3
    L6_3 = A1_3
    L2_3(L3_3, L4_3, L5_3, L6_3)
  end
  L5_2(L6_2, L7_2)
  L5_2 = RegisterNetEvent
  L6_2 = "ls-phone:s:stopCall"
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = TriggerClientEvent
    L2_3 = "ls-phone:c:stopCall"
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L5_2(L6_2, L7_2)
  L5_2 = RegisterNetEvent
  L6_2 = "ls-phone:s:deletServerUser"
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = ipairs
    L2_3 = L4_2
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.serverId
      if L7_3 == A0_3 then
        L7_3 = table
        L7_3 = L7_3.remove
        L8_3 = L4_2
        L9_3 = L5_3
        L7_3(L8_3, L9_3)
      end
    end
  end
  L5_2(L6_2, L7_2)
  L5_2 = RegisterNetEvent
  L6_2 = "ls-phone:s:StartCallVideo"
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = source
    L2_3 = GetUserByPhoneNumber
    L3_3 = A0_3.dialnumber
    L2_3 = L2_3(L3_3)
    if nil ~= L2_3 then
      L3_3 = TriggerClientEvent
      L4_3 = "ls-phone:c:videoCall"
      L5_3 = L1_3
      L6_3 = L2_3.Source
      L3_3(L4_3, L5_3, L6_3)
    end
  end
  L5_2(L6_2, L7_2)
end
SetupPhone = L0_1
L0_1 = GetResourceState
L1_1 = "ls-core"
L0_1 = L0_1(L1_1)
if "started" == L0_1 then
  L0_1 = GetCurrentResourceName
  L0_1 = L0_1()
  if "ls-phone" == L0_1 then
    goto lbl_25
  end
end
L0_1 = GetResourceState
L1_1 = "ls-core"
L0_1 = L0_1(L1_1)
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = ""
    L1_2 = L0_1
    if "started" ~= L1_2 then
      L1_2 = GetResourceState
      L2_2 = "ls-core"
      L1_2 = L1_2(L2_2)
      if "started" == L1_2 then
        L0_2 = [[
ls-core is started. 
^8Please restart your server.^7 
Phone not will work.]]
      else
        L0_2 = "ls-core not found. Please install before trying to use phone. ^8Error Code 2^7"
      end
    end
    L1_2 = GetCurrentResourceName
    L1_2 = L1_2()
    if "ls-phone" ~= L1_2 then
      L1_2 = string
      L1_2 = L1_2.len
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      if L1_2 > 0 then
        L1_2 = L0_2
        L2_2 = [[

Phone name is ^8]]
        L3_2 = GetCurrentResourceName
        L3_2 = L3_2()
        L4_2 = "^7, change script name to ^8ls-phone^7. ^8Error Code 3^7"
        L1_2 = L1_2 .. L2_2 .. L3_2 .. L4_2
        L0_2 = L1_2
      else
        L1_2 = "Phone name is ^8"
        L2_2 = GetCurrentResourceName
        L2_2 = L2_2()
        L3_2 = "^7, change script name to ^8ls-phone^7. ^8Error Code 3^7"
        L1_2 = L1_2 .. L2_2 .. L3_2
        L0_2 = L1_2
      end
    end
    L1_2 = print
    L2_2 = L0_2
    L1_2(L2_2)
    L1_2 = Citizen
    L1_2 = L1_2.Wait
    L2_2 = 5000
    L1_2(L2_2)
  end
end
L1_1(L2_1)
goto lbl_43
::lbl_25::
L0_1 = exports
L0_1 = L0_1["ls-core"]
L1_1 = L0_1
L0_1 = L0_1.GetCoreObject
L0_1 = L0_1(L1_1)
LS_CORE = L0_1
L0_1 = GetResourceMetadata
L1_1 = GetCurrentResourceName
L1_1 = L1_1()
L2_1 = "version"
L0_1 = L0_1(L1_1, L2_1)
L1_1 = LS_CORE
L1_1 = L1_1.Functions
L1_1 = L1_1.GetVersionScript
L2_1 = L0_1
L3_1 = "ls-phone"
L1_1(L2_1, L3_1)
L1_1 = SetupPhone
L1_1()
::lbl_43::
