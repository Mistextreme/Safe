Config = {}

Config.Shared = {}

Config.Shared.Business = {
    ["ambulance"] = {
        employeeJob = "ambulance", -- The job of the employees at this business
        businessName = "ambulance", -- The name of the business
        title = "Ambulance",
        businessLabel = "Ambulance", -- The label of the business
        description = "Trust the healthcare industry. We are here for you..", -- A short description of the business
        rating = 3.7, -- The pre defined rating of the business
        isOnline = false, -- Whether the business is online or not
        image = "https://png.pngtree.com/png-clipart/20230110/ourmid/pngtree-3d-icon-of-hospital-heart-health-care-and-medical-concept-png-image_6557799.png", -- The URL of the image for the business
        
        requests = {}, -- A table of requests made to this business
    },
    ["police"] = {
        employeeJob = "police", -- The job of the employees at this business
        businessName = "police", -- The name of the business
        title = "LSPD",
        businessLabel = "LSPD", -- The label of the business
        description = "Trust the lspd industry. We are here for you.", -- A short description of the business
        rating = 3.7, -- The pre defined rating of the business
        isOnline = false, -- Whether the business is online or not
        image = "https://static.wikia.nocookie.net/vorpwiki/images/0/08/Lspd-420x420.png/revision/latest?cb=20191231235730&path-prefix=tr", -- The URL of the image for the business
        
        requests = {}, -- A table of requests made to this business
    }
}

VehKeyEvent = function(vehicle)
    TriggerEvent("vehiclekeys:client:SetOwner", Framework.Functions.GetPlate(vehicle))

end

Config.Shared.DefaultWallpapers = {
    ["img/backgrounds/iphone.png"] = true,
    ["img/backgrounds/blue.png"] = true,
    ["img/backgrounds/deeppurple.png"] = true,
    ["img/backgrounds/gold.png"] = true,
    ["img/backgrounds/midnight.png"] = true,
    ["img/backgrounds/purple.png"] = true,
    ["img/backgrounds/red.png"] = true,
    ["img/backgrounds/silver.png"] = true,
    ["img/backgrounds/spaceblack.png"] = true,
    ["img/backgrounds/starlight.png"] = true,
}