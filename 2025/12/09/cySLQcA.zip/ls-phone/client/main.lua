local L0_1, L1_1
LS_CORE = nil
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L0_2 = Config
  L0_2 = L0_2.Client
  L0_2 = L0_2.Framework
  Framework = L0_2
  isplayerdead = false
  L0_2 = {}
  L0_2.isOpen = false
  L0_2.Identifier = nil
  PhoneInfo = L0_2
  function L0_2()
    local L0_3, L1_3
    L0_3 = Citizen
    L0_3 = L0_3.CreateThread
    function L1_3()
      local L0_4, L1_4, L2_4, L3_4
      while true do
        L0_4 = Config
        L0_4 = L0_4.Client
        L0_4 = L0_4.InputsWhileFocus
        if not L0_4 then
          break
        end
        L0_4 = PhoneInfo
        L0_4 = L0_4.isOpen
        if not L0_4 then
          break
        end
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 18
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 69
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 92
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 106
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 122
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = Config
        L0_4 = L0_4.Client
        L0_4 = L0_4.CameraMovementFocus
        if not L0_4 then
          L0_4 = isInCamera
          if not L0_4 then
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 12
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 13
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 1
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 2
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 3
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 4
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 5
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
            L0_4 = DisableControlAction
            L1_4 = 0
            L2_4 = 6
            L3_4 = true
            L0_4(L1_4, L2_4, L3_4)
          end
        end
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 263
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 264
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 257
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 140
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 141
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 142
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 143
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 177
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 200
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 202
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 322
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 245
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 199
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 25
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 24
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 45
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 44
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 0
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 26
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 20
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 236
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 157
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 158
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 160
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 164
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 165
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 159
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 161
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 162
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 163
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 163
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 73
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 47
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 58
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = DisableControlAction
        L1_4 = 0
        L2_4 = 74
        L3_4 = true
        L0_4(L1_4, L2_4, L3_4)
        L0_4 = Citizen
        L0_4 = L0_4.Wait
        L1_4 = 3
        L0_4(L1_4)
      end
    end
    L0_3(L1_3)
  end
  CreateFocusActions = L0_2
  L0_2 = RegisterNetEvent
  L1_2 = "ls-phone:c:openPhone"
  function L2_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = PhoneInfo
    L2_3 = L2_3.isOpen
    if not L2_3 then
      L2_3 = isplayerdead
      if false == L2_3 then
        L2_3 = PhoneInfo
        L2_3.isOpen = true
        L2_3 = DoPhoneAnimation
        L3_3 = "cellphone_text_in"
        L2_3(L3_3)
        L2_3 = SetNuiFocus
        L3_3 = true
        L4_3 = true
        L2_3(L3_3, L4_3)
        L2_3 = SetNuiFocusKeepInput
        L3_3 = Config
        L3_3 = L3_3.Client
        L3_3 = L3_3.InputsWhileFocus
        L2_3(L3_3)
        L2_3 = CreateFocusActions
        L2_3()
        L2_3 = A0_3.info
        L2_3 = L2_3.MetaData
        L2_3 = L2_3.serialnumber
        L3_3 = PhoneInfo
        L3_3 = L3_3.Identifier
        if L3_3 ~= L2_3 then
          L3_3 = PhoneInfo
          L3_3 = L3_3.Identifier
          if nil ~= L3_3 then
            L3_3 = SendNUIMessage
            L4_3 = {}
            L4_3.action = "refreshJavascript"
            L3_3(L4_3)
            L3_3 = Wait
            L4_3 = 750
            L3_3(L4_3)
            L3_3 = SendNUIMessage
            L4_3 = {}
            L4_3.action = "open"
            L5_3 = A0_3.info
            L4_3.PhoneData = L5_3
            L4_3.Webhook = A1_3
            L3_3(L4_3)
        end
        else
          L3_3 = SendNUIMessage
          L4_3 = {}
          L4_3.action = "open"
          L5_3 = A0_3.info
          L4_3.PhoneData = L5_3
          L4_3.Webhook = A1_3
          L3_3(L4_3)
        end
        L3_3 = PhoneInfo
        L3_3.Identifier = L2_3
        L3_3 = SetTimeout
        L4_3 = 250
        function L5_3()
          local L0_4, L1_4
          L0_4 = newPhoneProp
          L0_4()
        end
        L3_3(L4_3, L5_3)
    end
    else
      L2_3 = ClosePhone
      L2_3()
      L2_3 = SendNUIMessage
      L3_3 = {}
      L3_3.action = "close"
      L2_3(L3_3)
    end
  end
  L0_2(L1_2, L2_2)
  L0_2 = RegisterNetEvent
  L1_2 = "ls-phone:c:airpodsUsed"
  function L2_2()
    local L0_3, L1_3
    L0_3 = SendNUIMessage
    L1_3 = {}
    L1_3.action = "airdropUsed"
    L0_3(L1_3)
  end
  L0_2(L1_2, L2_2)
  L0_2 = RegisterNetEvent
  L1_2 = "ls-phone:c:powerbankUse"
  function L2_2()
    local L0_3, L1_3
    L0_3 = SendNUIMessage
    L1_3 = {}
    L1_3.action = "powerBankUsage"
    L0_3(L1_3)
  end
  L0_2(L1_2, L2_2)
  L0_2 = RegisterNUICallback
  L1_2 = "closeNUI"
  function L2_2()
    local L0_3, L1_3
    L0_3 = ClosePhone
    L0_3()
  end
  L0_2(L1_2, L2_2)
  function L0_2(A0_3)
    local L1_3, L2_3, L3_3
    if nil == A0_3 then
      A0_3 = false
    end
    L1_3 = DestroyMobilePhone
    L1_3()
    L1_3 = PhoneInfo
    L1_3.isOpen = A0_3
    L1_3 = SetNuiFocus
    L2_3 = A0_3
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
    L1_3 = SetNuiFocusKeepInput
    L2_3 = Config
    L2_3 = L2_3.Client
    L2_3 = L2_3.InputsWhileFocus
    L1_3(L2_3)
    L1_3 = DoPhoneAnimation
    L2_3 = "cellphone_text_out"
    L1_3(L2_3)
    L1_3 = SetTimeout
    L2_3 = 400
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4
      L0_4 = StopAnimTask
      L1_4 = PlayerPedId
      L1_4 = L1_4()
      L2_4 = AnimationData
      L2_4 = L2_4.lib
      L3_4 = AnimationData
      L3_4 = L3_4.anim
      L4_4 = 2.5
      L0_4(L1_4, L2_4, L3_4, L4_4)
      L0_4 = deletePhone
      L0_4()
      L0_4 = AnimationData
      L0_4.lib = nil
      L0_4 = AnimationData
      L0_4.anim = nil
    end
    L1_3(L2_3, L3_3)
    isFrontCamera = false
  end
  ClosePhone = L0_2
  L0_2 = RegisterNUICallback
  L1_2 = "getWeather"
  function L2_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L2_3 = GetWeatherTypeTransition
    L2_3 = L2_3()
    L3_3 = Citizen
    L3_3 = L3_3.InvokeNative
    L4_3 = 6218213562023429539
    L3_3 = L3_3(L4_3)
    L4_3 = {}
    L5_3 = GetWeather
    L6_3 = L2_3
    L5_3 = L5_3(L6_3)
    L4_3.weatherCurrent = L5_3
    L5_3 = GetWeather
    L6_3 = GetNextWeatherTypeHashName
    L6_3, L7_3, L8_3, L9_3 = L6_3()
    L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
    L4_3.weatherNext = L5_3
    L5_3 = FtoC
    L6_3 = calcTemp
    L7_3 = getWeatherStringFromHash
    L8_3 = L3_3
    L7_3 = L7_3(L8_3)
    L8_3 = GetClockMonth
    L8_3 = L8_3()
    L9_3 = GetClockHours
    L9_3 = L9_3()
    L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
    L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
    L4_3.degree = L5_3
    L5_3 = A1_3
    L6_3 = L4_3
    L5_3(L6_3)
  end
  L0_2(L1_2, L2_2)
  function L0_2(A0_3)
    local L1_3, L2_3
    L1_3 = GetHashKey
    L2_3 = "THUNDER"
    L1_3 = L1_3(L2_3)
    if L1_3 == A0_3 then
      A0_3 = "thunder"
    else
      L1_3 = GetHashKey
      L2_3 = "RAIN"
      L1_3 = L1_3(L2_3)
      if L1_3 == A0_3 then
        A0_3 = "rain"
      else
        L1_3 = GetHashKey
        L2_3 = "EXTRASUNNY"
        L1_3 = L1_3(L2_3)
        if L1_3 == A0_3 then
          A0_3 = "extrasunny"
        else
          L1_3 = GetHashKey
          L2_3 = "CLOUDS"
          L1_3 = L1_3(L2_3)
          if L1_3 == A0_3 then
            A0_3 = "clouds"
          else
            L1_3 = GetHashKey
            L2_3 = "OVERCAST"
            L1_3 = L1_3(L2_3)
            if L1_3 == A0_3 then
              A0_3 = "overcast"
            else
              L1_3 = GetHashKey
              L2_3 = "CLEAR"
              L1_3 = L1_3(L2_3)
              if L1_3 == A0_3 then
                A0_3 = "clear"
              else
                L1_3 = GetHashKey
                L2_3 = "CLEARING"
                L1_3 = L1_3(L2_3)
                if L1_3 == A0_3 then
                  A0_3 = "clearing"
                else
                  L1_3 = GetHashKey
                  L2_3 = "SMOG"
                  L1_3 = L1_3(L2_3)
                  if L1_3 == A0_3 then
                    A0_3 = "smog"
                  else
                    L1_3 = GetHashKey
                    L2_3 = "FOGGY"
                    L1_3 = L1_3(L2_3)
                    if L1_3 == A0_3 then
                      A0_3 = "foggy"
                    else
                      L1_3 = GetHashKey
                      L2_3 = "XMAS"
                      L1_3 = L1_3(L2_3)
                      if L1_3 == A0_3 then
                        A0_3 = "xmas"
                      else
                        L1_3 = GetHashKey
                        L2_3 = "SNOWLIGHT"
                        L1_3 = L1_3(L2_3)
                        if L1_3 == A0_3 then
                          A0_3 = "snowlight"
                        else
                          L1_3 = GetHashKey
                          L2_3 = "BLIZZARD"
                          L1_3 = L1_3(L2_3)
                          if L1_3 == A0_3 then
                            A0_3 = "blizzard"
                          else
                            A0_3 = "unknown"
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
    return A0_3
  end
  GetWeather = L0_2
  MAX_INCREASE = 1.5
  MIN_INCREASE = 0.2
  RAND_FLUC = 0.2
  START_INCREASE_HR = 4
  STOP_INCREASE_HR = 16
  L0_2 = {}
  L1_2 = {}
  L2_2 = 36
  L3_2 = 20
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = {}
  L3_2 = 41
  L4_2 = 24
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L3_2 = {}
  L4_2 = 53
  L5_2 = 34
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L4_2 = {}
  L5_2 = 65
  L6_2 = 43
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L5_2 = {}
  L6_2 = 75
  L7_2 = 54
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  L6_2 = {}
  L7_2 = 82
  L8_2 = 61
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L7_2 = {}
  L8_2 = 86
  L9_2 = 66
  L7_2[1] = L8_2
  L7_2[2] = L9_2
  L8_2 = {}
  L9_2 = 85
  L10_2 = 64
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L9_2 = {}
  L10_2 = 78
  L11_2 = 58
  L9_2[1] = L10_2
  L9_2[2] = L11_2
  L10_2 = {}
  L11_2 = 66
  L12_2 = 46
  L10_2[1] = L11_2
  L10_2[2] = L12_2
  L11_2 = {}
  L12_2 = 53
  L13_2 = 37
  L11_2[1] = L12_2
  L11_2[2] = L13_2
  L12_2 = {}
  L13_2 = 43
  L14_2 = 28
  L12_2[1] = L13_2
  L12_2[2] = L14_2
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L0_2[7] = L7_2
  L0_2[8] = L8_2
  L0_2[9] = L9_2
  L0_2[10] = L10_2
  L0_2[11] = L11_2
  L0_2[12] = L12_2
  MonthData = L0_2
  L0_2 = {}
  L1_2 = "EXTRASUNNY"
  L2_2 = "CLEAR"
  L3_2 = "NEUTRAL"
  L4_2 = "SMOG"
  L5_2 = "FOGGY"
  L6_2 = "OVERCAST"
  L7_2 = "CLOUDS"
  L8_2 = "CLEARING"
  L9_2 = "RAIN"
  L10_2 = "THUNDER"
  L11_2 = "SNOW"
  L12_2 = "BLIZZARD"
  L13_2 = "SNOWLIGHT"
  L14_2 = "XMAS"
  L15_2 = "HALLOWEEN"
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L0_2[4] = L4_2
  L0_2[5] = L5_2
  L0_2[6] = L6_2
  L0_2[7] = L7_2
  L0_2[8] = L8_2
  L0_2[9] = L9_2
  L0_2[10] = L10_2
  L0_2[11] = L11_2
  L0_2[12] = L12_2
  L0_2[13] = L13_2
  L0_2[14] = L14_2
  L0_2[15] = L15_2
  AvailableWeatherTypes = L0_2
  function L0_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    if nil == A1_3 then
      L3_3 = GetClockMonth
      L3_3 = L3_3()
      A1_3 = L3_3
    end
    A1_3 = A1_3 + 1
    L3_3 = MonthData
    L3_3 = L3_3[A1_3]
    L3_3 = L3_3[1]
    L4_3 = MonthData
    L4_3 = L4_3[A1_3]
    L4_3 = L4_3[2]
    L5_3 = nil
    L6_3 = nil
    L7_3 = nil
    if "SNOW" == A0_3 or "BLIZZARD" == A0_3 or "SNOWLIGHT" == A0_3 or "XMAS" == A0_3 then
      L5_3 = 32
      L6_3 = -20
    elseif "EXTRASUNNY" == A0_3 then
      L5_3 = L3_3 + 20
      L6_3 = L4_3 + 20
    elseif "SMOG" == A0_3 then
      L5_3 = L3_3 + 10
      L6_3 = L4_3 + 10
    elseif "FOGGY" == A0_3 or "CLOUDS" == A0_3 or "THUNDER" == A0_3 or "HALLOWEEN" == A0_3 then
      L5_3 = L3_3 - 10
      L6_3 = L4_3 - 10
    else
      L5_3 = L3_3
      L6_3 = L4_3
    end
    L8_3 = randf
    L9_3 = L6_3
    L10_3 = L5_3
    L8_3 = L8_3(L9_3, L10_3)
    L7_3 = L8_3
    L8_3 = START_INCREASE_HR
    if A2_3 >= L8_3 then
      L8_3 = STOP_INCREASE_HR
      if A2_3 < L8_3 then
        if L5_3 <= L7_3 then
          L8_3 = randf
          L9_3 = RAND_FLUC
          L9_3 = -L9_3
          L10_3 = RAND_FLUC
          L8_3 = L8_3(L9_3, L10_3)
          L7_3 = L5_3 + L8_3
        else
          L8_3 = randf
          L9_3 = MIN_INCREASE
          L10_3 = MAX_INCREASE
          L8_3 = L8_3(L9_3, L10_3)
          L7_3 = L7_3 + L8_3
        end
    end
    elseif L6_3 >= L7_3 then
      L8_3 = randf
      L9_3 = RAND_FLUC
      L9_3 = -L9_3
      L10_3 = RAND_FLUC
      L8_3 = L8_3(L9_3, L10_3)
      L7_3 = L6_3 + L8_3
    else
      L8_3 = randf
      L9_3 = MIN_INCREASE
      L10_3 = MAX_INCREASE
      L8_3 = L8_3(L9_3, L10_3)
      L7_3 = L7_3 - L8_3
    end
    return L7_3
  end
  calcTemp = L0_2
  function L0_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = "?"
    L2_3 = 1
    L3_3 = AvailableWeatherTypes
    L3_3 = #L3_3
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = GetHashKey
      L7_3 = AvailableWeatherTypes
      L7_3 = L7_3[L5_3]
      L6_3 = L6_3(L7_3)
      if A0_3 == L6_3 then
        L6_3 = AvailableWeatherTypes
        L1_3 = L6_3[L5_3]
      end
    end
    return L1_3
  end
  getWeatherStringFromHash = L0_2
  function L0_2()
    local L0_3, L1_3
    L0_3 = GetClockYear
    L0_3 = L0_3()
    L1_3 = GetClockMonth
    L1_3 = L1_3()
    L0_3 = L0_3 + L1_3
    L1_3 = GetClockDayOfWeek
    L1_3 = L1_3()
    L0_3 = L0_3 + L1_3
    return L0_3
  end
  genSeed = L0_2
  function L0_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = math
    L2_3 = L2_3.randomseed
    L3_3 = GetClockDayOfMonth
    L3_3 = L3_3()
    L4_3 = GetClockYear
    L4_3 = L4_3()
    L3_3 = L3_3 + L4_3
    L4_3 = GetClockMonth
    L4_3 = L4_3()
    L3_3 = L3_3 + L4_3
    L4_3 = GetClockHours
    L4_3 = L4_3()
    L3_3 = L3_3 + L4_3
    L2_3(L3_3)
    L2_3 = math
    L2_3 = L2_3.random
    L2_3 = L2_3()
    L3_3 = A1_3 - A0_3
    L2_3 = L2_3 * L3_3
    L2_3 = A0_3 + L2_3
    return L2_3
  end
  randf = L0_2
  L0_2 = false
  L1_2 = AddEventHandler
  L2_2 = "showHud"
  function L3_2(A0_3)
    local L1_3
    L1_3 = not A0_3
    L0_2 = L1_3
  end
  L1_2(L2_2, L3_2)
  function L1_2(A0_3)
    local L1_3
    L1_3 = A0_3 - 32
    L1_3 = L1_3 * 0.5555555555555556
    return L1_3
  end
  FtoC = L1_2
  L1_2 = RegisterNUICallback
  L2_2 = "getInstagramUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getInstagramUser"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getPostData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4
      L0_4 = LS_CORE
      L0_4 = L0_4.Callback
      L0_4 = L0_4.Functions
      L0_4 = L0_4.TriggerCallback
      L1_4 = "ls-phone:s:getPostData"
      function L2_4(A0_5)
        local L1_5, L2_5
        L1_5 = A1_3
        L2_5 = A0_5
        L1_5(L2_5)
      end
      L3_4 = A0_3
      L0_4(L1_4, L2_4, L3_4)
    end
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllInstagramUsers"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllInstagramUsers"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateIgUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateIgUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createInstagramUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createInstagramUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllPostData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllPostData"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getInstgaramQuery"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getInstgaramQuery"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getDMData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getDMData"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllDM"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllDM"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createNewDM"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createNewDM"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateIgDM"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateIgDM"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateIgDM"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateInstagramDM"
      L2_3.dmdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createIgPost"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createIgPost"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "deleteIGPost"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:deleteIGPost"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateIgPost"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateInstagramPost"
      L2_3.postdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateIgPost"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateIgPost"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getTwitterUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getTwitterUser"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllTwitterUsers"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllTwitterUsers"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateTwUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateTwUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createTwitterUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createTwitterUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllTweetsData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllTweetsData"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateTwTweet"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateTwitterTweet"
      L2_3.postdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateTwTweet"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateTwTweet"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createTwTweet"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createTwTweet"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "deleteTWTTweet"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:deleteTWTTweet"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getNearbyPhones"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Functions
    L2_3 = L2_3.GetPlayersFromCoords
    L3_3 = GetEntityCoords
    L4_3 = PlayerPedId
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L4_3()
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L4_3 = 5
    L2_3 = L2_3(L3_3, L4_3)
    L3_3 = pairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = PlayerId
      L9_3 = L9_3()
      if L8_3 == L9_3 then
        L2_3[L7_3] = nil
      else
        L9_3 = GetPlayerServerId
        L10_3 = L8_3
        L9_3 = L9_3(L10_3)
        L2_3[L7_3] = L9_3
      end
    end
    L3_3 = LS_CORE
    L3_3 = L3_3.Callback
    L3_3 = L3_3.Functions
    L3_3 = L3_3.TriggerCallback
    L4_3 = "ls-phone:s:getPhoneData"
    function L5_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L6_3 = L2_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "sendImgAirdrop"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:sendImgAirdrop"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:sendImgAirdrop"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "airdropImageIncome"
    L2_3.airdropdata = A0_3
    L1_3(L2_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "shareNumber"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Functions
    L2_3 = L2_3.GetPlayersFromCoords
    L3_3 = GetEntityCoords
    L4_3 = PlayerPedId
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L4_3()
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L4_3 = 5
    L2_3 = L2_3(L3_3, L4_3)
    L3_3 = pairs
    L4_3 = L2_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = PlayerId
      L9_3 = L9_3()
      if L8_3 == L9_3 then
        L2_3[L7_3] = nil
      else
        L9_3 = GetPlayerServerId
        L10_3 = L8_3
        L9_3 = L9_3(L10_3)
        L2_3[L7_3] = L9_3
      end
    end
    L3_3 = TriggerServerEvent
    L4_3 = "ls-phone:s:shareNumber"
    L5_3 = L2_3
    L6_3 = A0_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:NumberShareInfo"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "shareNumbernotify"
    L2_3.isright = A0_3
    L1_3(L2_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:shareNumber"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "shareNumber"
    L2_3.shareddata = A0_3
    L1_3(L2_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getPlayerCoords"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getPlayerCoords"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createSnapchatUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createSnapchatUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getSnapchatUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getSnapchatUser"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getTweetData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4
      L0_4 = LS_CORE
      L0_4 = L0_4.Callback
      L0_4 = L0_4.Functions
      L0_4 = L0_4.TriggerCallback
      L1_4 = "ls-phone:s:getTweetData"
      function L2_4(A0_5)
        local L1_5, L2_5
        L1_5 = A1_3
        L2_5 = A0_5
        L1_5(L2_5)
      end
      L3_4 = A0_3
      L0_4(L1_4, L2_4, L3_4)
    end
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getSnapchatUsers"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getSnapchatUsers"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllChats"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllChats"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateSCUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateSCUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createNewChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createNewChat"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateSCChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateSCChat"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateSCChat"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateSnapchatChat"
      L2_3.scdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAdvert"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAdvert"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllAdverts"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllAdverts"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createNewAdvert"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createNewAdvert"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:createNewAdvert"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "newAdvertCreated"
      L2_3.advert = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getNews"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getNews"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllNews"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllNews"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "controlnewsjob"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:controlnewsjob"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createNewNews"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createNewNews"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:createNewNews"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "newNewsCreated"
      L2_3.advert = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getCash"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getCash"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getDarkchatUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getDarkchatUser"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getDarkchatChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4
      L0_4 = LS_CORE
      L0_4 = L0_4.Callback
      L0_4 = L0_4.Functions
      L0_4 = L0_4.TriggerCallback
      L1_4 = "ls-phone:s:getDarkchatChat"
      function L2_4(A0_5)
        local L1_5, L2_5
        L1_5 = A1_3
        L2_5 = A0_5
        L1_5(L2_5)
      end
      L3_4 = A0_3
      L0_4(L1_4, L2_4, L3_4)
    end
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllDarkchatUsers"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllDarkchatUsers"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateDCUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateDCUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createDarkchatUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createDarkchatUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllDarkchatChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllDarkchatChat"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createNewDarkChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createNewDarkChat"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateDCChat"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateDCChat"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateDCChat"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateDarkchatChat"
      L2_3.chatdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getMessages"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getMessages"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllMessages"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllMessages"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createMessage"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createMessage"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateContactsMessage"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateContactsMessage"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateContactMessages"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "updateContactMessages"
    L2_3.chatdata = A0_3
    L3_3 = PhoneInfo
    L3_3 = L3_3.isOpen
    L2_3.phonestate = L3_3
    L1_3(L2_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getWhatsappMessages"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getWhatsappMessages"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllWhatsappMessages"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllWhatsappMessages"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createWPMessage"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createWPMessage"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateWhatsappMessage"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateWhatsappMessage"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNetEvent
  L2_2 = "ls-phone:c:updateWhatsappMessage"
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "updateWhatsappMessage"
      L2_3.chatdata = A0_3
      L1_3(L2_3)
    end
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getWhatsappUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getWhatsappUser"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllWhatsappUsers"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllWhatsappUsers"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "createWPUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:createWPUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "updateWhatsappUser"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:updateWhatsappUser"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = A1_3
    L3_3 = true
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getAllUberRequests"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllUberRequests"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getLocationData"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L2_3 = GetEntityCoords
    L3_3 = PlayerPedId
    L3_3, L4_3, L5_3, L6_3, L7_3 = L3_3()
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
    L3_3 = vector3
    L4_3 = L2_3.x
    L5_3 = L2_3.y
    L6_3 = 0
    L3_3 = L3_3(L4_3, L5_3, L6_3)
    L4_3 = vector3
    L5_3 = A0_3.toLocation
    L5_3 = L5_3.y
    L6_3 = A0_3.toLocation
    L6_3 = L6_3.x
    L7_3 = 0
    L4_3 = L4_3(L5_3, L6_3, L7_3)
    L3_3 = L3_3 - L4_3
    L3_3 = #L3_3
    L4_3 = A1_3
    L5_3 = {}
    L6_3 = {}
    L7_3 = L2_3.x
    L6_3.x = L7_3
    L7_3 = L2_3.y
    L6_3.y = L7_3
    L7_3 = L2_3.z
    L6_3.z = L7_3
    L5_3.PlayerCoords = L6_3
    L5_3.PlayerDistance = L3_3
    L6_3 = Config
    L6_3 = L6_3.Client
    L6_3 = L6_3.UberPrice
    L6_3 = L3_3 * L6_3
    L5_3.CalculatedPrice = L6_3
    L4_3(L5_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "getUberLocation"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = GetEntityCoords
    L3_3 = GetPlayerPed
    L4_3 = GetPlayerFromServerId
    L5_3 = A0_3.currentUber
    L4_3, L5_3, L6_3 = L4_3(L5_3)
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3, L5_3, L6_3)
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    L3_3 = A1_3
    L4_3 = {}
    L5_3 = {}
    L6_3 = L2_3.x
    L5_3.x = L6_3
    L6_3 = L2_3.y
    L5_3.y = L6_3
    L6_3 = L2_3.z
    L5_3.z = L6_3
    L4_3.PlayerCoords = L5_3
    L3_3(L4_3)
  end
  L1_2(L2_2, L3_2)
  function L1_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = GetLabelText
    L2_3 = GetNameOfZone
    L3_3 = A0_3.x
    L4_3 = A0_3.y
    L5_3 = A0_3.z
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3, L4_3, L5_3)
    L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3)
    L2_3 = GetStreetNameAtCoord
    L3_3 = A0_3.x
    L4_3 = A0_3.y
    L5_3 = A0_3.z
    L2_3 = L2_3(L3_3, L4_3, L5_3)
    L3_3 = GetStreetNameFromHashKey
    L4_3 = L2_3
    L3_3 = L3_3(L4_3)
    currentStreetName = L3_3
    L3_3 = currentStreetName
    L4_3 = ", "
    L5_3 = L1_3
    L3_3 = L3_3 .. L4_3 .. L5_3
    playerStreetsLocation = L3_3
    L3_3 = playerStreetsLocation
    return L3_3
  end
  getStreetandZone = L1_2
  L1_2 = RegisterNUICallback
  L2_2 = "uberRequest"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = getStreetandZone
    L3_3 = vector3
    L4_3 = A0_3.location
    L4_3 = L4_3.y
    L5_3 = A0_3.location
    L5_3 = L5_3.x
    L6_3 = 1
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3, L5_3, L6_3)
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    A0_3.street = L2_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:uberRequest"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = RegisterNUICallback
  L2_2 = "deleteUberRequest"
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:deleteUberRequest"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = {}
  L2_2 = RegisterNUICallback
  L3_2 = "acceptedRequest"
  function L4_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L1_2 = A0_3
    L2_3 = SetNewWaypoint
    L3_3 = A0_3.personLocation
    L3_3 = L3_3.x
    L4_3 = A0_3.personLocation
    L4_3 = L4_3.y
    L2_3(L3_3, L4_3)
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:acceptedRequest"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:deleteUberRequest"
    L4_3 = A0_3
    L2_3(L3_3, L4_3)
    L2_3 = Citizen
    L2_3 = L2_3.CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4
      while true do
        L0_4 = GetEntityCoords
        L1_4 = PlayerPedId
        L1_4, L2_4, L3_4, L4_4, L5_4 = L1_4()
        L0_4 = L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L1_4 = vector3
        L2_4 = L1_2.personLocation
        L2_4 = L2_4.x
        L3_4 = L1_2.personLocation
        L3_4 = L3_4.y
        L4_4 = L1_2.personLocation
        L4_4 = L4_4.z
        L1_4 = L1_4(L2_4, L3_4, L4_4)
        L2_4 = vector3
        L3_4 = L0_4.x
        L4_4 = L0_4.y
        L5_4 = L0_4.z
        L2_4 = L2_4(L3_4, L4_4, L5_4)
        L1_4 = L1_4 - L2_4
        L1_4 = #L1_4
        if L1_4 < 10 then
          L2_4 = TriggerServerEvent
          L3_4 = "ls-phone:s:uberDeleteMap"
          L4_4 = L1_2
          L2_4(L3_4, L4_4)
          L2_4 = SetNewWaypoint
          L3_4 = L1_2.location
          L3_4 = L3_4.y
          L4_4 = L1_2.location
          L4_4 = L4_4.x
          L2_4(L3_4, L4_4)
          break
        end
        L2_4 = Citizen
        L2_4 = L2_4.Wait
        L3_4 = 500
        L2_4(L3_4)
      end
    end
    L2_3(L3_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:c:uberDeleteMap"
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "clearUberMap"
      L1_3(L2_3)
    end
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:c:uberRequest"
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "newUberRequest"
      L2_3.uberRequest = A0_3
      L1_3(L2_3)
    end
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:c:deleteUberRequest"
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "deleteUberRequest"
      L2_3.uberid = A0_3
      L1_3(L2_3)
    end
  end
  L2_2(L3_2, L4_2)
  L2_2 = RegisterNetEvent
  L3_2 = "ls-phone:c:sendNotification"
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = PhoneInfo
    L1_3 = L1_3.isOpen
    if L1_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "newNotification"
      L2_3.notifydata = A0_3
      L1_3(L2_3)
    end
  end
  L2_2(L3_2, L4_2)
  L2_2 = nil
  L3_2 = true
  L4_2 = RegisterNUICallback
  L5_2 = "getUberEatsJob"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = math
    L2_3 = L2_3.random
    L3_3 = Config
    L3_3 = L3_3.Client
    L3_3 = L3_3.UberEats
    L3_3 = L3_3.Locations
    L3_3 = #L3_3
    L2_3 = L2_3(L3_3)
    L3_3 = Config
    L3_3 = L3_3.Client
    L3_3 = L3_3.UberEats
    L3_3 = L3_3.Locations
    L3_3 = L3_3[L2_3]
    L2_2 = L3_3
    L3_3 = Citizen
    L3_3 = L3_3.CreateThread
    function L4_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4
      L0_4 = 5
      L1_4 = true
      L2_4 = GetEntityCoords
      L3_4 = PlayerPedId
      L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4 = L3_4()
      L2_4 = L2_4(L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4)
      L3_4 = L2_2
      L2_4 = L2_4 - L3_4
      L2_4 = #L2_4
      L3_4 = SetNewWaypoint
      L4_4 = L2_2.x
      L5_4 = L2_2.y
      L3_4(L4_4, L5_4)
      while L1_4 do
        L3_4 = GetEntityCoords
        L4_4 = PlayerPedId
        L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4 = L4_4()
        L3_4 = L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4)
        L4_4 = L2_2
        L3_4 = L3_4 - L4_4
        L3_4 = #L3_4
        if L3_4 < 20 then
          L4_4 = IsControlJustPressed
          L5_4 = 0
          L6_4 = 46
          L4_4 = L4_4(L5_4, L6_4)
          if L4_4 and L3_4 <= 2 then
            L4_4 = ESX
            L4_4 = L4_4.Progressbar
            L5_4 = "Delivering product."
            L6_4 = 1000
            L7_4 = {}
            L7_4.FreezePlayer = true
            L8_4 = {}
            L8_4.type = "anim"
            L8_4.dict = "random@domestic"
            L8_4.lib = "pickup_low"
            L7_4.animation = L8_4
            function L8_4()
              local L0_5, L1_5, L2_5
              L0_5 = false
              L2_2 = L0_5
              L0_5 = false
              L1_4 = L0_5
              L0_5 = Config
              L0_5 = L0_5.Client
              L0_5 = L0_5.HideText
              L0_5()
              L0_5 = ClearPedTasks
              L1_5 = PlayerPedId
              L1_5, L2_5 = L1_5()
              L0_5(L1_5, L2_5)
              L0_5 = TriggerServerEvent
              L1_5 = "ls-phone:s:uberDeliver"
              L2_5 = L2_4
              L0_5(L1_5, L2_5)
            end
            L7_4.onFinish = L8_4
            function L8_4()
              local L0_5, L1_5
            end
            L7_4[1] = L8_4
            L4_4(L5_4, L6_4, L7_4)
          elseif L3_4 <= 2 then
            L4_4 = L3_2
            if not L4_4 then
              L4_4 = Config
              L4_4 = L4_4.Client
              L4_4 = L4_4.DisplayText
              L4_4()
              L4_4 = true
              L3_2 = L4_4
            end
          elseif L3_4 > 2 then
            L4_4 = L3_2
            if L4_4 then
              L4_4 = Config
              L4_4 = L4_4.Client
              L4_4 = L4_4.HideText
              L4_4()
              L4_4 = false
              L3_2 = L4_4
            end
          end
          L4_4 = DrawMarker
          L5_4 = 20
          L6_4 = L2_2.x
          L7_4 = L2_2.y
          L8_4 = L2_2.z
          L9_4 = 0
          L10_4 = 0
          L11_4 = 0
          L12_4 = 0
          L13_4 = 0
          L14_4 = 0
          L15_4 = 2.001
          L16_4 = 2.0001
          L17_4 = 0.5001
          L18_4 = 0
          L19_4 = 155
          L20_4 = 255
          L21_4 = 200
          L22_4 = 0
          L23_4 = 0
          L24_4 = 0
          L25_4 = 0
          L4_4(L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4, L25_4)
          L0_4 = 5
        else
          L4_4 = L3_2
          if L4_4 then
            L4_4 = Config
            L4_4 = L4_4.Client
            L4_4 = L4_4.HideText
            L4_4()
            L4_4 = false
            L3_2 = L4_4
          end
          L0_4 = 1000
        end
        L4_4 = Citizen
        L4_4 = L4_4.Wait
        L5_4 = L0_4
        L4_4(L5_4)
      end
    end
    L3_3(L4_3)
    L3_3 = A1_3
    L4_3 = {}
    L5_3 = L2_2.x
    L4_3.x = L5_3
    L5_3 = L2_2.y
    L4_3.y = L5_3
    L3_3(L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getCryptoTransactions"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getCryptoTransactions"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getAllMails"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllMails"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getBank"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getBank"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "tryToSendMoney"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:tryToSendMoney"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:sendinfowalletother"
  function L6_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "giveinfowallet"
    L2_3.amount = A0_3
    L1_3(L2_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "removeMoney"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:removeMoney"
    L4_3 = A0_3.cashAmount
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "addMoney"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:addMoney"
    L4_3 = A0_3.cashAmount
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "setWaypoint"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = SetNewWaypoint
    L3_3 = A0_3.x
    L4_3 = A0_3.y
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNetEvent
  L5_2 = "ls-phone:c:sendServiceMessage"
  function L6_2(A0_3)
    local L1_3, L2_3
    L1_3 = Config
    L1_3 = L1_3.Shared
    L1_3 = L1_3.Business
    L2_3 = A0_3.service
    L1_3 = L1_3[L2_3]
    L1_3 = L1_3.employeeJob
    L2_3 = A0_3.currentPlayerJob
    if L1_3 == L2_3 then
      L1_3 = SendNUIMessage
      L2_3 = {}
      L2_3.action = "newServiceNotification"
      L2_3.serviceData = A0_3
      L1_3(L2_3)
    end
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "sendServiceMessage"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = GetEntityCoords
    L3_3 = PlayerPedId
    L3_3, L4_3, L5_3 = L3_3()
    L2_3 = L2_3(L3_3, L4_3, L5_3)
    L3_3 = {}
    L4_3 = L2_3.x
    L3_3.x = L4_3
    L4_3 = L2_3.y
    L3_3.y = L4_3
    L4_3 = L2_3.z
    L3_3.z = L4_3
    A0_3.location = L3_3
    L3_3 = TriggerServerEvent
    L4_3 = "ls-phone:s:sendServiceMessage"
    L5_3 = A0_3
    L3_3(L4_3, L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getAllBusiness"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllBusiness"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getAllBusinessNotifications"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getAllBusinessNotifications"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = RegisterNUICallback
  L5_2 = "getServiceData"
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getServiceData"
    function L4_3(A0_4)
      local L1_4, L2_4
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L5_3 = A0_3.identifier
    L2_3(L3_3, L4_3, L5_3)
  end
  L4_2(L5_2, L6_2)
  L4_2 = false
  L5_2 = nil
  L6_2 = RegisterNUICallback
  L7_2 = "getCars"
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getCars"
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L1_4 = pairs
      L2_4 = A0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L7_4 = print
        L8_4 = json
        L8_4 = L8_4.encode
        L9_4 = L6_4.model
        L8_4, L9_4 = L8_4(L9_4)
        L7_4(L8_4, L9_4)
        L7_4 = A0_4[L5_4]
        L8_4 = GetDisplayNameFromVehicleModel
        L9_4 = L6_4.model
        L9_4 = L9_4.model
        L8_4 = L8_4(L9_4)
        L7_4.model = L8_4
      end
      L1_4 = A1_3
      L2_4 = A0_4
      L1_4(L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L6_2(L7_2, L8_2)
  L6_2 = RegisterNUICallback
  L7_2 = "sendRequestValet"
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = LS_CORE
    L1_3 = L1_3.Callback
    L1_3 = L1_3.Functions
    L1_3 = L1_3.TriggerCallback
    L2_3 = "ls-phone:s:getVehicleFromPlate"
    function L3_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4
      L1_4 = json
      L1_4 = L1_4.decode
      L2_4 = A0_4.vehicle
      L1_4 = L1_4(L2_4)
      A0_4.vehicle = L1_4
      L1_4 = A0_4.vehicle
      A0_4.mods = L1_4
      L1_4 = TriggerServerEvent
      L2_4 = "ls-phone:s:changeVehicleDatabaseStatus"
      L3_4 = A0_4.plate
      L1_4(L2_4, L3_4)
      L1_4 = PlayerPedId
      L1_4 = L1_4()
      L2_4 = GetEntityCoords
      L3_4 = L1_4
      L2_4 = L2_4(L3_4)
      L3_4 = 999748158
      L4_4 = A0_4.vehicle
      L4_4 = L4_4.model
      while true do
        L5_4 = HasModelLoaded
        L6_4 = L3_4
        L5_4 = L5_4(L6_4)
        if L5_4 then
          break
        end
        L5_4 = RequestModel
        L6_4 = L3_4
        L5_4 = L5_4(L6_4)
        if not L5_4 then
          break
        end
        L5_4 = RequestModel
        L6_4 = L3_4
        L5_4(L6_4)
        L5_4 = Citizen
        L5_4 = L5_4.Wait
        L6_4 = 0
        L5_4(L6_4)
      end
      L5_4 = SpawnVehicle
      L6_4 = L2_4.x
      L7_4 = L2_4.y
      L8_4 = L2_4.z
      L9_4 = L4_4
      L10_4 = L3_4
      L11_4 = A0_4.mods
      L5_4(L6_4, L7_4, L8_4, L9_4, L10_4, L11_4)
    end
    L4_3 = A0_3.plate
    L1_3(L2_3, L3_3, L4_3)
  end
  L6_2(L7_2, L8_2)
  function L6_2(A0_3, A1_3, A2_3, A3_3, A4_3, A5_3)
    local L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L6_3 = GetClosestVehicleNodeWithHeading
    L7_3 = math
    L7_3 = L7_3.random
    L8_3 = -100
    L9_3 = 100
    L7_3 = L7_3(L8_3, L9_3)
    L7_3 = A0_3 + L7_3
    L8_3 = math
    L8_3 = L8_3.random
    L9_3 = -100
    L10_3 = 100
    L8_3 = L8_3(L9_3, L10_3)
    L8_3 = A1_3 + L8_3
    L9_3 = A2_3
    L10_3 = 0
    L11_3 = 3
    L12_3 = 0
    L6_3, L7_3, L8_3 = L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
    L9_3 = Framework
    L9_3 = L9_3.Game
    L9_3 = L9_3.SpawnVehicle
    L10_3 = A3_3
    L11_3 = L7_3
    L12_3 = L8_3
    function L13_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
      L1_4 = SetVehicleHasBeenOwnedByPlayer
      L2_4 = A0_4
      L3_4 = true
      L1_4(L2_4, L3_4)
      L1_4 = SetEntityAsMissionEntity
      L2_4 = A0_4
      L3_4 = true
      L4_4 = true
      L1_4(L2_4, L3_4, L4_4)
      L1_4 = ClearAreaOfVehicles
      L2_4 = GetEntityCoords
      L3_4 = A0_4
      L2_4 = L2_4(L3_4)
      L3_4 = 5000
      L4_4 = false
      L5_4 = false
      L6_4 = false
      L7_4 = false
      L8_4 = false
      L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4)
      L1_4 = SetVehicleOnGroundProperly
      L2_4 = A0_4
      L1_4(L2_4)
      L1_4 = Framework
      L1_4 = L1_4.Game
      L1_4 = L1_4.SetVehicleProperties
      L2_4 = A0_4
      L3_4 = A5_3
      L1_4(L2_4, L3_4)
      L1_4 = CreatePedInsideVehicle
      L2_4 = A0_4
      L3_4 = 26
      L4_4 = A4_3
      L5_4 = -1
      L6_4 = true
      L7_4 = false
      L1_4 = L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
      L5_2 = L1_4
      L1_4 = AddBlipForEntity
      L2_4 = A0_4
      L1_4 = L1_4(L2_4)
      mechBlip = L1_4
      L1_4 = SetBlipFlashes
      L2_4 = mechBlip
      L3_4 = true
      L1_4(L2_4, L3_4)
      L1_4 = SetBlipColour
      L2_4 = mechBlip
      L3_4 = 5
      L1_4(L2_4, L3_4)
      L1_4 = GoToTarget
      L2_4 = A0_3
      L3_4 = A1_3
      L4_4 = A2_3
      L5_4 = A0_4
      L6_4 = L5_2
      L7_4 = A3_3
      L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
    end
    L9_3(L10_3, L11_3, L12_3, L13_3)
  end
  SpawnVehicle = L6_2
  function L6_2(A0_3, A1_3, A2_3, A3_3, A4_3, A5_3, A6_3)
    local L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L7_3 = true
    L4_2 = L7_3
    while true do
      L7_3 = L4_2
      if not L7_3 then
        break
      end
      L7_3 = Citizen
      L7_3 = L7_3.Wait
      L8_3 = 500
      L7_3(L8_3)
      L7_3 = PlayerPedId
      L7_3 = L7_3()
      L8_3 = GetEntityCoords
      L9_3 = L7_3
      L8_3 = L8_3(L9_3)
      L9_3 = SetDriverAbility
      L10_3 = A4_3
      L11_3 = 1.0
      L9_3(L10_3, L11_3)
      L9_3 = SetDriverAggressiveness
      L10_3 = A4_3
      L11_3 = 0.0
      L9_3(L10_3, L11_3)
      L9_3 = TaskVehicleDriveToCoord
      L10_3 = A4_3
      L11_3 = A3_3
      L12_3 = L8_3.x
      L13_3 = L8_3.y
      L14_3 = L8_3.z
      L15_3 = 20.0
      L16_3 = 0
      L17_3 = A5_3
      L18_3 = 4457279
      L19_3 = 1
      L20_3 = true
      L9_3(L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
      L9_3 = GetEntityCoords
      L10_3 = A3_3
      L9_3 = L9_3(L10_3)
      L9_3 = L8_3 - L9_3
      L9_3 = #L9_3
      if not (L9_3 < 15) then
        L10_3 = 150
        if not (L9_3 > L10_3) then
          goto lbl_72
        end
      end
      L10_3 = VehKeyEvent
      L11_3 = A3_3
      L10_3(L11_3)
      L10_3 = RemoveBlip
      L11_3 = mechBlip
      L10_3(L11_3)
      L10_3 = TaskVehicleTempAction
      L11_3 = A4_3
      L12_3 = A3_3
      L13_3 = 27
      L14_3 = 6000
      L10_3(L11_3, L12_3, L13_3, L14_3)
      L10_3 = SetEntityHealth
      L11_3 = L5_2
      L12_3 = 2000
      L10_3(L11_3, L12_3)
      L10_3 = GoToTargetWalking
      L11_3 = A0_3
      L12_3 = A1_3
      L13_3 = A2_3
      L14_3 = A3_3
      L15_3 = A4_3
      L10_3(L11_3, L12_3, L13_3, L14_3, L15_3)
      L10_3 = false
      L4_2 = L10_3
      ::lbl_72::
    end
  end
  GoToTarget = L6_2
  function L6_2(A0_3, A1_3, A2_3, A3_3, A4_3)
    local L5_3, L6_3, L7_3, L8_3
    L5_3 = Citizen
    L5_3 = L5_3.Wait
    L6_3 = 500
    L5_3(L6_3)
    L5_3 = TaskWanderStandard
    L6_3 = A4_3
    L7_3 = 10.0
    L8_3 = 10
    L5_3(L6_3, L7_3, L8_3)
    L5_3 = TriggerServerEvent
    L6_3 = "ls-phone:s:deletePed"
    L5_3(L6_3)
    L5_3 = Citizen
    L5_3 = L5_3.Wait
    L6_3 = 35000
    L5_3(L6_3)
    L5_3 = DeletePed
    L6_3 = L5_2
    L5_3(L6_3)
    L5_3 = nil
    L5_2 = L5_3
  end
  GoToTargetWalking = L6_2
  L6_2 = RegisterNUICallback
  L7_2 = "getNearbyConnections"
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L2_3 = GetEntityCoords
    L3_3 = PlayerPedId
    L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L3_3()
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    L3_3 = {}
    L4_3 = pairs
    L5_3 = Config
    L5_3 = L5_3.Client
    L5_3 = L5_3.WiFi
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = 0
      L11_3 = L9_3.coords
      L11_3 = L11_3 - L2_3
      L11_3 = #L11_3
      if L11_3 <= 10 then
        L10_3 = 4
      elseif L11_3 > 10 and L11_3 <= 20 then
        L10_3 = 3
      elseif L11_3 > 20 and L11_3 <= 30 then
        L10_3 = 2
      elseif L11_3 > 30 and L11_3 <= 50 then
        L10_3 = 1
      end
      if 0 ~= L10_3 then
        L12_3 = L9_3.identifier
        L13_3 = {}
        L14_3 = L9_3.identifier
        L13_3.identifier = L14_3
        L14_3 = L9_3.label
        L13_3.label = L14_3
        L14_3 = L9_3.cspeed
        L13_3.cspeed = L14_3
        L14_3 = L9_3.secure
        L13_3.secure = L14_3
        L14_3 = L9_3.passcode
        L13_3.passcode = L14_3
        L14_3 = L9_3.coords
        L13_3.coords = L14_3
        L13_3.wave = L10_3
        L3_3[L12_3] = L13_3
      end
    end
    L4_3 = A1_3
    L5_3 = L3_3
    L4_3(L5_3)
  end
  L6_2(L7_2, L8_2)
  L6_2 = RegisterNUICallback
  L7_2 = "getMapCoords"
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L2_3 = GetEntityCoords
    L3_3 = PlayerPedId
    L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3 = L3_3()
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
    L3_3 = GetEntityHeading
    L4_3 = PlayerPedId
    L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3 = L4_3()
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
    L4_3 = {}
    L5_3 = A0_3.getBlips
    if L5_3 then
      L5_3 = Config
      L5_3 = L5_3.Client
      L5_3 = L5_3.UseBlipsOnMap
      if L5_3 then
        L5_3 = 0
        L6_3 = 802
        L7_3 = 1
        for L8_3 = L5_3, L6_3, L7_3 do
          L9_3 = GetFirstBlipInfoId
          L10_3 = L8_3
          L9_3 = L9_3(L10_3)
          L10_3 = DoesBlipExist
          L11_3 = L9_3
          L10_3 = L10_3(L11_3)
          if L10_3 then
            L10_3 = GetBlipCoords
            L11_3 = L9_3
            L10_3 = L10_3(L11_3)
            L11_3 = table
            L11_3 = L11_3.insert
            L12_3 = L4_3
            L13_3 = {}
            L14_3 = {}
            L15_3 = L10_3.x
            L14_3.x = L15_3
            L15_3 = L10_3.y
            L14_3.y = L15_3
            L15_3 = L10_3.z
            L14_3.z = L15_3
            L13_3.coords = L14_3
            L14_3 = GetBlipSprite
            L15_3 = L9_3
            L14_3 = L14_3(L15_3)
            L13_3.blipid = L14_3
            L11_3(L12_3, L13_3)
            while true do
              L11_3 = GetNextBlipInfoId
              L12_3 = L8_3
              L11_3 = L11_3(L12_3)
              L12_3 = DoesBlipExist
              L13_3 = L11_3
              L12_3 = L12_3(L13_3)
              if L12_3 then
                L12_3 = GetBlipCoords
                L13_3 = L11_3
                L12_3 = L12_3(L13_3)
                L13_3 = table
                L13_3 = L13_3.insert
                L14_3 = L4_3
                L15_3 = {}
                L16_3 = {}
                L17_3 = L12_3.x
                L16_3.x = L17_3
                L17_3 = L12_3.y
                L16_3.y = L17_3
                L17_3 = L12_3.z
                L16_3.z = L17_3
                L15_3.coords = L16_3
                L16_3 = GetBlipSprite
                L17_3 = L11_3
                L16_3 = L16_3(L17_3)
                L15_3.blipid = L16_3
                L13_3(L14_3, L15_3)
              else
                break
              end
            end
          end
        end
      end
    end
    L5_3 = A1_3
    L6_3 = {}
    L6_3.blips = L4_3
    L7_3 = {}
    L8_3 = {}
    L9_3 = L2_3.x
    L8_3.x = L9_3
    L9_3 = L2_3.y
    L8_3.y = L9_3
    L9_3 = L2_3.z
    L8_3.z = L9_3
    L7_3.coords = L8_3
    L7_3.heading = L3_3
    L6_3.player = L7_3
    L5_3(L6_3)
  end
  L6_2(L7_2, L8_2)
  L6_2 = {}
  L7_2 = {}
  L8_2 = false
  L9_2 = RegisterNUICallback
  L10_2 = "soundActions"
  function L11_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = A0_3.action
    if "play" == L2_3 then
      L2_3 = TriggerServerEvent
      L3_3 = "ls-phone:s:songAction"
      L4_3 = A0_3
      L2_3(L3_3, L4_3)
    else
      L2_3 = A0_3.action
      if "play2d" == L2_3 then
        L2_3 = A0_3.identifier
        L3_3 = L2_3.identifier
        L2_3 = L6_2
        L2_3[L3_3] = A0_3
        L2_3 = exports
        L2_3 = L2_3.xsound
        L3_3 = L2_3
        L2_3 = L2_3.PlayUrl
        L4_3 = A0_3.identifier
        L4_3 = L4_3.identifier
        L5_3 = A0_3.identifier
        L5_3 = L5_3.url
        L6_3 = A0_3.songVolume
        L2_3(L3_3, L4_3, L5_3, L6_3)
      else
        L2_3 = A0_3.action
        if "pause" == L2_3 then
          L2_3 = TriggerServerEvent
          L3_3 = "ls-phone:s:songAction"
          L4_3 = A0_3
          L2_3(L3_3, L4_3)
        else
          L2_3 = A0_3.action
          if "resume" == L2_3 then
            L2_3 = TriggerServerEvent
            L3_3 = "ls-phone:s:songAction"
            L4_3 = A0_3
            L2_3(L3_3, L4_3)
          else
            L2_3 = A0_3.action
            if "delete" == L2_3 then
              L2_3 = TriggerServerEvent
              L3_3 = "ls-phone:s:songAction"
              L4_3 = A0_3
              L2_3(L3_3, L4_3)
            else
              L2_3 = A0_3.action
              if "changedelete" == L2_3 then
                L2_3 = TriggerServerEvent
                L3_3 = "ls-phone:s:songAction"
                L4_3 = A0_3
                L2_3(L3_3, L4_3)
              else
                L2_3 = A0_3.action
                if "changestart" == L2_3 then
                  L2_3 = exports
                  L2_3 = L2_3.xsound
                  L3_3 = L2_3
                  L2_3 = L2_3.getTimeStamp
                  L4_3 = A0_3.identifier
                  L4_3 = L4_3.identifier
                  L2_3 = L2_3(L3_3, L4_3)
                  A0_3.timestamp = L2_3
                  L2_3 = TriggerServerEvent
                  L3_3 = "ls-phone:s:songAction"
                  L4_3 = A0_3
                  L2_3(L3_3, L4_3)
                else
                  L2_3 = A0_3.action
                  if "changetimestamp" == L2_3 then
                    L2_3 = TriggerServerEvent
                    L3_3 = "ls-phone:s:songAction"
                    L4_3 = A0_3
                    L2_3(L3_3, L4_3)
                  end
                end
              end
            end
          end
        end
      end
    end
  end
  L9_2(L10_2, L11_2)
  L9_2 = RegisterNUICallback
  L10_2 = "getSoundDuration"
  function L11_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = A1_3
    L3_3 = {}
    L4_3 = exports
    L4_3 = L4_3.xsound
    L5_3 = L4_3
    L4_3 = L4_3.getTimeStamp
    L6_3 = A0_3.identifier
    L6_3 = L6_3.identifier
    L4_3 = L4_3(L5_3, L6_3)
    L3_3.duration = L4_3
    L4_3 = exports
    L4_3 = L4_3.xsound
    L5_3 = L4_3
    L4_3 = L4_3.getMaxDuration
    L6_3 = A0_3.identifier
    L6_3 = L6_3.identifier
    L4_3 = L4_3(L5_3, L6_3)
    L3_3.maxduration = L4_3
    L2_3(L3_3)
  end
  L9_2(L10_2, L11_2)
  L9_2 = RegisterNetEvent
  L10_2 = "ls-phone:c:songAction"
  function L11_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = A0_3.action
    if "play" == L1_3 then
      L1_3 = A0_3.identifier
      L2_3 = L1_3.identifier
      L1_3 = L6_2
      L1_3[L2_3] = A0_3
      L1_3 = print
      L2_3 = A0_3.identifier
      L2_3 = L2_3.identifier
      L1_3(L2_3)
      L1_3 = exports
      L1_3 = L1_3.xsound
      L2_3 = L1_3
      L1_3 = L1_3.PlayUrlPos
      L3_3 = A0_3.identifier
      L3_3 = L3_3.identifier
      L4_3 = A0_3.identifier
      L4_3 = L4_3.url
      L5_3 = A0_3.songVolume
      L5_3 = L5_3 / 100
      L6_3 = GetEntityCoords
      L7_3 = GetPlayerPed
      L8_3 = GetPlayerFromServerId
      L9_3 = A0_3.songSource
      L8_3, L9_3 = L8_3(L9_3)
      L7_3, L8_3, L9_3 = L7_3(L8_3, L9_3)
      L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
      L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
      L1_3 = exports
      L1_3 = L1_3.xsound
      L2_3 = L1_3
      L1_3 = L1_3.Distance
      L3_3 = A0_3.identifier
      L3_3 = L3_3.identifier
      L4_3 = tonumber
      L5_3 = A0_3.songVolume
      L4_3 = L4_3(L5_3)
      L4_3 = L4_3 / 10
      L1_3(L2_3, L3_3, L4_3)
      L1_3 = exports
      L1_3 = L1_3.xsound
      L2_3 = L1_3
      L1_3 = L1_3.onPlayEnd
      L3_3 = A0_3.identifier
      L3_3 = L3_3.identifier
      function L4_3(A0_4)
        local L1_4, L2_4
        L1_4 = SendNUIMessage
        L2_4 = {}
        L2_4.action = "endSong"
        L1_4(L2_4)
      end
      L1_3(L2_3, L3_3, L4_3)
    else
      L1_3 = A0_3.action
      if "pause" == L1_3 then
        L1_3 = exports
        L1_3 = L1_3.xsound
        L2_3 = L1_3
        L1_3 = L1_3.Pause
        L3_3 = A0_3.identifier
        L3_3 = L3_3.identifier
        L1_3(L2_3, L3_3)
      else
        L1_3 = A0_3.action
        if "resume" == L1_3 then
          L1_3 = exports
          L1_3 = L1_3.xsound
          L2_3 = L1_3
          L1_3 = L1_3.Resume
          L3_3 = A0_3.identifier
          L3_3 = L3_3.identifier
          L1_3(L2_3, L3_3)
        else
          L1_3 = A0_3.action
          if "delete" == L1_3 then
            L1_3 = A0_3.identifier
            if nil ~= L1_3 then
              L1_3 = A0_3.identifier
              L2_3 = L1_3.identifier
              L1_3 = L6_2
              L1_3[L2_3] = nil
              L1_3 = exports
              L1_3 = L1_3.xsound
              L2_3 = L1_3
              L1_3 = L1_3.Destroy
              L3_3 = A0_3.identifier
              L3_3 = L3_3.identifier
              L1_3(L2_3, L3_3)
          end
          else
            L1_3 = A0_3.action
            if "changedelete" == L1_3 then
              L1_3 = A0_3.identifier
              if nil ~= L1_3 then
                L1_3 = A0_3.songSource
                L2_3 = GetPlayerServerId
                L3_3 = PlayerId
                L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L3_3()
                L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
                if L1_3 ~= L2_3 then
                  L1_3 = A0_3.identifier
                  L2_3 = L1_3.identifier
                  L1_3 = L6_2
                  L1_3[L2_3] = nil
                  L1_3 = exports
                  L1_3 = L1_3.xsound
                  L2_3 = L1_3
                  L1_3 = L1_3.Destroy
                  L3_3 = A0_3.identifier
                  L3_3 = L3_3.identifier
                  L1_3(L2_3, L3_3)
                end
            end
            else
              L1_3 = A0_3.action
              if "changestart" == L1_3 then
                L1_3 = A0_3.identifier
                if nil ~= L1_3 then
                  L1_3 = A0_3.songSource
                  L2_3 = GetPlayerServerId
                  L3_3 = PlayerId
                  L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L3_3()
                  L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
                  if L1_3 ~= L2_3 then
                    L1_3 = A0_3.identifier
                    L2_3 = L1_3.identifier
                    L1_3 = L6_2
                    L1_3[L2_3] = A0_3
                    L1_3 = exports
                    L1_3 = L1_3.xsound
                    L2_3 = L1_3
                    L1_3 = L1_3.PlayUrlPos
                    L3_3 = A0_3.identifier
                    L3_3 = L3_3.identifier
                    L4_3 = A0_3.identifier
                    L4_3 = L4_3.url
                    L5_3 = A0_3.songVolume
                    L5_3 = L5_3 / 100
                    L6_3 = GetEntityCoords
                    L7_3 = GetPlayerPed
                    L8_3 = GetPlayerFromServerId
                    L9_3 = A0_3.songSource
                    L8_3, L9_3 = L8_3(L9_3)
                    L7_3, L8_3, L9_3 = L7_3(L8_3, L9_3)
                    L6_3, L7_3, L8_3, L9_3 = L6_3(L7_3, L8_3, L9_3)
                    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
                    L1_3 = exports
                    L1_3 = L1_3.xsound
                    L2_3 = L1_3
                    L1_3 = L1_3.Distance
                    L3_3 = A0_3.identifier
                    L3_3 = L3_3.identifier
                    L4_3 = tonumber
                    L5_3 = A0_3.songVolume
                    L4_3 = L4_3(L5_3)
                    L4_3 = L4_3 / 10
                    L1_3(L2_3, L3_3, L4_3)
                    L1_3 = exports
                    L1_3 = L1_3.xsound
                    L2_3 = L1_3
                    L1_3 = L1_3.setTimeStamp
                    L3_3 = A0_3.identifier
                    L3_3 = L3_3.identifier
                    L4_3 = A0_3.timestamp
                    L1_3(L2_3, L3_3, L4_3)
                  end
              end
              else
                L1_3 = A0_3.action
                if "changetimestamp" == L1_3 then
                  L1_3 = A0_3.identifier
                  if nil ~= L1_3 then
                    L1_3 = exports
                    L1_3 = L1_3.xsound
                    L2_3 = L1_3
                    L1_3 = L1_3.setTimeStamp
                    L3_3 = A0_3.identifier
                    L3_3 = L3_3.identifier
                    L4_3 = A0_3.timestamp
                    L1_3(L2_3, L3_3, L4_3)
                  end
                end
              end
            end
          end
        end
      end
    end
  end
  L9_2(L10_2, L11_2)
  L9_2 = CreateThread
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L0_3 = 5000
    while true do
      L1_3 = false
      L2_3 = pairs
      L3_3 = L6_2
      L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
      for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
        if nil ~= L7_3 then
          L8_3 = L7_3.identifier
          if nil ~= L8_3 then
            L8_3 = exports
            L8_3 = L8_3.xsound
            L9_3 = L8_3
            L8_3 = L8_3.soundExists
            L10_3 = L7_3.identifier
            L10_3 = L10_3.identifier
            L8_3 = L8_3(L9_3, L10_3)
            if L8_3 then
              L8_3 = GetEntityCoords
              L9_3 = GetPlayerPed
              L10_3 = GetPlayerFromServerId
              L11_3 = L7_3.songSource
              L10_3, L11_3, L12_3 = L10_3(L11_3)
              L9_3, L10_3, L11_3, L12_3 = L9_3(L10_3, L11_3, L12_3)
              L8_3 = L8_3(L9_3, L10_3, L11_3, L12_3)
              L9_3 = GetEntityCoords
              L10_3 = PlayerPedId
              L10_3, L11_3, L12_3 = L10_3()
              L9_3 = L9_3(L10_3, L11_3, L12_3)
              L9_3 = L8_3 - L9_3
              L9_3 = #L9_3
              if 0.0 == L9_3 then
                L9_3 = GetPlayerServerId
                L10_3 = PlayerId
                L10_3, L11_3, L12_3 = L10_3()
                L9_3 = L9_3(L10_3, L11_3, L12_3)
                L10_3 = L7_3.songSource
                if L9_3 ~= L10_3 then
                  L9_3 = vector3
                  L10_3 = 9999
                  L11_3 = 9999
                  L12_3 = 9999
                  L9_3 = L9_3(L10_3, L11_3, L12_3)
                  L8_3 = L9_3
                end
              end
              L9_3 = exports
              L9_3 = L9_3.xsound
              L10_3 = L9_3
              L9_3 = L9_3.Position
              L11_3 = L7_3.identifier
              L11_3 = L11_3.identifier
              L12_3 = L8_3
              L9_3(L10_3, L11_3, L12_3)
              L9_3 = GetEntityCoords
              L10_3 = PlayerPedId
              L10_3, L11_3, L12_3 = L10_3()
              L9_3 = L9_3(L10_3, L11_3, L12_3)
              L9_3 = L8_3 - L9_3
              L9_3 = #L9_3
              if L9_3 < 20 then
                L9_3 = exports
                L9_3 = L9_3.xsound
                L10_3 = L9_3
                L9_3 = L9_3.isPaused
                L11_3 = L7_3.identifier
                L11_3 = L11_3.identifier
                L9_3 = L9_3(L10_3, L11_3)
                if not L9_3 then
                  L9_3 = GetEntityCoords
                  L10_3 = PlayerPedId
                  L10_3, L11_3, L12_3 = L10_3()
                  L9_3 = L9_3(L10_3, L11_3, L12_3)
                  L9_3 = L8_3 - L9_3
                  L9_3 = #L9_3
                  if 0.0 ~= L9_3 then
                    L1_3 = true
                  end
                end
              end
              L9_3 = GetPlayerServerId
              L10_3 = PlayerId
              L10_3, L11_3, L12_3 = L10_3()
              L9_3 = L9_3(L10_3, L11_3, L12_3)
              L10_3 = L7_3.songSource
              if L9_3 == L10_3 then
                L9_3 = exports
                L9_3 = L9_3.xsound
                L10_3 = L9_3
                L9_3 = L9_3.isPaused
                L11_3 = L7_3.identifier
                L11_3 = L11_3.identifier
                L9_3 = L9_3(L10_3, L11_3)
                if not L9_3 then
                  L1_3 = true
                end
              end
            end
          end
        end
      end
      if L1_3 then
        L2_3 = IsPedInAnyVehicle
        L3_3 = PlayerPedId
        L3_3 = L3_3()
        L4_3 = false
        L2_3 = L2_3(L3_3, L4_3)
        if L2_3 then
          L0_3 = 1
        else
          L0_3 = 5
        end
      else
        L0_3 = 1000
      end
      L2_3 = Wait
      L3_3 = L0_3
      L2_3(L3_3)
    end
  end
  L9_2(L10_2)
  L9_2 = RegisterNuiCallback
  L10_2 = "enableControls"
  function L11_2()
    local L0_3, L1_3
    L0_3 = SetNuiFocusKeepInput
    L1_3 = Config
    L1_3 = L1_3.Client
    L1_3 = L1_3.InputsWhileFocus
    L0_3(L1_3)
  end
  L9_2(L10_2, L11_2)
  L9_2 = RegisterNuiCallback
  L10_2 = "disableControls"
  function L11_2()
    local L0_3, L1_3
    L0_3 = SetNuiFocusKeepInput
    L1_3 = false
    L0_3(L1_3)
  end
  L9_2(L10_2, L11_2)
  L9_2 = RegisterNUICallback
  L10_2 = "savePhone"
  function L11_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:savePhone"
    L4_3 = A0_3.PhoneData
    L5_3 = PhoneInfo
    L5_3 = L5_3.Identifier
    L2_3(L3_3, L4_3, L5_3)
  end
  L9_2(L10_2, L11_2)
  L9_2 = false
  isInCamera = false
  L10_2 = RegisterNUICallback
  L11_2 = "enterCameraMode"
  function L12_2()
    local L0_3, L1_3
    L0_3 = CameraMode
    L0_3()
  end
  L10_2(L11_2, L12_2)
  L10_2 = true
  function L11_2()
    local L0_3, L1_3, L2_3
    L0_3 = ClosePhone
    L1_3 = true
    L0_3(L1_3)
    isInCamera = true
    L0_3 = InCamera
    L0_3()
    L0_3 = SetTimeout
    L1_3 = 405
    function L2_3()
      local L0_4, L1_4, L2_4
      L0_4 = isInCamera
      if L0_4 then
        L0_4 = SetNuiFocus
        L1_4 = true
        L2_4 = true
        L0_4(L1_4, L2_4)
        L0_4 = SetNuiFocusKeepInput
        L1_4 = true
        L0_4(L1_4)
        L0_4 = CreateMobilePhone
        L1_4 = 0
        L0_4(L1_4)
        L0_4 = CellCamActivate
        L1_4 = true
        L2_4 = true
        L0_4(L1_4, L2_4)
        L0_4 = false
        L9_2 = L0_4
      else
        L0_4 = DoPhoneAnimation
        L1_4 = "cellphone_text_in"
        L0_4(L1_4)
        L0_4 = SetTimeout
        L1_4 = 250
        function L2_4()
          local L0_5, L1_5
          L0_5 = newPhoneProp
          L0_5()
        end
        L0_4(L1_4, L2_4)
      end
    end
    L0_3(L1_3, L2_3)
  end
  CameraMode = L11_2
  function L11_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = BeginTextCommandDisplayHelp
    L2_3 = "STRING"
    L1_3(L2_3)
    L1_3 = AddTextComponentSubstringPlayerName
    L2_3 = A0_3
    L1_3(L2_3)
    L1_3 = EndTextCommandDisplayHelp
    L2_3 = 0
    L3_3 = false
    L4_3 = false
    L5_3 = -1
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  DisplayHelpText = L11_2
  L11_2 = RegisterNUICallback
  L12_2 = "changeCameraMovement"
  function L13_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = isInCamera
    if L2_3 then
      L2_3 = L10_2
      if L2_3 then
        L2_3 = SetNuiFocus
        L3_3 = true
        L4_3 = true
        L2_3(L3_3, L4_3)
        L2_3 = SetNuiFocusKeepInput
        L3_3 = false
        L2_3(L3_3)
      else
        L2_3 = SetNuiFocus
        L3_3 = true
        L4_3 = true
        L2_3(L3_3, L4_3)
        L2_3 = SetNuiFocusKeepInput
        L3_3 = true
        L2_3(L3_3)
      end
      L2_3 = L10_2
      L2_3 = not L2_3
      L10_2 = L2_3
    end
  end
  L11_2(L12_2, L13_2)
  function L11_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = Citizen
    L1_3 = L1_3.InvokeNative
    L2_3 = 2635073306796480568
    L3_3 = A0_3
    return L1_3(L2_3, L3_3)
  end
  CellFrontCamActivate = L11_2
  L11_2 = RegisterNUICallback
  L12_2 = "rotateCamera"
  function L13_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = L9_2
    L2_3 = not L2_3
    L9_2 = L2_3
    L2_3 = CellFrontCamActivate
    L3_3 = L9_2
    L2_3(L3_3)
  end
  L11_2(L12_2, L13_2)
  L11_2 = RegisterNUICallback
  L12_2 = "closeCamera"
  function L13_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = ClosePhone
    L3_3 = true
    L2_3(L3_3)
    isInCamera = false
    L2_3 = true
    L10_2 = L2_3
    L2_3 = OutCamera
    L2_3()
    L2_3 = SetTimeout
    L3_3 = 405
    function L4_3()
      local L0_4, L1_4, L2_4
      L0_4 = DoPhoneAnimation
      L1_4 = "cellphone_text_in"
      L0_4(L1_4)
      L0_4 = SetTimeout
      L1_4 = 250
      function L2_4()
        local L0_5, L1_5
        L0_5 = newPhoneProp
        L0_5()
      end
      L0_4(L1_4, L2_4)
    end
    L2_3(L3_3, L4_3)
  end
  L11_2(L12_2, L13_2)
  L11_2 = RegisterNUICallback
  L12_2 = "CaptureImage"
  function L13_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:getWebhook"
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4
      L1_4 = L9_2
      if not L1_4 then
        L1_4 = A0_3.flash
        if L1_4 then
          L1_4 = RequestNamedPtfxAsset
          L2_4 = "scr_rcpaparazzo1"
          L1_4(L2_4)
          L1_4 = UseParticleFxAsset
          L2_4 = "scr_rcpaparazzo1"
          L1_4(L2_4)
          L1_4 = _ENV
          L2_4 = "StartNetworkedParticleFxNonLoopedOnPedBone"
          L1_4 = L1_4[L2_4]
          L2_4 = "scr_rcpap1_camera"
          L3_4 = PlayerPedId
          L3_4 = L3_4()
          L4_4 = 0.0
          L5_4 = 0.0
          L6_4 = -0.05
          L7_4 = 0.0
          L8_4 = 0.0
          L9_4 = 90.0
          L10_4 = 57005
          L11_4 = 1065353216
          L12_4 = 0
          L13_4 = 0
          L14_4 = 0
          L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4)
          L1_4 = Wait
          L2_4 = 50
          L1_4(L2_4)
        end
      end
      L1_4 = exports
      L1_4 = L1_4["screenshot-basic"]
      L2_4 = L1_4
      L1_4 = L1_4.requestScreenshotUpload
      L3_4 = tostring
      L4_4 = A0_4
      L3_4 = L3_4(L4_4)
      L4_4 = "files[]"
      function L5_4(A0_5)
        local L1_5, L2_5, L3_5
        L1_5 = json
        L1_5 = L1_5.decode
        L2_5 = A0_5
        L1_5 = L1_5(L2_5)
        L2_5 = A1_3
        L3_5 = L1_5.attachments
        L3_5 = L3_5[1]
        L3_5 = L3_5.proxy_url
        L2_5(L3_5)
      end
      L1_4(L2_4, L3_4, L4_4, L5_4)
    end
    L2_3(L3_3, L4_3)
  end
  L11_2(L12_2, L13_2)
  L11_2 = RegisterNUICallback
  L12_2 = "getPlayerIdentifier"
  function L13_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A1_3
    L3_3 = LS_CORE
    L3_3 = L3_3.PLAYER_DATA
    L3_3 = L3_3.identifier
    L2_3(L3_3)
  end
  L11_2(L12_2, L13_2)
  L11_2 = 1000
  L12_2 = false
  L13_2 = RegisterNUICallback
  L14_2 = "flashLight"
  function L15_2(A0_3, A1_3)
    local L2_3
    L2_3 = A0_3.flashStatus
    L12_2 = L2_3
    L2_3 = L12_2
    if L2_3 then
      L2_3 = 0
      L11_2 = L2_3
    else
      L2_3 = 1000
      L11_2 = L2_3
    end
  end
  L13_2(L14_2, L15_2)
  L13_2 = Citizen
  L13_2 = L13_2.CreateThread
  function L14_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    while true do
      L0_3 = PhoneInfo
      L0_3 = L0_3.isOpen
      if L0_3 then
        L0_3 = L12_2
        if L0_3 then
          L0_3 = GetEntityCoords
          L1_3 = PlayerPedId
          L1_3 = L1_3()
          L2_3 = true
          L0_3 = L0_3(L1_3, L2_3)
          L1_3 = GetEntityForwardVector
          L2_3 = PlayerPedId
          L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3 = L2_3()
          L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
          L2_3 = DrawSpotLight
          L3_3 = L0_3.x
          L4_3 = L0_3.y
          L5_3 = L0_3.z
          L6_3 = L1_3.x
          L7_3 = L1_3.y
          L8_3 = L1_3.z
          L9_3 = 255
          L10_3 = 255
          L11_3 = 255
          L12_3 = 20.0
          L13_3 = 5.0
          L14_3 = 5.0
          L15_3 = 25.0
          L16_3 = 0
          L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
        end
      end
      L0_3 = Citizen
      L0_3 = L0_3.Wait
      L1_3 = L11_2
      L0_3(L1_3)
    end
  end
  L13_2(L14_2)
  L13_2 = {}
  L13_2.Incall = false
  L13_2.CallId = nil
  L13_2.AnsweredCall = false
  L14_2 = {}
  L13_2.TargetData = L14_2
  L13_2.CallType = "outgoing"
  L13_2.IsVideo = false
  function L14_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = math
    L2_3 = L2_3.ceil
    L3_3 = tonumber
    L4_3 = A0_3
    L3_3 = L3_3(L4_3)
    L4_3 = tonumber
    L5_3 = A1_3
    L4_3 = L4_3(L5_3)
    L3_3 = L3_3 + L4_3
    L3_3 = L3_3 / 100
    L3_3 = L3_3 * 1
    L2_3 = L2_3(L3_3)
    return L2_3
  end
  GenerateCallId = L14_2
  function L14_2()
    local L0_3, L1_3, L2_3
    L0_3 = TriggerServerEvent
    L1_3 = "ls-phone:s:CancelCall"
    L2_3 = L13_2.TargetData
    L0_3(L1_3, L2_3)
    L0_3 = L13_2.CallType
    if "ongoing" == L0_3 then
      L0_3 = RemovePlayerFromCall
      L1_3 = L13_2.CallId
      L0_3(L1_3)
    end
    L0_3 = PhoneInfo
    L0_3 = L0_3.isOpen
    if L0_3 then
      L0_3 = L13_2.AnsweredCall
      if not L0_3 then
        L0_3 = TriggerEvent
        L1_3 = "ls-phone:c:sendNotification"
        L2_3 = {}
        L2_3.app = "contacts"
        L2_3.message = "DENY_CALL"
        L0_3(L1_3, L2_3)
      end
    end
    L0_3 = SendNUIMessage
    L1_3 = {}
    L1_3.action = "setupHomeScreen"
    L0_3(L1_3)
    L13_2.CallType = nil
    L13_2.Incall = false
    L13_2.AnsweredCall = false
    L0_3 = {}
    L13_2.TargetData = L0_3
    L13_2.CallId = nil
    L13_2.IsVideo = false
    L0_3 = PhoneInfo
    L0_3 = L0_3.isOpen
    if L0_3 then
      L0_3 = SetTimeout
      L1_3 = 405
      function L2_3()
        local L0_4, L1_4, L2_4
        L0_4 = DoPhoneAnimation
        L1_4 = "cellphone_text_in"
        L0_4(L1_4)
        L0_4 = SetTimeout
        L1_4 = 250
        function L2_4()
          local L0_5, L1_5
          L0_5 = newPhoneProp
          L0_5()
        end
        L0_4(L1_4, L2_4)
      end
      L0_3(L1_3, L2_3)
    end
    L0_3 = DeleteAlarm
    L0_3()
    L0_3 = TriggerServerEvent
    L1_3 = "ls-phone:s:SetCallState"
    L2_3 = false
    L0_3(L1_3, L2_3)
  end
  CancelCall = L14_2
  function L14_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = 0
    L13_2.CallType = "outgoing"
    L13_2.Incall = true
    L13_2.TargetData = A0_3
    L13_2.AnsweredCall = false
    L2_3 = GenerateCallId
    L3_3 = L13_2.TargetData
    L3_3 = L3_3.dialnumber
    L4_3 = A0_3.mainnumber
    L2_3 = L2_3(L3_3, L4_3)
    L13_2.CallId = L2_3
    L2_3 = A0_3.isVideoCall
    L13_2.IsVideo = L2_3
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:CallContact"
    L4_3 = L13_2.TargetData
    L5_3 = L13_2.CallId
    L2_3(L3_3, L4_3, L5_3)
    L2_3 = TriggerServerEvent
    L3_3 = "ls-phone:s:SetCallState"
    L4_3 = true
    L2_3(L3_3, L4_3)
    L2_3 = 1
    L3_3 = Config
    L3_3 = L3_3.Client
    L3_3 = L3_3.Call
    L3_3 = L3_3.RepeatTimes
    L3_3 = L3_3 + 1
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = L13_2.AnsweredCall
      if not L6_3 then
        L6_3 = L1_3 + 1
        L7_3 = Config
        L7_3 = L7_3.Client
        L7_3 = L7_3.Call
        L7_3 = L7_3.RepeatTimes
        L7_3 = L7_3 + 1
        if L6_3 ~= L7_3 then
          L6_3 = L13_2.Incall
          if L6_3 then
            L1_3 = L1_3 + 1
            L6_3 = StartCallAlarm
            L7_3 = "arayan"
            L6_3(L7_3)
          else
            break
          end
          L6_3 = Wait
          L7_3 = Config
          L7_3 = L7_3.Client
          L7_3 = L7_3.Call
          L7_3 = L7_3.RepeatWait
          L6_3(L7_3)
          L6_3 = DeleteAlarm
          L6_3()
        else
          L6_3 = CancelCall
          L6_3()
          break
        end
      else
        break
      end
    end
  end
  CallContact = L14_2
  function L14_2(A0_3)
    local L1_3, L2_3
    L1_3 = Citizen
    L1_3 = L1_3.CreateThread
    function L2_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4
      L0_4 = Wait
      L1_4 = 150
      L0_4(L1_4)
      L0_4 = nil
      L1_4 = A0_3
      if "aranan" == L1_4 then
        L0_4 = "nui://ls-phone/html/sounds/iphonering.wav"
      else
        L0_4 = "nui://ls-phone/html/sounds/arayan.wav"
      end
      L1_4 = {}
      L2_4 = {}
      L3_4 = "alarm_"
      L4_4 = GetPlayerServerId
      L5_4 = PlayerId
      L5_4 = L5_4()
      L4_4 = L4_4(L5_4)
      L3_4 = L3_4 .. L4_4
      L2_4.identifier = L3_4
      L2_4.url = L0_4
      L1_4.identifier = L2_4
      L1_4.action = "play"
      L1_4.songVolume = 100.0
      ringtone = L1_4
      L1_4 = TriggerServerEvent
      L2_4 = "ls-phone:s:callsongAction"
      L3_4 = ringtone
      L1_4(L2_4, L3_4)
    end
    L1_3(L2_3)
  end
  StartCallAlarm = L14_2
  function L14_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = {}
    L1_3 = {}
    L2_3 = "alarm_"
    L3_3 = GetPlayerServerId
    L4_3 = PlayerId
    L4_3 = L4_3()
    L3_3 = L3_3(L4_3)
    L2_3 = L2_3 .. L3_3
    L1_3.identifier = L2_3
    L1_3.url = "nui://ls-phone/html/sounds/dest.ogg"
    L0_3.identifier = L1_3
    L0_3.action = "delete"
    L0_3.songVolume = 100.0
    ringtone = L0_3
    L0_3 = TriggerServerEvent
    L1_3 = "ls-phone:s:callsongAction"
    L2_3 = ringtone
    L0_3(L1_3, L2_3)
  end
  DeleteAlarm = L14_2
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:callsongAction"
  function L16_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = A0_3.action
    if "play" == L1_3 then
      L1_3 = A0_3.songSource
      L2_3 = GetPlayerServerId
      L3_3 = PlayerId
      L3_3, L4_3, L5_3 = L3_3()
      L2_3 = L2_3(L3_3, L4_3, L5_3)
      if L1_3 == L2_3 then
        L1_3 = A0_3.identifier
        L2_3 = L1_3.identifier
        L1_3 = L7_2
        L1_3[L2_3] = A0_3
        L1_3 = exports
        L1_3 = L1_3.xsound
        L2_3 = L1_3
        L1_3 = L1_3.PlayUrl
        L3_3 = A0_3.identifier
        L3_3 = L3_3.identifier
        L4_3 = A0_3.identifier
        L4_3 = L4_3.url
        L5_3 = A0_3.songVolume
        L5_3 = L5_3 / 100
        L1_3(L2_3, L3_3, L4_3, L5_3)
        L1_3 = exports
        L1_3 = L1_3.xsound
        L2_3 = L1_3
        L1_3 = L1_3.onPlayEnd
        L3_3 = A0_3.identifier
        L3_3 = L3_3.identifier
        function L4_3(A0_4)
          local L1_4, L2_4
          L1_4 = SendNUIMessage
          L2_4 = {}
          L2_4.action = "endSong"
          L1_4(L2_4)
        end
        L1_3(L2_3, L3_3, L4_3)
      end
    else
      L1_3 = A0_3.action
      if "delete" == L1_3 then
        L1_3 = A0_3.identifier
        if nil ~= L1_3 then
          L1_3 = A0_3.identifier
          L2_3 = L1_3.identifier
          L1_3 = L7_2
          L1_3[L2_3] = nil
          L1_3 = exports
          L1_3 = L1_3.xsound
          L2_3 = L1_3
          L1_3 = L1_3.Destroy
          L3_3 = A0_3.identifier
          L3_3 = L3_3.identifier
          L1_3(L2_3, L3_3)
        end
      end
    end
  end
  L14_2(L15_2, L16_2)
  function L14_2()
    local L0_3, L1_3, L2_3
    L0_3 = L13_2.CallType
    if "incoming" ~= L0_3 then
      L0_3 = L13_2.CallType
      if "outgoing" ~= L0_3 then
        goto lbl_48
      end
    end
    L0_3 = L13_2.Incall
    if L0_3 then
      L0_3 = L13_2.AnsweredCall
      if not L0_3 then
        L13_2.CallType = "ongoing"
        L13_2.AnsweredCall = true
        L13_2.CallTime = 0
        L0_3 = SendNUIMessage
        L1_3 = {}
        L1_3.action = "AnswerCall"
        L2_3 = L13_2
        L1_3.calldata = L2_3
        L0_3(L1_3)
        L0_3 = TriggerServerEvent
        L1_3 = "ls-phone:s:SetCallState"
        L2_3 = true
        L0_3(L1_3, L2_3)
        L0_3 = PhoneInfo
        L0_3 = L0_3.isOpen
        if L0_3 then
          L0_3 = DoPhoneAnimation
          L1_3 = "cellphone_text_to_call"
          L0_3(L1_3)
        else
          L0_3 = DoPhoneAnimation
          L1_3 = "cellphone_call_listen_base"
          L0_3(L1_3)
        end
        L0_3 = CreateThread
        function L1_3()
          local L0_4, L1_4, L2_4
          while true do
            L0_4 = L13_2.AnsweredCall
            if L0_4 then
              L0_4 = L13_2.CallTime
              L0_4 = L0_4 + 1
              L13_2.CallTime = L0_4
              L0_4 = SendNUIMessage
              L1_4 = {}
              L1_4.action = "UpdateCallTime"
              L2_4 = L13_2.CallTime
              L1_4.time = L2_4
              L0_4(L1_4)
            else
              break
            end
            L0_4 = Wait
            L1_4 = 1000
            L0_4(L1_4)
          end
        end
        L0_3(L1_3)
        L0_3 = TriggerServerEvent
        L1_3 = "ls-phone:s:AnswerCall"
        L2_3 = L13_2
        L0_3(L1_3, L2_3)
        L0_3 = AddPlayerToCall
        L1_3 = L13_2.CallId
        L0_3(L1_3)
      end
    end
    ::lbl_48::
  end
  AnswerCall = L14_2
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:CancelCall"
  function L16_2()
    local L0_3, L1_3, L2_3
    L0_3 = L13_2.CallType
    if "ongoing" == L0_3 then
      L0_3 = SendNUIMessage
      L1_3 = {}
      L1_3.action = "CancelOngoingCall"
      L0_3(L1_3)
      L0_3 = RemovePlayerFromCall
      L1_3 = L13_2.CallId
      L0_3(L1_3)
    end
    L0_3 = PhoneInfo
    L0_3 = L0_3.isOpen
    if L0_3 then
      L0_3 = L13_2.AnsweredCall
      if not L0_3 then
        L0_3 = TriggerEvent
        L1_3 = "ls-phone:c:sendNotification"
        L2_3 = {}
        L2_3.app = "contacts"
        L2_3.message = "DENY_CALL"
        L0_3(L1_3, L2_3)
      end
    end
    L0_3 = SendNUIMessage
    L1_3 = {}
    L1_3.action = "setupHomeScreen"
    L0_3(L1_3)
    L13_2.CallType = nil
    L13_2.Incall = false
    L13_2.AnsweredCall = false
    L0_3 = {}
    L13_2.TargetData = L0_3
    L13_2.IsVideo = false
    L0_3 = PhoneInfo
    L0_3 = L0_3.isOpen
    if L0_3 then
      L0_3 = SetTimeout
      L1_3 = 405
      function L2_3()
        local L0_4, L1_4, L2_4
        L0_4 = DoPhoneAnimation
        L1_4 = "cellphone_text_in"
        L0_4(L1_4)
        L0_4 = SetTimeout
        L1_4 = 250
        function L2_4()
          local L0_5, L1_5
          L0_5 = newPhoneProp
          L0_5()
        end
        L0_4(L1_4, L2_4)
      end
      L0_3(L1_3, L2_3)
    end
    L0_3 = DeleteAlarm
    L0_3()
    L0_3 = TriggerServerEvent
    L1_3 = "ls-phone:s:SetCallState"
    L2_3 = false
    L0_3(L1_3, L2_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:AnswerCall"
  function L16_2()
    local L0_3, L1_3
    L0_3 = AnswerCall
    L0_3()
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "cancelCall"
  function L16_2(A0_3, A1_3)
    local L2_3
    L2_3 = CancelCall
    L2_3()
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "callContact"
  function L16_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = LS_CORE
    L2_3 = L2_3.Callback
    L2_3 = L2_3.Functions
    L2_3 = L2_3.TriggerCallback
    L3_3 = "ls-phone:s:GetCallState"
    function L4_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4
      L2_4 = {}
      L2_4.CanCall = A0_4
      L2_4.IsOnline = A1_4
      L3_4 = L13_2.Incall
      L2_4.InCall = L3_4
      L3_4 = A1_3
      L4_4 = L2_4
      L3_4(L4_4)
      if A0_4 then
        L3_4 = L2_4.InCall
        if not L3_4 then
          L3_4 = A0_3.dialnumber
          L4_4 = A0_3.mainnumber
          if L3_4 ~= L4_4 then
            L3_4 = CallContact
            L4_4 = A0_3
            L3_4(L4_4)
          end
        end
      end
    end
    L5_3 = A0_3
    L2_3(L3_3, L4_3, L5_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "AnswerCall"
  function L16_2(A0_3, A1_3)
    local L2_3
    L2_3 = AnswerCall
    L2_3()
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:GetCalled"
  function L16_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L3_3 = 0
    L4_3 = {}
    L4_3.number = A0_3
    L13_2.CallType = "incoming"
    L13_2.Incall = true
    L13_2.AnsweredCall = false
    L13_2.TargetData = L4_3
    L13_2.CallId = A1_3
    L5_3 = A2_3.isVideoCall
    L13_2.IsVideo = L5_3
    L5_3 = TriggerServerEvent
    L6_3 = "ls-phone:s:SetCallState"
    L7_3 = true
    L5_3(L6_3, L7_3)
    L5_3 = SendNUIMessage
    L6_3 = {}
    L6_3.action = "PhoneCalling"
    L7_3 = L13_2
    L6_3.calldata = L7_3
    L5_3(L6_3)
    L5_3 = 1
    L6_3 = Config
    L6_3 = L6_3.Client
    L6_3 = L6_3.Call
    L6_3 = L6_3.RepeatTimes
    L6_3 = L6_3 + 1
    L7_3 = 1
    for L8_3 = L5_3, L6_3, L7_3 do
      L9_3 = L13_2.AnsweredCall
      if not L9_3 then
        L9_3 = L3_3 + 1
        L10_3 = Config
        L10_3 = L10_3.Client
        L10_3 = L10_3.Call
        L10_3 = L10_3.RepeatTimes
        L10_3 = L10_3 + 1
        if L9_3 ~= L10_3 then
          L9_3 = L13_2.Incall
          if L9_3 then
            L9_3 = StartCallAlarm
            L10_3 = "aranan"
            L9_3(L10_3)
          end
          L9_3 = Wait
          L10_3 = Config
          L10_3 = L10_3.Client
          L10_3 = L10_3.Call
          L10_3 = L10_3.RepeatWait
          L9_3(L10_3)
          L9_3 = DeleteAlarm
          L9_3()
        else
          L9_3 = DeleteAlarm
          L9_3()
          L9_3 = TriggerEvent
          L10_3 = "ls-phone:c:sendNotification"
          L11_3 = {}
          L11_3.app = "contacts"
          L11_3.message = "Missing Call"
          L9_3(L10_3, L11_3)
          L9_3 = SendNUIMessage
          L10_3 = {}
          L10_3.action = "setupHomeScreen"
          L9_3(L10_3)
          break
        end
      else
        break
      end
    end
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "startVideoCall"
  function L16_2()
    local L0_3, L1_3, L2_3
    L0_3 = TriggerServerEvent
    L1_3 = "ls-phone:s:StartCallVideo"
    L2_3 = L13_2.TargetData
    L0_3(L1_3, L2_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "startCallId"
  function L16_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = TriggerServerEvent
    L2_3 = "ls-phone:s:sendCall"
    L3_3 = A0_3.id
    L4_3 = GetPlayerServerId
    L5_3 = PlayerId
    L5_3 = L5_3()
    L4_3, L5_3 = L4_3(L5_3)
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:sendCall"
  function L16_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = SendNUIMessage
    L3_3 = {}
    L3_3.type = "answer"
    L3_3.serverId = A0_3
    L3_3.callerId = A1_3
    L2_3(L3_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "sendData"
  function L16_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = A0_3.serverId
    if nil == L1_3 then
      L1_3 = GetPlayerServerId
      L2_3 = PlayerId
      L2_3, L3_3 = L2_3()
      L1_3 = L1_3(L2_3, L3_3)
      A0_3.serverId = L1_3
    end
    L1_3 = TriggerServerEvent
    L2_3 = "ls-phone:s:sendData"
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "stopVideoCall"
  function L16_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = TriggerServerEvent
    L2_3 = "ls-phone:s:stopCall"
    L3_3 = A0_3.callId
    L1_3(L2_3, L3_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNUICallback
  L15_2 = "deletServerUser"
  function L16_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = GetPlayerServerId
    L1_3 = PlayerId
    L1_3, L2_3, L3_3 = L1_3()
    L0_3 = L0_3(L1_3, L2_3, L3_3)
    L1_3 = TriggerServerEvent
    L2_3 = "ls-phone:s:deletServerUser"
    L3_3 = L0_3
    L1_3(L2_3, L3_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:stopCall"
  function L16_2()
    local L0_3, L1_3
    L0_3 = SendNUIMessage
    L1_3 = {}
    L1_3.type = "stopCall"
    L0_3(L1_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:sendData"
  function L16_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.data = A0_3
    L2_3.type = "sendData"
    L1_3(L2_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = RegisterNetEvent
  L15_2 = "ls-phone:c:videoCall"
  function L16_2(A0_3)
    local L1_3, L2_3
    L1_3 = SendNUIMessage
    L2_3 = {}
    L2_3.action = "startVideoCall"
    L2_3.callId = A0_3
    L1_3(L2_3)
  end
  L14_2(L15_2, L16_2)
  L14_2 = true
  L15_2 = false
  L16_2 = RegisterNUICallback
  L17_2 = "openCam"
  function L18_2()
    local L0_3, L1_3
    L0_3 = CameraMode
    L0_3()
  end
  L16_2(L17_2, L18_2)
  L16_2 = RegisterNUICallback
  L17_2 = "closeCam"
  function L18_2()
    local L0_3, L1_3, L2_3
    L0_3 = ClosePhone
    L1_3 = true
    L0_3(L1_3)
    L0_3 = SetTimeout
    L1_3 = 405
    function L2_3()
      local L0_4, L1_4, L2_4
      L0_4 = DoPhoneAnimation
      L1_4 = "cellphone_text_in"
      L0_4(L1_4)
      L0_4 = SetTimeout
      L1_4 = 250
      function L2_4()
        local L0_5, L1_5
        L0_5 = newPhoneProp
        L0_5()
      end
      L0_4(L1_4, L2_4)
    end
    L0_3(L1_3, L2_3)
  end
  L16_2(L17_2, L18_2)
end
SetupPhoneMain = L0_1
L0_1 = GetResourceState
L1_1 = "ls-core"
L0_1 = L0_1(L1_1)
if "started" ~= L0_1 then
  L0_1 = CreateThread
  function L1_1()
    local L0_2, L1_2
    while true do
      L0_2 = GetResourceState
      L1_2 = "ls-core"
      L0_2 = L0_2(L1_2)
      if "started" == L0_2 then
        L0_2 = print
        L1_2 = [[
ls-core is started. 
^8Please restart your server.^7 
Phone not will work.]]
        L0_2(L1_2)
      else
        L0_2 = print
        L1_2 = "ls-core not found. Please install before trying to use phone. ^8Error Code 2^7"
        L0_2(L1_2)
      end
      L0_2 = Citizen
      L0_2 = L0_2.Wait
      L1_2 = 5000
      L0_2(L1_2)
    end
  end
  L0_1(L1_1)
else
  L0_1 = exports
  L0_1 = L0_1["ls-core"]
  L1_1 = L0_1
  L0_1 = L0_1.GetCoreObject
  L0_1 = L0_1(L1_1)
  LS_CORE = L0_1
  L0_1 = SetupPhoneMain
  L0_1()
end
