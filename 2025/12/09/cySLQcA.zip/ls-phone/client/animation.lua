local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
L0_1 = {}
L0_1.lib = nil
L0_1.anim = nil
AnimationData = L0_1
L0_1 = 0
L1_1 = "prop_npc_phone_02"
L2_1 = "out"
L3_1 = nil
L4_1 = nil
L5_1 = false
L6_1 = {}
L7_1 = {}
L8_1 = {}
L8_1.text = "cellphone_text_in"
L8_1.call = "cellphone_call_listen_base"
L7_1.out = L8_1
L8_1 = {}
L8_1.out = "cellphone_text_out"
L8_1.text = "cellphone_text_in"
L8_1.call = "cellphone_text_to_call"
L7_1.text = L8_1
L8_1 = {}
L8_1.out = "cellphone_call_out"
L8_1.text = "cellphone_call_to_text"
L8_1.call = "cellphone_text_to_call"
L7_1.call = L8_1
L6_1["cellphone@"] = L7_1
L7_1 = {}
L8_1 = {}
L8_1.text = "cellphone_text_in"
L8_1.call = "cellphone_call_in"
L7_1.out = L8_1
L8_1 = {}
L8_1.out = "cellphone_text_out"
L8_1.text = "cellphone_text_in"
L8_1.call = "cellphone_text_to_call"
L7_1.text = L8_1
L8_1 = {}
L8_1.out = "cellphone_horizontal_exit"
L8_1.text = "cellphone_call_to_text"
L8_1.call = "cellphone_text_to_call"
L7_1.call = L8_1
L6_1["anim@cellphone@in_car@ps"] = L7_1
function L7_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = deletePhone
  L0_2()
  L0_2 = RequestModel
  L1_2 = L1_1
  L0_2(L1_2)
  while true do
    L0_2 = HasModelLoaded
    L1_2 = L1_1
    L0_2 = L0_2(L1_2)
    if L0_2 then
      break
    end
    L0_2 = Citizen
    L0_2 = L0_2.Wait
    L1_2 = 1
    L0_2(L1_2)
  end
  L0_2 = CreateObject
  L1_2 = L1_1
  L2_2 = 1.0
  L3_2 = 1.0
  L4_2 = 1.0
  L5_2 = 1
  L6_2 = 1
  L7_2 = 0
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L0_1 = L0_2
  L0_2 = GetPedBoneIndex
  L1_2 = GetPlayerPed
  L2_2 = -1
  L1_2 = L1_2(L2_2)
  L2_2 = 28422
  L0_2 = L0_2(L1_2, L2_2)
  L1_2 = L1_1
  if "prop_cs_phone_01" == L1_2 then
    L1_2 = AttachEntityToEntity
    L2_2 = L0_1
    L3_2 = GetPlayerPed
    L4_2 = -1
    L3_2 = L3_2(L4_2)
    L4_2 = L0_2
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = 50.0
    L9_2 = 320.0
    L10_2 = 50.0
    L11_2 = 1
    L12_2 = 1
    L13_2 = 0
    L14_2 = 0
    L15_2 = 2
    L16_2 = 1
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  else
    L1_2 = AttachEntityToEntity
    L2_2 = L0_1
    L3_2 = GetPlayerPed
    L4_2 = -1
    L3_2 = L3_2(L4_2)
    L4_2 = L0_2
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = 0.0
    L9_2 = 0.0
    L10_2 = 0.0
    L11_2 = 1
    L12_2 = 1
    L13_2 = 0
    L14_2 = 0
    L15_2 = 2
    L16_2 = 1
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  end
end
newPhoneProp = L7_1
function L7_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L0_1
  if 0 ~= L0_2 then
    L0_2 = Citizen
    L0_2 = L0_2.InvokeNative
    L1_2 = -5891624910369535543
    L2_2 = Citizen
    L2_2 = L2_2.PointerValueIntInitialized
    L3_2 = L0_1
    L2_2, L3_2 = L2_2(L3_2)
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = 0
    L0_1 = L0_2
  end
end
deletePhone = L7_1
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = RequestAnimDict
  L2_2 = A0_2
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Citizen
    L1_2 = L1_2.Wait
    L2_2 = 1
    L1_2(L2_2)
  end
end
LoadAnimation = L7_1
function L7_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = "cellphone@"
  L2_2 = "cellphone_call_listen_base"
  L3_2 = IsPedInAnyVehicle
  L4_2 = L0_2
  L5_2 = false
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L1_2 = "anim@cellphone@in_car@ps"
  end
  L3_2 = PhoneInfo
  L3_2 = L3_2.isOpen
  if L3_2 then
    L2_2 = "cellphone_call_to_text"
  end
  L3_2 = LoadAnimation
  L4_2 = L1_2
  L3_2(L4_2)
  L3_2 = TaskPlayAnim
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = 3.0
  L8_2 = 3.0
  L9_2 = -1
  L10_2 = 50
  L11_2 = 0
  L12_2 = false
  L13_2 = false
  L14_2 = false
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L3_2 = PhoneInfo
  L3_2 = L3_2.isOpen
  if not L3_2 then
    L3_2 = deletePhone
    L3_2()
  end
end
CancelPhoneAnim = L7_1
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = "cellphone@"
  L3_2 = A0_2
  L4_2 = IsPedInAnyVehicle
  L5_2 = L1_2
  L6_2 = false
  L4_2 = L4_2(L5_2, L6_2)
  if L4_2 then
    L2_2 = "anim@cellphone@in_car@ps"
  end
  L4_2 = LoadAnimation
  L5_2 = L2_2
  L4_2(L5_2)
  L4_2 = TaskPlayAnim
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = L3_2
  L8_2 = 3.0
  L9_2 = 3.0
  L10_2 = -1
  L11_2 = 50
  L12_2 = 0
  L13_2 = false
  L14_2 = false
  L15_2 = false
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L4_2 = AnimationData
  L4_2.lib = L2_2
  L4_2 = AnimationData
  L4_2.anim = L3_2
  L4_2 = CheckAnimLoop
  L5_2 = L2_2
  L6_2 = L3_2
  L4_2(L5_2, L6_2)
end
DoPhoneAnimation = L7_1
function L7_1()
  local L0_2, L1_2
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    while true do
      L0_3 = AnimationData
      L0_3 = L0_3.lib
      if nil == L0_3 then
        break
      end
      L0_3 = AnimationData
      L0_3 = L0_3.anim
      if nil == L0_3 then
        break
      end
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = IsEntityPlayingAnim
      L2_3 = L0_3
      L3_3 = AnimationData
      L3_3 = L3_3.lib
      L4_3 = AnimationData
      L4_3 = L4_3.anim
      L5_3 = 3
      L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3)
      if not L1_3 then
        L1_3 = LoadAnimation
        L2_3 = AnimationData
        L2_3 = L2_3.lib
        L1_3(L2_3)
        L1_3 = TaskPlayAnim
        L2_3 = L0_3
        L3_3 = AnimationData
        L3_3 = L3_3.lib
        L4_3 = AnimationData
        L4_3 = L4_3.anim
        L5_3 = 3.0
        L6_3 = 3.0
        L7_3 = -1
        L8_3 = 50
        L9_3 = 0
        L10_3 = false
        L11_3 = false
        L12_3 = false
        L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
      end
      L1_3 = Citizen
      L1_3 = L1_3.Wait
      L2_3 = 500
      L1_3(L2_3)
    end
  end
  L0_2(L1_2)
end
CheckAnimLoop = L7_1
function L7_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L3_2 = L2_1
  if L3_2 == A0_2 and true ~= A2_2 then
    return
  end
  L3_2 = GetPlayerPed
  L4_2 = -1
  L3_2 = L3_2(L4_2)
  myPedId = L3_2
  L3_2 = A1_2 or L3_2
  if not A1_2 then
    L3_2 = false
  end
  L4_2 = "cellphone@"
  L5_2 = IsPedInAnyVehicle
  L6_2 = myPedId
  L7_2 = false
  L5_2 = L5_2(L6_2, L7_2)
  if L5_2 then
    L4_2 = "anim@cellphone@in_car@ps"
  end
  L5_2 = loadAnimDict
  L6_2 = L4_2
  L5_2(L6_2)
  L5_2 = L6_1
  L5_2 = L5_2[L4_2]
  L6_2 = L2_1
  L5_2 = L5_2[L6_2]
  L5_2 = L5_2[A0_2]
  L6_2 = L2_1
  if "out" ~= L6_2 then
    L6_2 = StopAnimTask
    L7_2 = myPedId
    L8_2 = L3_1
    L9_2 = L4_1
    L10_2 = 1.0
    L6_2(L7_2, L8_2, L9_2, L10_2)
  end
  L6_2 = 50
  if true == L3_2 then
    L6_2 = 14
  end
  L7_2 = TaskPlayAnim
  L8_2 = myPedId
  L9_2 = L4_2
  L10_2 = L5_2
  L11_2 = 3.0
  L12_2 = -1
  L13_2 = -1
  L14_2 = L6_2
  L15_2 = 0
  L16_2 = false
  L17_2 = false
  L18_2 = false
  L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  if "out" ~= A0_2 then
    L7_2 = L2_1
    if "out" == L7_2 then
      L7_2 = Citizen
      L7_2 = L7_2.Wait
      L8_2 = 380
      L7_2(L8_2)
      L7_2 = newPhoneProp
      L7_2()
    end
  end
  L3_1 = L4_2
  L4_1 = L5_2
  L5_1 = L3_2
  L2_1 = A0_2
  if "out" == A0_2 then
    L7_2 = Citizen
    L7_2 = L7_2.Wait
    L8_2 = 180
    L7_2(L8_2)
    L7_2 = deletePhone
    L7_2()
    L7_2 = StopAnimTask
    L8_2 = myPedId
    L9_2 = L3_1
    L10_2 = L4_1
    L11_2 = 1.0
    L7_2(L8_2, L9_2, L10_2, L11_2)
  end
end
PhonePlayAnim = L7_1
function L7_1()
  local L0_2, L1_2
  L0_2 = PhonePlayAnim
  L1_2 = "out"
  L0_2(L1_2)
end
PhonePlayOut = L7_1
function L7_1()
  local L0_2, L1_2
  L0_2 = PhonePlayAnim
  L1_2 = "text"
  L0_2(L1_2)
end
PhonePlayText = L7_1
function L7_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PhonePlayAnim
  L2_2 = "call"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
PhonePlayCall = L7_1
function L7_1()
  local L0_2, L1_2
  L0_2 = L2_1
  if "out" == L0_2 then
    L0_2 = PhonePlayText
    L0_2()
  end
end
PhonePlayIn = L7_1
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = RequestAnimDict
  L2_2 = A0_2
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Citizen
    L1_2 = L1_2.Wait
    L2_2 = 1
    L1_2(L2_2)
  end
end
loadAnimDict = L7_1
