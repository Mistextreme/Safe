RegisterNetEvent('qb-phone:client:AddTransaction', function(_, _, Message, Title)
    local Data = {
        TransactionTitle = Title,
        TransactionMessage = Message,
    }
    TriggerServerEvent('qb-phone:server:AddTransaction', Data)
end)

RegisterNUICallback('GetCryptoData', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback('ls-crypto:server:GetCryptoData', function(CryptoData)
        cb(CryptoData)
    end, data.crypto)
end)

RegisterNUICallback('GetCryptoTransactions', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback('ls-crypto:server:GetCryptoTransactions', function(CryptoData)
        cb(CryptoData)
    end, data.crypto)
end)

RegisterNUICallback('BuyCrypto', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback('ls-crypto:server:BuyCrypto', function(CryptoData)
        cb(CryptoData)
    end, data)
end)
RegisterNUICallback('SellCrypto', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback('ls-crypto:server:SellCrypto', function(CryptoData)
        cb(CryptoData)
    end, data)
end)
RegisterNUICallback('TransferCrypto', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback('ls-crypto:server:TransferCrypto', function(CryptoData)
        cb(CryptoData)
    end, data)
end)
RegisterNUICallback('getPlayerJob', function(data, cb)
    cb(LS_CORE.Functions.GetPlayerData().PlayerData.job.name)
end)


RegisterNUICallback('PayInvoice', function(data, cb)
    local senderCitizenId = data.senderCitizenId
    local society = data.society
    local amount = data.amount
    local invoiceId = data.invoiceId
    LS_CORE.Callback.Functions.TriggerCallback('esx_billing:payBill', function(Invoices)
        LS_CORE.Callback.Functions.TriggerCallback("ls-phone:s:getAllBilling", function(result)
            cb(result)
        end)
    end, invoiceId)
    --TriggerServerEvent('qb-phone:server:BillingEmail', data, true)
end)

RegisterNUICallback('getAllBilling', function(data, cb)
    LS_CORE.Callback.Functions.TriggerCallback("ls-phone:s:getAllBilling", function(result)
        cb(result)
    end)
end)


-- RegisterNetEvent("esx:setAccountMoney", function(type, amount, action, reason)
--     if (type == "bank") then
--         SendNUIMessage({
--             action = "moneyChanged",
--             moneyAmount = amount,
--             moneyAction = action,
--             moneyReason = reason
--         })
--     end
-- end)

AddPlayerToCall = function(call)
    if GetResourceState("pma-voice") == "started" then
        exports['pma-voice']:addPlayerToCall(call)
    else
        exports.saltychat:SetRadioChannel(call, false)
    end
end
RemovePlayerFromCall = function(call)
    if GetResourceState("pma-voice") == "started" then
        exports['pma-voice']:removePlayerFromCall(call)
    else
        exports.saltychat:SetRadioChannel("", false)
    end
end

RegisterCommand("openphone", function()
    TriggerServerEvent("ls-phone:s:tryOpenPhone")
end)
RegisterKeyMapping('openphone', 'Phone Shortcut', 'keyboard', 'M')


PhoneisOpen = function()
   return PhoneInfo.isOpen
end


PhoneisDead = function(typss)
    if typss == nil then 
        typss = not isplayerdead
    end
    isplayerdead = typss

   

    if isplayerdead == true then 
        ClosePhone()

        SendNUIMessage({
            action = "close",
        })
    end
end


