fx_version 'cerulean'
games { 'gta5' }

author 'Eviate'
description 'Tow Rope Script'
version '1.0.1'

shared_scripts {
	'config.js',
}

client_scripts {
	'client/cl_*.js',
}

server_scripts {
	'sv_main.js',
}
