Config = {}

Config.Command = {
    use = true,
    commandName = "fb_garage",
    event = "fb_garage:open", -- Eviter de changer par sécurité

    jobs = {
        "police",
        "cardealer",
        "mecano",
        "ambulance"
    },

    types = {
        "Entreprise",
        "Personnel"
    },

    coords = {
        {
            id = 1,
            name = "Garage 1",
            jobs = {
                "police",
                "mecano"
            },
            garage = { x = 216.685715, y = -809.775818, z = 30.712036 },
            spawn = { x = 219.890106, y = -785.195618, z = 30.779541 },
            types = {
                "Entreprise",
                "Fourrière"
            }
        },
        {
            id = 2,
            name = "Garage 2",
            jobs = { "ambulance" },
            garage = {
                x = 231.837372, y = -786.870300, z = 30.644653
            },
            spawn = {
                x = 225.613190, y = -765.876892, z = 30.796387
            },
            types = {
                "Entreprise",
                "Fourrière",
                "Personnel"
            }
        }
    },
    message = "Appuyez sur ~INPUT_PICKUP~ pour ouvrir le garage",
    vehicles = {
        {
            name = "Blista",
            model = "blista",
            brand = "Declasse",
            plate = "ABC123",
            owner = "VY.E",
            location = {
                "Entreprise"
            }
        },
        {
            name = "Blista",
            model = "blista",
            brand = "Declasse",
            plate = "ABC123222",
            owner = "VY.ssssssE",
            location = "Entreprise"
        },
        {
            name = "Blista",
            model = "blista",
            brand = "Declasse",
            plate = "ABC123222",
            owner = "VY.dsqdqsE",
            location = {
                "Entreprise",
                "Fourrière"
            }
        },
        {
            name = "SALOPE",
            model = "sultan2",
            brand = "Declasse",
            plate = "ABC123222",
            owner = "VY.dsqdqsE",
            location = {
                "Entreprise",
                "Fourrière"
            }
        },
    }
}
