local L0_1, L1_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = IsLoadingPromptBeingDisplayed
  L2_2 = L2_2()
  if L2_2 then
    L2_2 = RemoveLoadingPrompt
    L2_2()
  end
  if nil == A0_2 then
    L2_2 = BeginTextCommandBusyString
    L3_2 = nil
    L2_2(L3_2)
  else
    L2_2 = BeginTextCommandBusyString
    L3_2 = "STRING"
    L2_2(L3_2)
    L2_2 = AddTextComponentSubstringPlayerName
    L3_2 = A0_2
    L2_2(L3_2)
  end
  L2_2 = EndTextCommandBusyString
  L3_2 = A1_2
  L2_2(L3_2)
end
LoadingPrompt = L0_1
function L0_1()
  local L0_2, L1_2
  L0_2 = IsLoadingPromptBeingDisplayed
  L0_2 = L0_2()
  if L0_2 then
    L0_2 = RemoveLoadingPrompt
    L0_2()
  end
end
LoadingPromptHide = L0_1
