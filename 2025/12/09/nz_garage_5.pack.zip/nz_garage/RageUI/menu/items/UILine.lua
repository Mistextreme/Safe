local L0_1, L1_1, L2_1
L0_1 = {}
L1_1 = {}
L1_1.Y = 0
L1_1.Width = 431
L1_1.Height = 35
L0_1.Rectangle = L1_1
L1_1 = {}
L1_1.X = 8
L1_1.Y = 3
L1_1.Scale = 0.3
L0_1.Text = L1_1
L1_1 = {}
L1_1.Dictionary = "RageUI_"
L1_1.Texture = "custom_background"
L1_1.Y = 0
L1_1.Width = 431
L1_1.Height = 44
L0_1.SelectedSprite = L1_1
L1_1 = RageUI
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L0_2 = RageUI
  L0_2 = L0_2.CurrentMenu
  if nil ~= L0_2 then
    L1_2 = L0_2
    L1_2 = L1_2()
    if L1_2 then
      L1_2 = RageUI
      L1_2 = L1_2.Options
      L1_2 = L1_2 + 1
      L2_2 = L0_2.Pagination
      L2_2 = L2_2.Minimum
      if L1_2 >= L2_2 then
        L2_2 = L0_2.Pagination
        L2_2 = L2_2.Maximum
        if L1_2 <= L2_2 then
          L2_2 = RenderSprite
          L3_2 = L0_1.SelectedSprite
          L3_2 = L3_2.Dictionary
          L4_2 = L0_1.SelectedSprite
          L4_2 = L4_2.Texture
          L5_2 = L0_2.X
          L6_2 = L0_2.WidthOffset
          L6_2 = L6_2 * 2.5
          if 0 ~= L6_2 then
            L6_2 = L0_2.WidthOffset
            L6_2 = L6_2 * 2.5
            if L6_2 then
              goto lbl_38
            end
          end
          L6_2 = 200
          ::lbl_38::
          L5_2 = L5_2 + L6_2
          L5_2 = L5_2 - 150
          L5_2 = L5_2 + 8
          L6_2 = L0_2.Y
          L7_2 = RageUI
          L7_2 = L7_2.ItemOffset
          L6_2 = L6_2 + L7_2
          L6_2 = L6_2 + 43
          L7_2 = 300
          L8_2 = 3
          L9_2 = false
          L10_2 = 255
          L11_2 = 255
          L12_2 = 255
          L13_2 = 220
          L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
          L2_2 = RageUI
          L3_2 = RageUI
          L3_2 = L3_2.ItemOffset
          L4_2 = L0_1.Rectangle
          L4_2 = L4_2.Height
          L3_2 = L3_2 + L4_2
          L2_2.ItemOffset = L3_2
          L2_2 = L0_2.Index
          if L2_2 == L1_2 then
            L2_2 = RageUI
            L2_2 = L2_2.LastControl
            if L2_2 then
              L2_2 = L1_2 - 1
              L0_2.Index = L2_2
              L2_2 = L0_2.Index
              if L2_2 < 1 then
                L2_2 = RageUI
                L2_2 = L2_2.CurrentMenu
                L2_2 = L2_2.Options
                L0_2.Index = L2_2
              end
            else
              L2_2 = L1_2 + 1
              L0_2.Index = L2_2
            end
          end
        end
      end
      L2_2 = RageUI
      L3_2 = RageUI
      L3_2 = L3_2.Options
      L3_2 = L3_2 + 1
      L2_2.Options = L3_2
    end
  end
end
L1_1.Line = L2_1
