local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = {}
L1_1.Y = 0
L1_1.Width = 431
L1_1.Height = 45
L0_1.Rectangle = L1_1
L1_1 = {}
L1_1.X = 8
L1_1.Y = 9
L1_1.Scale = 0.33
L0_1.Text = L1_1
L1_1 = {}
L1_1.Y = 2
L1_1.Width = 40
L1_1.Height = 40
L0_1.LeftBadge = L1_1
L1_1 = {}
L1_1.X = 385
L1_1.Y = 2
L1_1.Width = 40
L1_1.Height = 40
L0_1.RightBadge = L1_1
L1_1 = {}
L1_1.X = 420
L1_1.Y = 9
L1_1.Scale = 0.35
L0_1.RightText = L1_1
L1_1 = {}
L1_1.Dictionary = "RageUI_"
L1_1.Texture = "custom_background"
L1_1.Y = 0
L1_1.Width = 431
L1_1.Height = 44
L0_1.SelectedSprite = L1_1
L1_1 = {}
L2_1 = {}
L2_1.X = 8
L2_1.Y = 33
L2_1.Width = 415
L2_1.Height = 20
L1_1.Background = L2_1
L2_1 = {}
L2_1.X = 11.75
L2_1.Y = 36.75
L2_1.Width = 407.5
L2_1.Height = 12.5
L1_1.Bar = L2_1
L1_1.Height = 60
L2_1 = RageUI
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2)
  local L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  L7_2 = RageUI
  L7_2 = L7_2.CurrentMenu
  if nil ~= L7_2 then
    L8_2 = L7_2
    L8_2 = L8_2()
    if L8_2 then
      L8_2 = {}
      L9_2 = 1
      L10_2 = A2_2
      L11_2 = 1
      for L12_2 = L9_2, L10_2, L11_2 do
        L13_2 = table
        L13_2 = L13_2.insert
        L14_2 = L8_2
        L15_2 = L12_2
        L13_2(L14_2, L15_2)
      end
      L9_2 = RageUI
      L9_2 = L9_2.Options
      L9_2 = L9_2 + 1
      L10_2 = L7_2.Pagination
      L10_2 = L10_2.Minimum
      if L9_2 >= L10_2 then
        L10_2 = L7_2.Pagination
        L10_2 = L10_2.Maximum
        if L9_2 <= L10_2 then
          L10_2 = L7_2.Index
          L10_2 = L10_2 == L9_2
          L11_2 = false
          L12_2 = RageUI
          L12_2 = L12_2.ItemsSafeZone
          L13_2 = L7_2
          L12_2(L13_2)
          L12_2 = false
          L13_2 = L7_2.EnableMouse
          if true == L13_2 then
            L13_2 = L7_2.CursorStyle
            if 0 == L13_2 then
              goto lbl_53
            end
          end
          L13_2 = L7_2.CursorStyle
          ::lbl_53::
          if 1 == L13_2 then
            L13_2 = RageUI
            L13_2 = L13_2.ItemsMouseBounds
            L14_2 = L7_2
            L15_2 = L10_2
            L16_2 = L9_2
            L17_2 = L0_1
            L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2)
            L12_2 = L13_2
          end
          if A4_2 then
            L13_2 = A1_2
            L14_2 = "/"
            L15_2 = #L8_2
            L13_2 = L13_2 .. L14_2 .. L15_2
            if L13_2 then
              goto lbl_83
            end
          end
          L13_2 = type
          L14_2 = L8_2[A1_2]
          L13_2 = L13_2(L14_2)
          if "table" == L13_2 then
            L13_2 = tostring
            L14_2 = L8_2[A1_2]
            L14_2 = L14_2.Name
            L13_2 = L13_2(L14_2)
            if L13_2 then
              goto lbl_83
            end
          end
          L13_2 = tostring
          L14_2 = L8_2[A1_2]
          L13_2 = L13_2(L14_2)
          ::lbl_83::
          L14_2 = RenderSprite
          L15_2 = L0_1.SelectedSprite
          L15_2 = L15_2.Dictionary
          L16_2 = L0_1.SelectedSprite
          L16_2 = L16_2.Texture
          L17_2 = L7_2.X
          L18_2 = L7_2.Y
          L19_2 = L0_1.SelectedSprite
          L19_2 = L19_2.Y
          L18_2 = L18_2 + L19_2
          L19_2 = L7_2.SubtitleHeight
          L18_2 = L18_2 + L19_2
          L19_2 = RageUI
          L19_2 = L19_2.ItemOffset
          L18_2 = L18_2 + L19_2
          L19_2 = L0_1.SelectedSprite
          L19_2 = L19_2.Width
          L20_2 = L7_2.WidthOffset
          L19_2 = L19_2 + L20_2
          L20_2 = L0_1.SelectedSprite
          L20_2 = L20_2.Height
          L21_2 = false
          L22_2 = 0
          L23_2 = 0
          L24_2 = 0
          L25_2 = 200
          L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
          if L10_2 then
            L14_2 = RenderSprite
            L15_2 = L0_1.SelectedSprite
            L15_2 = L15_2.Dictionary
            L16_2 = L0_1.SelectedSprite
            L16_2 = L16_2.Texture
            L17_2 = L7_2.X
            L18_2 = L7_2.Y
            L19_2 = L0_1.SelectedSprite
            L19_2 = L19_2.Y
            L18_2 = L18_2 + L19_2
            L19_2 = L7_2.SubtitleHeight
            L18_2 = L18_2 + L19_2
            L19_2 = RageUI
            L19_2 = L19_2.ItemOffset
            L18_2 = L18_2 + L19_2
            L19_2 = L0_1.SelectedSprite
            L19_2 = L19_2.Width
            L20_2 = L7_2.WidthOffset
            L19_2 = L19_2 + L20_2
            L20_2 = L0_1.SelectedSprite
            L20_2 = L20_2.Height
            L21_2 = false
            L22_2 = 255
            L23_2 = 255
            L24_2 = 255
            L25_2 = 255
            L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
            L14_2 = RageUI
            L14_2 = L14_2.IsMouseInBounds
            L15_2 = L7_2.X
            L16_2 = L1_1.Bar
            L16_2 = L16_2.X
            L15_2 = L15_2 + L16_2
            L16_2 = L7_2.SafeZoneSize
            L16_2 = L16_2.X
            L15_2 = L15_2 + L16_2
            L16_2 = L7_2.Y
            L17_2 = L1_1.Bar
            L17_2 = L17_2.Y
            L16_2 = L16_2 + L17_2
            L17_2 = L7_2.SafeZoneSize
            L17_2 = L17_2.Y
            L16_2 = L16_2 + L17_2
            L17_2 = L7_2.SubtitleHeight
            L16_2 = L16_2 + L17_2
            L17_2 = RageUI
            L17_2 = L17_2.ItemOffset
            L16_2 = L16_2 + L17_2
            L16_2 = L16_2 - 12
            L17_2 = L1_1.Bar
            L17_2 = L17_2.Width
            L18_2 = L7_2.WidthOffset
            L17_2 = L17_2 + L18_2
            L18_2 = L1_1.Bar
            L18_2 = L18_2.Height
            L18_2 = L18_2 + 24
            L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2)
            L11_2 = L14_2
          end
          if true == A5_2 or nil == A5_2 then
            if L10_2 then
              L14_2 = RenderText
              L15_2 = L13_2
              L16_2 = L7_2.X
              L17_2 = L0_1.RightText
              L17_2 = L17_2.X
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.WidthOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.Y
              L18_2 = L0_1.RightText
              L18_2 = L18_2.Y
              L17_2 = L17_2 + L18_2
              L18_2 = L7_2.SubtitleHeight
              L17_2 = L17_2 + L18_2
              L18_2 = RageUI
              L18_2 = L18_2.ItemOffset
              L17_2 = L17_2 + L18_2
              L18_2 = 0
              L19_2 = L0_1.RightText
              L19_2 = L19_2.Scale
              L20_2 = 255
              L21_2 = 255
              L22_2 = 255
              L23_2 = 255
              L24_2 = 2
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
              L14_2 = RenderText
              L15_2 = A0_2
              L16_2 = L7_2.X
              L17_2 = L0_1.Text
              L17_2 = L17_2.X
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.Y
              L18_2 = L0_1.Text
              L18_2 = L18_2.Y
              L17_2 = L17_2 + L18_2
              L18_2 = L7_2.SubtitleHeight
              L17_2 = L17_2 + L18_2
              L18_2 = RageUI
              L18_2 = L18_2.ItemOffset
              L17_2 = L17_2 + L18_2
              L18_2 = 0
              L19_2 = L0_1.Text
              L19_2 = L19_2.Scale
              L20_2 = 255
              L21_2 = 255
              L22_2 = 255
              L23_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Background
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Background
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L1_1.Background
              L17_2 = L17_2.Width
              L18_2 = L7_2.WidthOffset
              L17_2 = L17_2 + L18_2
              L18_2 = L1_1.Background
              L18_2 = L18_2.Height
              L19_2 = 0
              L20_2 = 0
              L21_2 = 0
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Bar
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Bar
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = #L8_2
              L17_2 = A1_2 / L17_2
              L18_2 = L1_1.Bar
              L18_2 = L18_2.Width
              L19_2 = L7_2.WidthOffset
              L18_2 = L18_2 + L19_2
              L17_2 = L17_2 * L18_2
              L18_2 = L1_1.Bar
              L18_2 = L18_2.Height
              L19_2 = 240
              L20_2 = 240
              L21_2 = 240
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            else
              L14_2 = RenderText
              L15_2 = L13_2
              L16_2 = L7_2.X
              L17_2 = L0_1.RightText
              L17_2 = L17_2.X
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.WidthOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.Y
              L18_2 = L0_1.RightText
              L18_2 = L18_2.Y
              L17_2 = L17_2 + L18_2
              L18_2 = L7_2.SubtitleHeight
              L17_2 = L17_2 + L18_2
              L18_2 = RageUI
              L18_2 = L18_2.ItemOffset
              L17_2 = L17_2 + L18_2
              L18_2 = 0
              L19_2 = L0_1.RightText
              L19_2 = L19_2.Scale
              L20_2 = 255
              L21_2 = 255
              L22_2 = 255
              L23_2 = 255
              L24_2 = 2
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
              L14_2 = RenderText
              L15_2 = A0_2
              L16_2 = L7_2.X
              L17_2 = L0_1.Text
              L17_2 = L17_2.X
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.Y
              L18_2 = L0_1.Text
              L18_2 = L18_2.Y
              L17_2 = L17_2 + L18_2
              L18_2 = L7_2.SubtitleHeight
              L17_2 = L17_2 + L18_2
              L18_2 = RageUI
              L18_2 = L18_2.ItemOffset
              L17_2 = L17_2 + L18_2
              L18_2 = 0
              L19_2 = L0_1.Text
              L19_2 = L19_2.Scale
              L20_2 = 255
              L21_2 = 255
              L22_2 = 255
              L23_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Background
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Background
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L1_1.Background
              L17_2 = L17_2.Width
              L18_2 = L7_2.WidthOffset
              L17_2 = L17_2 + L18_2
              L18_2 = L1_1.Background
              L18_2 = L18_2.Height
              L19_2 = 240
              L20_2 = 240
              L21_2 = 240
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Bar
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Bar
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = #L8_2
              L17_2 = A1_2 / L17_2
              L18_2 = L1_1.Bar
              L18_2 = L18_2.Width
              L19_2 = L7_2.WidthOffset
              L18_2 = L18_2 + L19_2
              L17_2 = L17_2 * L18_2
              L18_2 = L1_1.Bar
              L18_2 = L18_2.Height
              L19_2 = 0
              L20_2 = 0
              L21_2 = 0
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            end
          else
            L14_2 = RenderText
            L15_2 = L13_2
            L16_2 = L7_2.X
            L17_2 = L0_1.RightText
            L17_2 = L17_2.X
            L16_2 = L16_2 + L17_2
            L17_2 = L7_2.WidthOffset
            L16_2 = L16_2 + L17_2
            L17_2 = L7_2.Y
            L18_2 = L0_1.RightText
            L18_2 = L18_2.Y
            L17_2 = L17_2 + L18_2
            L18_2 = L7_2.SubtitleHeight
            L17_2 = L17_2 + L18_2
            L18_2 = RageUI
            L18_2 = L18_2.ItemOffset
            L17_2 = L17_2 + L18_2
            L18_2 = 0
            L19_2 = L0_1.RightText
            L19_2 = L19_2.Scale
            L20_2 = 163
            L21_2 = 159
            L22_2 = 148
            L23_2 = 255
            L24_2 = 2
            L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
            L14_2 = RenderText
            L15_2 = A0_2
            L16_2 = L7_2.X
            L17_2 = L0_1.Text
            L17_2 = L17_2.X
            L16_2 = L16_2 + L17_2
            L17_2 = L7_2.Y
            L18_2 = L0_1.Text
            L18_2 = L18_2.Y
            L17_2 = L17_2 + L18_2
            L18_2 = L7_2.SubtitleHeight
            L17_2 = L17_2 + L18_2
            L18_2 = RageUI
            L18_2 = L18_2.ItemOffset
            L17_2 = L17_2 + L18_2
            L18_2 = 0
            L19_2 = L0_1.Text
            L19_2 = L19_2.Scale
            L20_2 = 163
            L21_2 = 159
            L22_2 = 148
            L23_2 = 255
            L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
            if L10_2 then
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Background
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Background
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L1_1.Background
              L17_2 = L17_2.Width
              L18_2 = L7_2.WidthOffset
              L17_2 = L17_2 + L18_2
              L18_2 = L1_1.Background
              L18_2 = L18_2.Height
              L19_2 = 0
              L20_2 = 0
              L21_2 = 0
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            else
              L14_2 = RenderRectangle
              L15_2 = L7_2.X
              L16_2 = L1_1.Background
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L16_2 = L7_2.Y
              L17_2 = L1_1.Background
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L7_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = L1_1.Background
              L17_2 = L17_2.Width
              L18_2 = L7_2.WidthOffset
              L17_2 = L17_2 + L18_2
              L18_2 = L1_1.Background
              L18_2 = L18_2.Height
              L19_2 = 240
              L20_2 = 240
              L21_2 = 240
              L22_2 = 255
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            end
          end
          L14_2 = RageUI
          L15_2 = RageUI
          L15_2 = L15_2.ItemOffset
          L16_2 = L1_1.Height
          L15_2 = L15_2 + L16_2
          L14_2.ItemOffset = L15_2
          L14_2 = RageUI
          L14_2 = L14_2.ItemsDescription
          L15_2 = L7_2
          L16_2 = A3_2
          L17_2 = L10_2
          L14_2(L15_2, L16_2, L17_2)
          if L10_2 then
            L14_2 = L7_2.Controls
            L14_2 = L14_2.Left
            L14_2 = L14_2.Active
            if L14_2 then
              L14_2 = L7_2.Controls
              L14_2 = L14_2.Right
              L14_2 = L14_2.Active
              if not L14_2 then
                A1_2 = A1_2 - 1
                if A1_2 < 0 then
                  A1_2 = #L8_2
                end
                L14_2 = RageUI
                L14_2 = L14_2.Settings
                L14_2 = L14_2.Audio
                L15_2 = RageUI
                L15_2 = L15_2.PlaySound
                L16_2 = L14_2.Use
                L16_2 = L14_2[L16_2]
                L16_2 = L16_2.LeftRight
                L16_2 = L16_2.audioName
                L17_2 = L14_2.Use
                L17_2 = L14_2[L17_2]
                L17_2 = L17_2.LeftRight
                L17_2 = L17_2.audioRef
                L15_2(L16_2, L17_2)
            end
          end
          elseif L10_2 then
            L14_2 = L7_2.Controls
            L14_2 = L14_2.Right
            L14_2 = L14_2.Active
            if L14_2 then
              L14_2 = L7_2.Controls
              L14_2 = L14_2.Left
              L14_2 = L14_2.Active
              if not L14_2 then
                A1_2 = A1_2 + 1
                L14_2 = #L8_2
                if A1_2 > L14_2 then
                  A1_2 = 0
                end
                L14_2 = RageUI
                L14_2 = L14_2.Settings
                L14_2 = L14_2.Audio
                L15_2 = RageUI
                L15_2 = L15_2.PlaySound
                L16_2 = L14_2.Use
                L16_2 = L14_2[L16_2]
                L16_2 = L16_2.LeftRight
                L16_2 = L16_2.audioName
                L17_2 = L14_2.Use
                L17_2 = L14_2[L17_2]
                L17_2 = L17_2.LeftRight
                L17_2 = L17_2.audioRef
                L15_2(L16_2, L17_2)
              end
            end
          end
          if L10_2 then
            L14_2 = L7_2.Controls
            L14_2 = L14_2.Select
            L14_2 = L14_2.Active
            if not L14_2 then
              if not L12_2 then
                goto lbl_670
              end
              L14_2 = L7_2.Controls
              L14_2 = L14_2.Click
              L14_2 = L14_2.Active
              if not L14_2 or L11_2 then
                goto lbl_670
              end
            end
            L14_2 = RageUI
            L14_2 = L14_2.Settings
            L14_2 = L14_2.Audio
            L15_2 = RageUI
            L15_2 = L15_2.PlaySound
            L16_2 = L14_2.Use
            L16_2 = L14_2[L16_2]
            L16_2 = L16_2.Select
            L16_2 = L16_2.audioName
            L17_2 = L14_2.Use
            L17_2 = L14_2[L17_2]
            L17_2 = L17_2.Select
            L17_2 = L17_2.audioRef
            L15_2(L16_2, L17_2)
          ::lbl_670::
          elseif L10_2 and L12_2 then
            L14_2 = L7_2.Controls
            L14_2 = L14_2.Click
            L14_2 = L14_2.Active
            if L14_2 and L11_2 then
              L14_2 = math
              L14_2 = L14_2.round
              L15_2 = GetControlNormal
              L16_2 = 2
              L17_2 = 239
              L15_2 = L15_2(L16_2, L17_2)
              L15_2 = L15_2 * 1920
              L14_2 = L14_2(L15_2)
              L15_2 = L7_2.SafeZoneSize
              L15_2 = L15_2.X
              L14_2 = L14_2 - L15_2
              L15_2 = L1_1.Bar
              L15_2 = L15_2.X
              L14_2 = L14_2 - L15_2
              L15_2 = L1_1.Bar
              L15_2 = L15_2.Width
              L16_2 = L7_2.WidthOffset
              L15_2 = L15_2 + L16_2
              if L14_2 > L15_2 then
                L14_2 = L15_2
              elseif L14_2 < 0 then
                L14_2 = 0
              end
              L16_2 = math
              L16_2 = L16_2.round
              L17_2 = #L8_2
              L18_2 = L14_2 / L15_2
              L17_2 = L17_2 * L18_2
              L16_2 = L16_2(L17_2)
              A1_2 = L16_2
              L16_2 = #L8_2
              if A1_2 > L16_2 or A1_2 < 0 then
                A1_2 = 0
              end
            end
          end
          if A5_2 then
            L14_2 = A6_2
            L15_2 = L12_2
            L16_2 = L10_2
            L17_2 = L7_2.Controls
            L17_2 = L17_2.Select
            L17_2 = L17_2.Active
            if not L17_2 then
              if not L12_2 then
                goto lbl_748
                L17_2 = L12_2 or L17_2
              end
              L17_2 = L7_2.Controls
              L17_2 = L17_2.Click
              L17_2 = L17_2.Active
            end
            L17_2 = L17_2 and not L11_2 and L17_2
            ::lbl_748::
            L18_2 = A1_2
            L14_2(L15_2, L16_2, L17_2, L18_2)
          end
        end
      end
      L10_2 = RageUI
      L11_2 = RageUI
      L11_2 = L11_2.Options
      L11_2 = L11_2 + 1
      L10_2.Options = L11_2
      L8_2 = nil
    end
  end
end
L2_1.Progress = L3_1
