local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = {}
L1_1 = {}
L1_1.Y = 0
L1_1.Width = 400
L1_1.Height = 45
L0_1.Rectangle = L1_1
L1_1 = {}
L1_1.X = -13
L1_1.Y = 14
L1_1.Scale = 0.28
L0_1.Text = L1_1
L1_1 = {}
L1_1.Y = 30
L1_1.Width = 37
L1_1.Height = 37
L0_1.LeftBadge = L1_1
L1_1 = {}
L1_1.X = 340
L1_1.Y = 28.5
L1_1.Width = 40
L1_1.Height = 40
L0_1.RightBadge = L1_1
L1_1 = {}
L1_1.X = 400
L1_1.Y = 18
L1_1.Scale = 0.25
L0_1.RightText = L1_1
L1_1 = {}
L1_1.Dictionary = "commonmenu"
L1_1.Texture = "background"
L1_1.Y = 8
L1_1.Width = 430
L1_1.Height = 42
L0_1.SelectedSprite = L1_1
L1_1 = 0
L2_1 = false
L3_1 = true
L4_1 = false
L5_1 = 100
L6_1 = RageUI
function L7_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  if A3_2 then
    L6_2 = isWaitingForServer
    A3_2 = not L6_2
  end
  L6_2 = RageUI
  L6_2 = L6_2.CurrentMenu
  if nil ~= L6_2 then
    L7_2 = L6_2
    L7_2 = L7_2()
    if L7_2 then
      L7_2 = RageUI
      L7_2 = L7_2.Options
      L7_2 = L7_2 + 1
      L8_2 = L6_2.Pagination
      L8_2 = L8_2.Minimum
      if L7_2 >= L8_2 then
        L8_2 = L6_2.Pagination
        L8_2 = L8_2.Maximum
        if L7_2 <= L8_2 then
          L8_2 = L6_2.Index
          L8_2 = L8_2 == L7_2
          L9_2 = RageUI
          L9_2 = L9_2.ItemsSafeZone
          L10_2 = L6_2
          L9_2(L10_2)
          L9_2 = A2_2.LeftBadge
          if L9_2 then
            L9_2 = A2_2.LeftBadge
            L10_2 = RageUI
            L10_2 = L10_2.BadgeStyle
            L10_2 = L10_2.None
            L9_2 = L9_2 ~= L10_2
          end
          L10_2 = A2_2.RightBadge
          if L10_2 then
            L10_2 = A2_2.RightBadge
            L11_2 = RageUI
            L11_2 = L11_2.BadgeStyle
            L11_2 = L11_2.None
          end
          L10_2 = L10_2 ~= L11_2
          if L9_2 then
            L11_2 = 27
            if L11_2 then
              goto lbl_70
            end
          end
          L11_2 = 0
          ::lbl_70::
          if L10_2 then
            L12_2 = 32
            if L12_2 then
              goto lbl_76
            end
          end
          L12_2 = 0
          ::lbl_76::
          L13_2 = RenderSprite
          L14_2 = "commonmenu"
          L15_2 = "bouton"
          L16_2 = L6_2.X
          L16_2 = L16_2 + 7
          L17_2 = L6_2.Y
          L17_2 = L17_2 + 20
          L18_2 = L0_1.SelectedSprite
          L18_2 = L18_2.Y
          L17_2 = L17_2 + L18_2
          L18_2 = L6_2.SubtitleHeight
          L17_2 = L17_2 + L18_2
          L18_2 = RageUI
          L18_2 = L18_2.ItemOffset
          L17_2 = L17_2 + L18_2
          L18_2 = L0_1.SelectedSprite
          L18_2 = L18_2.Width
          L19_2 = L6_2.WidthOffset
          L18_2 = L18_2 + L19_2
          L18_2 = L18_2 - 55
          L19_2 = L0_1.SelectedSprite
          L19_2 = L19_2.Height
          L19_2 = L19_2 - 1
          L20_2 = 0
          L21_2 = 0
          L22_2 = 0
          L23_2 = 0
          L24_2 = 100
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          if L8_2 then
            L13_2 = RenderSprite
            L14_2 = "commonmenu"
            L15_2 = "bouton"
            L16_2 = L6_2.X
            L16_2 = L16_2 + 7
            L17_2 = L6_2.Y
            L17_2 = L17_2 + 20
            L18_2 = L0_1.SelectedSprite
            L18_2 = L18_2.Y
            L17_2 = L17_2 + L18_2
            L18_2 = L6_2.SubtitleHeight
            L17_2 = L17_2 + L18_2
            L18_2 = RageUI
            L18_2 = L18_2.ItemOffset
            L17_2 = L17_2 + L18_2
            L18_2 = L0_1.SelectedSprite
            L18_2 = L18_2.Width
            L19_2 = L6_2.WidthOffset
            L18_2 = L18_2 + L19_2
            L18_2 = L18_2 - 55
            L19_2 = L0_1.SelectedSprite
            L19_2 = L19_2.Height
            L19_2 = L19_2 - 1
            L20_2 = 0
            L21_2 = Configk2rUI
            L21_2 = L21_2.Menu
            L21_2 = L21_2.CouleurBouton
            L21_2 = L21_2.R
            L22_2 = Configk2rUI
            L22_2 = L22_2.Menu
            L22_2 = L22_2.CouleurBouton
            L22_2 = L22_2.G
            L23_2 = Configk2rUI
            L23_2 = L23_2.Menu
            L23_2 = L23_2.CouleurBouton
            L23_2 = L23_2.B
            L24_2 = 100
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          end
          if A3_2 then
            if L9_2 then
              L13_2 = A2_2.LeftBadge
              if nil ~= L13_2 then
                L13_2 = A2_2.LeftBadge
                L14_2 = L8_2
                L13_2 = L13_2(L14_2)
                L14_2 = RenderSprite
                L15_2 = L13_2.BadgeDictionary
                if not L15_2 then
                  L15_2 = "commonmenu"
                end
                L16_2 = L13_2.BadgeTexture
                if not L16_2 then
                  L16_2 = ""
                end
                L17_2 = L6_2.X
                L17_2 = L17_2 + 7
                L18_2 = L6_2.Y
                L19_2 = L0_1.LeftBadge
                L19_2 = L19_2.Y
                L18_2 = L18_2 + L19_2
                L19_2 = L6_2.SubtitleHeight
                L18_2 = L18_2 + L19_2
                L19_2 = RageUI
                L19_2 = L19_2.ItemOffset
                L18_2 = L18_2 + L19_2
                L19_2 = L0_1.LeftBadge
                L19_2 = L19_2.Width
                L20_2 = L0_1.LeftBadge
                L20_2 = L20_2.Height
                L21_2 = 0
                L22_2 = L13_2.BadgeColour
                if L22_2 then
                  L22_2 = L13_2.BadgeColour
                  L22_2 = L22_2.R
                  if L22_2 then
                    goto lbl_208
                  end
                end
                L22_2 = 255
                ::lbl_208::
                L23_2 = L13_2.BadgeColour
                if L23_2 then
                  L23_2 = L13_2.BadgeColour
                  L23_2 = L23_2.G
                  if L23_2 then
                    goto lbl_216
                  end
                end
                L23_2 = 255
                ::lbl_216::
                L24_2 = L13_2.BadgeColour
                if L24_2 then
                  L24_2 = L13_2.BadgeColour
                  L24_2 = L24_2.B
                  if L24_2 then
                    goto lbl_224
                  end
                end
                L24_2 = 255
                ::lbl_224::
                L25_2 = L13_2.BadgeColour
                if L25_2 then
                  L25_2 = L13_2.BadgeColour
                  L25_2 = L25_2.A
                  if L25_2 then
                    goto lbl_232
                  end
                end
                L25_2 = 255
                ::lbl_232::
                L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
              end
            end
            if L10_2 then
              L13_2 = A2_2.RightBadge
              if nil ~= L13_2 then
                L13_2 = A2_2.RightBadge
                L14_2 = L8_2
                L13_2 = L13_2(L14_2)
                L14_2 = RenderSprite
                L15_2 = L13_2.BadgeDictionary
                if not L15_2 then
                  L15_2 = "commonmenu"
                end
                L16_2 = L13_2.BadgeTexture
                if not L16_2 then
                  L16_2 = ""
                end
                L17_2 = L6_2.X
                L18_2 = L0_1.RightBadge
                L18_2 = L18_2.X
                L17_2 = L17_2 + L18_2
                L18_2 = L6_2.WidthOffset
                L17_2 = L17_2 + L18_2
                L18_2 = L6_2.Y
                L19_2 = L0_1.RightBadge
                L19_2 = L19_2.Y
                L18_2 = L18_2 + L19_2
                L19_2 = L6_2.SubtitleHeight
                L18_2 = L18_2 + L19_2
                L19_2 = RageUI
                L19_2 = L19_2.ItemOffset
                L18_2 = L18_2 + L19_2
                L19_2 = L0_1.RightBadge
                L19_2 = L19_2.Width
                L20_2 = L0_1.RightBadge
                L20_2 = L20_2.Height
                L21_2 = 0
                L22_2 = L13_2.BadgeColour
                if L22_2 then
                  L22_2 = L13_2.BadgeColour
                  L22_2 = L22_2.R
                  if L22_2 then
                    goto lbl_283
                  end
                end
                L22_2 = 255
                ::lbl_283::
                L23_2 = L13_2.BadgeColour
                if L23_2 then
                  L23_2 = L13_2.BadgeColour
                  L23_2 = L23_2.G
                  if L23_2 then
                    goto lbl_291
                  end
                end
                L23_2 = 255
                ::lbl_291::
                L24_2 = L13_2.BadgeColour
                if L24_2 then
                  L24_2 = L13_2.BadgeColour
                  L24_2 = L24_2.B
                  if L24_2 then
                    goto lbl_299
                  end
                end
                L24_2 = 255
                ::lbl_299::
                L25_2 = L13_2.BadgeColour
                if L25_2 then
                  L25_2 = L13_2.BadgeColour
                  L25_2 = L25_2.A
                  if L25_2 then
                    goto lbl_307
                  end
                end
                L25_2 = 255
                ::lbl_307::
                L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
              end
            end
            L13_2 = A2_2.RightLabel
            if L13_2 then
              L13_2 = RenderText
              L14_2 = A2_2.RightLabel
              L15_2 = L6_2.X
              L16_2 = L0_1.RightText
              L16_2 = L16_2.X
              L15_2 = L15_2 + L16_2
              L15_2 = L15_2 - L12_2
              L16_2 = L6_2.WidthOffset
              L15_2 = L15_2 + L16_2
              L15_2 = L15_2 - 25
              L16_2 = L6_2.Y
              L16_2 = 20 + L16_2
              L17_2 = L0_1.RightText
              L17_2 = L17_2.Y
              L16_2 = L16_2 + L17_2
              L17_2 = L6_2.SubtitleHeight
              L16_2 = L16_2 + L17_2
              L17_2 = RageUI
              L17_2 = L17_2.ItemOffset
              L16_2 = L16_2 + L17_2
              L17_2 = 0
              L18_2 = L0_1.RightText
              L18_2 = L18_2.Scale
              if L8_2 then
                L19_2 = 255
                if L19_2 then
                  goto lbl_348
                end
              end
              L19_2 = 255
              ::lbl_348::
              if L8_2 then
                L20_2 = 255
                if L20_2 then
                  goto lbl_354
                end
              end
              L20_2 = 255
              ::lbl_354::
              if L8_2 then
                L21_2 = 255
                if L21_2 then
                  goto lbl_360
                end
              end
              L21_2 = 255
              ::lbl_360::
              L22_2 = 255
              L23_2 = 2
              L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
            end
            if not L8_2 then
              L13_2 = 150
              if L13_2 then
                goto lbl_369
              end
            end
            L13_2 = 255
            ::lbl_369::
            if not L8_2 then
              L14_2 = 150
              if L14_2 then
                goto lbl_375
              end
            end
            L14_2 = 255
            ::lbl_375::
            if not L8_2 then
              L15_2 = 150
              if L15_2 then
                goto lbl_381
              end
            end
            L15_2 = 255
            ::lbl_381::
            L16_2 = RenderText
            L17_2 = A0_2 or L17_2
            if L8_2 or not A0_2 then
              L17_2 = A0_2
            end
            L18_2 = L6_2.X
            L19_2 = L0_1.Text
            L19_2 = L19_2.X
            L18_2 = L18_2 + L19_2
            L18_2 = L18_2 + L11_2
            L18_2 = L18_2 + 28
            L19_2 = L6_2.Y
            L19_2 = 20 + L19_2
            L20_2 = L0_1.Text
            L20_2 = L20_2.Y
            L19_2 = L19_2 + L20_2
            L20_2 = L6_2.SubtitleHeight
            L19_2 = L19_2 + L20_2
            L20_2 = RageUI
            L20_2 = L20_2.ItemOffset
            L19_2 = L19_2 + L20_2
            L20_2 = fontIdButton
            L21_2 = L0_1.Text
            L21_2 = L21_2.Scale
            L22_2 = 255
            L23_2 = 255
            L24_2 = 255
            L25_2 = 255
            L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
          else
            if L10_2 then
              L13_2 = RageUI
              L13_2 = L13_2.BadgeStyle
              L13_2 = L13_2.Lock
              L14_2 = L8_2
              L13_2 = L13_2(L14_2)
              L14_2 = RenderSprite
              L15_2 = L13_2.BadgeDictionary
              if not L15_2 then
                L15_2 = "commonmenu"
              end
              L16_2 = L13_2.BadgeTexture
              if not L16_2 then
                L16_2 = ""
              end
              L17_2 = L6_2.X
              L18_2 = L0_1.RightBadge
              L18_2 = L18_2.X
              L17_2 = L17_2 + L18_2
              L18_2 = L6_2.WidthOffset
              L17_2 = L17_2 + L18_2
              L18_2 = L6_2.Y
              L18_2 = 20 + L18_2
              L19_2 = L0_1.RightBadge
              L19_2 = L19_2.Y
              L18_2 = L18_2 + L19_2
              L19_2 = L6_2.SubtitleHeight
              L18_2 = L18_2 + L19_2
              L19_2 = RageUI
              L19_2 = L19_2.ItemOffset
              L18_2 = L18_2 + L19_2
              L19_2 = L0_1.RightBadge
              L19_2 = L19_2.Width
              L20_2 = L0_1.RightBadge
              L20_2 = L20_2.Height
              L21_2 = 0
              L22_2 = L13_2.BadgeColour
              if L22_2 then
                L22_2 = L13_2.BadgeColour
                L22_2 = L22_2.R
                if L22_2 then
                  goto lbl_470
                end
              end
              L22_2 = 255
              ::lbl_470::
              L23_2 = L13_2.BadgeColour
              if L23_2 then
                L23_2 = L13_2.BadgeColour
                L23_2 = L23_2.G
                if L23_2 then
                  goto lbl_478
                end
              end
              L23_2 = 255
              ::lbl_478::
              L24_2 = L13_2.BadgeColour
              if L24_2 then
                L24_2 = L13_2.BadgeColour
                L24_2 = L24_2.B
                if L24_2 then
                  goto lbl_486
                end
              end
              L24_2 = 255
              ::lbl_486::
              L25_2 = L13_2.BadgeColour
              if L25_2 then
                L25_2 = L13_2.BadgeColour
                L25_2 = L25_2.A
                if L25_2 then
                  goto lbl_494
                end
              end
              L25_2 = 255
              ::lbl_494::
              L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
            end
            if not L8_2 then
              L13_2 = 104
              if L13_2 then
                goto lbl_501
              end
            end
            L13_2 = 124
            ::lbl_501::
            if not L8_2 then
              L14_2 = 108
              if L14_2 then
                goto lbl_507
              end
            end
            L14_2 = 129
            ::lbl_507::
            if not L8_2 then
              L15_2 = 114
              if L15_2 then
                goto lbl_513
              end
            end
            L15_2 = 135
            ::lbl_513::
            L16_2 = RenderText
            L17_2 = A0_2
            L18_2 = L6_2.X
            L19_2 = L0_1.Text
            L19_2 = L19_2.X
            L18_2 = L18_2 + L19_2
            L18_2 = L18_2 + L11_2
            L18_2 = L18_2 + 28
            L19_2 = L6_2.Y
            L19_2 = 20 + L19_2
            L20_2 = L0_1.Text
            L20_2 = L20_2.Y
            L19_2 = L19_2 + L20_2
            L20_2 = L6_2.SubtitleHeight
            L19_2 = L19_2 + L20_2
            L20_2 = RageUI
            L20_2 = L20_2.ItemOffset
            L19_2 = L19_2 + L20_2
            L20_2 = L0_1.Text
            L20_2 = L20_2.Scale
            L21_2 = 255
            L22_2 = 255
            L23_2 = 255
            L24_2 = 255
            L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          end
          L13_2 = RageUI
          L14_2 = RageUI
          L14_2 = L14_2.ItemOffset
          L15_2 = L0_1.Rectangle
          L15_2 = L15_2.Height
          L14_2 = L14_2 + L15_2
          L13_2.ItemOffset = L14_2
          L13_2 = RageUI
          L13_2 = L13_2.ItemsDescription
          L14_2 = L6_2
          L15_2 = A1_2
          L16_2 = L8_2
          L13_2(L14_2, L15_2, L16_2)
          if A3_2 then
            L13_2 = L6_2.EnableMouse
            if L13_2 then
              L13_2 = L6_2.CursorStyle
              if 0 ~= L13_2 then
                L13_2 = L6_2.CursorStyle
              end
              L13_2 = RageUI
              L13_2 = L13_2.ItemsMouseBounds
              L14_2 = L6_2
              L15_2 = L8_2
              L16_2 = L7_2 + 1
              L17_2 = L0_1
              L13_2 = 1 == L13_2 and L13_2
            end
            L14_2 = L6_2.Controls
            L14_2 = L14_2.Select
            L14_2 = L14_2.Active
            if not L14_2 then
              if not L13_2 then
                goto lbl_594
                L14_2 = L13_2 or L14_2
              end
              L14_2 = L6_2.Controls
              L14_2 = L14_2.Click
              L14_2 = L14_2.Active
              if not L14_2 then
                goto lbl_594
              end
            end
            L14_2 = L8_2
            ::lbl_594::
            L15_2 = A4_2.onHovered
            if nil ~= L15_2 and L13_2 then
              L15_2 = A4_2.onHovered
              L15_2()
            end
            L15_2 = A4_2.onActive
            if nil ~= L15_2 and L8_2 then
              L15_2 = A4_2.onActive
              L15_2()
            end
            if L14_2 then
              L15_2 = RageUI
              L15_2 = L15_2.Settings
              L15_2 = L15_2.Audio
              L16_2 = RageUI
              L16_2 = L16_2.PlaySound
              L17_2 = L15_2.Use
              L17_2 = L15_2[L17_2]
              L17_2 = L17_2.Select
              L17_2 = L17_2.audioName
              L18_2 = L15_2.Use
              L18_2 = L15_2[L18_2]
              L18_2 = L18_2.Select
              L18_2 = L18_2.audioRef
              L16_2(L17_2, L18_2)
              L16_2 = A4_2.onSelected
              if nil ~= L16_2 then
                L16_2 = Citizen
                L16_2 = L16_2.CreateThread
                function L17_2()
                  local L0_3, L1_3
                  L0_3 = A4_2.onSelected
                  L0_3()
                end
                L16_2(L17_2)
              end
              if A5_2 then
                L16_2 = A5_2
                L16_2 = L16_2()
                if L16_2 then
                  L16_2 = RageUI
                  L16_2.NextMenu = A5_2
                end
              end
            end
          end
        end
      end
      L8_2 = RageUI
      L9_2 = RageUI
      L9_2 = L9_2.Options
      L9_2 = L9_2 + 1
      L8_2.Options = L9_2
    end
  end
end
L6_1.Button = L7_1
