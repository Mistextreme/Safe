local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
L0_1 = {}
L1_1 = {}
L1_1.Y = 0
L1_1.Width = 400
L1_1.Height = 45
L0_1.Rectangle = L1_1
L1_1 = {}
L1_1.X = 5
L1_1.Y = 12
L1_1.Scale = 0.28
L0_1.Text = L1_1
L1_1 = {}
L1_1.Y = 30
L1_1.Width = 37
L1_1.Height = 37
L0_1.LeftBadge = L1_1
L1_1 = {}
L1_1.X = 340
L1_1.Y = 28.5
L1_1.Width = 40
L1_1.Height = 40
L0_1.RightBadge = L1_1
L1_1 = {}
L1_1.X = 400
L1_1.Y = 18
L1_1.Scale = 0.25
L0_1.RightText = L1_1
L1_1 = {}
L1_1.Dictionary = "commonmenu"
L1_1.Texture = "background"
L1_1.Y = 8
L1_1.Width = 430
L1_1.Height = 42
L0_1.SelectedSprite = L1_1
L1_1 = {}
L1_1.Dictionary = "commonmenu"
L2_1 = {}
L3_1 = "shop_box_blankb"
L4_1 = "shop_box_tickb"
L5_1 = "shop_box_blank"
L6_1 = "shop_box_tick"
L7_1 = "shop_box_crossb"
L8_1 = "shop_box_cross"
L2_1[1] = L3_1
L2_1[2] = L4_1
L2_1[3] = L5_1
L2_1[4] = L6_1
L2_1[5] = L7_1
L2_1[6] = L8_1
L1_1.Textures = L2_1
L1_1.X = 330
L1_1.Y = 1.5
L1_1.Width = 55
L1_1.Height = 55
L2_1 = RageUI
L3_1 = {}
L3_1.Tick = 1
L3_1.Cross = 2
L2_1.CheckboxStyle = L3_1
function L2_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L5_2 = RageUI
  L5_2 = L5_2.CurrentMenu
  if nil == A4_2 then
    A4_2 = 0
  end
  if A1_2 then
    L6_2 = RenderSprite
    L7_2 = L1_1.Dictionary
    L8_2 = L1_1.Textures
    L8_2 = L8_2[A3_2]
    L9_2 = L5_2.X
    L10_2 = L1_1.X
    L9_2 = L9_2 + L10_2
    L10_2 = L5_2.WidthOffset
    L9_2 = L9_2 + L10_2
    L9_2 = L9_2 - A4_2
    L10_2 = L5_2.Y
    L10_2 = 20 + L10_2
    L11_2 = L1_1.Y
    L10_2 = L10_2 + L11_2
    L11_2 = L5_2.SubtitleHeight
    L10_2 = L10_2 + L11_2
    L11_2 = RageUI
    L11_2 = L11_2.ItemOffset
    L10_2 = L10_2 + L11_2
    L11_2 = L1_1.Width
    L12_2 = L1_1.Height
    L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  else
    L6_2 = RenderSprite
    L7_2 = L1_1.Dictionary
    L8_2 = L1_1.Textures
    L8_2 = L8_2[3]
    L9_2 = L5_2.X
    L10_2 = L1_1.X
    L9_2 = L9_2 + L10_2
    L10_2 = L5_2.WidthOffset
    L9_2 = L9_2 + L10_2
    L9_2 = L9_2 - A4_2
    L10_2 = L5_2.Y
    L10_2 = 20 + L10_2
    L11_2 = L1_1.Y
    L10_2 = L10_2 + L11_2
    L11_2 = L5_2.SubtitleHeight
    L10_2 = L10_2 + L11_2
    L11_2 = RageUI
    L11_2 = L11_2.ItemOffset
    L10_2 = L10_2 + L11_2
    L11_2 = L1_1.Width
    L12_2 = L1_1.Height
    L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  end
end
L3_1 = RageUI
function L4_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  L5_2 = RageUI
  L5_2 = L5_2.CurrentMenu
  if nil ~= L5_2 then
    L6_2 = L5_2
    L6_2 = L6_2()
    if L6_2 then
      L6_2 = RageUI
      L6_2 = L6_2.Options
      L6_2 = L6_2 + 1
      L7_2 = L5_2.Pagination
      L7_2 = L7_2.Minimum
      if L6_2 >= L7_2 then
        L7_2 = L5_2.Pagination
        L7_2 = L7_2.Maximum
        if L6_2 <= L7_2 then
          L7_2 = L5_2.Index
          L7_2 = L7_2 == L6_2
          L8_2 = A3_2.LeftBadge
          L9_2 = RageUI
          L9_2 = L9_2.BadgeStyle
          L9_2 = L9_2.None
          if L8_2 ~= L9_2 then
            L8_2 = A3_2.LeftBadge
            if nil ~= L8_2 then
              goto lbl_38
            end
          end
          L8_2 = 0
          ::lbl_38::
          if not L8_2 then
            L8_2 = 27
          end
          L9_2 = A3_2.RightBadge
          L10_2 = RageUI
          L10_2 = L10_2.BadgeStyle
          L10_2 = L10_2.None
          if L9_2 ~= L10_2 then
            L9_2 = A3_2.RightBadge
            if nil ~= L9_2 then
              goto lbl_51
            end
          end
          L9_2 = 0
          ::lbl_51::
          if not L9_2 then
            L9_2 = 32
          end
          L10_2 = 0
          L11_2 = RageUI
          L11_2 = L11_2.ItemsSafeZone
          L12_2 = L5_2
          L11_2(L12_2)
          L11_2 = L5_2.EnableMouse
          if true == L11_2 then
            L11_2 = L5_2.CursorStyle
            if 0 == L11_2 then
              goto lbl_66
            end
          end
          L11_2 = L5_2.CursorStyle
          ::lbl_66::
          if 1 == L11_2 then
            L11_2 = RageUI
            L11_2 = L11_2.ItemsMouseBounds
            L12_2 = L5_2
            L13_2 = L7_2
            L14_2 = L6_2
            L15_2 = L0_1
            L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
            Hovered = L11_2
          end
          L11_2 = RenderSprite
          L12_2 = "commonmenu"
          L13_2 = "bouton"
          L14_2 = L5_2.X
          L14_2 = L14_2 + 7
          L15_2 = L5_2.Y
          L15_2 = L15_2 + 20
          L16_2 = L0_1.SelectedSprite
          L16_2 = L16_2.Y
          L15_2 = L15_2 + L16_2
          L16_2 = L5_2.SubtitleHeight
          L15_2 = L15_2 + L16_2
          L16_2 = RageUI
          L16_2 = L16_2.ItemOffset
          L15_2 = L15_2 + L16_2
          L16_2 = L0_1.SelectedSprite
          L16_2 = L16_2.Width
          L17_2 = L5_2.WidthOffset
          L16_2 = L16_2 + L17_2
          L16_2 = L16_2 - 55
          L17_2 = L0_1.SelectedSprite
          L17_2 = L17_2.Height
          L17_2 = L17_2 - 1
          L18_2 = 0
          L19_2 = 0
          L20_2 = 0
          L21_2 = 0
          L22_2 = 100
          L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          if L7_2 then
            L11_2 = RenderSprite
            L12_2 = "commonmenu"
            L13_2 = "bouton"
            L14_2 = L5_2.X
            L14_2 = L14_2 + 7
            L15_2 = L5_2.Y
            L15_2 = L15_2 + 20
            L16_2 = L0_1.SelectedSprite
            L16_2 = L16_2.Y
            L15_2 = L15_2 + L16_2
            L16_2 = L5_2.SubtitleHeight
            L15_2 = L15_2 + L16_2
            L16_2 = RageUI
            L16_2 = L16_2.ItemOffset
            L15_2 = L15_2 + L16_2
            L16_2 = L0_1.SelectedSprite
            L16_2 = L16_2.Width
            L17_2 = L5_2.WidthOffset
            L16_2 = L16_2 + L17_2
            L16_2 = L16_2 - 55
            L17_2 = L0_1.SelectedSprite
            L17_2 = L17_2.Height
            L17_2 = L17_2 - 1
            L18_2 = 0
            L19_2 = Configk2rUI
            L19_2 = L19_2.Menu
            L19_2 = L19_2.CouleurBouton
            L19_2 = L19_2.R
            L20_2 = Configk2rUI
            L20_2 = L20_2.Menu
            L20_2 = L20_2.CouleurBouton
            L20_2 = L20_2.G
            L21_2 = Configk2rUI
            L21_2 = L21_2.Menu
            L21_2 = L21_2.CouleurBouton
            L21_2 = L21_2.B
            L22_2 = 100
            L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          end
          L11_2 = type
          L12_2 = A3_2
          L11_2 = L11_2(L12_2)
          if "table" == L11_2 then
            L11_2 = A3_2.Enabled
            if true ~= L11_2 then
              L11_2 = A3_2.Enabled
              if nil ~= L11_2 then
                goto lbl_400
              end
            end
            if L7_2 then
              L11_2 = RenderText
              L12_2 = A0_2
              L13_2 = L5_2.X
              L13_2 = 10 + L13_2
              L14_2 = L0_1.Text
              L14_2 = L14_2.X
              L13_2 = L13_2 + L14_2
              L13_2 = L13_2 + L8_2
              L14_2 = L5_2.Y
              L14_2 = 21 + L14_2
              L15_2 = L0_1.Text
              L15_2 = L15_2.Y
              L14_2 = L14_2 + L15_2
              L15_2 = L5_2.SubtitleHeight
              L14_2 = L14_2 + L15_2
              L15_2 = RageUI
              L15_2 = L15_2.ItemOffset
              L14_2 = L14_2 + L15_2
              L15_2 = fontIdButton
              L16_2 = L0_1.Text
              L16_2 = L16_2.Scale
              L17_2 = 255
              L18_2 = 255
              L19_2 = 255
              L20_2 = 255
              L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
            else
              L11_2 = RenderText
              L12_2 = A0_2
              L13_2 = L5_2.X
              L13_2 = 10 + L13_2
              L14_2 = L0_1.Text
              L14_2 = L14_2.X
              L13_2 = L13_2 + L14_2
              L13_2 = L13_2 + L8_2
              L14_2 = L5_2.Y
              L14_2 = 21 + L14_2
              L15_2 = L0_1.Text
              L15_2 = L15_2.Y
              L14_2 = L14_2 + L15_2
              L15_2 = L5_2.SubtitleHeight
              L14_2 = L14_2 + L15_2
              L15_2 = RageUI
              L15_2 = L15_2.ItemOffset
              L14_2 = L14_2 + L15_2
              L15_2 = fontIdButton
              L16_2 = L0_1.Text
              L16_2 = L16_2.Scale
              L17_2 = 255
              L18_2 = 255
              L19_2 = 255
              L20_2 = 255
              L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
            end
            L11_2 = type
            L12_2 = A3_2
            L11_2 = L11_2(L12_2)
            if "table" == L11_2 then
              L11_2 = A3_2.LeftBadge
              if nil ~= L11_2 then
                L11_2 = A3_2.LeftBadge
                L12_2 = RageUI
                L12_2 = L12_2.BadgeStyle
                L12_2 = L12_2.None
                if L11_2 ~= L12_2 then
                  L11_2 = A3_2.LeftBadge
                  L12_2 = L7_2
                  L11_2 = L11_2(L12_2)
                  L12_2 = RenderSprite
                  L13_2 = L11_2.BadgeDictionary
                  if not L13_2 then
                    L13_2 = "commonmenu"
                  end
                  L14_2 = L11_2.BadgeTexture
                  if not L14_2 then
                    L14_2 = ""
                  end
                  L15_2 = L5_2.X
                  L16_2 = L5_2.Y
                  L16_2 = 21 + L16_2
                  L17_2 = L0_1.LeftBadge
                  L17_2 = L17_2.Y
                  L16_2 = L16_2 + L17_2
                  L17_2 = L5_2.SubtitleHeight
                  L16_2 = L16_2 + L17_2
                  L17_2 = RageUI
                  L17_2 = L17_2.ItemOffset
                  L16_2 = L16_2 + L17_2
                  L17_2 = L0_1.LeftBadge
                  L17_2 = L17_2.Width
                  L18_2 = L0_1.LeftBadge
                  L18_2 = L18_2.Height
                  L19_2 = 0
                  L20_2 = L11_2.BadgeColour
                  if L20_2 then
                    L20_2 = L11_2.BadgeColour
                    L20_2 = L20_2.R
                    if L20_2 then
                      goto lbl_293
                    end
                  end
                  L20_2 = 255
                  ::lbl_293::
                  L21_2 = L11_2.BadgeColour
                  if L21_2 then
                    L21_2 = L11_2.BadgeColour
                    L21_2 = L21_2.G
                    if L21_2 then
                      goto lbl_301
                    end
                  end
                  L21_2 = 255
                  ::lbl_301::
                  L22_2 = L11_2.BadgeColour
                  if L22_2 then
                    L22_2 = L11_2.BadgeColour
                    L22_2 = L22_2.B
                    if L22_2 then
                      goto lbl_309
                    end
                  end
                  L22_2 = 255
                  ::lbl_309::
                  L23_2 = L11_2.BadgeColour
                  if L23_2 then
                    L23_2 = L11_2.BadgeColour
                    L23_2 = L23_2.A
                    if L23_2 then
                      goto lbl_317
                    end
                  end
                  L23_2 = 255
                  ::lbl_317::
                  L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
                end
              end
              L11_2 = A3_2.RightBadge
              if nil ~= L11_2 then
                L11_2 = A3_2.RightBadge
                L12_2 = RageUI
                L12_2 = L12_2.BadgeStyle
                L12_2 = L12_2.None
                if L11_2 ~= L12_2 then
                  L11_2 = A3_2.RightBadge
                  L12_2 = L7_2
                  L11_2 = L11_2(L12_2)
                  L12_2 = RenderSprite
                  L13_2 = L11_2.BadgeDictionary
                  if not L13_2 then
                    L13_2 = "commonmenu"
                  end
                  L14_2 = L11_2.BadgeTexture
                  if not L14_2 then
                    L14_2 = ""
                  end
                  L15_2 = L5_2.X
                  L16_2 = L0_1.RightBadge
                  L16_2 = L16_2.X
                  L15_2 = L15_2 + L16_2
                  L16_2 = L5_2.WidthOffset
                  L15_2 = L15_2 + L16_2
                  L16_2 = L5_2.Y
                  L16_2 = 21 + L16_2
                  L17_2 = L0_1.RightBadge
                  L17_2 = L17_2.Y
                  L16_2 = L16_2 + L17_2
                  L17_2 = L5_2.SubtitleHeight
                  L16_2 = L16_2 + L17_2
                  L17_2 = RageUI
                  L17_2 = L17_2.ItemOffset
                  L16_2 = L16_2 + L17_2
                  L17_2 = L0_1.RightBadge
                  L17_2 = L17_2.Width
                  L18_2 = L0_1.RightBadge
                  L18_2 = L18_2.Height
                  L19_2 = 0
                  L20_2 = L11_2.BadgeColour
                  if L20_2 then
                    L20_2 = L11_2.BadgeColour
                    L20_2 = L20_2.R
                    if L20_2 then
                      goto lbl_374
                    end
                  end
                  L20_2 = 255
                  ::lbl_374::
                  L21_2 = L11_2.BadgeColour
                  if L21_2 then
                    L21_2 = L11_2.BadgeColour
                    L21_2 = L21_2.G
                    if L21_2 then
                      goto lbl_382
                    end
                  end
                  L21_2 = 255
                  ::lbl_382::
                  L22_2 = L11_2.BadgeColour
                  if L22_2 then
                    L22_2 = L11_2.BadgeColour
                    L22_2 = L22_2.B
                    if L22_2 then
                      goto lbl_390
                    end
                  end
                  L22_2 = 255
                  ::lbl_390::
                  L23_2 = L11_2.BadgeColour
                  if L23_2 then
                    L23_2 = L11_2.BadgeColour
                    L23_2 = L23_2.A
                    if L23_2 then
                      goto lbl_398
                    end
                  end
                  L23_2 = 255
                  ::lbl_398::
                  L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
                  goto lbl_543
                  ::lbl_400::
                  L11_2 = RageUI
                  L11_2 = L11_2.BadgeStyle
                  L11_2 = L11_2.Lock
                  L12_2 = RageUI
                  L12_2 = L12_2.BadgeStyle
                  L12_2 = L12_2.None
                  if L11_2 == L12_2 or nil == L11_2 then
                    L12_2 = 0
                    if L12_2 then
                      goto lbl_414
                    end
                  end
                  L12_2 = 27
                  ::lbl_414::
                  if L7_2 then
                    L13_2 = RenderText
                    L14_2 = A0_2
                    L15_2 = L5_2.X
                    L15_2 = 10 + L15_2
                    L16_2 = L0_1.Text
                    L16_2 = L16_2.X
                    L15_2 = L15_2 + L16_2
                    L15_2 = L15_2 + L12_2
                    L16_2 = L5_2.Y
                    L16_2 = 21 + L16_2
                    L17_2 = L0_1.Text
                    L17_2 = L17_2.Y
                    L16_2 = L16_2 + L17_2
                    L17_2 = L5_2.SubtitleHeight
                    L16_2 = L16_2 + L17_2
                    L17_2 = RageUI
                    L17_2 = L17_2.ItemOffset
                    L16_2 = L16_2 + L17_2
                    L17_2 = fontIdButton
                    L18_2 = L0_1.Text
                    L18_2 = L18_2.Scale
                    L19_2 = 0
                    L20_2 = 0
                    L21_2 = 0
                    L22_2 = 255
                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                  else
                    L13_2 = RenderText
                    L14_2 = A0_2
                    L15_2 = L5_2.X
                    L15_2 = 10 + L15_2
                    L16_2 = L0_1.Text
                    L16_2 = L16_2.X
                    L15_2 = L15_2 + L16_2
                    L15_2 = L15_2 + L12_2
                    L16_2 = L5_2.Y
                    L16_2 = 21 + L16_2
                    L17_2 = L0_1.Text
                    L17_2 = L17_2.Y
                    L16_2 = L16_2 + L17_2
                    L17_2 = L5_2.SubtitleHeight
                    L16_2 = L16_2 + L17_2
                    L17_2 = RageUI
                    L17_2 = L17_2.ItemOffset
                    L16_2 = L16_2 + L17_2
                    L17_2 = fontIdButton
                    L18_2 = L0_1.Text
                    L18_2 = L18_2.Scale
                    L19_2 = 255
                    L20_2 = 255
                    L21_2 = 255
                    L22_2 = 255
                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                  end
                  L13_2 = RageUI
                  L13_2 = L13_2.BadgeStyle
                  L13_2 = L13_2.None
                  if L11_2 ~= L13_2 and nil ~= L11_2 then
                    L13_2 = L11_2
                    L14_2 = L7_2
                    L13_2 = L13_2(L14_2)
                    L14_2 = RenderSprite
                    L15_2 = L13_2.BadgeDictionary
                    if not L15_2 then
                      L15_2 = "commonmenu"
                    end
                    L16_2 = L13_2.BadgeTexture
                    if not L16_2 then
                      L16_2 = ""
                    end
                    L17_2 = L5_2.X
                    L18_2 = L5_2.Y
                    L18_2 = 21 + L18_2
                    L19_2 = L0_1.LeftBadge
                    L19_2 = L19_2.Y
                    L18_2 = L18_2 + L19_2
                    L19_2 = L5_2.SubtitleHeight
                    L18_2 = L18_2 + L19_2
                    L19_2 = RageUI
                    L19_2 = L19_2.ItemOffset
                    L18_2 = L18_2 + L19_2
                    L19_2 = L0_1.LeftBadge
                    L19_2 = L19_2.Width
                    L20_2 = L0_1.LeftBadge
                    L20_2 = L20_2.Height
                    L21_2 = 0
                    L22_2 = L13_2.BadgeColour
                    L22_2 = L22_2.R
                    if not L22_2 then
                      L22_2 = 255
                    end
                    L23_2 = L13_2.BadgeColour
                    L23_2 = L23_2.G
                    if not L23_2 then
                      L23_2 = 255
                    end
                    L24_2 = L13_2.BadgeColour
                    L24_2 = L24_2.B
                    if not L24_2 then
                      L24_2 = 255
                    end
                    L25_2 = L13_2.BadgeColour
                    L25_2 = L25_2.A
                    if not L25_2 then
                      L25_2 = 255
                    end
                    L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
                  end
                end
              end
            end
            ::lbl_543::
            L11_2 = A3_2.Enabled
            if true ~= L11_2 then
              L11_2 = A3_2.Enabled
              if nil ~= L11_2 then
                goto lbl_650
              end
            end
            if L7_2 then
              L11_2 = A3_2.RightLabel
              if nil ~= L11_2 then
                L11_2 = A3_2.RightLabel
                if "" ~= L11_2 then
                  L11_2 = RenderText
                  L12_2 = A3_2.RightLabel
                  L13_2 = L5_2.X
                  L13_2 = 10 + L13_2
                  L14_2 = L0_1.RightText
                  L14_2 = L14_2.X
                  L13_2 = L13_2 + L14_2
                  L13_2 = L13_2 - L9_2
                  L14_2 = L5_2.WidthOffset
                  L13_2 = L13_2 + L14_2
                  L14_2 = L5_2.Y
                  L14_2 = 21 + L14_2
                  L15_2 = L0_1.RightText
                  L15_2 = L15_2.Y
                  L14_2 = L14_2 + L15_2
                  L15_2 = L5_2.SubtitleHeight
                  L14_2 = L14_2 + L15_2
                  L15_2 = RageUI
                  L15_2 = L15_2.ItemOffset
                  L14_2 = L14_2 + L15_2
                  L15_2 = fontIdButton
                  L16_2 = L0_1.RightText
                  L16_2 = L16_2.Scale
                  L17_2 = 0
                  L18_2 = 0
                  L19_2 = 0
                  L20_2 = 255
                  L21_2 = 2
                  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
                  L11_2 = MeasureStringWidth
                  L12_2 = A3_2.RightLabel
                  L13_2 = 0
                  L14_2 = 0.35
                  L11_2 = L11_2(L12_2, L13_2, L14_2)
                  L10_2 = L11_2
                end
              end
            else
              L11_2 = A3_2.RightLabel
              if nil ~= L11_2 then
                L11_2 = A3_2.RightLabel
                if "" ~= L11_2 then
                  L11_2 = RenderText
                  L12_2 = A3_2.RightLabel
                  L13_2 = L5_2.X
                  L13_2 = 10 + L13_2
                  L14_2 = L0_1.RightText
                  L14_2 = L14_2.X
                  L13_2 = L13_2 + L14_2
                  L13_2 = L13_2 - L9_2
                  L14_2 = L5_2.WidthOffset
                  L13_2 = L13_2 + L14_2
                  L14_2 = L5_2.Y
                  L14_2 = 21 + L14_2
                  L15_2 = L0_1.RightText
                  L15_2 = L15_2.Y
                  L14_2 = L14_2 + L15_2
                  L15_2 = L5_2.SubtitleHeight
                  L14_2 = L14_2 + L15_2
                  L15_2 = RageUI
                  L15_2 = L15_2.ItemOffset
                  L14_2 = L14_2 + L15_2
                  L15_2 = fontIdButton
                  L16_2 = L0_1.RightText
                  L16_2 = L16_2.Scale
                  L17_2 = 255
                  L18_2 = 255
                  L19_2 = 255
                  L20_2 = 255
                  L21_2 = 2
                  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
                  L11_2 = MeasureStringWidth
                  L12_2 = A3_2.RightLabel
                  L13_2 = 0
                  L14_2 = 0.35
                  L11_2 = L11_2(L12_2, L13_2, L14_2)
                  L10_2 = L11_2
                end
              end
            end
            ::lbl_650::
            L10_2 = L9_2 + L10_2
            L11_2 = A3_2.Style
            if nil ~= L11_2 then
              L11_2 = A3_2.Style
              L12_2 = RageUI
              L12_2 = L12_2.CheckboxStyle
              L12_2 = L12_2.Tick
              if L11_2 == L12_2 then
                L11_2 = L2_1
                L12_2 = L7_2
                L13_2 = A2_2
                L14_2 = 2
                L15_2 = 4
                L16_2 = L10_2
                L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
              else
                L11_2 = A3_2.Style
                L12_2 = RageUI
                L12_2 = L12_2.CheckboxStyle
                L12_2 = L12_2.Cross
                if L11_2 == L12_2 then
                  L11_2 = L2_1
                  L12_2 = L7_2
                  L13_2 = A2_2
                  L14_2 = 5
                  L15_2 = 6
                  L16_2 = L10_2
                  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
                else
                  L11_2 = L2_1
                  L12_2 = L7_2
                  L13_2 = A2_2
                  L14_2 = 2
                  L15_2 = 4
                  L16_2 = L10_2
                  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
                end
              end
            else
              L11_2 = L2_1
              L12_2 = L7_2
              L13_2 = A2_2
              L14_2 = 2
              L15_2 = 4
              L16_2 = L10_2
              L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
            end
            if L7_2 then
              L11_2 = L5_2.Controls
              L11_2 = L11_2.Select
              L11_2 = L11_2.Active
              if not L11_2 then
                L11_2 = Hovered
                if L11_2 then
                  L11_2 = L5_2.Controls
                  L11_2 = L11_2.Click
                  L11_2 = L11_2.Active
                  if L11_2 then
                    L11_2 = A3_2.Enabled
                    if true ~= L11_2 then
                      L11_2 = A3_2.Enabled
                    end
                    if nil == L11_2 then
                      L11_2 = isWaitingForServer
                      if not L11_2 then
                        L11_2 = RageUI
                        L11_2 = L11_2.Settings
                        L11_2 = L11_2.Audio
                        L12_2 = RageUI
                        L12_2 = L12_2.PlaySound
                        L13_2 = L11_2.Use
                        L13_2 = L11_2[L13_2]
                        L13_2 = L13_2.Select
                        L13_2 = L13_2.audioName
                        L14_2 = L11_2.Use
                        L14_2 = L11_2[L14_2]
                        L14_2 = L14_2.Select
                        L14_2 = L14_2.audioRef
                        L12_2(L13_2, L14_2)
                        A2_2 = not A2_2
                        if A2_2 then
                          L12_2 = A4_2.onChecked
                          if nil ~= L12_2 then
                            L12_2 = A4_2.onChecked
                            L12_2()
                          end
                        else
                          L12_2 = A4_2.onUnChecked
                          if nil ~= L12_2 then
                            L12_2 = A4_2.onUnChecked
                            L12_2()
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          else
            L11_2 = error
            L12_2 = "UICheckBox Style is not a `table`"
            L11_2(L12_2)
          end
          L11_2 = RageUI
          L12_2 = RageUI
          L12_2 = L12_2.ItemOffset
          L13_2 = L0_1.Rectangle
          L13_2 = L13_2.Height
          L12_2 = L12_2 + L13_2
          L11_2.ItemOffset = L12_2
          L11_2 = RageUI
          L11_2 = L11_2.ItemsDescription
          L12_2 = L5_2
          L13_2 = A1_2
          L14_2 = L7_2
          L11_2(L12_2, L13_2, L14_2)
          L11_2 = A4_2.onSelected
          if nil ~= L11_2 and L7_2 then
            L11_2 = A4_2.onSelected
            L12_2 = A2_2
            L11_2(L12_2)
          end
        end
      end
      L7_2 = RageUI
      L8_2 = RageUI
      L8_2 = L8_2.Options
      L8_2 = L8_2 + 1
      L7_2.Options = L8_2
    end
  end
end
L3_1.Checkbox = L4_1
