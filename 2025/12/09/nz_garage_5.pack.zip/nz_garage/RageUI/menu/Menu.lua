local L0_1, L1_1
L0_1 = RageUI
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2)
  local L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  L10_2 = {}
  L11_2 = {}
  L10_2.Display = L11_2
  L11_2 = {}
  L10_2.InstructionalButtons = L11_2
  L11_2 = L10_2.Display
  L11_2.Header = true
  L11_2 = L10_2.Display
  L11_2.Glare = false
  L11_2 = L10_2.Display
  L11_2.Subtitle = true
  L11_2 = L10_2.Display
  L11_2.Background = true
  L11_2 = L10_2.Display
  L11_2.Navigation = true
  L11_2 = L10_2.Display
  L11_2.InstructionalButton = true
  L11_2 = L10_2.Display
  L11_2.PageCounter = true
  L11_2 = Configk2rUI
  L11_2 = L11_2.Menu
  L11_2 = L11_2.TitreMenu
  L10_2.Title = L11_2
  L10_2.TitleFont = 6
  L10_2.TitleScale = 0.7
  L11_2 = A1_2 or L11_2
  if not A1_2 then
    L11_2 = nil
  end
  L10_2.Subtitle = L11_2
  L10_2.SubtitleHeight = -100
  L10_2.Description = nil
  L11_2 = RageUI
  L11_2 = L11_2.Settings
  L11_2 = L11_2.Items
  L11_2 = L11_2.Description
  L11_2 = L11_2.Background
  L11_2 = L11_2.Height
  L10_2.DescriptionHeight = L11_2
  L11_2 = A2_2 or L11_2
  if not A2_2 then
    L11_2 = 0
  end
  L10_2.X = L11_2
  L11_2 = A3_2 or L11_2
  if not A3_2 then
    L11_2 = 0
  end
  L10_2.Y = L11_2
  L10_2.Parent = nil
  L11_2 = RageUI
  L11_2 = L11_2.UI
  L11_2 = L11_2.Style
  L12_2 = RageUI
  L12_2 = L12_2.UI
  L12_2 = L12_2.Current
  L11_2 = L11_2[L12_2]
  L11_2 = L11_2.Width
  L10_2.WidthOffset = L11_2
  L10_2.Open = false
  L11_2 = RageUI
  L11_2 = L11_2.Settings
  L11_2 = L11_2.Controls
  L10_2.Controls = L11_2
  L10_2.Index = 1
  L11_2 = {}
  L11_2.Dictionary = "commonmenu"
  L11_2.Texture = "interaction_bgd"
  L12_2 = {}
  L12_2.R = A6_2
  L12_2.G = A7_2
  L12_2.B = A8_2
  L12_2.A = A9_2
  L11_2.Color = L12_2
  L10_2.Sprite = L11_2
  L10_2.Rectangle = nil
  L11_2 = {}
  L11_2.Minimum = 1
  L11_2.Maximum = 13
  L11_2.Total = 14
  L10_2.Pagination = L11_2
  L10_2.Safezone = true
  L10_2.SafeZoneSize = nil
  L10_2.EnableMouse = false
  L10_2.Options = 0
  L10_2.Closable = true
  L11_2 = RequestScaleformMovie
  L12_2 = "INSTRUCTIONAL_BUTTONS"
  L11_2 = L11_2(L12_2)
  L10_2.InstructionalScaleform = L11_2
  L10_2.CursorStyle = 1
  L11_2 = string
  L11_2 = L11_2.starts
  L12_2 = L10_2.Subtitle
  L13_2 = "~"
  L11_2 = L11_2(L12_2, L13_2)
  if L11_2 then
    L11_2 = string
    L11_2 = L11_2.lower
    L12_2 = string
    L12_2 = L12_2.sub
    L13_2 = L10_2.Subtitle
    L14_2 = 1
    L15_2 = 3
    L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L12_2(L13_2, L14_2, L15_2)
    L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
    L10_2.PageCounterColour = L11_2
  else
    L10_2.PageCounterColour = ""
  end
  L11_2 = L10_2.Subtitle
  if "" ~= L11_2 then
    L11_2 = GetLineCount
    L12_2 = L10_2.Subtitle
    L13_2 = L10_2.X
    L14_2 = RageUI
    L14_2 = L14_2.Settings
    L14_2 = L14_2.Items
    L14_2 = L14_2.Subtitle
    L14_2 = L14_2.Text
    L14_2 = L14_2.X
    L13_2 = L13_2 + L14_2
    L14_2 = L10_2.Y
    L15_2 = RageUI
    L15_2 = L15_2.Settings
    L15_2 = L15_2.Items
    L15_2 = L15_2.Subtitle
    L15_2 = L15_2.Text
    L15_2 = L15_2.Y
    L14_2 = L14_2 + L15_2
    L15_2 = 0
    L16_2 = RageUI
    L16_2 = L16_2.Settings
    L16_2 = L16_2.Items
    L16_2 = L16_2.Subtitle
    L16_2 = L16_2.Text
    L16_2 = L16_2.Scale
    L17_2 = 255
    L18_2 = 255
    L19_2 = 255
    L20_2 = 255
    L21_2 = nil
    L22_2 = false
    L23_2 = false
    L24_2 = RageUI
    L24_2 = L24_2.Settings
    L24_2 = L24_2.Items
    L24_2 = L24_2.Subtitle
    L24_2 = L24_2.Background
    L24_2 = L24_2.Width
    L25_2 = L10_2.WidthOffset
    L24_2 = L24_2 + L25_2
    L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
    if L11_2 > 1 then
      L12_2 = 18 * L11_2
      L10_2.SubtitleHeight = L12_2
    else
      L10_2.SubtitleHeight = 0
    end
  end
  L11_2 = Citizen
  L11_2 = L11_2.CreateThread
  function L12_2()
    local L0_3, L1_3
    L0_3 = HasScaleformMovieLoaded
    L1_3 = L10_2.InstructionalScaleform
    L0_3 = L0_3(L1_3)
    if not L0_3 then
      L0_3 = RequestScaleformMovie
      L1_3 = "INSTRUCTIONAL_BUTTONS"
      L0_3 = L0_3(L1_3)
      L10_2.InstructionalScaleform = L0_3
    end
  end
  L11_2(L12_2)
  L11_2 = setmetatable
  L12_2 = L10_2
  L13_2 = RageUI
  L13_2 = L13_2.Menus
  return L11_2(L12_2, L13_2)
end
L0_1.CreateMenu = L1_1
L0_1 = RageUI
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2)
  local L11_2, L12_2, L13_2, L14_2, L15_2
  if nil ~= A0_2 then
    L11_2 = A0_2
    L11_2 = L11_2()
    if L11_2 then
      L11_2 = RageUI
      L11_2 = L11_2.CreateMenu
      L12_2 = A1_2 or L12_2
      if not A1_2 then
        L12_2 = A0_2.Title
      end
      L13_2 = A2_2 or L13_2
      if not A2_2 then
        L13_2 = A0_2.Subtitle
      end
      L14_2 = A3_2 or L14_2
      if not A3_2 then
        L14_2 = A0_2.X
      end
      L15_2 = A4_2 or L15_2
      if not A4_2 then
        L15_2 = A0_2.Y
      end
      L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
      L11_2.Parent = A0_2
      L12_2 = A0_2.WidthOffset
      L11_2.WidthOffset = L12_2
      L12_2 = A0_2.Safezone
      L11_2.Safezone = L12_2
      L12_2 = A0_2.Sprite
      if L12_2 then
        L12_2 = {}
        L13_2 = A5_2 or L13_2
        if not A5_2 then
          L13_2 = A0_2.Sprite
          L13_2 = L13_2.Dictionary
        end
        L12_2.Dictionary = L13_2
        L13_2 = A6_2 or L13_2
        if not A6_2 then
          L13_2 = A0_2.Sprite
          L13_2 = L13_2.Texture
        end
        L12_2.Texture = L13_2
        L13_2 = {}
        L14_2 = A7_2 or L14_2
        if not A7_2 then
          L14_2 = A0_2.Sprite
          L14_2 = L14_2.Color
          L14_2 = L14_2.R
        end
        L13_2.R = L14_2
        L14_2 = A8_2 or L14_2
        if not A8_2 then
          L14_2 = A0_2.Sprite
          L14_2 = L14_2.Color
          L14_2 = L14_2.G
        end
        L13_2.G = L14_2
        L14_2 = A9_2 or L14_2
        if not A9_2 then
          L14_2 = A0_2.Sprite
          L14_2 = L14_2.Color
          L14_2 = L14_2.B
        end
        L13_2.B = L14_2
        L14_2 = A10_2 or L14_2
        if not A10_2 then
          L14_2 = A0_2.Sprite
          L14_2 = L14_2.Color
          L14_2 = L14_2.A
        end
        L13_2.A = L14_2
        L12_2.Color = L13_2
        L11_2.Sprite = L12_2
      else
        L12_2 = A0_2.Rectangle
        L11_2.Rectangle = L12_2
      end
      L12_2 = setmetatable
      L13_2 = L11_2
      L14_2 = RageUI
      L14_2 = L14_2.Menus
      return L12_2(L13_2, L14_2)
    else
      L11_2 = nil
      return L11_2
    end
  else
    L11_2 = nil
    return L11_2
  end
end
L0_1.CreateSubMenu = L1_1
L0_1 = RageUI
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2)
  local L11_2, L12_2, L13_2, L14_2, L15_2
  if nil ~= A0_2 then
    L11_2 = A0_2
    L11_2 = L11_2()
    if L11_2 then
      L11_2 = RageUI
      L11_2 = L11_2.CreateMenu
      L12_2 = A1_2 or L12_2
      if not A1_2 then
        L12_2 = A0_2.Title
      end
      L13_2 = A2_2 or L13_2
      if not A2_2 then
        L13_2 = string
        L13_2 = L13_2.upper
        L14_2 = A0_2.Subtitle
        L13_2 = L13_2(L14_2)
      end
      L14_2 = 1400
      L15_2 = 110
      L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
      L11_2.Parent = A0_2
      L12_2 = A0_2.WidthOffset
      L11_2.WidthOffset = L12_2
      L12_2 = A0_2.Safezone
      L11_2.Safezone = L12_2
      L12_2 = A0_2.Sprite
      if L12_2 then
        L12_2 = {}
        L13_2 = A5_2 or L13_2
        if not A5_2 then
          L13_2 = A0_2.Sprite
          L13_2 = L13_2.Dictionary
        end
        L12_2.Dictionary = L13_2
        L13_2 = A6_2 or L13_2
        if not A6_2 then
          L13_2 = A0_2.Sprite
          L13_2 = L13_2.Texture
        end
        L12_2.Texture = L13_2
        L13_2 = {}
        L13_2.R = A7_2
        L13_2.G = A8_2
        L13_2.B = A9_2
        L13_2.A = A10_2
        L12_2.Color = L13_2
        L11_2.Sprite = L12_2
      else
        L12_2 = A0_2.Rectangle
        L11_2.Rectangle = L12_2
      end
      L12_2 = setmetatable
      L13_2 = L11_2
      L14_2 = RageUI
      L14_2 = L14_2.Menus
      return L12_2(L13_2, L14_2)
    else
      L11_2 = nil
      return L11_2
    end
  else
    L11_2 = nil
    return L11_2
  end
end
L0_1.CreateSubMenuStaff = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.Header = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.Header
  return L2_2
end
L0_1.DisplayHeader = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.Glare = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.Glare
  return L2_2
end
L0_1.DisplayGlare = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.Subtitle = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.Subtitle
  return L2_2
end
L0_1.DisplaySubtitle = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.Navigation = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.Navigation
  return L2_2
end
L0_1.DisplayNavigation = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.InstructionalButton = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.InstructionalButton
  return L2_2
end
L0_1.DisplayInstructionalButton = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = A0_2.Display
  L2_2.PageCounter = A1_2
  L2_2 = A0_2.Display
  L2_2 = L2_2.PageCounter
  return L2_2
end
L0_1.DisplayPageCounter = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  A0_2.Title = A1_2
end
L0_1.SetTitle = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2
  L2_2 = nil
  if A1_2 >= 0 and A1_2 <= 100 then
    L2_2 = A1_2
  else
    L2_2 = 100
  end
  A0_2.WidthOffset = L2_2
end
L0_1.SetStyleSize = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  A0_2.PageCounter = A1_2
end
L0_1.SetPageCounter = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2)
  local L1_2
  L1_2 = A0_2.WidthOffset
  if 100 == L1_2 then
    L1_2 = "RageUI"
    return L1_2
  else
    L1_2 = A0_2.WidthOffset
    if 0 == L1_2 then
      L1_2 = "NativeUI"
      return L1_2
    else
      L1_2 = A0_2.WidthOffset
      return L1_2
    end
  end
end
L0_1.GetStyleSize = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = A1_2 or nil
  if not A1_2 then
    L2_2 = 1
    if not L2_2 then
      L2_2 = 0
    end
  end
  A0_2.CursorStyle = L2_2
  L2_2 = SetMouseCursorSprite
  L3_2 = A1_2
  L2_2(L3_2)
end
L0_1.SetCursorStyle = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2)
  local L1_2, L2_2
  A0_2.CursorStyle = 1
  L1_2 = SetMouseCursorSprite
  L2_2 = 1
  L1_2(L2_2)
end
L0_1.ResetCursorStyle = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2)
  local L1_2, L2_2
  L1_2 = SetMouseCursorSprite
  L2_2 = A0_2.CursorStyle
  L1_2(L2_2)
end
L0_1.UpdateCursorStyle = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2)
  local L1_2
  A0_2.Index = 1
end
L0_1.RefreshIndex = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2
  L5_2 = A0_2.Sprite
  L5_2 = L5_2.Dictionary
  if "commonmenu" == L5_2 then
    L5_2 = A0_2.Sprite
    L6_2 = {}
    L7_2 = tonumber
    L8_2 = A1_2
    L7_2 = L7_2(L8_2)
    if not L7_2 then
      L7_2 = 255
    end
    L6_2.R = L7_2
    L7_2 = tonumber
    L8_2 = A2_2
    L7_2 = L7_2(L8_2)
    if not L7_2 then
      L7_2 = 255
    end
    L6_2.G = L7_2
    L7_2 = tonumber
    L8_2 = A3_2
    L7_2 = L7_2(L8_2)
    if not L7_2 then
      L7_2 = 255
    end
    L6_2.B = L7_2
    L7_2 = tonumber
    L8_2 = A4_2
    L7_2 = L7_2(L8_2)
    if not L7_2 then
      L7_2 = 255
    end
    L6_2.A = L7_2
    L5_2.Color = L6_2
  end
end
L0_1.EditSpriteColor = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = tonumber
  L4_2 = A1_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = A0_2.X
  end
  A0_2.X = L3_2
  L3_2 = tonumber
  L4_2 = A2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = A0_2.Y
  end
  A0_2.Y = L3_2
end
L0_1.SetPosition = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = A0_2.Pagination
  L3_2 = tonumber
  L4_2 = A1_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = A0_2.Pagination
    L3_2 = L3_2.Total
  end
  L2_2.Total = L3_2
end
L0_1.SetTotalItemsPerPage = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2
  L5_2 = {}
  L6_2 = tonumber
  L7_2 = A1_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    L6_2 = 255
  end
  L5_2.R = L6_2
  L6_2 = tonumber
  L7_2 = A2_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    L6_2 = 255
  end
  L5_2.G = L6_2
  L6_2 = tonumber
  L7_2 = A3_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    L6_2 = 255
  end
  L5_2.B = L6_2
  L6_2 = tonumber
  L7_2 = A4_2
  L6_2 = L6_2(L7_2)
  if not L6_2 then
    L6_2 = 255
  end
  L5_2.A = L6_2
  A0_2.Rectangle = L5_2
  A0_2.Sprite = nil
end
L0_1.SetRectangleBanner = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = {}
  L4_2 = A1_2 or L4_2
  if not A1_2 then
    L4_2 = "commonmenu.ytd"
  end
  L3_2.Dictionary = L4_2
  L4_2 = A2_2 or L4_2
  if not A2_2 then
    L4_2 = "admin"
  end
  L3_2.Texture = L4_2
  A0_2.Sprite = L3_2
  A0_2.Rectangle = nil
end
L0_1.SetSpriteBanner = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "boolean" == L2_2 then
    A0_2.Closable = A1_2
  else
    L2_2 = error
    L3_2 = "Type is not boolean"
    L2_2(L3_2)
  end
end
L0_1.Closable = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "table" == L2_2 then
    L2_2 = #A1_2
    if 2 == L2_2 then
      L2_2 = table
      L2_2 = L2_2.insert
      L3_2 = A0_2.InstructionalButtons
      L4_2 = A1_2
      L2_2(L3_2, L4_2)
      L2_2 = A0_2.UpdateInstructionalButtons
      L3_2 = true
      L2_2(L3_2)
    end
  end
end
L0_1.AddInstructionButton = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if "table" == L2_2 then
    L2_2 = 1
    L3_2 = A0_2.InstructionalButtons
    L3_2 = #L3_2
    L4_2 = 1
    for L5_2 = L2_2, L3_2, L4_2 do
      L6_2 = A0_2.InstructionalButtons
      L6_2 = L6_2[L5_2]
      if A1_2 == L6_2 then
        L6_2 = table
        L6_2 = L6_2.remove
        L7_2 = A0_2.InstructionalButtons
        L8_2 = L5_2
        L6_2(L7_2, L8_2)
        L6_2 = A0_2.UpdateInstructionalButtons
        L7_2 = true
        L6_2(L7_2)
        break
      end
    end
  else
    L2_2 = tonumber
    L3_2 = A1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L2_2 = A0_2.InstructionalButtons
      L3_2 = tonumber
      L4_2 = A1_2
      L3_2 = L3_2(L4_2)
      L2_2 = L2_2[L3_2]
      if L2_2 then
        L2_2 = table
        L2_2 = L2_2.remove
        L3_2 = A0_2.InstructionalButtons
        L4_2 = tonumber
        L5_2 = A1_2
        L4_2, L5_2, L6_2, L7_2, L8_2 = L4_2(L5_2)
        L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
        L2_2 = A0_2.UpdateInstructionalButtons
        L3_2 = true
        L2_2(L3_2)
      end
    end
  end
end
L0_1.RemoveInstructionButton = L1_1
L0_1 = RageUI
L0_1 = L0_1.Menus
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if not A1_2 then
    return
  end
  L2_2 = BeginScaleformMovieMethod
  L3_2 = A0_2.InstructionalScaleform
  L4_2 = "CLEAR_ALL"
  L2_2(L3_2, L4_2)
  L2_2 = EndScaleformMovieMethod
  L2_2()
  L2_2 = BeginScaleformMovieMethod
  L3_2 = A0_2.InstructionalScaleform
  L4_2 = "TOGGLE_MOUSE_BUTTONS"
  L2_2(L3_2, L4_2)
  L2_2 = ScaleformMovieMethodAddParamInt
  L3_2 = 0
  L2_2(L3_2)
  L2_2 = EndScaleformMovieMethod
  L2_2()
  L2_2 = BeginScaleformMovieMethod
  L3_2 = A0_2.InstructionalScaleform
  L4_2 = "CREATE_CONTAINER"
  L2_2(L3_2, L4_2)
  L2_2 = EndScaleformMovieMethod
  L2_2()
  L2_2 = BeginScaleformMovieMethod
  L3_2 = A0_2.InstructionalScaleform
  L4_2 = "SET_DATA_SLOT"
  L2_2(L3_2, L4_2)
  L2_2 = ScaleformMovieMethodAddParamInt
  L3_2 = 0
  L2_2(L3_2)
  L2_2 = _ENV
  L3_2 = "PushScaleformMovieMethodParameterButtonName"
  L2_2 = L2_2[L3_2]
  L3_2 = GetControlInstructionalButton
  L4_2 = 2
  L5_2 = 176
  L6_2 = 0
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L2_2 = PushScaleformMovieMethodParameterString
  L3_2 = GetLabelText
  L4_2 = "HUD_INPUT2"
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L3_2(L4_2)
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L2_2 = EndScaleformMovieMethod
  L2_2()
  L2_2 = A0_2.Closable
  if L2_2 then
    L2_2 = BeginScaleformMovieMethod
    L3_2 = A0_2.InstructionalScaleform
    L4_2 = "SET_DATA_SLOT"
    L2_2(L3_2, L4_2)
    L2_2 = ScaleformMovieMethodAddParamInt
    L3_2 = 1
    L2_2(L3_2)
    L2_2 = _ENV
    L3_2 = "PushScaleformMovieMethodParameterButtonName"
    L2_2 = L2_2[L3_2]
    L3_2 = GetControlInstructionalButton
    L4_2 = 2
    L5_2 = 177
    L6_2 = 0
    L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L2_2 = PushScaleformMovieMethodParameterString
    L3_2 = GetLabelText
    L4_2 = "HUD_INPUT3"
    L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2 = L3_2(L4_2)
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L2_2 = EndScaleformMovieMethod
    L2_2()
  end
  L2_2 = 2
  L3_2 = A0_2.InstructionalButtons
  if nil ~= L3_2 then
    L3_2 = 1
    L4_2 = A0_2.InstructionalButtons
    L4_2 = #L4_2
    L5_2 = 1
    for L6_2 = L3_2, L4_2, L5_2 do
      L7_2 = A0_2.InstructionalButtons
      L7_2 = L7_2[L6_2]
      if L7_2 then
        L7_2 = A0_2.InstructionalButtons
        L7_2 = L7_2[L6_2]
        L7_2 = #L7_2
        if 2 == L7_2 then
          L7_2 = BeginScaleformMovieMethod
          L8_2 = A0_2.InstructionalScaleform
          L9_2 = "SET_DATA_SLOT"
          L7_2(L8_2, L9_2)
          L7_2 = ScaleformMovieMethodAddParamInt
          L8_2 = L2_2
          L7_2(L8_2)
          L7_2 = _ENV
          L8_2 = "PushScaleformMovieMethodParameterButtonName"
          L7_2 = L7_2[L8_2]
          L8_2 = A0_2.InstructionalButtons
          L8_2 = L8_2[L6_2]
          L8_2 = L8_2[1]
          L7_2(L8_2)
          L7_2 = PushScaleformMovieMethodParameterString
          L8_2 = A0_2.InstructionalButtons
          L8_2 = L8_2[L6_2]
          L8_2 = L8_2[2]
          L7_2(L8_2)
          L7_2 = EndScaleformMovieMethod
          L7_2()
          L2_2 = L2_2 + 1
        end
      end
    end
  end
  L3_2 = BeginScaleformMovieMethod
  L4_2 = A0_2.InstructionalScaleform
  L5_2 = "DRAW_INSTRUCTIONAL_BUTTONS"
  L3_2(L4_2, L5_2)
  L3_2 = ScaleformMovieMethodAddParamInt
  L4_2 = -1
  L3_2(L4_2)
  L3_2 = EndScaleformMovieMethod
  L3_2()
end
L0_1.UpdateInstructionalButtons = L1_1
