fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'LeZgeg & nezox'
description 'Système de garage by nz-developpment'

dependencies {
    'es_extended',
    'oxmysql'
}

shared_scripts {
    'config.lua'
}

client_scripts {
    "RageUI/RMenu.lua",
    "RageUI/menu/RageUI.lua",
    "RageUI/menu/Menu.lua",
    "RageUI/menu/MenuController.lua",
    "RageUI/components/*.lua",
    "RageUI/menu/elements/*.lua",
    "RageUI/menu/items/*.lua",
    "RageUI/menu/panels/*.lua",
    "RageUI/menu/windows/*.lua",
    'client.lua',
}

server_scripts {
    "@oxmysql/lib/MySQL.lua",
    "server.lua",
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/script.js',
    'ui/icons/*.svg',
}

escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'