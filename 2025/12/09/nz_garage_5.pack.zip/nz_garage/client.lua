local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1
L0_1 = false
L1_1 = nil
L2_1 = {}
L3_1 = {}
L3_1.isOpen = false
L4_1 = {}
L3_1.currentGarage = L4_1
L3_1.currentAction = nil
L4_1 = {}
L3_1.markers = L4_1
L4_1 = {}
L3_1.tempMarkers = L4_1
L3_1.tempPoints = nil
L3_1.newGarageName = nil
L3_1.newGarageLabel = nil
L3_1.garageType = "car"
L3_1.useBlip = true
L4_1 = RageUI
L4_1 = L4_1.CreateMenu
L5_1 = "Fourri\195\168re"
L6_1 = "VEHICULE"
L4_1 = L4_1(L5_1, L6_1)
function L5_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  if L0_2 then
    return
  end
  L0_2 = true
  L0_1 = L0_2
  L0_2 = ESX
  L0_2 = L0_2.TriggerServerCallback
  L1_2 = "nz_garage:getImpoundedVehicles"
  function L2_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = ESX
      L1_3 = L1_3.ShowNotification
      L2_3 = Config
      L2_3 = L2_3.Notifications
      L2_3 = L2_3.impound
      L2_3 = L2_3.noVehicles
      L1_3(L2_3)
      L1_3 = false
      L0_1 = L1_3
      return
    end
    L1_3 = RageUI
    L1_3 = L1_3.Visible
    L2_3 = L4_1
    L3_3 = true
    L1_3(L2_3, L3_3)
    L1_3 = CreateThread
    function L2_3()
      local L0_4, L1_4, L2_4
      while true do
        L0_4 = L0_1
        if not L0_4 then
          break
        end
        L0_4 = Wait
        L1_4 = 0
        L0_4(L1_4)
        L0_4 = RageUI
        L0_4 = L0_4.IsVisible
        L1_4 = L4_1
        function L2_4()
          local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5
          L0_5 = RageUI
          L0_5 = L0_5.Separator
          L1_5 = "V\195\169hicules en fourri\195\168re (%d)"
          L2_5 = L1_5
          L1_5 = L1_5.format
          L3_5 = A0_3
          L3_5 = #L3_5
          L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5 = L1_5(L2_5, L3_5)
          L0_5(L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5)
          L0_5 = pairs
          L1_5 = A0_3
          L0_5, L1_5, L2_5, L3_5 = L0_5(L1_5)
          for L4_5, L5_5 in L0_5, L1_5, L2_5, L3_5 do
            L6_5 = json
            L6_5 = L6_5.decode
            L7_5 = L5_5.vehicle
            L6_5 = L6_5(L7_5)
            L7_5 = GetLabelText
            L8_5 = GetDisplayNameFromVehicleModel
            L9_5 = L6_5.model
            L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5 = L8_5(L9_5)
            L7_5 = L7_5(L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5)
            L8_5 = Config
            L8_5 = L8_5.Impound
            L8_5 = L8_5.price
            if not L8_5 then
              L8_5 = 500
            end
            L9_5 = RageUI
            L9_5 = L9_5.Button
            L10_5 = "%s | %s"
            L11_5 = L10_5
            L10_5 = L10_5.format
            L12_5 = L7_5
            L13_5 = L5_5.plate
            if not L13_5 then
              L13_5 = ""
            end
            L10_5 = L10_5(L11_5, L12_5, L13_5)
            L11_5 = "Prix de r\195\169cup\195\169ration: $%d"
            L12_5 = L11_5
            L11_5 = L11_5.format
            L13_5 = L8_5
            L11_5 = L11_5(L12_5, L13_5)
            L12_5 = {}
            L13_5 = "$"
            L14_5 = L8_5
            L13_5 = L13_5 .. L14_5
            L12_5.RightLabel = L13_5
            L13_5 = true
            L14_5 = {}
            function L15_5()
              local L0_6, L1_6, L2_6, L3_6
              L0_6 = TriggerServerEvent
              L1_6 = "nz_garage:retrieveImpoundedVehicle"
              L2_6 = L5_5.plate
              L3_6 = L8_5
              L0_6(L1_6, L2_6, L3_6)
              L0_6 = false
              L0_1 = L0_6
              L0_6 = RageUI
              L0_6 = L0_6.Visible
              L1_6 = L4_1
              L2_6 = false
              L0_6(L1_6, L2_6)
            end
            L14_5.onSelected = L15_5
            L9_5(L10_5, L11_5, L12_5, L13_5, L14_5)
          end
          L0_5 = RageUI
          L0_5 = L0_5.Button
          L1_5 = "Fermer"
          L2_5 = nil
          L3_5 = {}
          L4_5 = true
          L5_5 = {}
          function L6_5()
            local L0_6, L1_6, L2_6
            L0_6 = false
            L0_1 = L0_6
            L0_6 = RageUI
            L0_6 = L0_6.Visible
            L1_6 = L4_1
            L2_6 = false
            L0_6(L1_6, L2_6)
          end
          L5_5.onSelected = L6_5
          L0_5(L1_5, L2_5, L3_5, L4_5, L5_5)
        end
        L0_4(L1_4, L2_4)
      end
    end
    L1_3(L2_3)
  end
  L0_2(L1_2, L2_2)
end
OpenImpound = L5_1
L5_1 = nil
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "vector3" == L1_2 then
    L1_2 = string
    L1_2 = L1_2.format
    L2_2 = "%.1f, %.1f, %.1f"
    L3_2 = A0_2.x
    L4_2 = A0_2.y
    L5_2 = A0_2.z
    return L1_2(L2_2, L3_2, L4_2, L5_2)
  else
    L1_2 = type
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if "table" == L1_2 then
      L1_2 = A0_2.x
      if L1_2 then
        L1_2 = A0_2.y
        if L1_2 then
          L1_2 = A0_2.z
          if L1_2 then
            L1_2 = string
            L1_2 = L1_2.format
            L2_2 = "%.1f, %.1f, %.1f"
            L3_2 = A0_2.x
            L4_2 = A0_2.y
            L5_2 = A0_2.z
            return L1_2(L2_2, L3_2, L4_2, L5_2)
        end
      end
    end
    else
      L1_2 = "Position invalide"
      return L1_2
    end
  end
end
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "vector4" == L1_2 then
    L1_2 = string
    L1_2 = L1_2.format
    L2_2 = "%.1f, %.1f, %.1f, %.1f"
    L3_2 = A0_2.x
    L4_2 = A0_2.y
    L5_2 = A0_2.z
    L6_2 = A0_2.w
    return L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  else
    L1_2 = type
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if "table" == L1_2 then
      L1_2 = A0_2.x
      if L1_2 then
        L1_2 = A0_2.y
        if L1_2 then
          L1_2 = A0_2.z
          if L1_2 then
            L1_2 = A0_2.w
            if L1_2 then
              L1_2 = string
              L1_2 = L1_2.format
              L2_2 = "%.1f, %.1f, %.1f, %.1f"
              L3_2 = A0_2.x
              L4_2 = A0_2.y
              L5_2 = A0_2.z
              L6_2 = A0_2.w
              return L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
          end
        end
      end
    end
    else
      L1_2 = "Position invalide"
      return L1_2
    end
  end
end
L8_1 = RegisterNetEvent
L9_1 = "nz_garage:syncGarages"
function L10_1(A0_2)
  local L1_2, L2_2
  L1_2 = Config
  L2_2 = A0_2 or L2_2
  if not A0_2 then
    L2_2 = {}
  end
  L1_2.Garages = L2_2
  L1_2 = A0_2 or L1_2
  if not A0_2 then
    L1_2 = {}
  end
  currentAction = L1_2
end
L8_1(L9_1, L10_1)
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = "car"
  L3_2 = "boat"
  L4_2 = "aircraft"
  L5_2 = "truck"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L1_2[3] = L4_2
  L1_2[4] = L5_2
  L2_2 = ipairs
  L3_2 = L1_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    if L7_2 == A0_2 then
      return L6_2
    end
  end
  L2_2 = 1
  return L2_2
end
function L9_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetDisplayNameFromVehicleModel
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L3_2 = L1_2
    L2_2 = L1_2.lower
    L2_2 = L2_2(L3_2)
    if L2_2 then
      goto lbl_11
    end
  end
  L2_2 = ""
  ::lbl_11::
  return L2_2
end
function L10_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = GetVehicleModelEstimatedMaxSpeed
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    L1_2 = 0.0
  end
  L1_2 = L1_2 * 1.25
  L2_2 = GetVehicleModelAcceleration
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = 0.0
  end
  L2_2 = L2_2 * 200.0
  L3_2 = GetVehicleModelMaxBraking
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = 0.0
  end
  L3_2 = L3_2 * 100.0
  L4_2 = GetVehicleModelMaxTraction
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    L4_2 = 0.0
  end
  L4_2 = L4_2 * 25.0
  L5_2 = {}
  L5_2.maxSpeed = L1_2
  L5_2.acceleration = L2_2
  L5_2.braking = L3_2
  L5_2.handling = L4_2
  return L5_2
end
function L11_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = Config
  L3_2 = L3_2.input
  L4_2 = A0_2
  return L3_2(L4_2)
end
L12_1 = CreateThread
function L13_1()
  local L0_2, L1_2
  L0_2 = Wait
  L1_2 = 2000
  L0_2(L1_2)
  L0_2 = TriggerServerEvent
  L1_2 = "nz_garage:requestGarages"
  L0_2(L1_2)
  L0_2 = TriggerServerEvent
  L1_2 = "nz_garage:requestSync"
  L0_2(L1_2)
  L0_2 = CreateGarageMarkers
  L0_2()
  L0_2 = CreateImpoundMarkers
  L0_2()
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = CreateGarageBlips
  L0_2()
end
L12_1(L13_1)
L12_1 = CreateThread
function L13_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L0_2 = Config
  if L0_2 then
    L0_2 = Config
    L0_2 = L0_2.UsePed
    if L0_2 then
      L0_2 = Config
      L0_2 = L0_2.PedList
      if L0_2 then
        goto lbl_13
      end
    end
  end
  do return end
  ::lbl_13::
  L0_2 = pairs
  L1_2 = Config
  L1_2 = L1_2.PedList
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = Config
    L6_2 = L6_2.Garages
    L6_2 = L6_2[L4_2]
    if L6_2 then
      L7_2 = L6_2.points
      if L7_2 then
        L7_2 = L6_2.points
        L7_2 = L7_2.enter
        if L7_2 then
          L7_2 = L6_2.points
          L7_2 = L7_2.enter
          L7_2 = L7_2.pos
          if L7_2 then
            L7_2 = L6_2.points
            L7_2 = L7_2.enter
            L7_2 = L7_2.pos
            L8_2 = GetHashKey
            L9_2 = L5_2.model
            L8_2 = L8_2(L9_2)
            L9_2 = RequestModel
            L10_2 = L8_2
            L9_2(L10_2)
            while true do
              L9_2 = HasModelLoaded
              L10_2 = L8_2
              L9_2 = L9_2(L10_2)
              if L9_2 then
                break
              end
              L9_2 = Wait
              L10_2 = 10
              L9_2(L10_2)
            end
            L9_2 = CreatePed
            L10_2 = 4
            L11_2 = L8_2
            L12_2 = L7_2.x
            L13_2 = L7_2.y
            L14_2 = L7_2.z
            L14_2 = L14_2 - 1.0
            L15_2 = L5_2.heading
            if not L15_2 then
              L15_2 = 0.0
            end
            L16_2 = false
            L17_2 = true
            L9_2 = L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
            L10_2 = FreezeEntityPosition
            L11_2 = L9_2
            L12_2 = true
            L10_2(L11_2, L12_2)
            L10_2 = SetEntityInvincible
            L11_2 = L9_2
            L12_2 = true
            L10_2(L11_2, L12_2)
            L10_2 = SetBlockingOfNonTemporaryEvents
            L11_2 = L9_2
            L12_2 = true
            L10_2(L11_2, L12_2)
            L10_2 = L5_2.animation
            if L10_2 then
              L10_2 = L5_2.animation
              L10_2 = L10_2.dict
              if "" ~= L10_2 then
                L10_2 = L5_2.animation
                L10_2 = L10_2.name
                if "" ~= L10_2 then
                  L10_2 = RequestAnimDict
                  L11_2 = L5_2.animation
                  L11_2 = L11_2.dict
                  L10_2(L11_2)
                  while true do
                    L10_2 = HasAnimDictLoaded
                    L11_2 = L5_2.animation
                    L11_2 = L11_2.dict
                    L10_2 = L10_2(L11_2)
                    if L10_2 then
                      break
                    end
                    L10_2 = Wait
                    L11_2 = 10
                    L10_2(L11_2)
                  end
                  L10_2 = TaskPlayAnim
                  L11_2 = L9_2
                  L12_2 = L5_2.animation
                  L12_2 = L12_2.dict
                  L13_2 = L5_2.animation
                  L13_2 = L13_2.name
                  L14_2 = 8.0
                  L15_2 = 0.0
                  L16_2 = -1
                  L17_2 = L5_2.animation
                  L17_2 = L17_2.flag
                  if not L17_2 then
                    L17_2 = 1
                  end
                  L18_2 = 0
                  L19_2 = false
                  L20_2 = false
                  L21_2 = false
                  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
              end
            end
            else
              L10_2 = L5_2.scenario
              if L10_2 then
                L10_2 = L5_2.scenario
                if "" ~= L10_2 then
                  L10_2 = TaskStartScenarioInPlace
                  L11_2 = L9_2
                  L12_2 = L5_2.scenario
                  L13_2 = 0
                  L14_2 = true
                  L10_2(L11_2, L12_2, L13_2, L14_2)
                end
              end
            end
            L10_2 = L2_1
            L10_2[L4_2] = L9_2
          end
        end
      end
    end
  end
end
L12_1(L13_1)
function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = Config
  L0_2 = L0_2.GarageBlips
  if L0_2 then
    L0_2 = pairs
    L1_2 = Config
    L1_2 = L1_2.GarageBlips
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = DoesBlipExist
      L7_2 = L5_2
      L6_2 = L6_2(L7_2)
      if L6_2 then
        L6_2 = RemoveBlip
        L7_2 = L5_2
        L6_2(L7_2)
      end
    end
  end
  L0_2 = Config
  L1_2 = {}
  L0_2.GarageBlips = L1_2
  L0_2 = Config
  L0_2 = L0_2.Blips
  if L0_2 then
    L0_2 = Config
    L0_2 = L0_2.Blips
    L0_2 = L0_2.enabled
    if L0_2 then
      goto lbl_35
    end
  end
  do return end
  ::lbl_35::
  L0_2 = pairs
  L1_2 = Config
  L1_2 = L1_2.Garages
  if not L1_2 then
    L1_2 = {}
  end
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.blip
    if false ~= L6_2 then
      L6_2 = L5_2.points
      if L6_2 then
        L6_2 = L5_2.points
        L6_2 = L6_2.enter
        if L6_2 then
          L6_2 = L5_2.points
          L6_2 = L6_2.enter
          L6_2 = L6_2.pos
          if L6_2 then
            L6_2 = L5_2.type
            if not L6_2 then
              L6_2 = "car"
            end
            L7_2 = Config
            L7_2 = L7_2.Blips
            L7_2 = L7_2.types
            if L7_2 then
              L7_2 = Config
              L7_2 = L7_2.Blips
              L7_2 = L7_2.types
              L7_2 = L7_2[L6_2]
              if L7_2 then
                goto lbl_77
              end
            end
            L7_2 = Config
            L7_2 = L7_2.Blips
            L7_2 = L7_2.garage
            ::lbl_77::
            L8_2 = L5_2.blip
            if L8_2 then
              L8_2 = L5_2.blip
              L8_2 = L8_2.sprite
              if L8_2 then
                goto lbl_85
              end
            end
            L8_2 = L7_2.sprite
            ::lbl_85::
            L9_2 = L5_2.blip
            if L9_2 then
              L9_2 = L5_2.blip
              L9_2 = L9_2.color
              if L9_2 then
                goto lbl_93
              end
            end
            L9_2 = L7_2.color
            ::lbl_93::
            L10_2 = L5_2.blip
            if L10_2 then
              L10_2 = L5_2.blip
              L10_2 = L10_2.scale
              if L10_2 then
                goto lbl_101
              end
            end
            L10_2 = L7_2.scale
            ::lbl_101::
            L11_2 = L5_2.blip
            if L11_2 then
              L11_2 = L5_2.blip
              L11_2 = L11_2.name
              if L11_2 then
                goto lbl_109
              end
            end
            L11_2 = L7_2.name
            ::lbl_109::
            L12_2 = L5_2.points
            L12_2 = L12_2.enter
            L12_2 = L12_2.pos
            L13_2 = AddBlipForCoord
            L14_2 = L12_2.x
            L15_2 = L12_2.y
            L16_2 = L12_2.z
            L13_2 = L13_2(L14_2, L15_2, L16_2)
            L14_2 = SetBlipSprite
            L15_2 = L13_2
            L16_2 = L8_2
            L14_2(L15_2, L16_2)
            L14_2 = SetBlipDisplay
            L15_2 = L13_2
            L16_2 = 4
            L14_2(L15_2, L16_2)
            L14_2 = SetBlipScale
            L15_2 = L13_2
            L16_2 = L10_2
            L14_2(L15_2, L16_2)
            L14_2 = SetBlipColour
            L15_2 = L13_2
            L16_2 = L9_2
            L14_2(L15_2, L16_2)
            L14_2 = SetBlipAsShortRange
            L15_2 = L13_2
            L16_2 = true
            L14_2(L15_2, L16_2)
            L14_2 = BeginTextCommandSetBlipName
            L15_2 = "STRING"
            L14_2(L15_2)
            L14_2 = AddTextComponentString
            L15_2 = L11_2
            L14_2(L15_2)
            L14_2 = EndTextCommandSetBlipName
            L15_2 = L13_2
            L14_2(L15_2)
            L14_2 = Config
            L14_2 = L14_2.GarageBlips
            L14_2[L4_2] = L13_2
          end
        end
      end
    end
  end
end
CreateGarageBlips = L12_1
L12_1 = CreateThread
function L13_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2, L43_2, L44_2, L45_2
  while true do
    L0_2 = Wait
    L1_2 = 0
    L0_2(L1_2)
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = IsPedInAnyVehicle
    L3_2 = L0_2
    L4_2 = false
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = false
    L4_2 = Config
    L4_2 = L4_2.Impound
    if L4_2 then
      L4_2 = Config
      L4_2 = L4_2.Impound
      L4_2 = L4_2.enabled
      if L4_2 then
        L4_2 = pairs
        L5_2 = Config
        L5_2 = L5_2.Impound
        L5_2 = L5_2.locations
        if not L5_2 then
          L5_2 = {}
        end
        L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
        for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
          L10_2 = L9_2.points
          if L10_2 then
            L10_2 = L9_2.points
            L10_2 = L10_2.enter
            if L10_2 then
              L10_2 = L9_2.points
              L10_2 = L10_2.enter
              L10_2 = L10_2.pos
              L11_2 = nil
              L12_2 = type
              L13_2 = L10_2
              L12_2 = L12_2(L13_2)
              if "vector3" == L12_2 then
                L11_2 = L10_2
              else
                L12_2 = type
                L13_2 = L10_2
                L12_2 = L12_2(L13_2)
                if "table" == L12_2 then
                  L12_2 = L10_2.x
                  if L12_2 then
                    L12_2 = L10_2.y
                    if L12_2 then
                      L12_2 = L10_2.z
                      if L12_2 then
                        L12_2 = vector3
                        L13_2 = L10_2.x
                        L14_2 = L10_2.y
                        L15_2 = L10_2.z
                        L12_2 = L12_2(L13_2, L14_2, L15_2)
                        L11_2 = L12_2
                      end
                    end
                  end
                end
              end
              if L11_2 then
                L12_2 = L1_2 - L11_2
                L12_2 = #L12_2
                L13_2 = Config
                L13_2 = L13_2.DrawDistance
                if not L13_2 then
                  L13_2 = 20.0
                end
                if L12_2 < L13_2 then
                  L13_2 = L9_2.points
                  L13_2 = L13_2.enter
                  L13_2 = L13_2.marker
                  if not L13_2 then
                    L13_2 = Config
                    L13_2 = L13_2.Markers
                    L13_2 = L13_2.enter
                  end
                  if L13_2 then
                    L14_2 = L13_2.height
                    if not L14_2 then
                      L14_2 = 0.0
                    end
                    L15_2 = DrawMarker
                    L16_2 = L13_2.type
                    L17_2 = L11_2.x
                    L18_2 = L11_2.y
                    L19_2 = L11_2.z
                    L19_2 = L19_2 + L14_2
                    L20_2 = 0.0
                    L21_2 = 0.0
                    L22_2 = 0.0
                    L23_2 = 0.0
                    L24_2 = 0.0
                    L25_2 = 0.0
                    L26_2 = L13_2.size
                    L26_2 = L26_2.x
                    if not L26_2 then
                      L26_2 = 1.0
                    end
                    L27_2 = L13_2.size
                    L27_2 = L27_2.y
                    if not L27_2 then
                      L27_2 = 1.0
                    end
                    L28_2 = L13_2.size
                    L28_2 = L28_2.z
                    if not L28_2 then
                      L28_2 = 1.0
                    end
                    L29_2 = L13_2.color
                    L29_2 = L29_2.r
                    if not L29_2 then
                      L29_2 = 255
                    end
                    L30_2 = L13_2.color
                    L30_2 = L30_2.g
                    if not L30_2 then
                      L30_2 = 0
                    end
                    L31_2 = L13_2.color
                    L31_2 = L31_2.b
                    if not L31_2 then
                      L31_2 = 0
                    end
                    L32_2 = L13_2.color
                    L32_2 = L32_2.a
                    if not L32_2 then
                      L32_2 = 255
                    end
                    L33_2 = false
                    L34_2 = L13_2.bobUpDown
                    if not L34_2 then
                      L34_2 = false
                    end
                    L35_2 = 2
                    L36_2 = L13_2.rotate
                    if not L36_2 then
                      L36_2 = false
                    end
                    L37_2 = nil
                    L38_2 = nil
                    L39_2 = false
                    L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2)
                  end
                  L14_2 = Config
                  L14_2 = L14_2.InteractDistance
                  if not L14_2 then
                    L14_2 = 2.5
                  end
                  if L12_2 < L14_2 then
                    L3_2 = true
                    L14_2 = ESX
                    L14_2 = L14_2.ShowHelpNotification
                    L15_2 = Config
                    L15_2 = L15_2.Notifications
                    L15_2 = L15_2.impound
                    L15_2 = L15_2.enter
                    L14_2(L15_2)
                    L14_2 = IsControlJustReleased
                    L15_2 = 0
                    L16_2 = 38
                    L14_2 = L14_2(L15_2, L16_2)
                    if L14_2 then
                      L14_2 = OpenImpound
                      L14_2()
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
    L4_2 = pairs
    L5_2 = Config
    L5_2 = L5_2.Garages
    if not L5_2 then
      L5_2 = {}
    end
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = pairs
      L11_2 = L9_2.points
      if not L11_2 then
        L11_2 = {}
      end
      L10_2, L11_2, L12_2, L13_2 = L10_2(L11_2)
      for L14_2, L15_2 in L10_2, L11_2, L12_2, L13_2 do
        if "store" ~= L14_2 or "store" == L14_2 and L2_2 then
          L16_2 = L15_2.pos
          if L16_2 then
            L17_2 = nil
            L18_2 = type
            L19_2 = L16_2
            L18_2 = L18_2(L19_2)
            if "vector3" == L18_2 then
              L17_2 = L16_2
            else
              L18_2 = type
              L19_2 = L16_2
              L18_2 = L18_2(L19_2)
              if "table" == L18_2 then
                L18_2 = L16_2.x
                if L18_2 then
                  L18_2 = L16_2.y
                  if L18_2 then
                    L18_2 = L16_2.z
                    if L18_2 then
                      L18_2 = vector3
                      L19_2 = L16_2.x
                      L20_2 = L16_2.y
                      L21_2 = L16_2.z
                      L18_2 = L18_2(L19_2, L20_2, L21_2)
                      L17_2 = L18_2
                  end
                end
              end
              else
                L17_2 = nil
              end
            end
            if L17_2 then
              L18_2 = L1_2 - L17_2
              L18_2 = #L18_2
              L19_2 = Config
              L19_2 = L19_2.DrawDistance
              if not L19_2 then
                L19_2 = 20.0
              end
              if L18_2 < L19_2 then
                L19_2 = Config
                L19_2 = L19_2.Markers
                L19_2 = L19_2[L14_2]
                if L19_2 then
                  L20_2 = L19_2.height
                  if not L20_2 then
                    L20_2 = 0.0
                  end
                  L21_2 = DrawMarker
                  L22_2 = L19_2.type
                  L23_2 = L17_2.x
                  L24_2 = L17_2.y
                  L25_2 = L17_2.z
                  L25_2 = L25_2 + L20_2
                  L26_2 = 0.0
                  L27_2 = 0.0
                  L28_2 = 0.0
                  L29_2 = 0.0
                  L30_2 = 0.0
                  L31_2 = 0.0
                  L32_2 = L19_2.size
                  L32_2 = L32_2.x
                  if not L32_2 then
                    L32_2 = 1.0
                  end
                  L33_2 = L19_2.size
                  L33_2 = L33_2.y
                  if not L33_2 then
                    L33_2 = 1.0
                  end
                  L34_2 = L19_2.size
                  L34_2 = L34_2.z
                  if not L34_2 then
                    L34_2 = 1.0
                  end
                  L35_2 = L19_2.color
                  L35_2 = L35_2.r
                  if not L35_2 then
                    L35_2 = 255
                  end
                  L36_2 = L19_2.color
                  L36_2 = L36_2.g
                  if not L36_2 then
                    L36_2 = 255
                  end
                  L37_2 = L19_2.color
                  L37_2 = L37_2.b
                  if not L37_2 then
                    L37_2 = 255
                  end
                  L38_2 = L19_2.color
                  L38_2 = L38_2.a
                  if not L38_2 then
                    L38_2 = 150
                  end
                  L39_2 = false
                  L40_2 = L19_2.bobUpDown
                  if not L40_2 then
                    L40_2 = false
                  end
                  L41_2 = 2
                  L42_2 = L19_2.rotate
                  if not L42_2 then
                    L42_2 = false
                  end
                  L43_2 = nil
                  L44_2 = nil
                  L45_2 = false
                  L21_2(L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2, L43_2, L44_2, L45_2)
                end
                L20_2 = Config
                L20_2 = L20_2.InteractDistance
                if not L20_2 then
                  L20_2 = 2.5
                end
                if L18_2 < L20_2 then
                  L3_2 = true
                  if "enter" == L14_2 then
                    L20_2 = Config
                    L20_2 = L20_2.UsePed
                    if L20_2 then
                      L20_2 = L2_1
                      L20_2 = L20_2[L8_2]
                    end
                    if not L20_2 then
                      L20_2 = ESX
                      L20_2 = L20_2.ShowHelpNotification
                      L21_2 = Config
                      L21_2 = L21_2.Notifications
                      L21_2 = L21_2.enter
                      L20_2(L21_2)
                      L20_2 = IsControlJustReleased
                      L21_2 = 0
                      L22_2 = 38
                      L20_2 = L20_2(L21_2, L22_2)
                      if L20_2 then
                        L20_2 = OpenGarageMenu
                        L21_2 = L8_2
                        L20_2(L21_2)
                      end
                    end
                  elseif "store" == L14_2 then
                    L20_2 = ESX
                    L20_2 = L20_2.ShowHelpNotification
                    L21_2 = Config
                    L21_2 = L21_2.Notifications
                    L21_2 = L21_2.store
                    L20_2(L21_2)
                    L20_2 = IsControlJustReleased
                    L21_2 = 0
                    L22_2 = 38
                    L20_2 = L20_2(L21_2, L22_2)
                    if L20_2 then
                      L20_2 = StoreVehicle
                      L21_2 = L8_2
                      L20_2(L21_2)
                      L20_2 = Wait
                      L21_2 = 1000
                      L20_2(L21_2)
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end
L12_1(L13_1)
L12_1 = false
function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = L12_1
  if L1_2 then
    return
  end
  L1_2 = true
  L12_1 = L1_2
  L1_2 = GetVehiclePedIsIn
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 and L1_2 > 0 then
    L2_2 = ESX
    L2_2 = L2_2.Game
    L2_2 = L2_2.GetVehicleProperties
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L3_2 = ESX
      L3_2 = L3_2.TriggerServerCallback
      L4_2 = "nz_garage:canStoreVehicle"
      function L5_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3
        if A0_3 then
          L1_3 = TriggerServerEvent
          L2_3 = "nz_garage:storeVehicle"
          L3_3 = L2_2
          L4_3 = L2_2.plate
          L5_3 = A0_2
          L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = ESX
          L1_3 = L1_3.Game
          L1_3 = L1_3.DeleteVehicle
          L2_3 = L1_2
          L1_3(L2_3)
          L1_3 = ESX
          L1_3 = L1_3.ShowNotification
          L2_3 = Config
          L2_3 = L2_3.Notifications
          L2_3 = L2_3.storeSuccess
          L1_3(L2_3)
        else
          L1_3 = ESX
          L1_3 = L1_3.ShowNotification
          L2_3 = Config
          L2_3 = L2_3.Notifications
          L2_3 = L2_3.notOwner
          L1_3(L2_3)
        end
        L1_3 = Wait
        L2_3 = 1000
        L1_3(L2_3)
        L1_3 = false
        L12_1 = L1_3
      end
      L6_2 = L2_2.plate
      L3_2(L4_2, L5_2, L6_2)
    else
      L3_2 = false
      L12_1 = L3_2
    end
  else
    L2_2 = ESX
    L2_2 = L2_2.ShowNotification
    L3_2 = Config
    L3_2 = L3_2.Notifications
    L3_2 = L3_2.notInVehicle
    L2_2(L3_2)
    L2_2 = false
    L12_1 = L2_2
  end
  L2_2 = SetTimeout
  L3_2 = 5000
  function L4_2()
    local L0_3, L1_3
    L0_3 = false
    L12_1 = L0_3
  end
  L2_2(L3_2, L4_2)
end
StoreVehicle = L13_1
L13_1 = RegisterNetEvent
L14_1 = "nz_garage:openGarage"
function L15_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ESX
  L1_2 = L1_2.TriggerServerCallback
  L2_2 = "nz_garage:getVehicles"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = {}
    L2_3 = ipairs
    L3_3 = A0_3 or L3_3
    if not A0_3 then
      L3_3 = {}
    end
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = json
      L8_3 = L8_3.decode
      L9_3 = L7_3.vehicle
      L8_3 = L8_3(L9_3)
      L9_3 = L8_3.model
      L10_3 = table
      L10_3 = L10_3.insert
      L11_3 = L1_3
      L12_3 = {}
      L13_3 = L7_3.id
      L12_3.id = L13_3
      L13_3 = L7_3.plate
      L12_3.plate = L13_3
      L13_3 = L7_3.stored
      L12_3.stored = L13_3
      L13_3 = L9_1
      L14_3 = L9_3
      L13_3 = L13_3(L14_3)
      L12_3.model = L13_3
      L12_3.hash = L9_3
      L13_3 = GetLabelText
      L14_3 = GetDisplayNameFromVehicleModel
      L15_3 = L9_3
      L14_3, L15_3 = L14_3(L15_3)
      L13_3 = L13_3(L14_3, L15_3)
      L12_3.name = L13_3
      L10_3(L11_3, L12_3)
    end
    L2_3 = SetNuiFocus
    L3_3 = true
    L4_3 = true
    L2_3(L3_3, L4_3)
    if A0_3 then
      L2_3 = SendNUIMessage
      L3_3 = {}
      L3_3.type = "openGarage"
      L3_3.vehicles = A0_3
      L2_3(L3_3)
      L2_3 = A0_2
      L1_1 = L2_3
    end
  end
  L1_2(L2_2, L3_2)
end
L13_1(L14_1, L15_1)
L13_1 = RegisterNUICallback
L14_1 = "getVehicleStats"
function L15_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = GetHashKey
  L3_2 = A0_2.model
  L2_2 = L2_2(L3_2)
  L3_2 = A1_2
  L4_2 = L10_1
  L5_2 = L2_2
  L4_2, L5_2 = L4_2(L5_2)
  L3_2(L4_2, L5_2)
end
L13_1(L14_1, L15_1)
L13_1 = RegisterNUICallback
L14_1 = "closeGarage"
function L15_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = A1_2
  L3_2 = {}
  L2_2(L3_2)
end
L13_1(L14_1, L15_1)
function L13_1()
  local L0_2, L1_2, L2_2
  L0_2 = SetNuiFocus
  L1_2 = false
  L2_2 = false
  L0_2(L1_2, L2_2)
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.type = "closeGarage"
  L0_2(L1_2)
end
CloseGarageMenu = L13_1
L13_1 = RegisterNUICallback
L14_1 = "spawnVehicle"
function L15_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L2_2 = A0_2.plate
  L3_2 = pairs
  L4_2 = L5_1
  if not L4_2 then
    L4_2 = {}
  end
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = L8_2.plate
    if L9_2 == L2_2 then
      L9_2 = L8_2.is_stored
      if 1 == L9_2 then
        L9_2 = TriggerServerEvent
        L10_2 = "nz_garage:server:spawnVehicle"
        L11_2 = L8_2.id
        L9_2(L10_2, L11_2)
        break
      end
      L9_2 = L8_2.entityId
      if L9_2 then
        L9_2 = DoesEntityExist
        L10_2 = L8_2.entityId
        L9_2 = L9_2(L10_2)
        if L9_2 then
          L9_2 = ESX
          L9_2 = L9_2.Game
          L9_2 = L9_2.GetVehicleProperties
          L10_2 = L8_2.entityId
          L9_2 = L9_2(L10_2)
          L10_2 = TriggerServerEvent
          L11_2 = "nz_garage:storeVehicle"
          L12_2 = L9_2
          L13_2 = L2_2
          L10_2(L11_2, L12_2, L13_2)
          L10_2 = ESX
          L10_2 = L10_2.Game
          L10_2 = L10_2.DeleteVehicle
          L11_2 = L8_2.entityId
          L10_2(L11_2)
        end
      end
      break
    end
  end
  L3_2 = CloseGarageMenu
  L3_2()
  L3_2 = A1_2
  L4_2 = {}
  L3_2(L4_2)
end
L13_1(L14_1, L15_1)
L13_1 = RegisterNetEvent
L14_1 = "nz_garage:client:spawnVehicle"
function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = Config
  L1_2 = L1_2.Garages
  L2_2 = L1_1
  L1_2 = L1_2[L2_2]
  if L1_2 then
    L2_2 = L1_2.spawnPoint
    if L2_2 then
      goto lbl_11
    end
  end
  do return end
  ::lbl_11::
  L2_2 = ESX
  L2_2 = L2_2.Game
  L2_2 = L2_2.SpawnVehicle
  L3_2 = A0_2.model
  L4_2 = vector3
  L5_2 = L1_2.spawnPoint
  L5_2 = L5_2.x
  L6_2 = L1_2.spawnPoint
  L6_2 = L6_2.y
  L7_2 = L1_2.spawnPoint
  L7_2 = L7_2.z
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = L1_2.spawnPoint
  L5_2 = L5_2.w
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = ESX
    L1_3 = L1_3.Game
    L1_3 = L1_3.SetVehicleProperties
    L2_3 = A0_3
    L3_3 = A0_2
    L1_3(L2_3, L3_3)
    L1_3 = TaskWarpPedIntoVehicle
    L2_3 = PlayerPedId
    L2_3 = L2_3()
    L3_3 = A0_3
    L4_3 = -1
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = SetVehicleEngineOn
    L2_3 = A0_3
    L3_3 = true
    L4_3 = true
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L13_1(L14_1, L15_1)
L13_1 = RegisterNetEvent
L14_1 = "nz_garage:spawnImpoundedVehicle"
function L15_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  if not A1_2 then
    return
  end
  L2_2 = ESX
  L2_2 = L2_2.Game
  L2_2 = L2_2.SpawnVehicle
  L3_2 = A0_2.model
  L4_2 = vector3
  L5_2 = A1_2.x
  L6_2 = A1_2.y
  L7_2 = A1_2.z
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = A1_2.w
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = ESX
    L1_3 = L1_3.Game
    L1_3 = L1_3.SetVehicleProperties
    L2_3 = A0_3
    L3_3 = A0_2
    L1_3(L2_3, L3_3)
    L1_3 = TaskWarpPedIntoVehicle
    L2_3 = PlayerPedId
    L2_3 = L2_3()
    L3_3 = A0_3
    L4_3 = -1
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = SetVehicleEngineOn
    L2_3 = A0_3
    L3_3 = true
    L4_3 = true
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L13_1(L14_1, L15_1)
function L13_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = ESX
  L1_2 = L1_2.TriggerServerCallback
  L2_2 = "nz_garage:getVehicles"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L1_3 = {}
    L2_3 = {}
    L1_3.personal = L2_3
    L2_3 = {}
    L1_3.job = L2_3
    L2_3 = {}
    L1_3.gang = L2_3
    L2_3 = ipairs
    L3_3 = A0_3 or L3_3
    if not A0_3 then
      L3_3 = {}
    end
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = json
      L8_3 = L8_3.decode
      L9_3 = L7_3.vehicle
      L8_3 = L8_3(L9_3)
      if L8_3 then
        L9_3 = L8_3.model
        L10_3 = L10_1
        L11_3 = L9_3
        L10_3 = L10_3(L11_3)
        L11_3 = GetLabelText
        L12_3 = GetMakeNameFromVehicleModel
        L13_3 = L9_3
        L12_3, L13_3, L14_3, L15_3, L16_3, L17_3 = L12_3(L13_3)
        L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3, L17_3)
        L12_3 = L7_3.vehicle_type
        if not L12_3 then
          L12_3 = "personal"
        end
        if "personal" == L12_3 then
          L13_3 = "Personnel"
          if L13_3 then
            goto lbl_47
          end
        end
        L13_3 = L7_3.firstname
        if not L13_3 then
          L13_3 = ""
        end
        ::lbl_47::
        L14_3 = {}
        L15_3 = L7_3.id
        L14_3.id = L15_3
        L15_3 = L7_3.plate
        L14_3.plate = L15_3
        L15_3 = tonumber
        L16_3 = L7_3.is_stored
        L15_3 = L15_3(L16_3)
        L14_3.stored = L15_3
        L15_3 = tonumber
        L16_3 = L7_3.is_stored
        L15_3 = L15_3(L16_3)
        L14_3.is_stored = L15_3
        L15_3 = L9_1
        L16_3 = L9_3
        L15_3 = L15_3(L16_3)
        L14_3.model = L15_3
        L14_3.brand = L11_3
        L15_3 = GetLabelText
        L16_3 = GetDisplayNameFromVehicleModel
        L17_3 = L9_3
        L16_3, L17_3 = L16_3(L17_3)
        L15_3 = L15_3(L16_3, L17_3)
        L14_3.name = L15_3
        L15_3 = L10_3.maxSpeed
        L14_3.maxSpeed = L15_3
        L15_3 = L10_3.acceleration
        L14_3.acceleration = L15_3
        L15_3 = L10_3.braking
        L14_3.braking = L15_3
        L15_3 = L10_3.handling
        L14_3.handling = L15_3
        L15_3 = L7_3.firstname
        L14_3.firstname = L15_3
        L15_3 = L7_3.lastname
        L14_3.lastname = L15_3
        L14_3.ownerType = L12_3
        L14_3.ownerLabel = L13_3
        L15_3 = table
        L15_3 = L15_3.insert
        L16_3 = L1_3[L12_3]
        L17_3 = L14_3
        L15_3(L16_3, L17_3)
      end
    end
    L2_3 = {}
    L5_1 = L2_3
    L2_3 = pairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = ipairs
      L9_3 = L7_3
      L8_3, L9_3, L10_3, L11_3 = L8_3(L9_3)
      for L12_3, L13_3 in L8_3, L9_3, L10_3, L11_3 do
        L14_3 = table
        L14_3 = L14_3.insert
        L15_3 = L5_1
        L16_3 = L13_3
        L14_3(L15_3, L16_3)
      end
    end
    L2_3 = A0_2
    L1_1 = L2_3
    L2_3 = SetNuiFocus
    L3_3 = true
    L4_3 = true
    L2_3(L3_3, L4_3)
    L2_3 = SendNUIMessage
    L3_3 = {}
    L3_3.type = "openGarage"
    L3_3.vehicles = L1_3
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2)
end
OpenGarageMenu = L13_1
L13_1 = RageUI
L13_1 = L13_1.CreateMenu
L14_1 = "Garage Builder"
L15_1 = "Gestion des garages"
L13_1 = L13_1(L14_1, L15_1)
L14_1 = RageUI
L14_1 = L14_1.CreateSubMenu
L15_1 = L13_1
L16_1 = "Liste des garages"
L17_1 = "S\195\169lectionnez un garage"
L14_1 = L14_1(L15_1, L16_1, L17_1)
L15_1 = RageUI
L15_1 = L15_1.CreateSubMenu
L16_1 = L14_1
L17_1 = "Modifier le garage"
L18_1 = "Options disponibles"
L15_1 = L15_1(L16_1, L17_1, L18_1)
L16_1 = RageUI
L16_1 = L16_1.CreateSubMenu
L17_1 = L13_1
L18_1 = "Cr\195\169er un garage"
L19_1 = "Cr\195\169er un nouveau garage"
L16_1 = L16_1(L17_1, L18_1, L19_1)
L17_1 = RegisterCommand
L18_1 = "garagebuilder"
function L19_1()
  local L0_2, L1_2, L2_2
  L0_2 = ESX
  L0_2 = L0_2.TriggerServerCallback
  L1_2 = "nz_garage:checkPermission"
  function L2_2(A0_3)
    local L1_3, L2_3
    if A0_3 then
      L1_3 = OpenGarageBuilder
      L1_3()
    else
      L1_3 = ESX
      L1_3 = L1_3.ShowNotification
      L2_3 = "~r~Vous n'avez pas les permissions n\195\169cessaires!"
      L1_3(L2_3)
    end
  end
  L0_2(L1_2, L2_2)
end
L20_1 = false
L17_1(L18_1, L19_1, L20_1)
L17_1 = RegisterCommand
L18_1 = "impound"
function L19_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetVehiclePedIsIn
  L4_2 = L2_2
  L5_2 = false
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 and L3_2 > 0 then
    L4_2 = GetVehicleNumberPlateText
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      L6_2 = L4_2
      L5_2 = L4_2.gsub
      L7_2 = "%s+"
      L8_2 = ""
      L5_2 = L5_2(L6_2, L7_2, L8_2)
      L6_2 = L5_2
      L5_2 = L5_2.gsub
      L7_2 = "^%s*(.-)%s*$"
      L8_2 = "%1"
      L5_2 = L5_2(L6_2, L7_2, L8_2)
      L4_2 = L5_2
      if "" ~= L4_2 then
        L5_2 = TriggerServerEvent
        L6_2 = "nz_garage:impoundVehicle"
        L7_2 = L4_2
        L5_2(L6_2, L7_2)
      else
        L5_2 = ESX
        L5_2 = L5_2.ShowNotification
        L6_2 = "~r~Impossible de r\195\169cup\195\169rer la plaque d'immatriculation"
        L5_2(L6_2)
      end
    else
      L5_2 = ESX
      L5_2 = L5_2.ShowNotification
      L6_2 = "~r~Impossible de r\195\169cup\195\169rer la plaque d'immatriculation"
      L5_2(L6_2)
    end
  else
    L4_2 = ESX
    L4_2 = L4_2.ShowNotification
    L5_2 = "~r~Vous devez \195\170tre dans un v\195\169hicule pour le mettre en fourri\195\168re"
    L4_2(L5_2)
  end
end
L20_1 = false
L17_1(L18_1, L19_1, L20_1)
L17_1 = RegisterCommand
L18_1 = "impoundplate"
function L19_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = A1_2[1]
  if L2_2 then
    L2_2 = A1_2[1]
    L3_2 = L2_2
    L2_2 = L2_2.upper
    L2_2 = L2_2(L3_2)
    L3_2 = TriggerServerEvent
    L4_2 = "nz_garage:impoundVehicle"
    L5_2 = L2_2
    L3_2(L4_2, L5_2)
  else
    L2_2 = ESX
    L2_2 = L2_2.ShowNotification
    L3_2 = "~r~Usage: /impoundplate [PLAQUE]"
    L2_2(L3_2)
  end
end
L20_1 = false
L17_1(L18_1, L19_1, L20_1)
L17_1 = RegisterCommand
L18_1 = "testimpound"
function L19_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetEntityCoords
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = GetEntityHeading
  L5_2 = L2_2
  L4_2 = L4_2(L5_2)
  L5_2 = ESX
  L5_2 = L5_2.Game
  L5_2 = L5_2.SpawnVehicle
  L6_2 = "adder"
  L7_2 = vector3
  L8_2 = L3_2.x
  L8_2 = L8_2 + 2
  L9_2 = L3_2.y
  L10_2 = L3_2.z
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  L8_2 = L4_2
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = "TEST"
    L2_3 = math
    L2_3 = L2_3.random
    L3_3 = 1000
    L4_3 = 9999
    L2_3 = L2_3(L3_3, L4_3)
    L1_3 = L1_3 .. L2_3
    L2_3 = SetVehicleNumberPlateText
    L3_3 = A0_3
    L4_3 = L1_3
    L2_3(L3_3, L4_3)
    L2_3 = SetTimeout
    L3_3 = 2000
    function L4_3()
      local L0_4, L1_4, L2_4
      L0_4 = TriggerServerEvent
      L1_4 = "nz_garage:impoundVehicle"
      L2_4 = L1_3
      L0_4(L1_4, L2_4)
      L0_4 = ESX
      L0_4 = L0_4.ShowNotification
      L1_4 = "~g~V\195\169hicule de test cr\195\169\195\169 et mis en fourri\195\168re: "
      L2_4 = L1_3
      L1_4 = L1_4 .. L2_4
      L0_4(L1_4)
    end
    L2_3(L3_3, L4_3)
  end
  L5_2(L6_2, L7_2, L8_2, L9_2)
end
L20_1 = false
L17_1(L18_1, L19_1, L20_1)
function L17_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L3_1.isOpen
  if L0_2 then
    return
  end
  L3_1.isOpen = true
  L0_2 = Wait
  L1_2 = 200
  L0_2(L1_2)
  L0_2 = 1
  L1_2 = L3_1.tempMarkers
  L1_2 = #L1_2
  L2_2 = 1
  for L3_2 = L0_2, L1_2, L2_2 do
    L4_2 = L3_1.tempMarkers
    L4_2 = L4_2[L3_2]
    L4_2.active = false
  end
  L0_2 = {}
  L3_1.tempMarkers = L0_2
  L0_2 = {}
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L0_3 = table
    L0_3 = L0_3.wipe
    L1_3 = L0_2
    L0_3(L1_3)
    function L0_3(A0_4)
      local L1_4, L2_4, L3_4
      L2_4 = A0_4
      L1_4 = A0_4.match
      L3_4 = "%((%d+)%)$"
      L1_4 = L1_4(L2_4, L3_4)
      L2_4 = tonumber
      L3_4 = L1_4
      L2_4 = L2_4(L3_4)
      if not L2_4 then
        L2_4 = 999
      end
      return L2_4
    end
    L1_3 = pairs
    L2_3 = Config
    L2_3 = L2_3.Garages
    if not L2_3 then
      L2_3 = {}
    end
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = table
      L7_3 = L7_3.insert
      L8_3 = L0_2
      L9_3 = {}
      L9_3.name = L5_3
      L10_3 = L6_3.name
      if not L10_3 then
        L10_3 = L5_3
      end
      L9_3.label = L10_3
      L10_3 = L0_3
      L11_3 = L6_3.name
      if not L11_3 then
        L11_3 = L5_3
      end
      L10_3 = L10_3(L11_3)
      L9_3.id = L10_3
      L7_3(L8_3, L9_3)
    end
    L1_3 = table
    L1_3 = L1_3.sort
    L2_3 = L0_2
    function L3_3(A0_4, A1_4)
      local L2_4, L3_4
      L2_4 = A0_4.id
      L3_4 = A1_4.id
      if L2_4 ~= L3_4 then
        L2_4 = A0_4.id
        L3_4 = A1_4.id
        L2_4 = L2_4 < L3_4
        return L2_4
      else
        L2_4 = A0_4.label
        L3_4 = A1_4.label
        L2_4 = L2_4 < L3_4
        return L2_4
      end
    end
    L1_3(L2_3, L3_3)
  end
  L2_2 = L1_2
  L2_2()
  L2_2 = RageUI
  L2_2 = L2_2.Visible
  L3_2 = L13_1
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = L3_1.isOpen
      if not L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 0
      L0_3(L1_3)
      L0_3 = RageUI
      L0_3 = L0_3.IsVisible
      L1_3 = L13_1
      function L2_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Liste des garages"
        L2_4 = nil
        L3_4 = {}
        L3_4.RightLabel = ">>>"
        L4_4 = true
        L5_4 = {}
        L6_4 = L1_2
        L5_4.onSelected = L6_4
        L6_4 = L14_1
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4)
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Cr\195\169er un garage"
        L2_4 = nil
        L3_4 = {}
        L3_4.RightLabel = ">>>"
        L4_4 = true
        L5_4 = {}
        L6_4 = L16_1
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4)
      end
      L0_3(L1_3, L2_3)
      L0_3 = RageUI
      L0_3 = L0_3.IsVisible
      L1_3 = L14_1
      function L2_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4
        L0_4 = L0_2
        L0_4 = #L0_4
        if 0 == L0_4 then
          L0_4 = RageUI
          L0_4 = L0_4.Separator
          L1_4 = "~r~Aucun garage disponible"
          L0_4(L1_4)
        else
          L0_4 = ipairs
          L1_4 = L0_2
          L0_4, L1_4, L2_4, L3_4 = L0_4(L1_4)
          for L4_4, L5_4 in L0_4, L1_4, L2_4, L3_4 do
            L6_4 = RageUI
            L6_4 = L6_4.Button
            L7_4 = L5_4.label
            L8_4 = nil
            L9_4 = {}
            L9_4.RightLabel = ">>>"
            L10_4 = true
            L11_4 = {}
            function L12_4()
              local L0_5, L1_5
              L0_5 = L5_4.name
              L3_1.currentGarage = L0_5
            end
            L11_4.onSelected = L12_4
            L12_4 = L15_1
            L6_4(L7_4, L8_4, L9_4, L10_4, L11_4, L12_4)
          end
        end
      end
      L0_3(L1_3, L2_3)
      L0_3 = RageUI
      L0_3 = L0_3.IsVisible
      L1_3 = L15_1
      function L2_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
        L0_4 = Config
        L0_4 = L0_4.Garages
        L1_4 = L3_1.currentGarage
        L0_4 = L0_4[L1_4]
        if not L0_4 then
          return
        end
        L1_4 = currentGarageTypeIndex
        if not L1_4 then
          L1_4 = L8_1
          L2_4 = L0_4.type
          if not L2_4 then
            L2_4 = "car"
          end
          L1_4 = L1_4(L2_4)
          currentGarageTypeIndex = L1_4
        end
        L1_4 = RageUI
        L1_4 = L1_4.Separator
        L2_4 = "Garage | %s"
        L3_4 = L2_4
        L2_4 = L2_4.format
        L4_4 = L3_1.currentGarage
        L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4 = L2_4(L3_4, L4_4)
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4)
        L1_4 = RageUI
        L1_4 = L1_4.Button
        L2_4 = "Modifier le nom"
        L3_4 = "Changer le nom affich\195\169 du garage"
        L4_4 = {}
        L5_4 = L0_4.name
        if L5_4 then
          L5_4 = L0_4.name
          L6_4 = L5_4
          L5_4 = L5_4.gsub
          L7_4 = " %((%d+)%)$"
          L8_4 = ""
          L5_4 = L5_4(L6_4, L7_4, L8_4)
          if L5_4 then
            goto lbl_42
          end
        end
        L5_4 = L3_1.currentGarage
        ::lbl_42::
        L4_4.RightLabel = L5_4
        L5_4 = true
        L6_4 = {}
        function L7_4()
          local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5
          L0_5 = L0_4.name
          if not L0_5 then
            L0_5 = L3_1.currentGarage
          end
          L2_5 = L0_5
          L1_5 = L0_5.match
          L3_5 = "%((%d+)%)$"
          L1_5 = L1_5(L2_5, L3_5)
          if L1_5 then
            L3_5 = L0_5
            L2_5 = L0_5.gsub
            L4_5 = " %((%d+)%)$"
            L5_5 = ""
            L2_5 = L2_5(L3_5, L4_5, L5_5)
            if L2_5 then
              goto lbl_17
            end
          end
          L2_5 = L0_5
          ::lbl_17::
          L3_5 = L11_1
          L4_5 = "Nom du garage"
          L5_5 = L2_5
          L6_5 = 50
          L3_5 = L3_5(L4_5, L5_5, L6_5)
          if L3_5 and "" ~= L3_5 then
            if L1_5 then
              L4_5 = "%s (%s)"
              L5_5 = L4_5
              L4_5 = L4_5.format
              L6_5 = L3_5
              L7_5 = L1_5
              L4_5 = L4_5(L5_5, L6_5, L7_5)
              if L4_5 then
                goto lbl_36
              end
            end
            L4_5 = L3_5
            ::lbl_36::
            L0_4.name = L4_5
            L4_5 = TriggerServerEvent
            L5_5 = "nz_garage:saveGarages"
            L6_5 = Config
            L6_5 = L6_5.Garages
            L4_5(L5_5, L6_5)
            L4_5 = L1_2
            L4_5()
            L4_5 = ESX
            L4_5 = L4_5.ShowNotification
            L5_5 = "~g~Nom modifi\195\169 et sauvegard\195\169!"
            L4_5(L5_5)
            L4_5 = RageUI
            L4_5 = L4_5.Visible
            L5_5 = L15_1
            L6_5 = false
            L4_5(L5_5, L6_5)
            L4_5 = RageUI
            L4_5 = L4_5.Visible
            L5_5 = L14_1
            L6_5 = true
            L4_5(L5_5, L6_5)
          end
        end
        L6_4.onSelected = L7_4
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4)
        L1_4 = L0_4.points
        if L1_4 then
          L1_4 = L0_4.points
          L1_4 = L1_4.enter
          if L1_4 then
            L1_4 = L0_4.points
            L1_4 = L1_4.enter
            L1_4 = L1_4.pos
            if L1_4 then
              L1_4 = L0_4.points
              L1_4 = L1_4.enter
              L1_4 = L1_4.pos
              L2_4 = RageUI
              L2_4 = L2_4.Button
              L3_4 = "Point d'entr\195\169e"
              L4_4 = "D\195\169finir le point d'entr\195\169e du garage"
              L5_4 = {}
              L6_4 = L6_1
              L7_4 = L1_4
              L6_4 = L6_4(L7_4)
              L5_4.RightLabel = L6_4
              L6_4 = true
              L7_4 = {}
              function L8_4()
                local L0_5, L1_5, L2_5, L3_5
                L0_5 = GetEntityCoords
                L1_5 = PlayerPedId
                L1_5, L2_5, L3_5 = L1_5()
                L0_5 = L0_5(L1_5, L2_5, L3_5)
                L1_5 = L0_4.points
                L1_5 = L1_5.enter
                L1_5.pos = L0_5
                L1_5 = TriggerServerEvent
                L2_5 = "nz_garage:saveGarages"
                L3_5 = Config
                L3_5 = L3_5.Garages
                L1_5(L2_5, L3_5)
                L1_5 = ESX
                L1_5 = L1_5.ShowNotification
                L2_5 = "~g~Point d'entr\195\169e mis \195\160 jour et sauvegard\195\169!"
                L1_5(L2_5)
              end
              L7_4.onSelected = L8_4
              L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
            end
          end
        end
        L1_4 = L0_4.points
        if L1_4 then
          L1_4 = L0_4.points
          L1_4 = L1_4.store
          if L1_4 then
            L1_4 = L0_4.points
            L1_4 = L1_4.store
            L1_4 = L1_4.pos
            if L1_4 then
              L1_4 = L0_4.points
              L1_4 = L1_4.store
              L1_4 = L1_4.pos
              L2_4 = RageUI
              L2_4 = L2_4.Button
              L3_4 = "Point de rangement"
              L4_4 = "D\195\169finir le point de rangement des v\195\169hicules"
              L5_4 = {}
              L6_4 = L6_1
              L7_4 = L1_4
              L6_4 = L6_4(L7_4)
              L5_4.RightLabel = L6_4
              L6_4 = true
              L7_4 = {}
              function L8_4()
                local L0_5, L1_5, L2_5, L3_5
                L0_5 = GetEntityCoords
                L1_5 = PlayerPedId
                L1_5, L2_5, L3_5 = L1_5()
                L0_5 = L0_5(L1_5, L2_5, L3_5)
                L1_5 = L0_4.points
                L1_5 = L1_5.store
                L1_5.pos = L0_5
                L1_5 = TriggerServerEvent
                L2_5 = "nz_garage:saveGarages"
                L3_5 = Config
                L3_5 = L3_5.Garages
                L1_5(L2_5, L3_5)
                L1_5 = ESX
                L1_5 = L1_5.ShowNotification
                L2_5 = "~g~Point de rangement mis \195\160 jour et sauvegard\195\169!"
                L1_5(L2_5)
              end
              L7_4.onSelected = L8_4
              L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
            end
          end
        end
        L1_4 = L0_4.spawnPoint
        if L1_4 then
          L1_4 = L0_4.spawnPoint
          L2_4 = RageUI
          L2_4 = L2_4.Button
          L3_4 = "Point de spawn"
          L4_4 = "D\195\169finir le point d'apparition des v\195\169hicules"
          L5_4 = {}
          L6_4 = L7_1
          L7_4 = L1_4
          L6_4 = L6_4(L7_4)
          L5_4.RightLabel = L6_4
          L6_4 = true
          L7_4 = {}
          function L8_4()
            local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5, L6_5
            L0_5 = GetEntityCoords
            L1_5 = PlayerPedId
            L1_5, L2_5, L3_5, L4_5, L5_5, L6_5 = L1_5()
            L0_5 = L0_5(L1_5, L2_5, L3_5, L4_5, L5_5, L6_5)
            L1_5 = GetEntityHeading
            L2_5 = PlayerPedId
            L2_5, L3_5, L4_5, L5_5, L6_5 = L2_5()
            L1_5 = L1_5(L2_5, L3_5, L4_5, L5_5, L6_5)
            L2_5 = vector4
            L3_5 = L0_5.x
            L4_5 = L0_5.y
            L5_5 = L0_5.z
            L6_5 = L1_5
            L2_5 = L2_5(L3_5, L4_5, L5_5, L6_5)
            L0_4.spawnPoint = L2_5
            L2_5 = TriggerServerEvent
            L3_5 = "nz_garage:saveGarages"
            L4_5 = Config
            L4_5 = L4_5.Garages
            L2_5(L3_5, L4_5)
            L2_5 = ESX
            L2_5 = L2_5.ShowNotification
            L3_5 = "~g~Point de spawn mis \195\160 jour et sauvegard\195\169!"
            L2_5(L3_5)
          end
          L7_4.onSelected = L8_4
          L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
        end
        L1_4 = {}
        L2_4 = "car"
        L3_4 = "boat"
        L4_4 = "aircraft"
        L5_4 = "truck"
        L1_4[1] = L2_4
        L1_4[2] = L3_4
        L1_4[3] = L4_4
        L1_4[4] = L5_4
        L2_4 = RageUI
        L2_4 = L2_4.List
        L3_4 = "Type de garage"
        L4_4 = L1_4
        L5_4 = currentGarageTypeIndex
        if not L5_4 then
          L5_4 = 1
        end
        L6_4 = "S\195\169lectionnez le type de v\195\169hicules accept\195\169s"
        L7_4 = {}
        L8_4 = true
        L9_4 = {}
        function L10_4(A0_5, A1_5)
          currentGarageTypeIndex = A0_5
        end
        L9_4.onListChange = L10_4
        function L10_4(A0_5, A1_5)
          local L2_5, L3_5, L4_5
          L2_5 = Config
          L2_5 = L2_5.Garages
          L3_5 = L3_1.currentGarage
          L2_5 = L2_5[L3_5]
          L3_5 = A1_5.Value
          L2_5.type = L3_5
          L2_5 = TriggerServerEvent
          L3_5 = "nz_garage:saveGarages"
          L4_5 = Config
          L4_5 = L4_5.Garages
          L2_5(L3_5, L4_5)
          L2_5 = CreateGarageBlips
          L2_5()
        end
        L9_4.onSelected = L10_4
        L2_4(L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4)
        L2_4 = RageUI
        L2_4 = L2_4.Checkbox
        L3_4 = "Afficher le blip"
        L4_4 = "Activer ou d\195\169sactiver le blip"
        L5_4 = L0_4.blip
        L5_4 = false ~= L5_4
        L6_4 = {}
        L7_4 = {}
        function L8_4()
          local L0_5, L1_5, L2_5
          L0_5 = L0_4.blip
          if false == L0_5 then
            L0_4.blip = nil
          else
            L0_5 = L0_4.blip
            if not L0_5 then
              L0_5 = {}
            end
            L0_4.blip = L0_5
          end
          L0_5 = TriggerServerEvent
          L1_5 = "nz_garage:saveGarages"
          L2_5 = Config
          L2_5 = L2_5.Garages
          L0_5(L1_5, L2_5)
          L0_5 = CreateGarageBlips
          L0_5()
        end
        L7_4.onChecked = L8_4
        function L8_4()
          local L0_5, L1_5, L2_5
          L0_4.blip = false
          L0_5 = TriggerServerEvent
          L1_5 = "nz_garage:saveGarages"
          L2_5 = Config
          L2_5 = L2_5.Garages
          L0_5(L1_5, L2_5)
          L0_5 = CreateGarageBlips
          L0_5()
        end
        L7_4.onUnChecked = L8_4
        L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
        L2_4 = L0_4.blip
        if false ~= L2_4 then
          L2_4 = RageUI
          L2_4 = L2_4.Button
          L3_4 = "Personnaliser le blip"
          L4_4 = "Options avanc\195\169es du blip"
          L5_4 = {}
          L5_4.RightLabel = ">>>"
          L6_4 = true
          L7_4 = {}
          function L8_4()
            local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5
            L0_5 = Config
            L0_5 = L0_5.Blips
            L0_5 = L0_5.types
            if L0_5 then
              L0_5 = Config
              L0_5 = L0_5.Blips
              L0_5 = L0_5.types
              L1_5 = L0_4.type
              if not L1_5 then
                L1_5 = "car"
              end
              L0_5 = L0_5[L1_5]
              if L0_5 then
                goto lbl_19
              end
            end
            L0_5 = Config
            L0_5 = L0_5.Blips
            L0_5 = L0_5.garage
            ::lbl_19::
            L1_5 = L0_4.blip
            if not L1_5 then
              L1_5 = {}
            end
            L2_5 = RageUI
            L2_5 = L2_5.CreateMenu
            L3_5 = "Personnaliser le blip"
            L4_5 = "Options"
            L2_5 = L2_5(L3_5, L4_5)
            L3_5 = RageUI
            L3_5 = L3_5.Visible
            L4_5 = L15_1
            L5_5 = false
            L3_5(L4_5, L5_5)
            L3_5 = RageUI
            L3_5 = L3_5.Visible
            L4_5 = L2_5
            L5_5 = true
            L3_5(L4_5, L5_5)
            L3_5 = CreateThread
            function L4_5()
              local L0_6, L1_6, L2_6, L3_6
              L0_6 = true
              while L0_6 do
                L1_6 = Wait
                L2_6 = 0
                L1_6(L2_6)
                L1_6 = RageUI
                L1_6 = L1_6.IsVisible
                L2_6 = L2_5
                function L3_6()
                  local L0_7, L1_7, L2_7, L3_7, L4_7, L5_7, L6_7
                  L0_7 = RageUI
                  L0_7 = L0_7.Button
                  L1_7 = "Ic\195\180ne (sprite)"
                  L2_7 = "Changer l'ic\195\180ne du blip"
                  L3_7 = {}
                  L4_7 = tostring
                  L5_7 = L1_5.sprite
                  if not L5_7 then
                    L5_7 = L0_5.sprite
                  end
                  L4_7 = L4_7(L5_7)
                  L3_7.RightLabel = L4_7
                  L4_7 = true
                  L5_7 = {}
                  function L6_7()
                    local L0_8, L1_8, L2_8, L3_8, L4_8
                    L0_8 = L11_1
                    L1_8 = "Sprite du blip"
                    L2_8 = tostring
                    L3_8 = L1_5.sprite
                    if not L3_8 then
                      L3_8 = L0_5.sprite
                    end
                    L2_8 = L2_8(L3_8)
                    L3_8 = 3
                    L0_8 = L0_8(L1_8, L2_8, L3_8)
                    if L0_8 then
                      L1_8 = tonumber
                      L2_8 = L0_8
                      L1_8 = L1_8(L2_8)
                      if L1_8 then
                        L2_8 = L0_4.blip
                        if not L2_8 then
                          L2_8 = {}
                        end
                        L0_4.blip = L2_8
                        L2_8 = L0_4.blip
                        L2_8.sprite = L1_8
                        L2_8 = TriggerServerEvent
                        L3_8 = "nz_garage:saveGarages"
                        L4_8 = Config
                        L4_8 = L4_8.Garages
                        L2_8(L3_8, L4_8)
                        L2_8 = CreateGarageBlips
                        L2_8()
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~g~Sprite du blip mis \195\160 jour"
                        L2_8(L3_8)
                      else
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~r~Valeur invalide!"
                        L2_8(L3_8)
                      end
                    end
                  end
                  L5_7.onSelected = L6_7
                  L0_7(L1_7, L2_7, L3_7, L4_7, L5_7)
                  L0_7 = RageUI
                  L0_7 = L0_7.Button
                  L1_7 = "Couleur"
                  L2_7 = "Changer la couleur du blip"
                  L3_7 = {}
                  L4_7 = tostring
                  L5_7 = L1_5.color
                  if not L5_7 then
                    L5_7 = L0_5.color
                  end
                  L4_7 = L4_7(L5_7)
                  L3_7.RightLabel = L4_7
                  L4_7 = true
                  L5_7 = {}
                  function L6_7()
                    local L0_8, L1_8, L2_8, L3_8, L4_8
                    L0_8 = L11_1
                    L1_8 = "Couleur du blip"
                    L2_8 = tostring
                    L3_8 = L1_5.color
                    if not L3_8 then
                      L3_8 = L0_5.color
                    end
                    L2_8 = L2_8(L3_8)
                    L3_8 = 3
                    L0_8 = L0_8(L1_8, L2_8, L3_8)
                    if L0_8 then
                      L1_8 = tonumber
                      L2_8 = L0_8
                      L1_8 = L1_8(L2_8)
                      if L1_8 then
                        L2_8 = L0_4.blip
                        if not L2_8 then
                          L2_8 = {}
                        end
                        L0_4.blip = L2_8
                        L2_8 = L0_4.blip
                        L2_8.color = L1_8
                        L2_8 = TriggerServerEvent
                        L3_8 = "nz_garage:saveGarages"
                        L4_8 = Config
                        L4_8 = L4_8.Garages
                        L2_8(L3_8, L4_8)
                        L2_8 = CreateGarageBlips
                        L2_8()
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~g~Couleur du blip mise \195\160 jour"
                        L2_8(L3_8)
                      else
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~r~Valeur invalide!"
                        L2_8(L3_8)
                      end
                    end
                  end
                  L5_7.onSelected = L6_7
                  L0_7(L1_7, L2_7, L3_7, L4_7, L5_7)
                  L0_7 = RageUI
                  L0_7 = L0_7.Button
                  L1_7 = "Taille"
                  L2_7 = "Changer la taille du blip"
                  L3_7 = {}
                  L4_7 = tostring
                  L5_7 = L1_5.scale
                  if not L5_7 then
                    L5_7 = L0_5.scale
                  end
                  L4_7 = L4_7(L5_7)
                  L3_7.RightLabel = L4_7
                  L4_7 = true
                  L5_7 = {}
                  function L6_7()
                    local L0_8, L1_8, L2_8, L3_8, L4_8
                    L0_8 = L11_1
                    L1_8 = "Taille du blip"
                    L2_8 = tostring
                    L3_8 = L1_5.scale
                    if not L3_8 then
                      L3_8 = L0_5.scale
                    end
                    L2_8 = L2_8(L3_8)
                    L3_8 = 3
                    L0_8 = L0_8(L1_8, L2_8, L3_8)
                    if L0_8 then
                      L1_8 = tonumber
                      L2_8 = L0_8
                      L1_8 = L1_8(L2_8)
                      if L1_8 then
                        L2_8 = L0_4.blip
                        if not L2_8 then
                          L2_8 = {}
                        end
                        L0_4.blip = L2_8
                        L2_8 = L0_4.blip
                        L2_8.scale = L1_8
                        L2_8 = TriggerServerEvent
                        L3_8 = "nz_garage:saveGarages"
                        L4_8 = Config
                        L4_8 = L4_8.Garages
                        L2_8(L3_8, L4_8)
                        L2_8 = CreateGarageBlips
                        L2_8()
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~g~Taille du blip mise \195\160 jour"
                        L2_8(L3_8)
                      else
                        L2_8 = ESX
                        L2_8 = L2_8.ShowNotification
                        L3_8 = "~r~Valeur invalide!"
                        L2_8(L3_8)
                      end
                    end
                  end
                  L5_7.onSelected = L6_7
                  L0_7(L1_7, L2_7, L3_7, L4_7, L5_7)
                  L0_7 = RageUI
                  L0_7 = L0_7.Button
                  L1_7 = "Nom"
                  L2_7 = "Changer le texte affich\195\169 du blip"
                  L3_7 = {}
                  L4_7 = tostring
                  L5_7 = L0_4.blip
                  if L5_7 then
                    L5_7 = L0_4.blip
                    L5_7 = L5_7.name
                    if L5_7 then
                      goto lbl_73
                    end
                  end
                  L5_7 = L0_5.name
                  ::lbl_73::
                  L4_7 = L4_7(L5_7)
                  L3_7.RightLabel = L4_7
                  L4_7 = true
                  L5_7 = {}
                  function L6_7()
                    local L0_8, L1_8, L2_8, L3_8
                    L0_8 = L11_1
                    L1_8 = "Nom du blip"
                    L2_8 = tostring
                    L3_8 = L0_4.blip
                    if L3_8 then
                      L3_8 = L0_4.blip
                      L3_8 = L3_8.name
                      if L3_8 then
                        goto lbl_12
                      end
                    end
                    L3_8 = L0_5.name
                    ::lbl_12::
                    L2_8 = L2_8(L3_8)
                    L3_8 = 40
                    L0_8 = L0_8(L1_8, L2_8, L3_8)
                    if L0_8 and "" ~= L0_8 then
                      L1_8 = L0_4.blip
                      if not L1_8 then
                        L1_8 = {}
                      end
                      L0_4.blip = L1_8
                      L1_8 = L0_4.blip
                      L1_8.name = L0_8
                      L1_8 = TriggerServerEvent
                      L2_8 = "nz_garage:saveGarages"
                      L3_8 = Config
                      L3_8 = L3_8.Garages
                      L1_8(L2_8, L3_8)
                      L1_8 = CreateGarageBlips
                      L1_8()
                      L1_8 = ESX
                      L1_8 = L1_8.ShowNotification
                      L2_8 = "~g~Nom du blip mis \195\160 jour"
                      L1_8(L2_8)
                    end
                  end
                  L5_7.onSelected = L6_7
                  L0_7(L1_7, L2_7, L3_7, L4_7, L5_7)
                  L0_7 = RageUI
                  L0_7 = L0_7.Visible
                  L1_7 = L2_5
                  L0_7 = L0_7(L1_7)
                  if not L0_7 then
                    L0_7 = RageUI
                    L0_7 = L0_7.Visible
                    L1_7 = L15_1
                    L2_7 = true
                    L0_7(L1_7, L2_7)
                    L0_7 = false
                    L0_6 = L0_7
                  end
                end
                L1_6(L2_6, L3_6)
              end
            end
            L3_5(L4_5)
          end
          L7_4.onSelected = L8_4
          L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
        end
        L2_4 = RageUI
        L2_4 = L2_4.Button
        L3_4 = "Supprimer"
        L4_4 = "Supprimer ce garage"
        L5_4 = {}
        L5_4.RightLabel = "~r~XXX"
        L6_4 = true
        L7_4 = {}
        function L8_4()
          local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5, L6_5
          function L0_5()
            local L0_6, L1_6, L2_6
            L0_6 = Config
            L0_6 = L0_6.Garages
            L1_6 = L3_1.currentGarage
            L0_6[L1_6] = nil
            L0_6 = TriggerServerEvent
            L1_6 = "nz_garage:saveGarages"
            L2_6 = Config
            L2_6 = L2_6.Garages
            L0_6(L1_6, L2_6)
            L0_6 = ESX
            L0_6 = L0_6.ShowNotification
            L1_6 = "~r~Garage supprim\195\169!"
            L0_6(L1_6)
            L3_1.currentGarage = nil
            L0_6 = L1_2
            L0_6()
            L0_6 = RageUI
            L0_6 = L0_6.Visible
            L1_6 = L15_1
            L2_6 = false
            L0_6(L1_6, L2_6)
            L0_6 = RageUI
            L0_6 = L0_6.Visible
            L1_6 = L14_1
            L2_6 = true
            L0_6(L1_6, L2_6)
          end
          L1_5 = exports
          if L1_5 then
            L1_5 = exports
            L1_5 = L1_5.fb_ui
            if L1_5 then
              L1_5 = exports
              L1_5 = L1_5.fb_ui
              L1_5 = L1_5.displayRequest
              if L1_5 then
                L1_5 = exports
                L1_5 = L1_5.fb_ui
                L2_5 = L1_5
                L1_5 = L1_5.displayRequest
                L3_5 = "Supprimer le garage"
                L4_5 = "\195\138tes-vous s\195\187r de vouloir supprimer ce garage ?"
                L5_5 = L0_5
                function L6_5()
                  local L0_6, L1_6
                end
                L1_5(L2_5, L3_5, L4_5, L5_5, L6_5)
            end
          end
          else
            L1_5 = L0_5
            L1_5()
          end
        end
        L7_4.onSelected = L8_4
        L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
      end
      L0_3(L1_3, L2_3)
      L0_3 = RageUI
      L0_3 = L0_3.IsVisible
      L1_3 = L16_1
      function L2_3()
        local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
        L0_4 = garageTypeIndex
        if not L0_4 then
          L0_4 = L8_1
          L1_4 = L3_1.garageType
          if not L1_4 then
            L1_4 = "car"
          end
          L0_4 = L0_4(L1_4)
          garageTypeIndex = L0_4
        end
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Nom du garage"
        L2_4 = nil
        L3_4 = {}
        L4_4 = L3_1.newGarageName
        if not L4_4 then
          L4_4 = " "
        end
        L3_4.RightLabel = L4_4
        L4_4 = true
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5, L2_5, L3_5
          L0_5 = L11_1
          L1_5 = "Identifiant du garage"
          L2_5 = ""
          L3_5 = 50
          L0_5 = L0_5(L1_5, L2_5, L3_5)
          if L0_5 and "" ~= L0_5 then
            L3_1.newGarageName = L0_5
          end
        end
        L5_4.onSelected = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Nom affich\195\169"
        L2_4 = nil
        L3_4 = {}
        L4_4 = L3_1.newGarageLabel
        if not L4_4 then
          L4_4 = " "
        end
        L3_4.RightLabel = L4_4
        L4_4 = true
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5, L2_5, L3_5
          L0_5 = L11_1
          L1_5 = "Nom affich\195\169"
          L2_5 = ""
          L3_5 = 50
          L0_5 = L0_5(L1_5, L2_5, L3_5)
          if L0_5 and "" ~= L0_5 then
            L3_1.newGarageLabel = L0_5
          end
        end
        L5_4.onSelected = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Point d'entr\195\169e"
        L2_4 = nil
        L3_4 = {}
        L4_4 = L3_1.tempPoints
        if L4_4 then
          L4_4 = L3_1.tempPoints
          L4_4 = L4_4.enter
          if L4_4 then
            L4_4 = L6_1
            L5_4 = L3_1.tempPoints
            L5_4 = L5_4.enter
            L4_4 = L4_4(L5_4)
            if L4_4 then
              goto lbl_65
            end
          end
        end
        L4_4 = "~r~non d\195\169fini"
        ::lbl_65::
        L3_4.RightLabel = L4_4
        L4_4 = true
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5
          L0_5 = GetEntityCoords
          L1_5 = PlayerPedId
          L1_5 = L1_5()
          L0_5 = L0_5(L1_5)
          L1_5 = L3_1.tempPoints
          if not L1_5 then
            L1_5 = {}
          end
          L3_1.tempPoints = L1_5
          L1_5 = L3_1.tempPoints
          L1_5.enter = L0_5
        end
        L5_4.onSelected = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Point de rangement"
        L2_4 = nil
        L3_4 = {}
        L4_4 = L3_1.tempPoints
        if L4_4 then
          L4_4 = L3_1.tempPoints
          L4_4 = L4_4.store
          if L4_4 then
            L4_4 = L6_1
            L5_4 = L3_1.tempPoints
            L5_4 = L5_4.store
            L4_4 = L4_4(L5_4)
            if L4_4 then
              goto lbl_92
            end
          end
        end
        L4_4 = "~r~non d\195\169fini"
        ::lbl_92::
        L3_4.RightLabel = L4_4
        L4_4 = true
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5
          L0_5 = GetEntityCoords
          L1_5 = PlayerPedId
          L1_5 = L1_5()
          L0_5 = L0_5(L1_5)
          L1_5 = L3_1.tempPoints
          if not L1_5 then
            L1_5 = {}
          end
          L3_1.tempPoints = L1_5
          L1_5 = L3_1.tempPoints
          L1_5.store = L0_5
        end
        L5_4.onSelected = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = RageUI
        L0_4 = L0_4.Button
        L1_4 = "Point de spawn"
        L2_4 = nil
        L3_4 = {}
        L4_4 = L3_1.tempPoints
        if L4_4 then
          L4_4 = L3_1.tempPoints
          L4_4 = L4_4.spawn
          if L4_4 then
            L4_4 = L7_1
            L5_4 = vector4
            L6_4 = L3_1.tempPoints
            L6_4 = L6_4.spawn
            L6_4 = L6_4.pos
            L6_4 = L6_4.x
            L7_4 = L3_1.tempPoints
            L7_4 = L7_4.spawn
            L7_4 = L7_4.pos
            L7_4 = L7_4.y
            L8_4 = L3_1.tempPoints
            L8_4 = L8_4.spawn
            L8_4 = L8_4.pos
            L8_4 = L8_4.z
            L9_4 = L3_1.tempPoints
            L9_4 = L9_4.spawn
            L9_4 = L9_4.heading
            L5_4, L6_4, L7_4, L8_4, L9_4 = L5_4(L6_4, L7_4, L8_4, L9_4)
            L4_4 = L4_4(L5_4, L6_4, L7_4, L8_4, L9_4)
            if L4_4 then
              goto lbl_134
            end
          end
        end
        L4_4 = "~r~non d\195\169fini"
        ::lbl_134::
        L3_4.RightLabel = L4_4
        L4_4 = true
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5, L2_5, L3_5
          L0_5 = GetEntityCoords
          L1_5 = PlayerPedId
          L1_5, L2_5, L3_5 = L1_5()
          L0_5 = L0_5(L1_5, L2_5, L3_5)
          L1_5 = GetEntityHeading
          L2_5 = PlayerPedId
          L2_5, L3_5 = L2_5()
          L1_5 = L1_5(L2_5, L3_5)
          L2_5 = L3_1.tempPoints
          if not L2_5 then
            L2_5 = {}
          end
          L3_1.tempPoints = L2_5
          L2_5 = L3_1.tempPoints
          L3_5 = {}
          L3_5.pos = L0_5
          L3_5.heading = L1_5
          L2_5.spawn = L3_5
        end
        L5_4.onSelected = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = RageUI
        L0_4 = L0_4.List
        L1_4 = "Type de garage"
        L2_4 = {}
        L3_4 = "car"
        L4_4 = "boat"
        L5_4 = "aircraft"
        L6_4 = "truck"
        L2_4[1] = L3_4
        L2_4[2] = L4_4
        L2_4[3] = L5_4
        L2_4[4] = L6_4
        L3_4 = garageTypeIndex
        if not L3_4 then
          L3_4 = 1
        end
        L4_4 = "Type de v\195\169hicules accept\195\169s"
        L5_4 = {}
        L6_4 = true
        L7_4 = {}
        function L8_4(A0_5, A1_5)
          garageTypeIndex = A0_5
        end
        L7_4.onListChange = L8_4
        function L8_4(A0_5, A1_5)
          local L2_5
          L2_5 = A1_5.Value
          L3_1.garageType = L2_5
        end
        L7_4.onSelected = L8_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
        L0_4 = RageUI
        L0_4 = L0_4.Checkbox
        L1_4 = "Afficher le blip"
        L2_4 = "Activer ou d\195\169sactiver le blip pour ce garage"
        L3_4 = L3_1.useBlip
        L3_4 = false ~= L3_4
        L4_4 = {}
        L5_4 = {}
        function L6_4()
          local L0_5, L1_5
          L3_1.useBlip = true
          L0_5 = ESX
          L0_5 = L0_5.ShowNotification
          L1_5 = "~g~Le blip sera activ\195\169"
          L0_5(L1_5)
        end
        L5_4.onChecked = L6_4
        function L6_4()
          local L0_5, L1_5
          L3_1.useBlip = false
          L0_5 = ESX
          L0_5 = L0_5.ShowNotification
          L1_5 = "~r~Le blip sera d\195\169sactiv\195\169"
          L0_5(L1_5)
        end
        L5_4.onUnChecked = L6_4
        L0_4(L1_4, L2_4, L3_4, L4_4, L5_4)
        L0_4 = L3_1.newGarageName
        if L0_4 then
          L0_4 = L3_1.newGarageLabel
          if L0_4 then
            L0_4 = L3_1.tempPoints
            if L0_4 then
              L0_4 = L3_1.tempPoints
              L0_4 = L0_4.enter
              if L0_4 then
                L0_4 = L3_1.tempPoints
                L0_4 = L0_4.store
                if L0_4 then
                  L0_4 = L3_1.tempPoints
                  L0_4 = L0_4.spawn
                end
              end
            end
          end
        end
        L1_4 = RageUI
        L1_4 = L1_4.Button
        L2_4 = "Cr\195\169er"
        L3_4 = nil
        L4_4 = {}
        if L0_4 then
          L5_4 = ">>>"
          if L5_4 then
            goto lbl_215
          end
        end
        L5_4 = "~r~INCOMPLET"
        ::lbl_215::
        L4_4.RightLabel = L5_4
        L5_4 = L0_4
        L6_4 = {}
        function L7_4()
          local L0_5, L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5
          L0_5 = L3_1.newGarageName
          L1_5 = L3_1.newGarageLabel
          L2_5 = Config
          L2_5 = L2_5.Garages
          L3_5 = {}
          L3_5.name = L1_5
          L4_5 = {}
          L5_5 = {}
          L6_5 = L3_1.tempPoints
          L6_5 = L6_5.enter
          L5_5.pos = L6_5
          L5_5.type = "enter"
          L4_5.enter = L5_5
          L5_5 = {}
          L6_5 = L3_1.tempPoints
          L6_5 = L6_5.store
          L5_5.pos = L6_5
          L5_5.type = "store"
          L4_5.store = L5_5
          L3_5.points = L4_5
          L4_5 = vector4
          L5_5 = L3_1.tempPoints
          L5_5 = L5_5.spawn
          L5_5 = L5_5.pos
          L5_5 = L5_5.x
          L6_5 = L3_1.tempPoints
          L6_5 = L6_5.spawn
          L6_5 = L6_5.pos
          L6_5 = L6_5.y
          L7_5 = L3_1.tempPoints
          L7_5 = L7_5.spawn
          L7_5 = L7_5.pos
          L7_5 = L7_5.z
          L8_5 = L3_1.tempPoints
          L8_5 = L8_5.spawn
          L8_5 = L8_5.heading
          L4_5 = L4_5(L5_5, L6_5, L7_5, L8_5)
          L3_5.spawnPoint = L4_5
          L4_5 = L3_1.garageType
          if not L4_5 then
            L4_5 = "car"
          end
          L3_5.type = L4_5
          L4_5 = L3_1.useBlip
          if false == L4_5 then
          end
          L3_5.blip = nil
          L2_5[L0_5] = L3_5
          L2_5 = TriggerServerEvent
          L3_5 = "nz_garage:saveGarages"
          L4_5 = Config
          L4_5 = L4_5.Garages
          L2_5(L3_5, L4_5)
          L2_5 = ESX
          L2_5 = L2_5.ShowNotification
          L3_5 = "~g~Garage cr\195\169\195\169 avec succ\195\168s !"
          L2_5(L3_5)
          L2_5 = CreateGarageBlips
          L2_5()
          L3_1.newGarageName = nil
          L3_1.newGarageLabel = nil
          L3_1.tempPoints = nil
          L3_1.garageType = "car"
          L3_1.useBlip = true
          L2_5 = Wait
          L3_5 = 200
          L2_5(L3_5)
          L2_5 = L1_2
          L2_5()
          L2_5 = RageUI
          L2_5 = L2_5.Visible
          L3_5 = L16_1
          L4_5 = false
          L2_5(L3_5, L4_5)
          L2_5 = RageUI
          L2_5 = L2_5.Visible
          L3_5 = L14_1
          L4_5 = true
          L2_5(L3_5, L4_5)
        end
        L6_4.onSelected = L7_4
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4)
      end
      L0_3(L1_3, L2_3)
      L0_3 = RageUI
      L0_3 = L0_3.Visible
      L1_3 = L13_1
      L0_3 = L0_3(L1_3)
      if not L0_3 then
        L0_3 = RageUI
        L0_3 = L0_3.Visible
        L1_3 = L14_1
        L0_3 = L0_3(L1_3)
        if not L0_3 then
          L0_3 = RageUI
          L0_3 = L0_3.Visible
          L1_3 = L15_1
          L0_3 = L0_3(L1_3)
          if not L0_3 then
            L0_3 = RageUI
            L0_3 = L0_3.Visible
            L1_3 = L16_1
            L0_3 = L0_3(L1_3)
            if not L0_3 then
              L3_1.isOpen = false
              L0_3 = 1
              L1_3 = L3_1.tempMarkers
              L1_3 = #L1_3
              L2_3 = 1
              for L3_3 = L0_3, L1_3, L2_3 do
                L4_3 = L3_1.tempMarkers
                L4_3 = L4_3[L3_3]
                L4_3.active = false
              end
              L0_3 = {}
              L3_1.tempMarkers = L0_3
              currentGarageTypeIndex = nil
              garageTypeIndex = nil
            end
          end
        end
      end
    end
  end
  L2_2(L3_2)
end
OpenGarageBuilder = L17_1
function L17_1()
  local L0_2, L1_2
end
CreateGarageMarkers = L17_1
function L17_1()
  local L0_2, L1_2
end
CreateImpoundMarkers = L17_1
function L17_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = 1
  L1_2 = L3_1.tempMarkers
  L1_2 = #L1_2
  L2_2 = 1
  for L3_2 = L0_2, L1_2, L2_2 do
    L4_2 = L3_1.tempMarkers
    L4_2 = L4_2[L3_2]
    L4_2.active = false
  end
  L0_2 = {}
  L3_1.tempMarkers = L0_2
end
CleanupTempMarkers = L17_1
