local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = MySQL
L0_1 = L0_1.ready
function L1_1()
  local L0_2, L1_2
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = " DROP TABLE IF EXISTS `garage_vehicles` "
  L0_2(L1_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = [[
 
    CREATE TABLE IF NOT EXISTS `garage_config` (
      `name` VARCHAR(50) NOT NULL,
      `data` LONGTEXT NOT NULL,
      PRIMARY KEY (`name`)
    )
  ]]
  L0_2(L1_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = [[
    ALTER TABLE `owned_vehicles` 
    ADD COLUMN IF NOT EXISTS `garage_name` VARCHAR(60) DEFAULT 'central' AFTER `stored`,
    ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER `garage_name`
  ]]
  L0_2(L1_2)
end
L0_1(L1_1)
function L0_1(A0_2)
  local L1_2, L2_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if "number" == L1_2 then
    return A0_2
  end
  L1_2 = tonumber
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    L1_2 = A0_2
  end
  return L1_2
end
GetVehicleModelFromHash = L0_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  if not A0_2 then
    L1_2 = "V\195\169hicule inconnu"
    return L1_2
  end
  L1_2 = tostring
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2
  L1_2 = L1_2.lower
  L1_2 = L1_2(L2_2)
  L2_2 = {}
  L2_2.adder = "Adder"
  L2_2.t20 = "T20"
  L2_2.zentorno = "Zentorno"
  L3_2 = L2_2[L1_2]
  if not L3_2 then
    L3_2 = "V\195\169hicule"
  end
  return L3_2
end
GetVehicleNameByHash = L1_1
L2_1 = ESX
L2_1 = L2_1.RegisterServerCallback
L3_1 = "nz_garage:getVehicles"
function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = {}
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = [[
 
    SELECT ov.plate as id, ov.owner, ov.plate, ov.vehicle, CAST(ov.`stored` AS UNSIGNED) as is_stored, 
           COALESCE(ov.garage_name, 'central') as garage_name,
           u.firstname, u.lastname, 'personal' as vehicle_type
    FROM owned_vehicles ov
    LEFT JOIN users u ON CAST(ov.owner AS CHAR CHARACTER SET utf8mb4) = CAST(u.identifier AS CHAR CHARACTER SET utf8mb4)
    WHERE ov.owner = ?
  ]]
  L6_2 = {}
  L7_2 = L2_2.identifier
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = pairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = table
        L7_3 = L7_3.insert
        L8_3 = L3_2
        L9_3 = L6_3
        L7_3(L8_3, L9_3)
      end
    end
    L1_3 = Config
    L1_3 = L1_3.Organizations
    if L1_3 then
      L1_3 = Config
      L1_3 = L1_3.Organizations
      L1_3 = L1_3.enabled
      if L1_3 then
        L1_3 = Config
        L1_3 = L1_3.Organizations
        L1_3 = L1_3.jobs
        if L1_3 then
          L1_3 = Config
          L1_3 = L1_3.Organizations
          L1_3 = L1_3.jobs
          L1_3 = L1_3.enabled
          if L1_3 then
            L1_3 = Config
            L1_3 = L1_3.Organizations
            L1_3 = L1_3.jobs
            L1_3 = L1_3.id_field
            if not L1_3 then
              L1_3 = "plate"
            end
            L2_3 = string
            L2_3 = L2_3.format
            L3_3 = [[
 
        SELECT %s as id, %s as owner, plate, vehicle, CAST(`stored` AS UNSIGNED) as is_stored, 
               COALESCE(garage_name, 'central') as garage_name,
               '%s' as firstname, 'Entreprise' as lastname, 'job' as vehicle_type
        FROM %s WHERE %s = ?
      ]]
            L4_3 = L1_3
            L5_3 = Config
            L5_3 = L5_3.Organizations
            L5_3 = L5_3.jobs
            L5_3 = L5_3.identifier_field
            L6_3 = L2_2.job
            L6_3 = L6_3.label
            L7_3 = Config
            L7_3 = L7_3.Organizations
            L7_3 = L7_3.jobs
            L7_3 = L7_3.ownership_table
            L8_3 = Config
            L8_3 = L8_3.Organizations
            L8_3 = L8_3.jobs
            L8_3 = L8_3.job_field
            L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
            L3_3 = MySQL
            L3_3 = L3_3.query
            L4_3 = L2_3
            L5_3 = {}
            L6_3 = L2_2.job
            L6_3 = L6_3.name
            L5_3[1] = L6_3
            function L6_3(A0_4)
              local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
              if A0_4 then
                L1_4 = #A0_4
                if L1_4 > 0 then
                  L1_4 = pairs
                  L2_4 = A0_4
                  L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
                  for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
                    L7_4 = table
                    L7_4 = L7_4.insert
                    L8_4 = L3_2
                    L9_4 = L6_4
                    L7_4(L8_4, L9_4)
                  end
                end
              end
              L1_4 = Config
              L1_4 = L1_4.Organizations
              if L1_4 then
                L1_4 = Config
                L1_4 = L1_4.Organizations
                L1_4 = L1_4.gangs
                if L1_4 then
                  L1_4 = Config
                  L1_4 = L1_4.Organizations
                  L1_4 = L1_4.gangs
                  L1_4 = L1_4.enabled
                  if L1_4 then
                    L1_4 = Config
                    L1_4 = L1_4.Organizations
                    L1_4 = L1_4.gangs
                    L1_4 = L1_4.id_field
                    if not L1_4 then
                      L1_4 = "plate"
                    end
                    L2_4 = L2_2.gang
                    if L2_4 then
                      L2_4 = L2_2.gang
                      L2_4 = L2_4.name
                      if L2_4 then
                        goto lbl_48
                      end
                    end
                    L2_4 = nil
                    ::lbl_48::
                    if L2_4 and "nogang" ~= L2_4 then
                      L3_4 = string
                      L3_4 = L3_4.format
                      L4_4 = [[
 
              SELECT %s as id, %s as owner, plate, vehicle, CAST(`stored` AS UNSIGNED) as is_stored, 
                     COALESCE(garage_name, 'central') as garage_name,
                     '%s' as firstname, 'Organisation' as lastname, 'gang' as vehicle_type
              FROM %s WHERE %s = ?
            ]]
                      L5_4 = L1_4
                      L6_4 = Config
                      L6_4 = L6_4.Organizations
                      L6_4 = L6_4.gangs
                      L6_4 = L6_4.identifier_field
                      L7_4 = L2_4
                      L8_4 = Config
                      L8_4 = L8_4.Organizations
                      L8_4 = L8_4.gangs
                      L8_4 = L8_4.ownership_table
                      L9_4 = Config
                      L9_4 = L9_4.Organizations
                      L9_4 = L9_4.gangs
                      L9_4 = L9_4.gang_field
                      L3_4 = L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4)
                      L4_4 = MySQL
                      L4_4 = L4_4.query
                      L5_4 = L3_4
                      L6_4 = {}
                      L7_4 = L2_4
                      L6_4[1] = L7_4
                      function L7_4(A0_5)
                        local L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5
                        if A0_5 then
                          L1_5 = #A0_5
                          if L1_5 > 0 then
                            L1_5 = pairs
                            L2_5 = A0_5
                            L1_5, L2_5, L3_5, L4_5 = L1_5(L2_5)
                            for L5_5, L6_5 in L1_5, L2_5, L3_5, L4_5 do
                              L7_5 = table
                              L7_5 = L7_5.insert
                              L8_5 = L3_2
                              L9_5 = L6_5
                              L7_5(L8_5, L9_5)
                            end
                          end
                        end
                        L1_5 = A1_2
                        L2_5 = L3_2
                        L1_5(L2_5)
                      end
                      L4_4(L5_4, L6_4, L7_4)
                    else
                      L3_4 = A1_2
                      L4_4 = L3_2
                      L3_4(L4_4)
                    end
                end
              end
              else
                L1_4 = A1_2
                L2_4 = L3_2
                L1_4(L2_4)
              end
            end
            L3_3(L4_3, L5_3, L6_3)
        end
      end
    end
    else
      L1_3 = A1_2
      L2_3 = L3_2
      L1_3(L2_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L2_1(L3_1, L4_1)
L2_1 = ESX
L2_1 = L2_1.RegisterServerCallback
L3_1 = "nz_garage:checkVehicleOwner"
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = ESX
  L3_2 = L3_2.GetPlayerFromId
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT 1 FROM owned_vehicles WHERE plate = ? AND owner = ?"
  L6_2 = {}
  L7_2 = A2_2
  L8_2 = L3_2.identifier
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  function L7_2(A0_3)
    local L1_3, L2_3
    L1_3 = A1_2
    L2_3 = A0_3 or L2_3
    if A0_3 then
      L2_3 = #A0_3
      L2_3 = L2_3 > 0
    end
    L1_3(L2_3)
  end
  L4_2(L5_2, L6_2, L7_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:storeVehicle"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:storeVehicle"
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = source
  L4_2 = ESX
  L4_2 = L4_2.GetPlayerFromId
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT owner FROM owned_vehicles WHERE plate = ?"
  L7_2 = {}
  L8_2 = A1_2
  L7_2[1] = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L1_3 = L1_3.owner
        L2_3 = L4_2.identifier
        if L1_3 == L2_3 then
          L1_3 = MySQL
          L1_3 = L1_3.update
          L2_3 = "UPDATE owned_vehicles SET `stored` = 1, vehicle = ?, garage_name = ? WHERE plate = ? AND owner = ?"
          L3_3 = {}
          L4_3 = json
          L4_3 = L4_3.encode
          L5_3 = A0_2
          L4_3 = L4_3(L5_3)
          L5_3 = A2_2
          L6_3 = A1_2
          L7_3 = L4_2.identifier
          L3_3[1] = L4_3
          L3_3[2] = L5_3
          L3_3[3] = L6_3
          L3_3[4] = L7_3
          L1_3(L2_3, L3_3)
        else
          L1_3 = TriggerClientEvent
          L2_3 = "esx:showNotification"
          L3_3 = L3_2
          L4_3 = "~r~Vous n'\195\170tes pas propri\195\169taire de ce v\195\169hicule"
          L1_3(L2_3, L3_3, L4_3)
        end
    end
    else
      L1_3 = TriggerClientEvent
      L2_3 = "esx:showNotification"
      L3_3 = L3_2
      L4_3 = "~r~Ce v\195\169hicule n'existe pas dans la base de donn\195\169es"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L5_2(L6_2, L7_2, L8_2)
end
L2_1(L3_1, L4_1)
L2_1 = ESX
L2_1 = L2_1.RegisterServerCallback
L3_1 = "nz_garage:canStoreVehicle"
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = ESX
  L3_2 = L3_2.GetPlayerFromId
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = MySQL
  L4_2 = L4_2.query
  L5_2 = "SELECT owner FROM owned_vehicles WHERE plate = ?"
  L6_2 = {}
  L7_2 = A2_2
  L6_2[1] = L7_2
  function L7_2(A0_3)
    local L1_3, L2_3, L3_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A1_2
        L2_3 = A0_3[1]
        L2_3 = L2_3.owner
        L3_3 = L3_2.identifier
        L2_3 = L2_3 == L3_3
        L1_3(L2_3)
    end
    else
      L1_3 = A1_2
      L2_3 = false
      L1_3(L2_3)
    end
  end
  L4_2(L5_2, L6_2, L7_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:server:spawnVehicle"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM owned_vehicles WHERE plate = ? AND owner = ?"
  L5_2 = {}
  L6_2 = A0_2
  L7_2 = L2_2.identifier
  L5_2[1] = L6_2
  L5_2[2] = L7_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = MySQL
        L1_3 = L1_3.update
        L2_3 = "UPDATE owned_vehicles SET `stored` = 0 WHERE plate = ?"
        L3_3 = {}
        L4_3 = A0_2
        L3_3[1] = L4_3
        L1_3(L2_3, L3_3)
        L1_3 = json
        L1_3 = L1_3.decode
        L2_3 = A0_3[1]
        L2_3 = L2_3.vehicle
        L1_3 = L1_3(L2_3)
        L2_3 = TriggerClientEvent
        L3_3 = "nz_garage:client:spawnVehicle"
        L4_3 = L1_2
        L5_3 = L1_3
        L2_3(L3_3, L4_3, L5_3)
    end
    else
      L1_3 = TriggerClientEvent
      L2_3 = "esx:showNotification"
      L3_3 = L1_2
      L4_3 = "~r~V\195\169hicule non trouv\195\169"
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L3_2(L4_2, L5_2, L6_2)
end
L2_1(L3_1, L4_1)
L2_1 = ESX
L2_1 = L2_1.RegisterServerCallback
L3_1 = "nz_garage:getImpoundedVehicles"
function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = [[
 
    SELECT * FROM owned_vehicles 
    WHERE owner = ? AND `stored` = 0 AND (garage_name IS NULL OR garage_name = '')
  ]]
  L5_2 = {}
  L6_2 = L2_2.identifier
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3
    L1_3 = A1_2
    L2_3 = A0_3 or L2_3
    if not A0_3 then
      L2_3 = {}
    end
    L1_3(L2_3)
  end
  L3_2(L4_2, L5_2, L6_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:retrieveImpoundedVehicle"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:retrieveImpoundedVehicle"
function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = source
  L3_2 = ESX
  L3_2 = L3_2.GetPlayerFromId
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.getMoney
  L4_2 = L4_2()
  if A1_2 <= L4_2 then
    L4_2 = MySQL
    L4_2 = L4_2.query
    L5_2 = "SELECT * FROM owned_vehicles WHERE plate = ? AND owner = ? AND `stored` = 0 AND (garage_name IS NULL OR garage_name = '')"
    L6_2 = {}
    L7_2 = A0_2
    L8_2 = L3_2.identifier
    L6_2[1] = L7_2
    L6_2[2] = L8_2
    function L7_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
      if A0_3 then
        L1_3 = #A0_3
        if L1_3 > 0 then
          L1_3 = L3_2.removeMoney
          L2_3 = A1_2
          L1_3(L2_3)
          L1_3 = MySQL
          L1_3 = L1_3.update
          L2_3 = "UPDATE owned_vehicles SET `stored` = 1, garage_name = 'central' WHERE plate = ? AND owner = ?"
          L3_3 = {}
          L4_3 = A0_2
          L5_3 = L3_2.identifier
          L3_3[1] = L4_3
          L3_3[2] = L5_3
          L1_3(L2_3, L3_3)
          L1_3 = json
          L1_3 = L1_3.decode
          L2_3 = A0_3[1]
          L2_3 = L2_3.vehicle
          L1_3 = L1_3(L2_3)
          L2_3 = TriggerClientEvent
          L3_3 = "nz_garage:spawnImpoundedVehicle"
          L4_3 = L2_2
          L5_3 = L1_3
          L6_3 = Config
          L6_3 = L6_3.Impound
          L6_3 = L6_3.locations
          L6_3 = L6_3.main
          L6_3 = L6_3.spawnPoint
          L2_3(L3_3, L4_3, L5_3, L6_3)
          L2_3 = TriggerClientEvent
          L3_3 = "esx:showNotification"
          L4_3 = L2_2
          L5_3 = Config
          L5_3 = L5_3.Notifications
          L5_3 = L5_3.impound
          L5_3 = L5_3.success
          L2_3(L3_3, L4_3, L5_3)
      end
      else
        L1_3 = TriggerClientEvent
        L2_3 = "esx:showNotification"
        L3_3 = L2_2
        L4_3 = "~r~Ce v\195\169hicule n'est plus en fourri\195\168re"
        L1_3(L2_3, L3_3, L4_3)
      end
    end
    L4_2(L5_2, L6_2, L7_2)
  else
    L4_2 = TriggerClientEvent
    L5_2 = "esx:showNotification"
    L6_2 = L2_2
    L7_2 = Config
    L7_2 = L7_2.Notifications
    L7_2 = L7_2.impound
    L7_2 = L7_2.notEnoughMoney
    L4_2(L5_2, L6_2, L7_2)
  end
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:impoundVehicle"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:impoundVehicle"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2.getGroup
  L3_2 = L3_2()
  if "admin" ~= L3_2 then
    L3_2 = L2_2.getGroup
    L3_2 = L3_2()
    if "superadmin" ~= L3_2 then
      L3_2 = L2_2.job
      L3_2 = L3_2.name
      if "police" ~= L3_2 then
        goto lbl_28
      end
    end
  end
  L3_2 = MySQL
  L3_2 = L3_2.query
  L4_2 = "SELECT * FROM owned_vehicles WHERE plate = ?"
  L5_2 = {}
  L6_2 = A0_2
  L5_2[1] = L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = MySQL
        L1_3 = L1_3.update
        L2_3 = "UPDATE owned_vehicles SET `stored` = 0, garage_name = NULL WHERE plate = ?"
        L3_3 = {}
        L4_3 = A0_2
        L3_3[1] = L4_3
        L1_3(L2_3, L3_3)
        L1_3 = TriggerClientEvent
        L2_3 = "esx:showNotification"
        L3_3 = L1_2
        L4_3 = "~g~V\195\169hicule mis en fourri\195\168re: "
        L5_3 = A0_2
        L4_3 = L4_3 .. L5_3
        L1_3(L2_3, L3_3, L4_3)
        L1_3 = A0_3[1]
        L1_3 = L1_3.owner
        L2_3 = ESX
        L2_3 = L2_3.GetPlayerFromIdentifier
        L3_3 = L1_3
        L2_3 = L2_3(L3_3)
        if L2_3 then
          L3_3 = TriggerClientEvent
          L4_3 = "esx:showNotification"
          L5_3 = L2_3.source
          L6_3 = "~r~Votre v\195\169hicule "
          L7_3 = A0_2
          L8_3 = " a \195\169t\195\169 mis en fourri\195\168re"
          L6_3 = L6_3 .. L7_3 .. L8_3
          L3_3(L4_3, L5_3, L6_3)
        end
    end
    else
      L1_3 = L2_2.getGroup
      L1_3 = L1_3()
      if "admin" ~= L1_3 then
        L1_3 = L2_2.getGroup
        L1_3 = L1_3()
        if "superadmin" ~= L1_3 then
          goto lbl_148
        end
      end
      L1_3 = {}
      L2_3 = GetHashKey
      L3_3 = "adder"
      L2_3 = L2_3(L3_3)
      L1_3.model = L2_3
      L2_3 = A0_2
      L1_3.plate = L2_3
      L1_3.plateIndex = 0
      L1_3.bodyHealth = 1000.0
      L1_3.engineHealth = 1000.0
      L1_3.tankHealth = 1000.0
      L1_3.fuelLevel = 100.0
      L1_3.dirtLevel = 0.0
      L1_3.color1 = 0
      L1_3.color2 = 0
      L1_3.pearlescentColor = 0
      L1_3.wheelColor = 0
      L1_3.wheels = 0
      L1_3.windowTint = 0
      L2_3 = {}
      L3_3 = false
      L4_3 = false
      L5_3 = false
      L6_3 = false
      L2_3[1] = L3_3
      L2_3[2] = L4_3
      L2_3[3] = L5_3
      L2_3[4] = L6_3
      L1_3.neonEnabled = L2_3
      L2_3 = {}
      L3_3 = 255
      L4_3 = 255
      L5_3 = 255
      L2_3[1] = L3_3
      L2_3[2] = L4_3
      L2_3[3] = L5_3
      L1_3.neonColor = L2_3
      L2_3 = {}
      L3_3 = 255
      L4_3 = 255
      L5_3 = 255
      L2_3[1] = L3_3
      L2_3[2] = L4_3
      L2_3[3] = L5_3
      L1_3.tyreSmokeColor = L2_3
      L1_3.modSpoilers = -1
      L1_3.modFrontBumper = -1
      L1_3.modRearBumper = -1
      L1_3.modSideSkirt = -1
      L1_3.modExhaust = -1
      L1_3.modFrame = -1
      L1_3.modGrille = -1
      L1_3.modHood = -1
      L1_3.modFender = -1
      L1_3.modRightFender = -1
      L1_3.modRoof = -1
      L1_3.modEngine = -1
      L1_3.modBrakes = -1
      L1_3.modTransmission = -1
      L1_3.modHorns = -1
      L1_3.modSuspension = -1
      L1_3.modArmor = -1
      L1_3.modTurbo = false
      L1_3.modXenon = false
      L1_3.modFrontWheels = -1
      L1_3.modBackWheels = -1
      L1_3.modPlateHolder = -1
      L1_3.modVanityPlate = -1
      L1_3.modTrimA = -1
      L1_3.modTrimB = -1
      L1_3.modOrnaments = -1
      L1_3.modDashboard = -1
      L1_3.modDial = -1
      L1_3.modDoorSpeaker = -1
      L1_3.modSeats = -1
      L1_3.modSteeringWheel = -1
      L1_3.modShifterLeavers = -1
      L1_3.modAPlate = -1
      L1_3.modSpeakers = -1
      L1_3.modTrunk = -1
      L1_3.modHydrolic = -1
      L1_3.modEngineBlock = -1
      L1_3.modAirFilter = -1
      L1_3.modStruts = -1
      L1_3.modArchCover = -1
      L1_3.modAerials = -1
      L1_3.modTrimC = -1
      L1_3.modTrimD = -1
      L1_3.modLivery = -1
      L1_3.modLightbar = -1
      L2_3 = MySQL
      L2_3 = L2_3.insert
      L3_3 = "INSERT INTO owned_vehicles (owner, plate, vehicle, stored, garage_name) VALUES (?, ?, ?, 0, NULL)"
      L4_3 = {}
      L5_3 = L2_2.identifier
      L6_3 = A0_2
      L7_3 = json
      L7_3 = L7_3.encode
      L8_3 = L1_3
      L7_3, L8_3 = L7_3(L8_3)
      L4_3[1] = L5_3
      L4_3[2] = L6_3
      L4_3[3] = L7_3
      L4_3[4] = L8_3
      function L5_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4, L5_4
        if A0_4 then
          L1_4 = TriggerClientEvent
          L2_4 = "esx:showNotification"
          L3_4 = L1_2
          L4_4 = "~g~V\195\169hicule de test cr\195\169\195\169 et mis en fourri\195\168re: "
          L5_4 = A0_2
          L4_4 = L4_4 .. L5_4
          L1_4(L2_4, L3_4, L4_4)
        else
          L1_4 = TriggerClientEvent
          L2_4 = "esx:showNotification"
          L3_4 = L1_2
          L4_4 = "~r~Erreur lors de la cr\195\169ation du v\195\169hicule de test"
          L1_4(L2_4, L3_4, L4_4)
        end
      end
      L2_3(L3_3, L4_3, L5_3)
      goto lbl_153
      ::lbl_148::
      L1_3 = TriggerClientEvent
      L2_3 = "esx:showNotification"
      L3_3 = L1_2
      L4_3 = "~r~V\195\169hicule non trouv\195\169"
      L1_3(L2_3, L3_3, L4_3)
    end
    ::lbl_153::
  end
  L3_2(L4_2, L5_2, L6_2)
  goto lbl_33
  ::lbl_28::
  L3_2 = TriggerClientEvent
  L4_2 = "esx:showNotification"
  L5_2 = L1_2
  L6_2 = "~r~Vous n'avez pas les permissions n\195\169cessaires"
  L3_2(L4_2, L5_2, L6_2)
  ::lbl_33::
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:requestSync"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:requestSync"
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = MySQL
  L1_2 = L1_2.query
  L2_2 = "SELECT data FROM garage_config WHERE name = ?"
  L3_2 = {}
  L4_2 = "garages"
  L3_2[1] = L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L1_3 = L1_3.data
        if L1_3 then
          L1_3 = pcall
          L2_3 = json
          L2_3 = L2_3.decode
          L3_3 = A0_3[1]
          L3_3 = L3_3.data
          L1_3, L2_3 = L1_3(L2_3, L3_3)
          if L1_3 and L2_3 then
            L3_3 = Config
            L3_3.Garages = L2_3
            L3_3 = L0_2
            if L3_3 then
              L3_3 = TriggerClientEvent
              L4_3 = "nz_garage:syncGarages"
              L5_3 = L0_2
              L6_3 = L2_3 or L6_3
              if not L2_3 then
                L6_3 = {}
              end
              L3_3(L4_3, L5_3, L6_3)
            end
          else
            L3_3 = LoadGaragesFromFile
            L3_3()
            L3_3 = L0_2
            if L3_3 then
              L3_3 = TriggerClientEvent
              L4_3 = "nz_garage:syncGarages"
              L5_3 = L0_2
              L6_3 = Config
              L6_3 = L6_3.Garages
              if not L6_3 then
                L6_3 = {}
              end
              L3_3(L4_3, L5_3, L6_3)
            end
          end
      end
    end
    else
      L1_3 = LoadGaragesFromFile
      L1_3()
      L1_3 = L0_2
      if L1_3 then
        L1_3 = TriggerClientEvent
        L2_3 = "nz_garage:syncGarages"
        L3_3 = L0_2
        L4_3 = Config
        L4_3 = L4_3.Garages
        if not L4_3 then
          L4_3 = {}
        end
        L1_3(L2_3, L3_3, L4_3)
      end
    end
  end
  L1_2(L2_2, L3_2, L4_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:saveGarages"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:saveGarages"
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = L2_2.getGroup
  L3_2 = L3_2()
  if "admin" ~= L3_2 and "superadmin" ~= L3_2 then
    return
  end
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  if not L4_2 then
    L5_2 = TriggerClientEvent
    L6_2 = "esx:showNotification"
    L7_2 = L1_2
    L8_2 = "~r~Erreur lors de l'encodage des donn\195\169es de garage"
    L5_2(L6_2, L7_2, L8_2)
    return
  end
  L5_2 = MySQL
  L5_2 = L5_2.query
  L6_2 = "SELECT * FROM garage_config WHERE name = ?"
  L7_2 = {}
  L8_2 = "garages"
  L7_2[1] = L8_2
  function L8_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = MySQL
        L1_3 = L1_3.update
        L2_3 = "UPDATE garage_config SET data = ? WHERE name = ?"
        L3_3 = {}
        L4_3 = L4_2
        L5_3 = "garages"
        L3_3[1] = L4_3
        L3_3[2] = L5_3
        function L4_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4
          if A0_4 > 0 then
            L1_4 = Config
            L2_4 = A0_2
            L1_4.Garages = L2_4
            L1_4 = TriggerClientEvent
            L2_4 = "nz_garage:syncGarages"
            L3_4 = -1
            L4_4 = A0_2
            L1_4(L2_4, L3_4, L4_4)
          else
            L1_4 = TriggerClientEvent
            L2_4 = "esx:showNotification"
            L3_4 = L1_2
            L4_4 = "~r~Erreur lors de la sauvegarde"
            L1_4(L2_4, L3_4, L4_4)
          end
        end
        L1_3(L2_3, L3_3, L4_3)
    end
    else
      L1_3 = MySQL
      L1_3 = L1_3.insert
      L2_3 = "INSERT INTO garage_config (name, data) VALUES (?, ?)"
      L3_3 = {}
      L4_3 = "garages"
      L5_3 = L4_2
      L3_3[1] = L4_3
      L3_3[2] = L5_3
      function L4_3(A0_4)
        local L1_4, L2_4, L3_4, L4_4
        if A0_4 and A0_4 > 0 then
          L1_4 = Config
          L2_4 = A0_2
          L1_4.Garages = L2_4
          L1_4 = TriggerClientEvent
          L2_4 = "nz_garage:syncGarages"
          L3_4 = -1
          L4_4 = A0_2
          L1_4(L2_4, L3_4, L4_4)
        else
          L1_4 = TriggerClientEvent
          L2_4 = "esx:showNotification"
          L3_4 = L1_2
          L4_4 = "~r~Erreur lors de la sauvegarde"
          L1_4(L2_4, L3_4, L4_4)
        end
      end
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L5_2(L6_2, L7_2, L8_2)
end
L2_1(L3_1, L4_1)
L2_1 = RegisterServerEvent
L3_1 = "nz_garage:requestGarages"
L2_1(L3_1)
L2_1 = AddEventHandler
L3_1 = "nz_garage:requestGarages"
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = TriggerClientEvent
  L2_2 = "nz_garage:syncGarages"
  L3_2 = L0_2
  L4_2 = Config
  L4_2 = L4_2.Garages
  L1_2(L2_2, L3_2, L4_2)
end
L2_1(L3_1, L4_1)
L2_1 = CreateThread
function L3_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = MySQL
  L0_2 = L0_2.query
  L1_2 = "SELECT data FROM garage_config WHERE name = ?"
  L2_2 = {}
  L3_2 = "garages"
  L2_2[1] = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    if A0_3 then
      L1_3 = #A0_3
      if L1_3 > 0 then
        L1_3 = A0_3[1]
        L1_3 = L1_3.data
        if L1_3 then
          L1_3 = pcall
          L2_3 = json
          L2_3 = L2_3.decode
          L3_3 = A0_3[1]
          L3_3 = L3_3.data
          L1_3, L2_3 = L1_3(L2_3, L3_3)
          if L1_3 and L2_3 then
            L3_3 = Config
            L3_3.Garages = L2_3
            L3_3 = TriggerClientEvent
            L4_3 = "nz_garage:syncGarages"
            L5_3 = -1
            L6_3 = L2_3
            L3_3(L4_3, L5_3, L6_3)
          else
            L3_3 = LoadGaragesFromFile
            L3_3()
          end
      end
    end
    else
      L1_3 = LoadGaragesFromFile
      L1_3()
    end
  end
  L0_2(L1_2, L2_2, L3_2)
end
L2_1(L3_1)
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = LoadResourceFile
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  L2_2 = "garages.json"
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = pcall
    L2_2 = json
    L2_2 = L2_2.decode
    L3_2 = L0_2
    L1_2, L2_2 = L1_2(L2_2, L3_2)
    if L1_2 and L2_2 then
      L3_2 = Config
      L3_2.Garages = L2_2
      L3_2 = MySQL
      L3_2 = L3_2.insert
      L4_2 = "INSERT INTO garage_config (name, data) VALUES (?, ?)"
      L5_2 = {}
      L6_2 = "garages"
      L7_2 = json
      L7_2 = L7_2.encode
      L8_2 = L2_2
      L7_2, L8_2 = L7_2(L8_2)
      L5_2[1] = L6_2
      L5_2[2] = L7_2
      L5_2[3] = L8_2
      L3_2(L4_2, L5_2)
      L3_2 = TriggerClientEvent
      L4_2 = "nz_garage:syncGarages"
      L5_2 = -1
      L6_2 = L2_2
      L3_2(L4_2, L5_2, L6_2)
    else
      L3_2 = Config
      L4_2 = {}
      L3_2.Garages = L4_2
      L3_2 = MySQL
      L3_2 = L3_2.insert
      L4_2 = "INSERT INTO garage_config (name, data) VALUES (?, ?)"
      L5_2 = {}
      L6_2 = "garages"
      L7_2 = json
      L7_2 = L7_2.encode
      L8_2 = {}
      L7_2, L8_2 = L7_2(L8_2)
      L5_2[1] = L6_2
      L5_2[2] = L7_2
      L5_2[3] = L8_2
      L3_2(L4_2, L5_2)
    end
  else
    L1_2 = Config
    L2_2 = {}
    L1_2.Garages = L2_2
    L1_2 = MySQL
    L1_2 = L1_2.insert
    L2_2 = "INSERT INTO garage_config (name, data) VALUES (?, ?)"
    L3_2 = {}
    L4_2 = "garages"
    L5_2 = json
    L5_2 = L5_2.encode
    L6_2 = {}
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L3_2[3] = L6_2
    L3_2[4] = L7_2
    L3_2[5] = L8_2
    L1_2(L2_2, L3_2)
  end
end
LoadGaragesFromFile = L2_1
L2_1 = RegisterCommand
L3_1 = "reloadgarages"
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = A0_2
  if 0 == L3_2 then
    L4_2 = LoadGaragesFromFile
    L4_2()
  end
end
L5_1 = true
L2_1(L3_1, L4_1, L5_1)
L2_1 = ESX
L2_1 = L2_1.RegisterServerCallback
L3_1 = "nz_garage:checkPermission"
function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2.getGroup
  L3_2 = L3_2()
  L4_2 = Config
  L4_2 = L4_2.Builder
  if L4_2 then
    L4_2 = Config
    L4_2 = L4_2.Builder
    L4_2 = L4_2.permissions
    if L4_2 then
      L4_2 = Config
      L4_2 = L4_2.Builder
      L4_2 = L4_2.permissions
      L4_2 = L4_2[L3_2]
      if L4_2 then
        L4_2 = A1_2
        L5_2 = true
        L4_2(L5_2)
    end
  end
  elseif "admin" == L3_2 or "superadmin" == L3_2 then
    L4_2 = A1_2
    L5_2 = true
    L4_2(L5_2)
  else
    L4_2 = A1_2
    L5_2 = false
    L4_2(L5_2)
  end
end
L2_1(L3_1, L4_1)
