ESX = exports["es_extended"]:getSharedObject()

Config = {} 

-- Configuration des peds
Config.UsePed = false

Config.input = function(txt)
    return exports.nz_ui:ShowInput(txt, true, 100, 'small_text', '', false, 'top-right')
end

Config.Organizations = {
    enabled = true,
    
    jobs = {
        enabled = true,
        ownership_table = "owned_vehicles",
        job_field = "job",
        identifier_field = "owner",
        id_field = "plate"
    },
    
    gangs = {
        enabled = false,
        ownership_table = "gang_vehicles",
        gang_field = "gang_name",
        identifier_field = "owner",
        id_field = "plate" 
    }
}

-- Configuration des marqueurs
Config.Markers = {
    enter = {
        type = 36, -- Type de marqueur
        size = vector3(1.0, 1.0, 1.0), -- Taille du marqueur (x, y, z)
        color = {r = 3, g = 0, b = 138, a = 170}, -- Couleur du marqueur (r, g, b, a)
        height = 0.5,
        bobUpDown = true, -- Animation verticale
        rotate = true -- Rotation du marqueur
    },
    store = {
        type = 25,
        size = vector3(3.0, 3.0, 1.0),
        color = {r = 255, g = 0, b = 0, a = 100},
        height = -0.5,
        bobUpDown = false,
        rotate = false
    }
}

Config.Garages = {} 

Config.Impound = {
    enabled = true,
    price = 500, -- Prix de base pour récupérer un véhicule
    locations = {
        ["main"] = {
            name = "Fourrière Principale",
            points = {
                enter = {
                    pos = vector3(409.51, -1623.13, 29.29),
                    type = "enter",
                    marker = {type = 36, size = vector3(1.0, 1.0, 1.0), color = {r = 255, g = 0, b = 0, a = 255}}
                }
            },
            ped = {
                model = "s_m_m_security_01",
                heading = 230.0,
                animation = {
                    dict = "amb@world_human_clipboard@male@idle_a",
                    name = "idle_c",
                    flag = 49
                },
                scenario = "",
                interactDistance = 2.0
            },
            spawnPoint = vector4(407.92, -1627.65, 29.29, 228.84)
        }
    }
}

Config.Builder = {
    command = "garagebuilder", -- Commande pour ouvrir le builder
    permissions = {
            -- Groupes qui peuvent utiliser le builder
        ["admin"] = true,
        ["superadmin"] = true
    }
}

Config.Blips = {
    enabled = true,
    
    garage = {
        sprite = 357,    
        color = 3,        
        scale = 0.8,      
        name = "Garage"   
    },
    types = {
        car = {
            sprite = 50,
            color = 3,
            scale = 0.8,
            name = "Garage"
        },
        boat = {
            sprite = 356, 
            color = 3,
            scale = 0.8,
            name = "Garage à bateaux"
        },
        aircraft = {
            sprite = 359,
            color = 3,
            scale = 0.8,
            name = "Hangar"
        },
        truck = {
            sprite = 357,
            color = 17,
            scale = 0.8,
            name = "Garage à camions" 
        }
    }
}

Config.Notifications = {
    enter = "Appuyez sur ~INPUT_CONTEXT~ pour accéder au garage",
    store = "Appuyez sur ~INPUT_CONTEXT~ pour ranger votre véhicule",
    notOwner = "~r~Vous n'êtes pas le propriétaire de ce véhicule!",
    storeSuccess = "~g~Véhicule rangé avec succès!",
    notInVehicle = "~r~Vous devez être dans un véhicule pour le ranger",
    vehicleOut = "~r~Ce véhicule est déjà sorti",
    vehicleNotFound = "~r~Véhicule non trouvé",
    impound = {
        enter = "Appuyez sur ~INPUT_CONTEXT~ pour accéder à la fourrière",
        noVehicles = "Vous n'avez aucun véhicule en fourrière",
        success = "~g~Véhicule récupéré avec succès",
        notEnoughMoney = "~r~Vous n'avez pas assez d'argent"
    }
}

Config.DrawDistance = 5.0 -- Distance à laquelle les marqueurs sont visibles
Config.InteractDistance = 5.0 -- Distance à laquelle on peut interagir avec les marqueurs

Configk2rUI = {}

Configk2rUI.Menu = {
    TitreMenu = "RAGEUI",
    CouleurBouton = { R = 173, G = 36, B = 36},
    DegraderBanniere = { R = 255, G = 0, B = 0 } 
}