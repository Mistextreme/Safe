fx_version 'adamant'
games { 'gta5' }

server_script {
    "server.lua"
}

client_script {
    "client.lua"
}
