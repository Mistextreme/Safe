const translate = new Object();

translate['garage-head-translation'] = "GARAGE"
translate['btn-impound'] = "In Beslag Nemen"
translate['btn-take'] = "Uitnemen"
translate['btn-select'] = "Tonen"
translate['btn-repair'] = "Repareren"
translate['impounding-vehicle-text'] = "Voertuig In Beslag Nemen..."
translate['repairing-vehicle-text'] = "Voertuig Repareren..."
translate['repairing'] = "Repareren..."
translate['impounding'] = "In Beslag Nemen..."
translate['enter_showroom'] = "Showroom binnenkomen."
translate['search-bar-text'] = "Zoek op kenteken of voertuignaam."