const translate = new Object();

translate['garage-head-translation'] = "GARAJE"
translate['btn-impound'] = "Confiscar"
translate['btn-take'] = "Sacar"
translate['btn-select'] = "Mostrar"
translate['btn-repair'] = "Reparar"
translate['impounding-vehicle-text'] = "Confiscando Vehículo..."
translate['repairing-vehicle-text'] = "Reparando Vehículo..."
translate['repairing'] = "Reparando..."
translate['impounding'] = "Confiscando..."
translate['enter_showroom'] = "Ingrese a la sala de exposición."
translate['search-bar-text'] = "Buscar matrícula o nombre del vehículo."