const translate = new Object();

translate['garage-head-translation'] = "GARAGE"
translate['btn-impound'] = "Beschlagnahmen"
translate['btn-take'] = "Rausnehmen"
translate['btn-select'] = "Anzeigen"
translate['btn-repair'] = "Reparieren"
translate['impounding-vehicle-text'] = "Fahrzeug Beschlagnahmen..."
translate['repairing-vehicle-text'] = "Fahrzeug Reparieren..."
translate['repairing'] = "Reparieren..."
translate['impounding'] = "Beschlagnahmen..."
translate['enter_showroom'] = "Betreten Sie den Ausstellungsraum."
translate['search-bar-text'] = "Suche nach Kennzeichen oder Fahrzeugnamen."