const translate = new Object();

translate['garage-head-translation'] = "GARAGE"
translate['btn-impound'] = "Impound"
translate['btn-take'] = "Take Out"
translate['btn-select'] = "Show"
translate['btn-repair'] = "Repair"
translate['impounding-vehicle-text'] = "Impounding Vehicle..."
translate['repairing-vehicle-text'] = "Repairing Vehicle..."
translate['repairing'] = "Repairing..."
translate['impounding'] = "Impounding..."
translate['enter_showroom'] = "Enter Showroom."
translate['search-bar-text'] = "Search Plate or Vehicle name."