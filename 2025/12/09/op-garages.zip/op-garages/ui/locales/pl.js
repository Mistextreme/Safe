const translate = new Object();

translate['garage-head-translation'] = "GARAŻ"
translate['btn-impound'] = "Odholuj"
translate['btn-take'] = "Wyciągnij"
translate['btn-select'] = "Pokaż"
translate['btn-repair'] = "Napraw"
translate['impounding-vehicle-text'] = "Odholowywanie Pojazdu..."
translate['repairing-vehicle-text'] = "Naprawianie pojazdu..."
translate['repairing'] = "Naprawianie..."
translate['impounding'] = "Odholowywanie..."
translate['enter_showroom'] = "Wejdź do showroomu."
translate['search-bar-text'] = "Szukaj tablicy rejestracyjnej lub nazwy pojazdu."