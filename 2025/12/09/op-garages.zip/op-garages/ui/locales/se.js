const translate = new Object();

translate['garage-head-translation'] = "GARAGE"
translate['btn-impound'] = "Bärgarn"
translate['btn-take'] = "Ta ut fordon"
translate['btn-select'] = "Visa"
translate['btn-repair'] = "Laga"
translate['impounding-vehicle-text'] = "Bärgar Fordon..."
translate['repairing-vehicle-text'] = "Lagar Fordon..."
translate['repairing'] = "Fordonet Lagas..."
translate['impounding'] = "Bärgas..."
translate['enter_showroom'] = "Öppna Garage."
