Bridges = {
    Database = true,
    Framework = true,
    Inventory = true,   
    Clothing = true,
    Prison = true,
    Invoices = true,
    Dispatch = true,
    Garages = true,
    Fuel = true,
    Licence = true,
    Menu = true,
    Notify = true,
    Society = true,
    TextUI = true,
    InteractionsTarget = true,
    Duty = true,
    Keys = true,
    PG = true,
    MDT = true,
}

Invoices = {
    KARTIK = "kartik-banking",
    VIVUM = 'vivum-billing',
    VMS = 'vms_cityhall',
    TGG = 'tgg-billing',
    JAKSAM = 'billing_ui',
    CODEM = 'codem-billing',
    GKS_PHONE = 'gksphone',
    ESX_BILLING = 'esx_billing',
    BRUTAL = 'brutal_billing',
    QB_PHONE = 'qb-phone',
    QBOX = FrameworkNames["qbx_core"],
    OKOK = 'okokBilling',
    FD = 'fd_banking',
    QS = 'qs-billing',
    NONE = NONE_RESOURCE
}

Input = {   
    RCORE = GetCurrentResourceName(),
    QB = 'qb-input',
    ESX = 'esx_input',
    OX = 'ox_lib',
    NONE = NONE_RESOURCE
}

Duty = {
    ESX = FrameworkNames["es_extended"],
    QBOX = FrameworkNames["qbx_core"],
    QBCORE = FrameworkNames["qb-core"],
    NONE = NONE_RESOURCE
}

TextUI = {
    RCORE = GetCurrentResourceName(),
    OX = 'ox_lib',
    QBCORE = FrameworkNames["qb-core"],
    ESX = 'esx_textui',
    NONE = NONE_RESOURCE,
}

Society = {
    JOBS_CREATOR = 'jobs_creator',
    TGG_BANKING = 'tgg-banking',
    CRM_BANKING = 'crm-banking',
    QS_BANKING = 'qs-banking',
    RENEWED = 'Renewed-Banking',
    WASABI_BANKING = "wasabi_banking",
    QB_MANAGEMENT = 'qb-management',
    QBX_MANAGEMENT = 'qbx_management',
    QB_BANKING = 'qb-banking',
    FD_BANKING = 'fd_banking',
    ESX = 'esx_society',
    OKOK = 'okokBanking',
    SNIPE = 'snipe-banking',
    CODESTUDIO = 'cs_bossmenu',
    VMS = 'vms_bossmenu',
    NONE = NONE_RESOURCE
}

Notify = {
    BRUTAL = 'brutal_notify',
    PNOTIFY = 'pNotify',
    OX = 'ox_lib',
    ESX_NOTIFY = 'esx_notify',
    QBCORE = FrameworkNames["qb-core"],
    QBOX = FrameworkNames["qbx_core"],
    ESX = FrameworkNames["es_extended"],
    MYTHIC = 'mythic_notify',
    OKOK = 'okokNotify',
    ST_NOTIFY = 'stNotify',
    RCORE = GetCurrentResourceName(),
    NONE = NONE_RESOURCE,
}

Keys = {
    QB = 'qb-vehiclekeys',
    ZYKE = 'zyke_garages',
    RENEWED = "Renewed-VehicleKeys",
    RCORE = 'rcore_garage',
    FIVECODE = 'fivecode_carkeys',
    WASABI = 'wasabi_carlock',
    CD = 'cd_garage',
    JAKSAM = 'vehicles_keys',
    OKOK = 'okokGarage',
    MK = 'mk_vehiclekeys',
    MR_NEWB = 'MrNewbVehicleKeys',
    QS = 'qs-vehiclekeys',
    XD = 'xd_locksystem',
    NONE = NONE_RESOURCE
}

Menu = {
    RCORE = GetCurrentResourceName(),
    ESX_CONTEXT = 'esx_context',
    OX = 'ox_lib',
    QB = 'qb-menu',
    NONE = NONE_RESOURCE
}

Licence = {
    VMS = "vms_documentsv2",
    CODESTUDIO = 'cs_license',
    ESX = 'esx_license',
    QBCORE = FrameworkNames["qb-core"],
    QBOX = FrameworkNames["qbx_core"],
    NONE = NONE_RESOURCE
}

Database = {
    OX = 'oxmysql',
    MYSQL_ASYNC = 'mysql-async',
    GHMATTI = 'ghmattimysql',
    NONE = NONE_RESOURCE
}

Inventory = {
    OX = 'ox_inventory',
    MF = 'mf-inventory',
    CHEEZA = 'inventory',
    QB = 'qb-inventory',
    QS = 'qs-inventory',
    PS = 'ps-inventory',
    LJ = 'lj-inventory',
    CORE = 'core_inventory',
    TGIANN = 'tgiann-inventory',
    CODEM = 'codem-inventory',
    ORIGEN = 'origen_inventory',
    ESX = FrameworkNames["es_extended"],
    NONE = NONE_RESOURCE
}

Framework = {
    ESX = FrameworkNames["es_extended"],
    QBCore = FrameworkNames["qb-core"],
    QBOX = FrameworkNames["qbx_core"],
    NONE = NONE_RESOURCE
}

Images = {
    NONE = "none",
    FIVEMERR = "fivemerr",
    FIVEMANAGE = "fivemanage",
}

Fuel = {
    RENEWED = "Renewed-Fuel",
    RCORE = 'rcore_fuel',
    LEGACY = 'LegacyFuel',
    PS = 'ps-fuel',
    LC = 'lc_fuel',
    CDN = 'cdn-fuel',
    TI = 'ti_fuel',
    MY = 'myFuel',
    OKOK = 'okokGasStation',
    LJ = 'lj-fuel',
    ND = 'nd_fuel',
    OX = 'ox_fuel',
    HYON_GAS = 'hyon_gas_station',
    NONE = NONE_RESOURCE
}

Garages = {
    OKOK = 'okokGarage',
    ZYKE = 'zyke_garages',
    QS = 'qs-advancedgarages',
    QB_GARAGE = 'qb-garages',
    QBOX_GARAGE = 'qbx_garages',
    ESX_GARAGE = 'esx_garage',
    JG = 'jg-advancedgarages',
    CD_GARAGE = 'cd_garage',
    NDCORE = 'ND_Core', 
    NONE = NONE_RESOURCE
}

Clothing = {
    ESX = 'skinchanger',
    QB = 'qb-clothing',
    SKINCHANGER = 'skinchanger',
    FAPPEARANCE = 'fivem-appearance',
    WASABI = 'wasabi',
    IAPPEARANCE = 'illenium-appearance',
    RCORE = 'rcore_clothing',
    CODEM = 'codem-appearance',
    CRM = 'crm-appearance',
    TGIANN = 'tgiann-clothing',
    NONE = NONE_RESOURCE
}

Prison = {
    RCORE = 'rcore_prison',
    R_PRISON = 'r_prison',
    QB_PRISON = 'qb-prison',
    XT = 'xt-prison',
    ESX_COMS = 'esx_communityservice',
    QALLE = 'esx-qalle-jail',
    NONE = NONE_RESOURCE
}

Dispatch = {
    LB_TABLET = 'lb-tablet',
    RCORE = 'rcore_dispatch',
    QS = 'qs-dispatch',
    PS = 'ps-dispatch',
    CD = 'cd_dispatch',
    CORE = 'core_dispatch',
    DUSA = 'dusa_dispatch',
    LOVE_SCRIPTS = 'emergencydispatch',
    CODEM = 'codem-dispatch',
    TK = 'tk_dispatch',
    ORIGEN = 'origen_police',
    NONE = NONE_RESOURCE
}

MDT = {
    PS = 'ps-mdt',
    DRX = 'drx_mdt',
    REDUTZU = 'redutzu-mdt',
    QS = 'qs-dispatch',
    LB_TABLET = 'lb-tablet',
    TK = 'tk_mdt',
    NONE = NONE_RESOURCE
}

PG = {
    QB = FrameworkNames["qb-core"],
    ESX = FrameworkNames["es_extended"],
    OX = 'ox_lib',
    NONE = NONE_RESOURCE
}

ORDERED_KEYS = {
    PG = { "QB", "ESX", "OX", "NONE"},
    Duty = { "ESX", "QBCORE", "QBOX", "ESX_SERVICE", "NONE" },
    Framework = { "QBCore", "ESX", "QBOX", "NONE" },
    TextUI = { "RCORE", "QBCORE", "ESX", "OX", "NONE" },
    Invoices = { "KARTIK", "VIVUM", "BRUTAL", "JAKSAM", "GKS_PHONE", "VMS", "TGG", "CODEM",  "OKOK", "QS", "ESX_BILLING", "QB_PHONE", "QBOX", "NONE" },
    Society = { "WASABI_BANKING", "CRM_BANKING", "TGG_BANKING", "VMS", "FD_BANKING", "QS_BANKING", "CODESTUDIO", "SNIPE", "RENEWED", "OKOK", "QB_BANKING", "JOBS_CREATOR", "QB_MANAGEMENT", "QBX_MANAGEMENT", "ESX", "NONE" },
    Notify = { "QBOX", "ESX", "QBCORE", "ESX_NOTIFY", "QBCORE", "MYTHIC", "OKOK", "RCORE", "OX", "NONE" },
    Garages = {  "QS", "JG", "CD_GARAGE", "OKOK", "ZYKE", "QB_GARAGE", "QBOX_GARAGE", "ESX_GARAGE", "NDCORE", "NONE" },
    Keys = { "ZYKE", "RCORE", "WASABI", "OKOK", "FIVECODE", "RENEWED", "CD", "QS", "XD", "NONE" },
    Menu = { "RCORE", "ESX_CONTEXT", "OX", "QB", "NONE" },
    Licence = { "VMS", "CODESTUDIO", "QBOX", "ESX", "QBCORE", "NONE" },
    Prison = { "RCORE", "R_PRISON", "QALLE", "QB_PRISON", "XT", "NONE" },
    Dispatch = { "LB_TABLET", "TK", "PS", "RCORE", "ORIGEN", "QS", "CD", "NONE" },
    Database = { "OX", "MYSQL_ASYNC", "GHMATTI", "NONE" },
    MDT = { "LB_TABLET", "PS", "REDUTZU", "QS", "NONE"},
    Inventory = { "CODEM", "OX", "CORE", "MF", "CHEEZA", "QB", "QS", "PS", "LJ", "TGIANN", "ORIGEN", "ESX", "NONE" },
}

IS_QB = {
    [Framework.QBCore] = true,
    [Framework.QBOX] = true,
}

FRAMEWORK_TO_SHORT_NAME = {
    [Framework.ESX] = 'ESX',
    [Framework.QBCore] = 'QBCORE',
    [Framework.QBOX] = 'QBOX',
    [Framework.NONE] = nil
}
