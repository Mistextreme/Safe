-- OX Inventory

local OX_ITEMS = {
    ['megaphone'] = {
        label = 'Megaphone',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['barrier'] = {
        label = 'Barricade',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['handcuffs'] = {
        label = 'Handcuffs',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },


    ["wheel_clamp_wrench"] = {
        label = "Wheel Clamp Wrench",
        weight = 1,
        stack = true,
        close = true
    },

    ["wheel_clamp"] = {
        label = "Wheel Clamp",
        weight = 1,
        stack = true,
        close = true
    },



    ['handcuffs_key']  = {
        label = 'Keys',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['spikes']         = {
        label = 'Spikes',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['speed_camera']   = {
        label = 'Speed camera',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['zipties']        = {
        label = 'Zip ties',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['paper_bag_rcore']      = {
        label = 'Paper Bag',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['panic_button']   = {
        label = 'Panic Button',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['zipties_cutter'] = {
        label = 'Zipties cutter',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['bodycam']        = {
        label = 'Bodycam',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['bodycam_tablet'] = {
        label = 'Bodycam tablet',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['photo']          = {
        label = 'Photo',
        weight = 100,
        stack = false,
        close = true,
        consume = 0,
    },

    ['camera']         = {
        label = 'Camera',
        weight = 100,
        stack = true,
        close = true,
        consume = 0,
    },

    ['gps']         = {
        label = 'GPS',
        weight = 100,
        stack = true,
        close = true,
        consume = 0
    },

}

-- QB Inventory

local QB_ITEMS = {
    speed_camera   = { name = 'speed_camera', label = 'Speed camera', weight = 100, type = 'item', image = 'speed_camera.png', unique = false, useable = true, shouldClose = true, description = '' },
    bodycam        = { name = 'bodycam', label = 'Bodycam', weight = 100, type = 'item', image = 'bodycam.png', unique = false, useable = true, shouldClose = true, description = '' },
    bodycam_tablet = { name = 'bodycam_tablet', label = 'Bodycam tablet', weight = 100, type = 'item', image = 'bodycam_tablet.png', unique = false, useable = true, shouldClose = true, description = '' },
    panic_button   = { name = 'panic_button', label = 'Panic Button', weight = 100, type = 'item', image = 'panic_button.png', unique = false, useable = true, shouldClose = true, description = '' },
    megaphone      = { name = 'megaphone', label = 'Megaphone', weight = 100, type = 'item', image = 'megaphone.png', unique = false, useable = true, shouldClose = true, description = '' },
    paper_bag      = { name = 'paper_bag', label = 'Paper Bag', weight = 100, type = 'item', image = 'paper_bag.png', unique = false, useable = true, shouldClose = true, description = '' },
    zipties        = { name = 'zipties', label = 'Zip ties', weight = 100, type = 'item', image = 'zipties.png', unique = false, useable = true, shouldClose = true, description = '' },
    spikes         = { name = 'spikes', label = 'Spikes', weight = 100, type = 'item', image = 'spikes.png', unique = false, useable = true, shouldClose = true, description = '' },
    handcuffs_key  = { name = 'handcuffs_key', label = 'Handcuffs Key', weight = 100, type = 'item', image = 'handcuffs_key.png', unique = false, useable = true, shouldClose = true, description = '' },
    handcuffs      = { name = 'handcuffs', label = 'Handcuffs', weight = 100, type = 'item', image = 'handcuffs.png', unique = false, useable = true, shouldClose = true, description = '' },
    barrier        = { name = 'barrier', label = 'Barrier', weight = 100, type = 'item', image = 'barrier.png', unique = false, useable = true, shouldClose = true, description = '' },
    zipties_cutter = { name = 'zipties_cutter', label = 'Zipties cutter', weight = 100, type = 'item', image = 'zipties_cutter.png', unique = false, useable = true, shouldClose = true, description = '' },


    gps                = {
        name = 'gps',
        label = 'GPS',
        weight = 1,
        type = 'item',
        image = 'gps.png',
        unique = true,
        useable = true,
        shouldClose = true,
        combinable = nil,
        description = 'GPS'
    },

    photo              = {
        name = 'photo',
        label = 'Photo',
        weight = 1,
        type = 'item',
        image = 'photo.png',
        unique = true,
        useable = true,
        shouldClose = true,
        combinable = nil,
        description = 'Photo'
    },

    camera             = {
        name = 'camera',
        label = 'Camera',
        weight = 1,
        type = 'item',
        image = 'camera.png',
        unique = false,
        useable = true,
        shouldClose = true,
        combinable = nil,
        description = 'Camera'
    },

    wheel_clamp        = {
        name = 'wheel_clamp',
        label = 'Wheel Clamp',
        weight = 1,
        type = 'item',
        image = 'wheel_clamp.png',
        unique = false,
        useable = true,
        shouldClose = true,
        combinable = nil,
        description = 'Wheel Clamp'
    },

    wheel_clamp_wrench = {
        name = 'wheel_clamp_wrench',
        label = 'Wheel Clamp Wrench',
        weight = 1,
        type = 'item',
        image = 'wheel_clamp_wrench.png',
        unique = false,
        useable = true,
        shouldClose = true,
        combinable = nil,
        description = 'Wheel Clamp Wrench'
    },
}


local TGIANN_ITEMS = {
    megaphone = {
        description = "A loud device used to amplify your voice during operations or events.",
        image = "megaphone.png",
        label = "Megaphone",
        name = "megaphone",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    
    gps                = {
        description = "GPS",
        image = "gps.png",
        label = "GPS",
        name = "gps",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    barrier = {
        description = "A portable barricade used to block paths or secure areas.",
        image = "barrier.png",
        label = "Barricade",
        name = "barrier",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    handcuffs = {
        description = "Standard issue handcuffs for restraining individuals.",
        image = "handcuffs.png",
        label = "Handcuffs",
        name = "handcuffs",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    handcuffs_key = {
        description = "Key used to unlock standard handcuffs.",
        image = "handcuffs_key.png",
        label = "Keys",
        name = "handcuffs_key",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    spikes = {
        description = "Spikes used to disable vehicle tires, useful in high-speed chases.",
        image = "spikes.png",
        label = "Spikes",
        name = "spikes",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    speed_camera = {
        description = "A portable speed camera used to monitor and catch speeding vehicles.",
        image = "speed_camera.png",
        label = "Speed camera",
        name = "speed_camera",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    zipties = {
        description = "Strong plastic restraints used as an alternative to handcuffs.",
        image = "zipties.png",
        label = "Zip ties",
        name = "zipties",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    paper_bag = {
        description = "A simple paper bag... perfect for some funny roleplay moments.",
        image = "paper_bag.png",
        label = "Paper Bag",
        name = "paper_bag",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    panic_button = {
        description = "A button that sends an emergency alert when pressed.",
        image = "panic_button.png",
        label = "Panic Button",
        name = "panic_button",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    zipties_cutter = {
        description = "A sharp tool to cut zip ties easily and safely.",
        image = "zipties_cutter.png",
        label = "Zipties cutter",
        name = "zipties_cutter",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    bodycam = {
        description = "A wearable body camera to record interactions and ensure transparency.",
        image = "bodycam.png",
        label = "Bodycam",
        name = "bodycam",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    bodycam_tablet = {
        description = "Tablet used to view and manage bodycam footage.",
        image = "bodycam_tablet.png",
        label = "Bodycam tablet",
        name = "bodycam_tablet",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    camera = {
        description = "camera",
        image = "camera.png",
        label = "Camera",
        name = "camera",
        shouldClose = true,
        type = "item",
        unique = true,
        useable = true,
        weight = 100,
    },

    photo = {
        description = "photo",
        image = "photo.png",
        label = "Photo",
        name = "photo",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    wheel_clamp = {
        description = "wheel_clamp",
        image = "wheel_clamp.png",
        label = "Wheel clamp",
        name = "wheel_clamp",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },

    wheel_clamp_wrench = {
        description = "wheel_clamp_wrench",
        image = "wheel_clamp_wrench.png",
        label = "Wheel clamp Wrench",
        name = "wheel_clamp_wrench",
        shouldClose = true,
        type = "item",
        unique = false,
        useable = true,
        weight = 100,
    },
}
