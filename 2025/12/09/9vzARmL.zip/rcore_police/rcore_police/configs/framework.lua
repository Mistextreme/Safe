FrameworkNames = {
    ["es_extended"] = "es_extended",
    ["qbx_core"] = "qbx_core",
    ["qb-core"] = "qb-core",
}