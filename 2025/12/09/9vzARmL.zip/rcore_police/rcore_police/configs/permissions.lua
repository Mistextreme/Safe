Permissions = {
    HAS_SERVER_GROUP = 'has_server_group', -- Player with this permission has a server group.
}

PermissionMap = {
    ['group.owner'] = {
        Permissions.HAS_SERVER_GROUP,
    },
    ['group.admin'] = {
        Permissions.HAS_SERVER_GROUP,
    },
}    