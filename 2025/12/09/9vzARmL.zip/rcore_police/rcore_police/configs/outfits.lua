Outfits = {
    ['short_sleeve'] = {
        male = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 58,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 55,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 15,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 24,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 51,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = DRAWABLE.NONE, textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        },
        female = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 35,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 48,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 34,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 31,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 133,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 52,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = DRAWABLE.NONE, textureId = 0 },
            { isProp = true,                                componentId = CLOTHING_COMPONENTS.MASKS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        }
    },
    ['long_sleeve'] = {
        male = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 58,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 317,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 8,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 24,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 51,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = DRAWABLE.NONE, textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        },
        female = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 35,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 327,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 34,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 31,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 133,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 52,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = DRAWABLE.NONE, textureId = 0 },
            { isProp = true,                                componentId = CLOTHING_COMPONENTS.MASKS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        }
    },
    ['trooper'] = {
        male = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 58,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 317,                        textureId = 3 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 20,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 24,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 51,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = 58, textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,  textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,  textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,  textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        },
        female = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 35,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 327,                        textureId = 3 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 34,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 31,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 133,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 52,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = DRAWABLE.NONE, textureId = 0 },
            { isProp = true,                                componentId = CLOTHING_COMPONENTS.MASKS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,             textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        }
    },
    ['swat'] = {
        male = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 58,                         textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 336,                        textureId = 3 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 15,                         textureId = 2 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 14,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 130,                        textureId = 1 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 24,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = 150, textureId = 0 },
            { isProp = true,                                componentId = CLOTHING_COMPONENTS.MASKS, drawableId = 52,  textureId = 3 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        },
        female = {
            { componentId = CLOTHING_COMPONENTS.SHIRT,      drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY,       drawableId = 327,                        textureId = 8 },
            { componentId = CLOTHING_COMPONENTS.DECALS,     drawableId = 0,                          textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.BODY_ARMOR, drawableId = 17,                         textureId = 2 },
            { componentId = CLOTHING_COMPONENTS.ARMS,       drawableId = 213,                        textureId = 0 },
            { componentId = CLOTHING_COMPONENTS.PANTS,      drawableId = 135,                        textureId = 1 },
            { componentId = CLOTHING_COMPONENTS.SHOES,      drawableId = 52,                         textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.HATS,      drawableId = 149, textureId = 0 },
            { isProp = true,                                componentId = CLOTHING_COMPONENTS.MASKS, drawableId = 35,  textureId = 3 },
            { isProp = true,                                componentId = PROP_COMPONENTS.EARS,      drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.WATCHES,   drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.BRACELETS, drawableId = 0,   textureId = 0 },
            { isProp = true,                                componentId = PROP_COMPONENTS.ACCESSORY, drawableId = DRAWABLE.NONE,             textureId = 0 },
        }
    }
}

DepartmentOutfits = {
    ['short_sleeve'] = {
        label = 'Short Sleeve',
        outfit = Outfits['short_sleeve']
    },
    ['long_sleeve'] = {
        label = 'Long Sleeve',
        outfit = Outfits['long_sleeve']
    },
    ['swat'] = {
        label = 'SWAT',
        outfit = Outfits['swat']
    },
    ['trooper'] = {
        label = 'Trooper',
        outfit = Outfits['trooper']
    },
}
