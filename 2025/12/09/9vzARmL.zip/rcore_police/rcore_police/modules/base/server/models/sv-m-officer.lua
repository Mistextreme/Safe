local L0_1, L1_1
function L0_1()
  local L0_2, L1_2
  L0_2 = {}
  L0_2.playerId = nil
  L0_2.identifier = nil
  L0_2.group = nil
  L0_2.grade = nil
  L0_2.grade_name = nil
  return L0_2
end
OfficerModel = L0_1
