local L0_1, L1_1
function L0_1(A0_2)
  local L1_2, L2_2
  L1_2 = {}
  L2_2 = A0_2.name
  if not L2_2 then
    L2_2 = "Unknown"
  end
  L1_2.name = L2_2
  return L1_2
end
GradeModel = L0_1
