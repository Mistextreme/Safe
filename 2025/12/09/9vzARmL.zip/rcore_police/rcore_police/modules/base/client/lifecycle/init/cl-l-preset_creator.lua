local L0_1, L1_1, L2_1
L0_1 = NetworkService
L0_1 = L0_1.RegisterNetEvent
L1_1 = "PresetCreator"
function L2_1(A0_2)
  local L1_2
  if A0_2 then
    L1_2 = HandlePresetCreator
    L1_2()
  end
end
L0_1(L1_1, L2_1)
