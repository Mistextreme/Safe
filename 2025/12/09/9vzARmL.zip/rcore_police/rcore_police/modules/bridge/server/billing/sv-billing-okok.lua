CreateThread(function()
    if Config.Invoices == Invoices.OKOK then
        CreateOfflineInvoiceForVehicle = function(vehiclePlate, fineAmount, vehicleSpeed)
            dbg.debug('Speed camera taken fine for this vehicle: %s - but you need to integrate this to your billing resource (sv-billing-okok.lua)', vehiclePlate)
        end

        CreateInvoiceToPlayerInVehicle = function(playerId, targetPlayerId, amount, data)
            if not playerId then
                return
            end

            if not targetPlayerId then
                return
            end

            if not data then
                data = {}
            end

            local reason = ''

            if data and data.reason then
                reason = data.reason
            end

            if data.job then
                reason = 'Speed camera'
            end

            local invoice = Framework.BuildInvoicePayload(playerId, targetPlayerId, reason, amount)

            if not invoice then
                return
            end

            StartClient(playerId, "GenerateInvoiceFromServer", invoice)

            Framework.sendNotification(playerId, _U('INVOICES.INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER'), 'success')
        end

        CreateInvoice = function(playerId, targetPlayerId, amount, data)
            if not playerId then
                return
            end

            if not targetPlayerId then
                return
            end

            if not Utils.IsPlayerNearAnotherPlayer(playerId, targetPlayerId) then
                return
            end
            
            if not data then
                data = {}
            end

            local invoice = Framework.BuildInvoicePayload(playerId, targetPlayerId, data.reason, amount)

            if not invoice then
                return
            end

            StartClient(playerId, "GenerateInvoiceFromServer", invoice)

            Framework.sendNotification(playerId, _U('INVOICES.INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER'), 'success')
        end
    end
end)

