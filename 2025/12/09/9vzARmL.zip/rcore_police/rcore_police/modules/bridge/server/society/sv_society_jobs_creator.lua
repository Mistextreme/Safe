CreateThread(function()
    if Config.Society == Society.JOBS_CREATOR then
        ---@param business string
        ---@return number | nil
        SocietyService.GetMoney = function(business)
            if doesExportExistInResource(Society.JOBS_CREATOR, "getJobAccountMoney") then
                return safeNumber(exports[Society.JOBS_CREATOR]:getJobAccountMoney(business), 0)
            end

            return 0
        end


        --- @param business string Name of business
        --- @param amount number Amount of money be removed
        --- @return boolean
        SocietyService.RemoveMoney = function(business, amount)
            if doesExportExistInResource(Society.JOBS_CREATOR, "removeSocietyMoney") then
                return exports[Society.JOBS_CREATOR]:removeSocietyMoney(business, amount)
            end

            return false
        end

        --- @param business string Name of business
        --- @param amount number Amount of money be added
        --- @return boolean
        SocietyService.AddMoney = function(business, amount)
            if doesExportExistInResource(Society.JOBS_CREATOR, "addSocietyMoney") then
                return exports[Society.JOBS_CREATOR]:addSocietyMoney(business, amount)
            end

            return false
        end

        --- @param business string Name of business
        --- @return boolean
        SocietyService.Register = function(business)
            return true
        end

        SocietyService.StoreDepartmentVehicle = function(data, cb)
            local retval = false

            if not data then
                return
            end

            local account = SocietyService.GetAccount(data.department)

            if account and next(account) then
                account.AddMoney(data.spawnPrice)
                retval = true
            end

            cb(retval, data.spawnPrice)
        end

        SocietyService.BuyDepartmentVehicle = function(data, cb)
            local retval = false

            if not data then
                return
            end

            local account = SocietyService.GetAccount(data.department)

            if account and next(account) then
                local balance = account.GetBalance()

                if balance and balance >= data.spawnPrice then
                    retval = true
                end
            end

            cb(retval, data.spawnPrice)
        end

        SocietyService.GetAccount = function(businessName)
            local account = nil
            local accountBalance = SocietyService.GetMoney(businessName)
            
            if accountBalance and accountBalance >= 0 then
                account = {
                    AddMoney = function(amount) 
                        SocietyService.AddMoney(businessName, amount) 
                    end,
                    RemoveMoney = function(amount) 
                        SocietyService.RemoveMoney(businessName, amount) 
                    end,
                    GetBalance = function() 
                        return SocietyService.GetMoney(businessName)
                    end
                }
            else
                dbg.debug('Failed to get society account: %s', businessName)
            end
            
            dbg.debug('Returning society business: %s (named: %s)', account and "Account exists" or "Account is nil", businessName)
            
            return account
        end
    end
end)