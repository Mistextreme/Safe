CreateThread(function()
    if Config.Garages == Garages.CD_GARAGE then
        GarageService.GetVehicleProps = function(vehicleId)
            local retval = {}

            if Config.Framework == Framework.ESX then
                retval = Framework.object.Game.GetVehicleProperties(vehicleId)
            end

            return retval
        end

        GarageService.SetVehicleToImpound = function(vehicleId, vehicleProps)
            if not vehicleId then
                return
            end
            
            TriggerEvent('cd_garage:ImpoundVehicle', vehicleId)
        end
    end
end)
