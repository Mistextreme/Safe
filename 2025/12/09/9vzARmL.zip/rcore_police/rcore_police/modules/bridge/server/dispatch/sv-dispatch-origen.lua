CreateThread(function()
    if Config.Dispatch == Dispatch.ORIGEN then
        EmergencyCall = function(playerData)
            if not playerData then
                return
            end

            local playerId = playerData.playerId
            local jobName = playerData.group
            local citizenName = Framework.getCharacterShortName(playerId)
            local group = GroupsService.GetGroupByName(jobName)
            local dispatchMessage = _U('DISPATCH.OFFICER_SENT_EMERGENCY_CALL', citizenName)

            local mePed = GetPlayerPed(playerId)
            local pedCoords = GetEntityCoords(mePed)

            if group then
                if Config.EmergencyCall.CooldownState and not EmergencyCalls[playerId] then
                    EmergencyCalls[playerId] = true

                    SetTimeout(Config.EmergencyCall.Cooldown * 60 * 1000, function()
                        EmergencyCalls[playerId] = nil
                    end)

                    if not Config.PanicButton.DispatchDisableGroupNotify then
                        group:Notify(dispatchMessage)
                    end
            
                    group:StartEvent("RenderEmergencyBlip", pedCoords, dispatchMessage)
                elseif not Config.EmergencyCall.CooldownState then
                    group:Notify(dispatchMessage)
                    group:StartEvent("RenderEmergencyBlip", pedCoords, dispatchMessage) 
                end
            end

            exports['origen_police']:SendAlert({
                coords = pedCoords,
                title = _U("DISPATCH.OFFICER_SENT_EMERGENCY_CALL_TITLE"),
                type = 'GENERAL',
                message = dispatchMessage,
                job = PoliceJobs and PoliceJobs[0],
            })
        end
    end
end)