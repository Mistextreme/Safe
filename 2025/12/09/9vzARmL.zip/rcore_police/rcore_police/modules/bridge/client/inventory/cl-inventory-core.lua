CreateThread(function()
    if Config.Inventory == Inventory.CORE then
        --- @param targetPlayerId number Target player which inventory should be opened
        --- @return void
        OpenPlayerInventory = function(targetPlayerId)
            local animDict = "anim@gangops@morgue@table@"
            local animName = "player_search"
            local flag = 49

            if InventoryUtils.CanSearch(targetPlayerId) then
                CancellableProgress(
                    Config.SearchInventory,
                    _U("SEARCHING_CITIZEN"),
                    animDict,
                    animName,
                    flag,
                    function()
                        TriggerServerEvent('core_inventory:server:openInventory', targetPlayerId, 'otherplayer', nil, nil,
                            false)
                    end,
                    function()
                    end,
                    {
                        checkDistance = true,
                        target = targetPlayerId,
                    })
            end
        end

        OpenPersonalLocker = function(internalZone)
            local zone = internalZone.getZoneData()
            local zoneType = internalZone.getZoneType()

            if not zone then
                return
            end

            local ctx = InventoryUtils.GetStashContext(zoneType, zone, false)

            if not ctx then
                return dbg.critical("OpenPersonalLocker: Failed to generate context")
            end

            dbg.debug('OpenPersonalLocker: Function is not defined')
        end

        OpenEvidenceStash = function(internalZone)
            local zone = internalZone.getZoneData()
            local zoneType = internalZone.getZoneType()

            if not zone then
                return
            end

            local retval = UI.Input(_U('EVIDENCE.TITLE'), {
                {
                    label = _U('EVIDENCE.INPUT_LABEL'),
                    placeholder = _U('EVIDENCE.INPUT_PLACEHOLDER'),
                    type = "number",
                    required = true
                },
            })

            if not retval then return end

            local evidenceNumber = retval[tostring(0)]
            local ctx = InventoryUtils.GetStashContext(zoneType, zone, false, evidenceNumber)

            if not ctx then
                return dbg.critical("OpenEvidenceStash: Failed to generate context")
            end

            TriggerServerEvent('core_inventory:server:openInventory', ctx.formattedId, 'stash')
        end

        OpenJobStash = function(internalZone)
            local zone = internalZone.getZoneData()
            local zoneType = internalZone.getZoneType()

            if not zone then
                return
            end

            local retval = UI.Input(_U('JOB_STASH.TITLE'), {
                {
                    label = _U('JOB_STASH.INPUT_LABEL'),
                    placeholder = _U('JOB_STASH.INPUT_PLACEHOLDER'),
                    type = "number",
                    required = true
                },
            })

            if not retval then return end

            local jobSharedStorage = retval[tostring(0)]
            local ctx = InventoryUtils.GetStashContext(zoneType, zone, false, jobSharedStorage)

            if not ctx then
                return dbg.critical("OpenJobStash: Failed to generate context")
            end

            TriggerServerEvent('core_inventory:server:openInventory', ctx.formattedId, 'stash')
        end


        OpenWeaponStorage = function(internalZone)
            local zone = internalZone.getZoneData()
            local zoneType = internalZone.getZoneType()

            if not zone then
                return
            end

            local ctx = InventoryUtils.GetStashContext(zoneType, zone, false)

            if not ctx then
                return dbg.critical("OpenWeaponStorage: Failed to generate context")
            end

            dbg.debug('OPEN_WEAPON_SHOP: Function is not defined')
        end

        IsInventoryBusy = function()
            local retval = false

            if doesExportExistInResource(Config.Inventory, 'isInventoryOpen') then
                retval = exports.core_inventory:isInventoryOpen()
            end

            return retval
        end
    end
end)
