CreateThread(function()
    if Config.Garages == Garages.ESX_GARAGE then
        GarageService.GetVehicleProps = function(vehicleId)
            local retval = {}

            if Config.Framework == Framework.ESX then
                retval = Framework.object.Game.GetVehicleProperties(vehicleId)
            end

            return retval
        end

        GarageService.SetVehicleToImpound = function(vehicleId, vehicleProps)
            if not vehicleId then
                return
            end

            if not vehicleProps then
                return
            end

            TriggerServerEvent('esx_garage:setImpound', 'LosSantos', vehicleProps)
        end
    end
end)
