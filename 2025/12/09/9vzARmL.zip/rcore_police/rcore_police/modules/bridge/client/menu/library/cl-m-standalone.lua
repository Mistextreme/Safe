function UI:CreateMenuStandalone(name, menuLabel, receivedData, shouldOpen)
    
end

function UI:CloseMenuStandalone(name)
    
end
