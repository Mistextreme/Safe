Locales['fr'] = {
    NO_CITIZEN_NEARBY = 'Aucun citoyen à proximité !',
    SELECT_PLAYER_MENU_TITLE = 'Sélectionner des joueurs',
    CANNOT_PEFORM_UNDEFINED_ACTION = "Vous ne pouvez pas effectuer une action non définie !",
    YOU_ARE_AREADY_IN_PLACING_MODE = "Vous êtes déjà occupé par la tâche en cours !",

    UNLOCKING_VEHICLE = 'Déverrouillage du véhicule',

    RELEASE_PLAYER_TACKLE = "Libérer le joueur",
    CUFF_PLAYER_TACKLE = "Menotter le joueur et escorter",

    SEARCHING_CITIZEN = "Fouille du citoyen",

    OFFICER_SEARCH = "Vous fouillez un citoyen",
    SEARCH_TARGET = "Vous êtes en train d’être fouillé !",
    ACTION_REQUIRE_ADMIN_RIGHTS = "Vous devez avoir les droits administrateur pour utiliser ceci !",

    ACTIONS_REQUIRE_HANDSUP = "Le citoyen doit lever les mains !",
    ACTIONS_REQUIRE_CUFFED = "Le citoyen doit être menotté !",
    ACTIONS_REQUIRE_CUFFED_OR_HANDSUP = "Le citoyen doit être menotté ou avoir les mains en l'air !",
    ACTIONS_REQUIRE_CUFFED_OR_DEAD_SEARCH_INV =
    "Le citoyen doit être menotté ou mort pour que vous puissiez ouvrir son inventaire.",

    MEGAPHONE_NOT_USEABLE_IN_VEHICLE = "Le mégaphone ne peut pas être utilisé dans un véhicule !",
    ZIPTIES_INITIATOR = "Vous avez attaché un citoyen avec des liens!",
    ZIPTIES_TARGET = "Vous êtes attaché avec des liens par un citoyen!",

    ZIPTIES_INITIATOR_REMOVE = "Vous avez retiré les liens d’un citoyen!",
    ZIPTIES_TARGET_REMOVE = "Un citoyen a retiré les liens de vos mains.",

    PLAYER_IS_NOT_ZIPTIED = "Le citoyen n’est pas attaché avec des liens!",

    INTERACT_TARGET_PREFIX_JOB = "Police",
    PLAYER_NAME_INPUT_INVOICE = "Nom du joueur",
    PLAYER_NAME_INPUT = "Joueur cible",

    PLAYER_IS_NOT_HANDCUFFED = "Le citoyen n’est pas menotté !",
    YOU_DONT_HAVE_ITEM_IN_YOUR_INVENTORY = "Vous n’avez pas d’objet nommé %s pour cette action !",
    YOU_CANNOT_DO_THAT_WHILE_ESCORTING_PLAYER = "Vous ne pouvez pas effectuer cette action en escortant un citoyen !",

    TO_INTERACT_NEED_TO_FACE_TARGET = "Vous devez avoir le citoyen en vue pour effectuer une action !",

    PLAYER_ESCAPED_TACKLE = "Le joueur a échappé à la prise !",

    SENT_FINE = "Vous avez envoyé une amende au citoyen !",

    EMPTY_INVENTORY = "Rien trouvé dans l’inventaire",

    CITIZEN_MUST_CUFFED = "Le citoyen doit être menotté !",
    CITIZEN_NOT_IN_FRONT = "Vous devez faire face au citoyen !",

    NOT_MDT_LOADED_STANDALONE = "Impossible d’ouvrir votre MDT !",
    NOT_DISPATCH_PANEL_LOADED_STANDALONE = "Impossible d’ouvrir le panneau de dispatch !",

    STOP_ESCORT_LABEL = "Arrêter l’escorte",
    ATTEMPT_BREAK_LABEL = "Tenter de s’échapper",
    CUFF_LABEL = 'Menotter le citoyen',

    MINIGAME_ESCORT_ESCAPE_FOR_OFFICER = "Le citoyen s’est échappé de l’escorte !",
    MINIGAME_ESCORT_ESCAPE_FOR_TARGET = "Vous vous êtes échappé de l’escorte, courez !",

    ZIP_TIES = 'Serre-câbles',
    HANDCUFFS_KEY = "Clé des menottes",
    PAPERBAG = "Sac en papier",
    HANDCUFFS = "Menottes",
    BARRIER = "Barrière",
    ZIP_TIES_CUTTER = "Coupe-serre-câbles",
    MEGAPHONE = "Mégaphone",
    SPEEDCAMERA = "Radar de vitesse",
    SPIKES = "Hérissons",
    CAMERA = {
        TAKE_PHOTO_HELPKEY = "Prendre une photo",
        EXIT_HELPKEY = "Quitter",

        ZOOM_HELPTEXT = "Utilisez la molette pour zoomer",

        PROCESSING_PHOTO = "La photo est en cours de traitement !",
        PROCESSING_PHOTO_FINISHED = "La photo a été ajoutée à votre inventaire !"
    },
    INPUT_JAIL_PLAYER = {
        HEADER = 'Mettre en prison - durée',
        REASON_LABEL = 'Raison (optionnel)',
        JAIL_TIME_LABEL = 'Durée',
    },

    SELECT_PLAYERS = {
        PLAYER = 'Joueur',
    },

    SPEED_RADAR = {
        RECEIVED_FINE = 'Vous avez reçu une amende de %s %s pour excès de vitesse à %s.',
    },

    OUTFITS = {
        MENU_TITLE = 'Tenues de travail',
        RESTORE_OUTFIT_LABEL = 'Restaurer la tenue'
    },

    DYNAMIC_ACTION = {
        SELECT_KEY = 'Sélectionner',
        EXIT_KEY = 'Quitter',
    },

    VEHICLE_MENU = {
        UNLOCK_VEHICLE = 'Déverrouiller le véhicule',
        IMPOUND_VEHICLE = 'Mettre en fourrière',
        VEHICLE_INFORMATION = 'Informations sur le véhicule',
        VEHICLE_EXTRAS = 'Accessoires du véhicule',
    },

    ESCORT = {
        KEYMAP_DESCRIPTION = 'Menotter : (pendant l’escorte uniquement)',
        INITIATOR_PLAYER_RELEASED_FROM_SCORT = 'Vous avez libéré le citoyen de l’escorte !',
        TARGET_PLAYER_RELEASED_FROM_ESCORT = 'Vous avez été libéré de l’escorte !'
    },

    POINTS = {
        STORE_VEHICLE = 'Ranger le véhicule'
    },

    PROP_EDITOR = {
        PROP_FAR_AWAY_BLOCKED = 'L’objet est trop loin, cela bloque le placement !',
        CAN_PLACE_PROP = 'Vous pouvez placer l’objet !'
    },

    ZONES_LABELS = {
        WRITE_REPORT = "Rédiger un rapport",
        REPORTS = "Rapports",
        WEAPON_STORAGE = 'Stockage d’armes',
        WEAPON_SHOP = 'Magasin d’armes',
        GARAGE_VEHICLE = 'Garage de travail',
        BOSS_MENU = 'Menu du chef',
        DUTY = 'Service',
        JOB_STASH = 'Stockage partagé du travail',
        PERSONAL_LOCKER = 'Casier personnel',
        EVIDENCE_STASH = 'Stockage des preuves',
        OUTFIT_ROOM = 'Vestiaire',
    },

    NOTIFY = {
        COPY_VALUE = 'Vous avez copié la valeur : %s'
    },

    VEHICLE_INFO = {
        MENU_TITLE = 'Informations sur le véhicule',

        PG_LABEL = 'Traitement des informations du véhicule.',

        VEHICLE_PLATE = 'Plaque d’immatriculation',
        VEHICLE_OWNER_NAME = 'Propriétaire',
        VEHICLE_NAME = 'Nom du véhicule',
        OWNER_PHONE_NUMBER = 'Téléphone du propriétaire',
        OWNER_IDENTIFIER = 'Identifiant d’état',
    },

    EVIDENCE = {
        TITLE = 'Stockage des preuves',
        INPUT_LABEL = 'Numéro de preuve',
        INPUT_PLACEHOLDER = '1'
    },

    JOB_STASH = {
        TITLE = 'Stockage du travail',
        INPUT_LABEL = 'Numéro de stockage',
        INPUT_PLACEHOLDER = '1'
    },

    STASHES = {
        PERSONAL_LOCKER_LABEL = 'Casier personnel',
        EVIDENCE_STASH_LABEL = 'Stockage des preuves : %s',
        JOB_STASH_LABEL = 'Stockage du travail : %s',
    },

    JOB_MENU = {
        MENU_TITLE = 'Menu du travail',
    },

    INTERACTIONS = {
        OFFICER_JAILED_TARGET = 'Vous avez envoyé le citoyen en prison !'
    },

    MENUS = {
        MAIN_MENU_PROPS_TITLE = 'Objets',
        MAIN_MENU_VEHICLE_INTERACTIONS_TITLE = 'Interactions avec les véhicules',
        MAIN_MENU_CITIZEN_TITLE = 'Interactions avec les citoyens',

        FROM_VEHICLE = 'Depuis le véhicule',
        IN_VEHICLE = 'Dans le véhicule',


        CITIZEN_SUB_MENU_ESCORT_PLAYER_TITLE = 'Escorter le joueur',
        CITIZEN_SUB_MENU_CUFF_SOFT_TITLE = 'Menotter',
        CITIZEN_SUB_MENU_SENT_TO_JAIL_TITLE = 'Envoyer en prison',
        CITIZEN_SUB_MENU_SENT_TO_COMS_TITLE = 'Envoyer aux COMS',
        CITIZEN_SUB_MENU_INVOICE_TITLE = 'Amende',
        CITIZEN_SUB_MENU_SEARCH_PLAYER_TITLE = 'Fouiller le joueur',
        CITIZEN_SUB_MENU_SHOW_PLAYER_LICENSES = 'Montrer les licences du joueur',

        GO_BACK_BUTTON_LABEL = 'Retour au menu précédent',
    },

    SEARCH_PLAYER = {
        ITEM_CONSFICATED = 'L’objet a été confisqué (%s) par l’officier !',
        ITEM_CONFISCATED_BY_OFFICER = 'Vous avez confisqué l’objet nommé %s au citoyen !',
    },

    MENU_INTERACT = {
        NOT_CLOSE_TO_ANY_VEHICLE = 'Vous n’êtes pas près d’un véhicule !'
    },

    INVOICES = {
        INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER = 'Amende envoyée avec succès',
        TARGET_SUCCESS_RECEIVED_INVOICE_FROM_PLAYEr = 'Vous avez reçu une amende !',

        INPUT_INVOICE_MENU_TITLE = 'Menu des amendes',
        INPUT_INVOICE_FINE_LABEL = 'Montant de l’amende :',
        INPUT_INVOICE_SUBMIT_LABEL = 'Envoyer'
    },

    LICENSES = {
        MENU_TITLE               = "Licences",
        CONFISCATED              = 'Votre licence %s a été confisquée !',
        RECEIVED_LICENSE         = 'Vous avez obtenu une licence nommée : %s',
        YOU_ALREADY_HAVE_LICENSE = 'Impossible de vous donner la licence %s, vous l’avez déjà !',
        YOU_DONT_HAVE_LICENSE    = 'Impossible de retirer votre licence %s, vous ne l’avez pas !',
        HAS_LICENSE              = 'Oui',
        NO_LICENSE               = 'Non',
    },

    DISPATCH = {
        OFFICER_SENT_EMERGENCY_CALL_TITLE = 'Alerte d’urgence',
        OFFICER_SENT_EMERGENCY_CALL = '%s a envoyé un appel d’urgence, besoin d’aide !'
    },

    PROPS = {
        FAILED_TO_SPAWN_PROP = 'Impossible de charger %s, car il n’est pas défini !',
        PICKING_UP_PROP = 'Ramassage de l’objet : %s',
        PLACING_OBJECT = "Placement de l’objet : %s",
        CANCELING_PLACING = "Vous abandonnez le placement de l’objet : %s",
        FAILED_PLACING = "Échec du placement de l’objet : %s",
        ALREADY_PICKING_UP = 'Quelqu’un est déjà en train de retirer l’objet !',
        CANNOT_PLACE_ON_ANOTHER_OBJECT = 'Il y a déjà un objet à cet endroit !',
        HELP_TEXT = "Ramasser l’objet",
        YOU_DONT_HAVE_ITEM_IN_INVENTORY = "Vous n’avez pas cet objet nommé %s dans votre inventaire !",
    },

    CAMERA_SPEED_RADAR = {
        TITLE = "Radar caméra",
        INPUT_SPEED_LABEL = "Type de vitesse : %s",
        INPUT_SPEED_PLACEHOLDER = "Définir la vitesse maximale",
        INPUT_FINE_LABEL = "Amende",
        INPUT_FINE_PLACEHOLDER = "Définir l’amende",
        INPUT_BLIP_LABEL = "Afficher un marqueur sur la carte :",
    },

    FINES = {
        HEADER_MENU_TITLE = 'Amendes',
        HEADER_MENU_LABEL_PREFIX = "Prix de l’amende : %s",
    },

    WEAPON_SHOP = {
        MENU_TITLE = 'Armurerie',
        MENU_WEAPON_LABEL = ('%s : %s %s'),
        MENU_WEAPON_LABEL_FREE = ('%s : Gratuit'),
        BUY_WEAPON_FAILED_NOT_ENOUGH_PERMS =
        'Échec de l\'obtention de l\'objet : %s, car votre grade est insuffisant pour l\'acheter !',
        BUY_WEAPON_FAILED_NOT_ENOUGH_BALANCE = 'Échec de l’obtention de l’objet : %s, solde insuffisant pour l’acheter !',
        BUY_WEAPON_FAILED_NOT_WEAPON_LICENSE =
        'Échec de l’obtention de l’objet : %s, vous n’avez pas de licence d’arme !',
        BUY_WEAPON_SUCCESS = 'Vous avez obtenu l’objet nommé : %s dans la boutique du département !',

        DIALOG_TITLE = 'Objet : %s',
        DIALOG_INPUT_TITLE = "Définir la quantité",
        DIALOG_DSC = 'Êtes-vous sûr de vouloir obtenir cet objet dans la boutique du département ?',
    },

    GARAGE = {
        MENU_TITLE = 'Garage de travail',
        NOT_FREE_PARKING_SPACE = 'Impossible de récupérer un véhicule du garage, il n’y a pas de place libre !',
        NOT_ENOUGH_MONEY_IN_SOCIETY_TO_GET_VEHICLE =
        'Votre département n’a pas assez d’argent %s %s pour récupérer un véhicule du garage !',
        NOT_ENOUGH_MONEY_IN_BANK_TO_GET_VEHICLE = 'Vous n’avez pas assez d’argent %s %s sur votre compte bancaire !',
        NOT_DEPARTMENT_VEHICLE =
        "Vous ne pouvez pas ranger un véhicule qui ne fait pas partie du garage du département !",
        VEHICLE_WAS_STORED = 'Le véhicule a été rangé dans le garage !',
        VEHICLE_BOUGHT = 'Vous avez acheté avec succès un véhicule du département pour %s %s',
        PAYDIALOG_TITLE = 'Payer pour le véhicule nommé %s',
        PAYDIALOG_DESC = 'Sélectionnez une option de paiement pour récupérer le véhicule du garage !',
        IMPOUND_ACTION = 'Envoi du véhicule à la fourrière',

        GARAGE_ORDER_VEHICLE_SUCC = 'Vous avez commandé %s véhicules pour le prix de %s %s !',
        GARAGE_ORDER_VEHICLE_FAIL = 'Pas assez d’argent dans le département pour commander des véhicules %s %s !',

        GARAGE_REQUEST_VEH_SUCC = 'Véhicule récupéré du garage !',
        GARAGE_REQUEST_VEH_FAILURE = 'Pas assez de véhicules dans le garage !',

        INPUT_TITLE = "Commander un véhicule",
        INPUT_LABEL = "Définir la quantité",
        INPUT_PLACEHOLDER = "10"
    },

    BOSS_MENU = {
        HEADER_TITLE_MENU = "Département",
        TITLE_MENU = "Menu du patron",
        TITLE_ORDER = "Commander des véhicules",
        YOU_HIRED_PLAYER = "Vous avez embauché le citoyen %s pour le poste !",
        YOU_HIRED_BY_INITIATOR = "Vous avez été embauché pour le poste nommé %s par %s"
    },


    IMPOUNDS = {
        VEHICLE_SENT_TO_IMPOUND = "Le véhicule a été envoyé à la fourrière !",
        VEHICLE_REVOKE_SENT_TO_IMPOUND = "Votre action a été annulée !"
    },

    PROGRESS_BAR = {
        CANCEL_ACTION_LABEL = "Annuler"
    },

    PERSONAL_STORAGE = {
        TITLE = 'Stockage personnel',
    },

    DUTY = {
        TITLE = 'Service du département',
        ON_DUTY_SERVICE_MSG = 'En service',
        OFF_DUTY_SERVICE_MSG = 'Hors service',

        NEED_TO_BE_ON_DUTY_TO_INTERACT_WITH_ZONE = 'Vous devez être en service pour pouvoir interagir',
        NEED_TO_BE_ON_DUTY_TO_OPEN_MENU = 'Vous devez être en service pour ouvrir ce menu !',
        YOU_ARE_IN_SERVICE = 'Vous êtes en service !',
        YOU_ARE_OFF_SERVICE = 'Vous êtes hors service !',
        COOLDOWN = 'Veuillez attendre avant de faire une autre action !'
    },

    REPORTS = {
        PLAYER_SUBMITTED_REPORT = 'Votre rapport a été envoyé !',
        PLAYER_REACHED_MAXIMUM_OPEN_REPORT =
        'Vous avez déjà ouvert un rapport, attendez un peu avant d’en ouvrir un nouveau !',
        PLAYER_DELETED_REPORT = "Le rapport a été supprimé !",

        RECEIVED_NEW_REPORT_OFFICERS = "Un nouveau rapport a été soumis par un citoyen !",

        OFFICER_UPDATED_REPORT_NOTE = "Note du rapport (%s) mise à jour à %s par %s",
        OFFICER_UPDATED_REPORT_STATUS = "Statut du rapport (%s) mis à jour à %s par %s",

        INPUT_TITLE = "Signaler un incident",
        INPUT_YOUR_NAME = "Votre nom",
        INPUT_PHONE_NUMBER = "Numéro de téléphone",
        INPUT_DETAILS = "Message"
    },

    RADIAL_MENU = {
        CUFF_LABEL = "Menotter",
        ESCORT_LABEL = "Escorter",
        LICENCES_LABEL = "Licences",
        IN_VEHICLE_LABEL = "Mettre dans",
        FROM_VEHICLE_LABEL = "Sortir",
        SEARCH_LABEL = "Fouiller",
        JAIL_LABEL = "Emprisonner",
        EMERGENCY_LABEL = "Urgence",
        FINE_LABEL = "Amende",
        MDT_LABEL = "MDT",

        PROP_SPEED_RADAR_LABEL = "Radar de vitesse",

        MAIN_MENU_TITLE = "Menu principal",
        POLICE_MENU_TITLE = "Autres",
        DISPATCH_LABEL = "Dispatch",
        IMPOUND_VEHICLE = "Mettre en fourrière",
        UNLOCK_VEHICLE = "Déverrouiller le véhicule",
        VEHICLE_INFO = "Infos véhicule",
        COMS = "COMS",
        RADAR = "Radar",
        MEGAPHONE = "Mégaphone",
        SPIKES = "Hérissons",
        BARRIER = "Barrière",
    },

    NO_REQUIRED_JOB = "Vous n’êtes pas dans le département de police pour effectuer cette action !",
    CURRENCY_SYMBOL = '$',

    KEY_MAPPING = {
        EXIT_BODYCAM = "Quitter la caméra corporelle",
        RADIAL_MENU = "Ouvrir le menu radial",
        JOB_MENU = "Ouvrir le menu du travail",
        TACKLE_CUFF_AND_ESCORT_PLAYER = 'Escorter et menotter le joueur',
        TACKLE_PLAYER = "Plaquer un joueur à proximité",
        TACKLE_STOP = 'Arrêter le plaquage',
        INTERACT_ZONE = "Interagir avec la zone",
        ESCORT_ESCAPE = "Échapper à l’escorte",
        HANDS_UP = "Mains en l’air",
        STOP_ESCORT = "Arrêter l’escorte",
        MEGAPHONE_STATE = 'Proximité du mégaphone',
        MEGAPHONE_EXIT = 'Arrêter d’utiliser le mégaphone'
    },

    HANDCUFF_INITIATOR = "Vous menottez un citoyen !",
    HANDCUFF_TARGET = "Vous êtes menotté par un officier !",

    HANDCUFF_INITIATOR_REMOVE = "Vous avez retiré les menottes au citoyen !",
    HANDCUFF_TARGET_REMOVE = "L’officier a retiré les menottes de vos mains.",

    ESCORT_INITIATOR = "Vous escortez un citoyen !",
    ESCORT_TARGET = "Vous êtes escorté par un officier !",

    ESCORT_INITIATOR_PED_REMOVE = "Vous avez arrêté d’escorter le citoyen !",
    ESCORT_TARGET_PED_REMOVE = "L’officier a arrêté de vous escorter !",

    NO_LICENCE_FOUND = "Le citoyen n’a aucune licence !",

    VEHICLE_UNLOCKED = 'Véhicule déverrouillé',

    TARGET = {
        HANDCUFF = "Menotter/Démenotter",
        SEARCH_PLAYER = "Fouiller le joueur",
        ESCORT = "Escorter",
        PUT_IN_VEHICLE = "Mettre dans le véhicule",
        FROM_VEHICLE = "Sortir le citoyen",
    },

    MEGA_PHONE = {
        TURN_STATE = 'Allumer / Éteindre',
        EXIT = 'Quitter',
        IS_OFF = 'Proximité : Inactif',
        IS_ON = 'Proximité : Actif',
    },

    BODYCAMS = {
        ACTIVATED = "La caméra corporelle est active !",
        DEACTIVATED = "La caméra corporelle est éteinte !",

        LABEL_OFFICER = "Officier",
        LABEL_CAMERA_ID = "ID de la caméra corporelle",
        LABEL_LOCATION = "Emplacement",
        LABEL_EXIT = "Quitter la caméra corporelle"
    },

    PAPER_BAG = {
        INITIATOR_ADDED_ON_TARGET = 'Vous avez mis un sac en papier sur le citoyen !',
        INITIATOR_REMOVED_FROM_TARGET = 'Vous avez retiré le sac en papier du citoyen',
    },

    JOB = {
        SET_BUSINESS_JOB_USE_CASE = 'Utilisation : /setjob [ID joueur] [nom du travail] [grade du travail]',
        SET_BUSINESS_INVALID_JOB = 'Vous devez taper l’un de ces mots : police',
        SET_BUSINESS_INVALID_GRADE = 'Ce grade n’existe pas dans ce travail',
        NOT_ENOUGH_PERMS_TO_ACCESS = 'Votre rang (%s) n’a pas accès à ceci !',

        REMOVED_FROM_PLAYER = 'Vous avez retiré le travail à ce joueur : %s.',
        ADD_TO_PLAYER = 'Vous avez ajouté un travail à ce joueur : %s avec le grade : %s',
        INVALID_TARGET = 'Veuillez spécifier l’ID du joueur cible',
    },

    BLIPS = {
        GPS_COOLDOWN  = "Veuillez patienter avant d’utiliser à nouveau le GPS !",
        GPS_TURN_ON   = "Vous avez activé votre GPS !",
        GPS_TURN_OFF  = "Votre GPS a été désactivé.",

        SUBSCRIBE_ON  = "Vous pouvez maintenant voir vos collègues sur la carte.",
        SUBSCRIBE_OFF = "Les blips de vos collègues ont été masqués de la carte.",
    },

    COMMANDS_HELP_TEXT = {
        SHOW_BLIPS = "Commande utilisée pour activer/désactiver l’affichage des blips de collègues.",

        PANIC_BUTTON = "Utilisateur de la commande du bouton de panique de l’officier",
        SEARCH_PLAYER = 'Commande utilisée pour fouiller un joueur.',
        ESCORT_PLAYER = 'Commande utilisée pour escorter un joueur.',
        PUT_PLAYER_IN_VEH = 'Commande utilisée pour mettre le joueur dans un véhicule.',
        GET_PLAYER_FROM_VEH = 'Commande utilisée pour sortir le joueur du véhicule.',
        PRESET_CREATOR = 'Outil pour créer un preset de département.',
        SET_PLAYER_JOB = 'Commande utilisée pour définir le travail d’un citoyen.',
        REMOVE_PLAYER_JOB = 'Commande utilisée pour supprimer le travail actuel d’un citoyen',
        GRANT_LICENCE = 'Commande utilisée pour accorder une licence à un citoyen.',
        REVOKE_LICENCE = 'Commande utilisée pour révoquer une licence d’un citoyen.'
    },

    HELP_MESSAGES = {
        NO_TARGET_NIL = 'Veuillez spécifier l’ID du citoyen cible !',
        NO_TARGET_OFFLINE = 'Ce citoyen spécifié n’est pas trouvé en ligne avec cet ID !',
        NO_ACCESS = 'Vous n’avez pas accès à cette commande !',
        NO_VALID_LICENCE =
        'Licence invalide : %s - veuillez sélectionner l’une de ces options : permis de conduire, arme, commerce !'
    },

    SUGGESTIONS = {
        KEY_NUMBER = 'nombre',
        KEY_STRING = 'chaîne',

        PRESET_CREATOR = '',
        HELP_PRESET_CREATOR = '',

        HELP_PLAYERID = 'ID du joueur cible',
        HELP_JOB = 'Spécifier le travail du citoyen : police',
        HELP_JOB_GRADE = 'Spécifier le grade du citoyen : 1-4',
        HELP_LICENCE = 'Spécifier la licence du citoyen : permis de conduire, commerce, arme'
    },

    RADAR = {
        LOCK_TOGGLE_OFF = 'Verrouillage du radar désactivé',
        LOCK_TOGGLE_ON = 'Verrouillage du radar activé',
    },

    PRESET_CREATOR = {
        HELP_KEY_TITLE = "Création de département",
        HELP_KEY_REMAINING_COUNT = "Nombre restant",
        HELP_KEY_TASK = "Tâche",
        HELP_KEY_ZONE_OWNER = "Propriétaire de la zone",
        HELP_KEY_RESOURCE = "Ressource",
        HELP_KEY_SAVE_POINT = "Sauvegarder le point actuel",

        DIALOG_CONFIRM_TITLE = "Définir le point",
        DIALOG_CONFIRM_DESC = "Vérifier",

        DIALOG_RESOURCE_TITLE = "Sélectionner une ressource",
        DIALOG_ZONE_OWNER = "Propriétaire de la zone",
        DIALOG_PRESET_TOOL_TITLE = 'Outil de preset',

        NOT_ENOUGH_PERMISSION = "Vous n’avez pas accès à l’utilisation du créateur de presets !",

        CLOSE_POINT = "Placement trop proche d’un point existant. Minimum 2m requis",
    },

    BOSS_MENU_ACTIONS = {
        SET_BONUS = 'Bonus envoyé avec succès à %s pour un montant de %s %s.',
        PROMOTE_CITIZEN = 'Promotion réussie de %s à %s !',

        DEPOSIT_SOCIETY_MONEY = 'Vous avez déposé avec succès %s %s dans la société.',
        WIDTHRAW_SOCIETY_MONEY = 'Vous avez retiré avec succès %s %s de la société.',
    },

    TITLE_NOTIFY = 'Général',

    UI = {
        MONEY_SYMBOL = '$',

        VIEW_PHOTO = {
            STATE_LOADING = "Chargement de l'image...",
            NOT_FOUND_TITLE = "Image introuvable",
            NOT_FOUND_DESC = "Cette image n'existe pas",
            DATE = "Date",
            LOCATION = "Lieu",
        },

        BOSS_MENU = {
            PAGE_DASHBOARD_BUTTON_NAVBAR_LABEL = "Tableau de bord",
            PAGE_DASHBOARD_BUTTON_FIRE_LABEL = "Licencier",
            PAGE_DASHBOARD_SELECT_EMPLOYEE_LABEL = "Sélectionnez un employé à gauche pour gérer.",
            PAGE_DASHBOARD_CHANGE_GRADE_LABEL = "Changer de grade :",
            PAGE_DASHBOARD_SET_BONUS_LABEL = 'Bonus',
            PAGE_DASHBOARD_SET_GRANT_BONUS_TITLE = 'Accorder un bonus :',
            PAGE_DASHBOARD_MANAGE_BUTTON_LABEL = "Gérer",

            PAGE_DASHBOARD_EMPLOYEE_ROW = "Employé",
            PAGE_DASHBOARD_GRADE_ROW = "Grade",
            PAGE_DASHBOARD_OPTION_ROW = "Option",

            PAGE_DASHBOARD_EMPLOYEES_TITLE = "Employés",
            PAGE_DASHBOARD_EMPLOYEES_TOTAL = "Total",

            PAGE_DASHBOARD_QUICK_ACTION_TITLE = "Solde de la société",
            PAGE_DASHBOARD_QUICK_ACTION_DEPOSIT_LABEL = "Déposer",
            PAGE_DASHBOARD_QUICK_ACTION_WIDTHRAW_LABEL = "Retirer",

            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_TITLE = "Changer de grade",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DESC = "Pour %s à %s",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DIALOG_OPTIONS_LABEL = "Confirmer le changement de grade",

            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_TITLE = "Changer de grade",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DESC = "Renvoyer %s du travail",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DIALOG_OPTIONS_LABEL = "Confirmer le renvoi du citoyen",

            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_TITLE = "Société",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_LABEL = "Montant du dépôt",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_PLACE_HOLDER = "Entrez le montant à déposer",

            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_TITLE = "Société",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_LABEL = "Montant du retrait",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_PLACE_HOLDER = "Entrez le montant à retirer",

            PAGE_GARAGE_TITLE = "Garage du département",
            PAGE_GARAGE_BUTTON_NAVBAR_LABEL = "Garage",
            PAGE_GARAGE_STOCK_BALANCE = "Solde des stocks :",
            PAGE_GARAGE_ORDER_BUTTON_LABEL = "Commander",

            PAGE_GARAGE_ORDER_DIALOG_TITLE = "Société",
            PAGE_GARAGE_ORDER_DIALOG_LABEL = 'Montant de la commande',
            PAGE_GARAGE_ORDER_DIALOG_PLACEHOLDER = 'Entrez le montant à commander',

            NAVBAR_TITLE = "TITRE",
            NAVBAR_DESC = "Système de gestion du menu du chef"
        },

        DIALOG = {
            CANCEL_BUTTON = "Annuler",
            CONFIRM_BUTTON = "Confirmer",

            VALIDATION_INPUT_REQUIRED_STRING = "est requis",
            VALIDATION_INPUT_LESS_THAN = "doit contenir moins de caractères",

            VALIDATION_NUMBER_REQUIRED_NAN = "doit être supérieur à 0",
            VALIDATION_NUMBER_REQUIRED = "est requis",

            TEXT_AREA_IS_REQUIRED = "est requis",
            TEXT_AREA_INPUT_LESS_THAN = "doit contenir moins de caractères",
        },

        SHOP = {
            BUY = "Acheter",
            TAKE = "Prendre",
            FREE = "Gratuit",
            NO_ITEMS = "Aucun objet trouvé dans le magasin",
            CHECK_BACK_SOON = "Réessayez plus tard, s’il vous plaît",
            TITLE = "Magasin du département",
            DESCRIPTION = "Sélectionnez l’objet que vous souhaitez obtenir.",
        },

        BOSS_MENU_GARAGE_STOCK = {
            ORDER_NOT_ENOUGH_BUTTON = "Stock vide",
            ORDER_HAS_BUTTON = "Commander",
        },

        GARAGE = {
            BUY = "Acheter",
            TAKE = "Prendre",
            FREE = "Gratuit",

            TITLE = "Garage du département",
            DESCRIPTION = "Sélectionnez le véhicule que vous souhaitez obtenir."
        },

        PAY_DIALOG = {
            CONFIRM_FREE = "Envoyer",
            COMPANY_BUTTON_LABEL = "Société",
            BANK_BUTTON_LABEL = "Banque",
            INPUT_PLACEHOLDER = "0",
        },

        POLICE_RADAR = {
            PAGE_RADAR = "Radar",
            SETTINGS_RADAR = "Paramètres",

            FRONT_RADAR_TITLE = "Antenne avant",
            REAR_RADAR_TITLE = "Antenne arrière",
            FAST_LOCK_LABEL = "Verrouillage rapide",

            PLATE_READER_FRONT = "Avant",
            PLATE_READER_REAR = "Arrière",
            PATROL_SPEED = "Vitesse de patrouille",

            RECENT_PLATE = "Plaque",
            RECENT_MODEL = "Modèle",
            RECENT_SPEED = "Vitesse",
            RECENT_LABEL = "Étiquette",

            SPEED_TITLE = "Vitesse",
        },

        MENU_SETTINGS = {
            TITLE = "Radar policier",
            DESC = "Modifier vos paramètres",

            RADAR_SCALE = "Échelle du radar",
            RADAR_SCALE_DESC = "Ajuster la taille du radar à l’écran",

            RESET_RADAR_POSITION = "Position du radar",
            RESET_RADAR_POSITION_DESC = "Réinitialiser à la position par défaut",
            RESET_RADAR_POSITION_BUTTON = "Réinitialiser",

            RESET_SCALE_POSITION = "Échelle du radar",
            RESET_SCALE_POSITION_DESC = "Réinitialiser à l’échelle par défaut",
            RESET_SCALE_BUTTON = "Réinitialiser",

            MISC_SECTION = "DIVERS",
            FAST_LIMIT = "Limite rapide",
            FAST_LIMIT_DESC = "Contrôler la limite de vitesse",
            RESET_SETTINGS = "Réinitialiser les paramètres",

            RESET_LABEL = "Réinitialiser le scanner",
            RESET_DESC = "Permet de réinitialiser le scanner",
            RESET_RADAR_BUTTON = "Réinitialiser",

            RADAR_SECTION = "Radar",
            TOGGLE_RADAR = "Activer/Désactiver le radar",
            TOGGLE_RADAR_DESC = "Afficher / Masquer le radar",

            TOGGLE_RADAR_MOVEMENT = "Activer/Désactiver le déplacement du radar",
            TOGGLE_RADAR_MOVEMENT_DESC = "Permet de déplacer le radar.",

            RECENT_PLATES_TITLE = "Plaques récentes",
            RECENT_PLATES_DESC = "Historique des plaques scannées",
            RECENT_PLATES_BUTTON = "Afficher/Masquer",
        },

        RECENT_PLATES = {
            TITLE = "Plaques récentes",
            DESC = "Historique des voitures récemment scannées",

            NO_HISTORY = "Aucun historique pour le radar actuel !",
            FILTER_LABEL = "Filtrer par",

            NEXT_PAGE = "Suivant",
            PREVIOUS_PAGE = "Précédent",
            RETURN_TO_SETTINGS_BUTTON_LABEL = "Retour aux paramètres",
        },

        BODYCAMS = {
            TITLE = "Flux des caméras corporelles",
            DESC = "Flux actuel des caméras actives de vos officiers !",
            NOT_ACTIVE_TITLE = "Aucune caméra corporelle active !",
            NOT_ACTIVE_DESC =
            "Il n’y a actuellement aucune caméra corporelle active disponible pour voir le flux en direct",

            CAMERA_ID = "Caméra :",
            OFFICER = "Officier :",
            LOCATION = "Emplacement :",

            VIEW_FEED_BUTTON_TITLE = "Voir le flux",
        },

        REPORTS = {
            FILTER_LABEL = "Filtres",
            MAIN_MENU_TITLE = "Rapports",
            MAIN_MENU_DESC = "Ici, vous pouvez voir tous les rapports des citoyens.",

            HEADER_PLAYER = "Citoyen",
            HEADER_PHONE = "Téléphone",
            HEADER_STATUS = "Statut",
            HEADER_ACTIONS = "Action",

            ACTIONS_REPORT_OPEN = "Afficher le rapport",
            ACTIONS_REPORT_CLOSE = "Fermer le rapport",

            STATE = "État du rapport",
            STATUS_OPTIONS = "Sélectionner l’état du rapport",
            UPDATE_STATUS = "Mettre à jour le statut",
            SAVE_STATUS = "Sauvegarder le statut",

            ADD_NOTE = "Ajouter une note",
            SAVE_NOTE = "Sauvegarder la note",
            SAVE = "Sauvegarder",

            NOTE_PLACEHOLDER = "Ajoutez votre note au rapport",

            DELETE_REPORT = "Supprimer le rapport",
            BACK_TO_REPORTS = "Retour aux rapports",

            NO_REPORTS_FOUND = "Aucun résultat.",

            PREVIOUS_BUTTON = "Précédent",
            NEXT_PREVIOUS_BUTTON = "Suivant",

            REPORT_TITLE = "Détails du rapport :",
            REPORT_PLAYER_NAME = "Nom du citoyen :",
            REPORT_MESSAGE = "Message",
            REPORT_PLAYER_PHONE = "Téléphone :",
            REPORT_STATUS = "Statut :",
            REPORT_NOTE = "Note :",

            STATES_NEW_REPORT = "Nouveau rapport",
            STATES_IN_REVIEW = "En cours de révision",
            STATES_RESOLVED = "Résolu",
        },

        RADIAL_MENU = {
            PRESS_LABEL = "Appuyer",
            GO_BACK_LABEL = "Retour",
        },

        GO_BACK_BUTTON = "◀ Retour"
    }
}
