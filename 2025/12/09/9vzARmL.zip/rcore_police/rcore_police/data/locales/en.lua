Locales['en'] = {
    NO_CITIZEN_NEARBY = 'No citizen nearby!',
    SELECT_PLAYER_MENU_TITLE = 'Select players',
    CANNOT_PEFORM_UNDEFINED_ACTION = "You cannot perform undefined action!",
    YOU_ARE_AREADY_IN_PLACING_MODE = "You are already ocuppied with current task!",

    UNLOCKING_VEHICLE = 'Unlocking vehicle',

    RELEASE_PLAYER_TACKLE = "Release player",
    CUFF_PLAYER_TACKLE = "Cuff player & escort",

    SEARCHING_CITIZEN = "Searching citizen",

    OFFICER_SEARCH = "You are searching citizen",
    SEARCH_TARGET = "You are being searched!",

    ACTION_REQUIRE_ADMIN_RIGHTS = "You need to have admin rights to use this!",

    ACTIONS_REQUIRE_HANDSUP = "Citizen needs to have hands up!",
    ACTIONS_REQUIRE_CUFFED = "Citizen needs to have cuffed hands!",
    ACTIONS_REQUIRE_CUFFED_OR_HANDSUP = 'Citizen needs to be cuffed or have handsup!',
    ACTIONS_REQUIRE_CUFFED_OR_DEAD_SEARCH_INV =
    "Citizen needs to be neither cuffed nor dead, you can't open their inventory",

    PLAYER_NAME_INPUT_INVOICE = "Player name",
    PLAYER_NAME_INPUT = "Target player",

    MEGAPHONE_NOT_USEABLE_IN_VEHICLE = "Megaphone cannot be used in vehicle!",

    PLAYER_IS_NOT_HANDCUFFED = "Citizen is not handcuffed!",
    PLAYER_IS_NOT_ZIPTIED = "Citizen is not ziptied!",

    YOU_DONT_HAVE_ITEM_IN_YOUR_INVENTORY = "Your dont have item named %s for this action!",
    YOU_CANNOT_DO_THAT_WHILE_ESCORTING_PLAYER = "You cannot do this action while escorting citizen!",

    TO_INTERACT_NEED_TO_FACE_TARGET = "You need have vision on citizen to be able perform action!",

    PLAYER_ESCAPED_TACKLE = "Player escaped from tackle!",

    SENT_FINE = "You sent fine to citizen!",

    EMPTY_INVENTORY = "Nothing found in inventory",

    CITIZEN_MUST_CUFFED = "Citizen must be cuffed!",
    CITIZEN_NOT_IN_FRONT = "You need to face citizen!",

    NOT_MDT_LOADED_STANDALONE = "Failed to open your MDT!",
    NOT_DISPATCH_PANEL_LOADED_STANDALONE = "Failed to open dispatch panel!",

    STOP_ESCORT_LABEL = "Stop Escort",
    ATTEMPT_BREAK_LABEL = "Attempt break",
    CUFF_LABEL = 'Handcuff citizen',

    MINIGAME_ESCORT_ESCAPE_FOR_OFFICER = "Citizen escaped from escort!",
    MINIGAME_ESCORT_ESCAPE_FOR_TARGET = "You escaped from escort, run!",

    UNDEFINED_ITEM_ERROR = 'Undefined item named %s doesnt exist on your server!',

    ZIP_TIES = 'Zip ties',
    HANDCUFFS_KEY = "Handcuffs key",
    PAPERBAG = "Paper Bag",
    HANDCUFFS = "Handcuffs",
    BARRIER = "Barrier",
    ZIP_TIES_CUTTER = "Zip ties cutter",
    MEGAPHONE = "Megaphone",
    SPEEDCAMERA = "Speed camera",
    SPIKES = "Spikes",

    INPUT_JAIL_PLAYER = {
        HEADER = 'Jail player - time',
        REASON_LABEL = 'Reason (optional)',
        JAIL_TIME_LABEL = 'Amount',
    },

    SELECT_PLAYERS = {
        PLAYER = 'Player',
    },

    CAMERA = {
        TAKE_PHOTO_HELPKEY = "Take photo",
        EXIT_HELPKEY = "Exit",

        ZOOM_HELPTEXT = "Use scroll to zoom",

        PROCESSING_PHOTO = "Photo is being processed!",
        PROCESSING_PHOTO_FINISHED = "Photo is added into your inventory!"
    },



    SPEED_RADAR = {
        RECEIVED_FINE = 'You received fine %s %s for speeding in %s.',
    },

    OUTFITS = {
        MENU_TITLE = 'Job outfits',
        RESTORE_OUTFIT_LABEL = 'Restore outfit'
    },

    ESCORT = {
        KEYMAP_DESCRIPTION = 'Cuff: (during escort only)',
        INITIATOR_PLAYER_RELEASED_FROM_SCORT = 'You have released citizen from escort!',
        TARGET_PLAYER_RELEASED_FROM_ESCORT = 'You have been released from escort!'
    },

    POINTS = {
        STORE_VEHICLE = 'Store vehicle'
    },

    PROP_EDITOR = {
        PROP_FAR_AWAY_BLOCKED = 'Object is far away, blocking placing!',
        CAN_PLACE_PROP = 'You can place object!'
    },

    ZONES_LABELS = {
        WRITE_REPORT = "Write report",
        REPORTS = "Reports",
        WEAPON_STORAGE = 'Weapon storage',
        WEAPON_SHOP = 'Weapon shop',
        GARAGE_VEHICLE = 'Job garage',
        BOSS_MENU = 'Boss menu',
        DUTY = 'Duty',
        JOB_STASH = 'Job shared storage',
        PERSONAL_LOCKER = 'Personal locker',
        EVIDENCE_STASH = 'Evidence stash',
        OUTFIT_ROOM = 'Outfit room',
        MUGSHOT = "Mugshot"
    },

    NOTIFY = {
        COPY_VALUE = 'You copied value: %s'
    },

    VEHICLE_INFO = {
        MENU_TITLE = 'Vehicle informations',

        PG_LABEL = 'Processing vehicle info.',

        VEHICLE_PLATE = 'Vehicle plate',
        VEHICLE_OWNER_NAME = 'Owner',
        VEHICLE_NAME = 'Vehicle name',
        OWNER_PHONE_NUMBER = 'Owner phone',
        OWNER_IDENTIFIER = 'State ID',
    },

    EVIDENCE = {
        TITLE = 'Evidence storage',
        INPUT_LABEL = 'Evidence number',
        INPUT_PLACEHOLDER = '1'
    },

    JOB_STASH = {
        TITLE = 'Job storage',
        INPUT_LABEL = 'Storage number',
        INPUT_PLACEHOLDER = '1'
    },

    STASHES = {
        PERSONAL_LOCKER_LABEL = 'Personal Locker',
        EVIDENCE_STASH_LABEL = 'Evidence Stash: %s',
        JOB_STASH_LABEL = 'Job storage: %s',
    },

    JOB_MENU = {
        MENU_TITLE = 'Job Menu',
    },

    INTERACTIONS = {
        OFFICER_JAILED_TARGET = 'You sent citizen to prison!'
    },

    MENUS = {
        MAIN_MENU_PROPS_TITLE = 'Objects',
        MAIN_MENU_VEHICLE_INTERACTIONS_TITLE = 'Vehicle interactions',
        MAIN_MENU_CITIZEN_TITLE = 'Citizen interactions',

        FROM_VEHICLE = 'From vehicle',
        IN_VEHICLE = 'In vehicle',

        CITIZEN_SUB_MENU_ESCORT_PLAYER_TITLE = 'Escort player',
        CITIZEN_SUB_MENU_CUFF_SOFT_TITLE = 'Cuff',
        CITIZEN_SUB_MENU_SENT_TO_JAIL_TITLE = 'Sent to jail',
        CITIZEN_SUB_MENU_HIRE_CLOSEST_PLAYER_TITLE = 'Hire citizen',
        CITIZEN_SUB_MENU_SENT_TO_COMS_TITLE = 'Sent to COMS',
        CITIZEN_SUB_MENU_INVOICE_TITLE = 'Invoice',
        CITIZEN_SUB_MENU_SEARCH_PLAYER_TITLE = 'Search player',
        CITIZEN_SUB_MENU_SHOW_PLAYER_LICENSES = 'Show player licenses',

        GO_BACK_BUTTON_LABEL = 'Back to previous menu',
    },

    SEARCH_PLAYER = {
        ITEM_CONSFICATED = 'Item was confiscated (%s) by officer!',
        ITEM_CONFISCATED_BY_OFFICER = 'You confiscated item named %s from citizen!',
    },

    MENU_INTERACT = {
        NOT_CLOSE_TO_ANY_VEHICLE = 'You are not close to any vehicle!'
    },



    INVOICES = {
        INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER = 'Invoice Successfully Sent',
        TARGET_SUCCESS_RECEIVED_INVOICE_FROM_PLAYEr = 'You received invoice!',

        INPUT_INVOICE_MENU_TITLE = 'Invoice menu',
        INPUT_INVOICE_FINE_LABEL = 'Fine amount:',
        INPUT_INVOICE_SUBMIT_LABEL = 'Submit'

    },

    LICENSES = {
        MENU_TITLE               = "Licences",
        CONFISCATED              = 'Your license %s was confiscated!',
        RECEIVED_LICENSE         = 'You gained license named: %s',
        YOU_ALREADY_HAVE_LICENSE = 'Cannot gave you license %s, since you already have it!',
        YOU_DONT_HAVE_LICENSE    = 'Cannot remove your license %s, since you dont have it!',
        HAS_LICENSE              = 'Yes',
        NO_LICENSE               = 'No',
    },

    DISPATCH = {
        OFFICER_SENT_EMERGENCY_CALL_TITLE = 'Emergency alert',
        OFFICER_SENT_EMERGENCY_CALL = '%s sent emergency call, need help!'
    },

    PROPS = {
        OBJECT_REQUIRES_ITEM_FOR_PICKUP = "Object requires item named %s for picking it up!",
        OBJECT_PICKED_UP = "Object picked up!",
        FAILED_TO_SPAWN_PROP = 'Cannot load %s, since its not defined!',
        PICKING_UP_PROP = 'Picking up object: %s',
        PLACING_OBJECT = "Placing up object: %s",
        CANCELING_PLACING = "You leave placing of object: %s",
        FAILED_PLACING = "You failed placing of object: %s",
        ALREADY_PICKING_UP = 'There is somebody already removing object!',
        CANNOT_PLACE_ON_ANOTHER_OBJECT = 'There is already object at this place!',
        HELP_TEXT = "Pickup object",
        YOU_DONT_HAVE_ITEM_IN_INVENTORY = "You dont have this item named %s in your inventory!",
    },

    CAMERA_SPEED_RADAR = {
        TITLE = "Camera radar",
        INPUT_SPEED_LABEL = "Speed type: %s",
        INPUT_SPEED_PLACEHOLDER = "Define max speed",
        INPUT_FINE_LABEL = "Fine",
        INPUT_FINE_PLACEHOLDER = "Define fine",
        INPUT_BLIP_LABEL = "Show blip on map:",
    },

    FINES = {
        HEADER_MENU_TITLE = 'Fines',
        HEADER_MENU_LABEL_PREFIX = "Fine price: %s",
    },

    WEAPON_SHOP = {
        MENU_TITLE = 'Armoury Shop',
        MENU_WEAPON_LABEL = ('%s: %s %s'),
        MENU_WEAPON_LABEL_FREE = ('%s: Free'),

        BUY_WEAPON_FAILED_NOT_ENOUGH_BALANCE = 'Failed to get item: %s, since not enough balance to buy it!',
        BUY_WEAPON_FAILED_NOT_ENOUGH_PERMS = 'Failed to get item: %s, since not enough grade to buy it!',
        BUY_WEAPON_FAILED_NOT_WEAPON_LICENSE = 'Failed to get item: %s, since you dont have Weapon licence!',
        BUY_WEAPON_SUCCESS = 'You get item named: %s from department shop!',

        DIALOG_TITLE = 'Item: %s',
        DIALOG_INPUT_TITLE = "Define amount",
        DIALOG_DSC = 'Are you sure, you want to get this item from department shop?',
    },

    GARAGE = {
        MENU_TITLE = 'Job garage',
        NOT_FREE_PARKING_SPACE = 'Cannot retrieve vehicle from garage, since there is no free space!',
        NOT_ENOUGH_MONEY_IN_SOCIETY_TO_GET_VEHICLE =
        'Your department doesnt have enough money %s %s, to get vehicle from garage!',
        NOT_ENOUGH_MONEY_IN_BANK_TO_GET_VEHICLE = 'You dont have enough money %s %s in your bank!',
        NOT_DEPARTMENT_VEHICLE = "You cannot store vehicle, which is not part of department garage!",
        VEHICLE_WAS_STORED = 'Vehicle was stored in garage!',
        VEHICLE_BOUGHT = 'You succesfully bought department vehicle for %s %s',
        PAYDIALOG_TITLE = 'Pay for vehicle named %s',
        PAYDIALOG_DESC = 'Select payment option, to get vehicle from garage!',
        IMPOUND_ACTION = 'Sending vehicle to impound',

        GARAGE_ORDER_VEHICLE_SUCC = 'You ordered %s vehicles for price %s %s!',
        GARAGE_ORDER_VEHICLE_FAIL = 'Not enough money in department for ordering vehicles %s %s!',


        GARAGE_REQUEST_VEH_SUCC = 'Vehicle retrieved from garage!',
        GARAGE_REQUEST_VEH_FAILURE = 'There is not enough vehicles in garage!',

        INPUT_TITLE = "Order vehicle",
        INPUT_LABEL = "Define amount",
        INPUT_PLACEHOLDER = "10"
    },

    BOSS_MENU = {
        HEADER_TITLE_MENU = "Department",
        TITLE_MENU = "Boss Menu",
        TITLE_ORDER = 'Order vehicles',
        YOU_HIRED_PLAYER = 'You hired citizen %s into job!',
        YOU_HIRED_BY_INITIATOR = 'You were hired into job named %s by %s'
    },

    IMPOUNDS = {
        VEHICLE_SENT_TO_IMPOUND = "Vehicle was sent to impound!",
        VEHICLE_REVOKE_SENT_TO_IMPOUND = "Your action was revoked!"
    },

    PROGRESS_BAR = {
        CANCEL_ACTION_LABEL = "Cancel"
    },

    PERSONAL_STORAGE = {
        TITLE = 'Personal storage',
    },

    BLIPS = {
        GPS_COOLDOWN  = "Please wait, before using GPS again!",
        GPS_TURN_ON   = "You have activated your GPS!",
        GPS_TURN_OFF  = "Your GPS has been deactivated!",

        SUBSCRIBE_ON  = "You can now see your colleagues on the map.",
        SUBSCRIBE_OFF = "Colleague blips have been hidden from your map.",
    },

    DUTY = {
        TITLE = 'Department duty',
        ON_DUTY_SERVICE_MSG = 'On duty',
        OFF_DUTY_SERVICE_MSG = 'Off duty',

        NEED_TO_BE_ON_DUTY_TO_INTERACT_WITH_ZONE = 'You need to clock into duty to be able perform interaction',
        NEED_TO_BE_ON_DUTY_TO_OPEN_MENU = 'You need to clock into duty to be able open this menu!',
        YOU_ARE_IN_SERVICE = 'You are on duty!',
        YOU_ARE_OFF_SERVICE = 'You are off duty!',
        COOLDOWN = 'Please wait before doing another action!'
    },


    REPORTS = {
        PLAYER_SUBMITTED_REPORT = 'Your report was sent!',
        PLAYER_REACHED_MAXIMUM_OPEN_REPORT = 'You already opened report, wait little bit before opening new one!',
        PLAYER_DELETED_REPORT = "Report was removed!",

        RECEIVED_NEW_REPORT_OFFICERS = "New reported was submitted by some citizen!",

        OFFICER_UPDATED_REPORT_NOTE = "Updated report (%s) note to %s by %s",
        OFFICER_UPDATED_REPORT_STATUS = "Updated report (%s) status to %s by %s",

        INPUT_TITLE = "Report incident",
        INPUT_YOUR_NAME = "Your name",
        INPUT_PHONE_NUMBER = "Phone number",
        INPUT_DETAILS = "Message"
    },


    RADIAL_MENU = {
        CUFF_LABEL = "Cuff",
        ESCORT_LABEL = "Escort",
        LICENCES_LABEL = "Licences",
        IN_VEHICLE_LABEL = "Put in",
        FROM_VEHICLE_LABEL = "Take out",
        SEARCH_LABEL = "Search",
        JAIL_LABEL = "Jail",
        EMERGENCY_LABEL = "Emergency",
        FINE_LABEL = "Fine",
        MDT_LABEL = "MDT",

        PROP_SPEED_RADAR_LABEL = "Speed radar",

        MAIN_MENU_TITLE = "Main menu",
        POLICE_MENU_TITLE = "Other",
        DISPATCH_LABEL = "Dispatch",
        IMPOUND_VEHICLE = "Impound",
        UNLOCK_VEHICLE = "Unlock vehicle",
        VEHICLE_INFO = "Vehicle info",
        COMS = "COMS",
        RADAR = "Radar",
        MEGAPHONE = "Megaphone",
        SPIKES = "Spike",
        BARRIER = "Barrier",
    },

    DYNAMIC_ACTION = {
        SELECT_KEY = 'Select',
        EXIT_KEY = 'Exit',
    },

    VEHICLE_MENU = {
        UNLOCK_VEHICLE = 'Unlock vehicle',
        IMPOUND_VEHICLE = 'Impound vehicle',
        VEHICLE_INFORMATION = 'Vehicle information',
        VEHICLE_EXTRAS = 'Vehicle extras',
    },

    NO_REQUIRED_JOB = "You are not in police derpament, to do this action!",
    CURRENCY_SYMBOL = '$',

    KEY_MAPPING = {
        EXIT_BODYCAM = "Exit bodycam",
        RADIAL_MENU = "Open radial menu",
        JOB_MENU = "Open job menu",
        TACKLE_CUFF_AND_ESCORT_PLAYER = 'Escort & cuff player',
        TACKLE_PLAYER = "Tackle nearby player",
        TACKLE_STOP = 'Stop tackle',
        INTERACT_ZONE = "Interact zone",
        ESCORT_ESCAPE = "Escort escape",
        HANDS_UP = "Handsup",
        STOP_ESCORT = "Stop Escort",
        MEGAPHONE_STATE = 'Megaphone proximity',
        MEGAPHONE_EXIT = 'Stop using megaphone'
    },


    INTERACT_TARGET_PREFIX_JOB = "Police",

    ZIPTIES_INITIATOR = "You ziptied an citizen!",
    ZIPTIES_TARGET = "You are being ziptied by an citizen!",

    ZIPTIES_INITIATOR_REMOVE = "You removed zipties from citizen!",
    ZIPTIES_TARGET_REMOVE = "Citizen removed zipties from your hands.",

    HANDCUFF_INITIATOR = "You are handcuffing citizen!",
    HANDCUFF_TARGET = "You are being handcuffed by officer!",

    HANDCUFF_INITIATOR_REMOVE = "You removed handcuffs from citizen!",
    HANDCUFF_TARGET_REMOVE = "Officer removed handcuffs from your hands.",

    ESCORT_INITIATOR = "You are escorting citizen!",
    ESCORT_TARGET = "You are being escorted by officer!",

    ESCORT_INITIATOR_PED_REMOVE = "You stopped escorting citizen!",
    ESCORT_TARGET_PED_REMOVE = "Officer stopped escorting you!",

    NO_LICENCE_FOUND = "Citizen is without any licence found!",

    VEHICLE_UNLOCKED = 'Vehicle unlocked',

    TARGET = {
        HANDCUFF = "Handcuff/Uncuff",
        SEARCH_PLAYER = "Search player",
        ESCORT = "Escort",
        PUT_IN_VEHICLE = "Put in vehicle",
        FROM_VEHICLE = "Take citizen out",
    },

    MEGA_PHONE = {
        TURN_STATE = 'Turn on / off',
        EXIT = 'Exit',
        IS_OFF = 'Proximity: Inactive',
        IS_ON = 'Proximity: Active',
    },

    BODYCAMS = {
        ACTIVATED = "Bodycam is active!",
        DEACTIVATED = "Bodycam is turned off!",

        LABEL_OFFICER = "Officer",
        LABEL_CAMERA_ID = "Bodycam ID",
        LABEL_LOCATION = "Location",
        LABEL_EXIT = "Exit bodycam"
    },

    PAPER_BAG = {
        INITIATOR_ADDED_ON_TARGET = 'You put paper bag on citizen!',
        INITIATOR_REMOVED_FROM_TARGET = 'You removed paper bag from citizen',
    },

    WHEEL_CLAMP = {
        PG_TITLE = "Wheel Clamp",
        NOT_CLOSE_TO_VEHICLE = "There is no vehicle nearby!",
        NOT_CLOSE_TO_WHEEL = "There is no vehicle wheel nearby!",
        NOT_ANY_WHEEL_CLAMP_ON_THIS_VEHICLE = "This vehicle doesnt have any wheel clamp!",
        PLACED = "You placed wheel clamp!"
    },

    JOB = {
        SET_BUSINESS_JOB_USE_CASE = 'Usage: /setjob [playerID] [jobName] [jobGrade]',
        SET_BUSINESS_INVALID_JOB = 'You need to type one of these: police',
        SET_BUSINESS_INVALID_GRADE = 'This grade doesnt exist in this job',
        NOT_ENOUGH_PERMS_TO_ACCESS = 'Your rank (%s) doesnt have access to this!',

        REMOVED_FROM_PLAYER = 'You removed job from this player: %s.',
        ADD_TO_PLAYER = 'You added job to this player: %s with grade: %s',
        INVALID_TARGET = 'Please specify target player playerId',
    },

    COMMANDS_HELP_TEXT = {
        SHOW_BLIPS = "Command used for turning on/off showing collegue blips.",

        PANIC_BUTTON = "Command user for panic button of officer",
        SEARCH_PLAYER = 'Command used for searching a player.',
        ESCORT_PLAYER = 'Command used for escort player.',
        PUT_PLAYER_IN_VEH = 'Command used for putting player in vehicle.',
        GET_PLAYER_FROM_VEH = 'Command used for getting player from vehicle.',

        PRESET_CREATOR = 'Tool for creating department preset.',
        SET_PLAYER_JOB = 'Command used for setting citizen job.',
        REMOVE_PLAYER_JOB = 'Command used for removing citizen current job',
        GRANT_LICENCE = 'Command used for granting citizen licence.',
        REVOKE_LICENCE = 'Command used for removing citizen licence.'
    },

    HELP_MESSAGES = {
        NO_TARGET_NIL = 'Please specify playerId of target citizen!',
        NO_TARGET_OFFLINE = 'This specified citizen is not found online with this playerId!',
        NO_ACCESS = 'You dont have access to use this command!',
        NO_VALID_LICENCE = 'Invalid licence: %s - please select one of these: driver, weapon, business!'
    },

    SUGGESTIONS = {
        KEY_NUMBER = 'number',
        KEY_STRING = 'string',

        PRESET_CREATOR = '',
        HELP_PRESET_CREATOR = '',

        HELP_PLAYERID = 'Target playerId',
        HELP_JOB = 'Specify citizen job: police',
        HELP_JOB_GRADE = 'Specify citizen grade: 1-4',
        HELP_LICENCE = 'Specify citizen licence: driver, business, weapon'
    },

    RADAR = {
        LOCK_TOGGLE_OFF = 'Radar lock disabled',
        LOCK_TOGGLE_ON = 'Radar lock enabled',
    },

    PRESET_CREATOR = {
        HELP_KEY_TITLE = "Department creation",
        HELP_KEY_REMAINING_COUNT = "Remaining count",
        HELP_KEY_TASK = "Task",
        HELP_KEY_ZONE_OWNER = "Zone owner",
        HELP_KEY_RESOURCE = "Resource",
        HELP_KEY_SAVE_POINT = "Save current point",
        HELP_KEY_EXIT = 'Exit',

        DIALOG_CONFIRM_TITLE = "Define point",
        DIALOG_CONFIRM_DESC = "Check",

        DIALOG_RESOURCE_TITLE = "Select resource",
        DIALOG_ZONE_OWNER = "Zone owner",
        DIALOG_PRESET_TOOL_TITLE = 'Preset tool',

        NOT_ENOUGH_PERMISSION = "You have dont access to use preset creator!",

        CLOSE_POINT = "Placement too close to existing point. Minimum 2m required",
    },

    BOSS_MENU_ACTIONS = {
        SET_BONUS = 'Successfully sent bonus to %s with amount %s %s.',
        PROMOTE_CITIZEN = 'Succesfully promoted %s to %s!',

        DEPOSIT_SOCIETY_MONEY = 'Successfully you deposited %s %s into society.',
        WIDTHRAW_SOCIETY_MONEY = 'Successfully removed %s %s from society.',
    },

    TITLE_NOTIFY = 'General',


    UI = {
        MONEY_SYMBOL = '$',

        VIEW_PHOTO = {
            STATE_LOADING = "Loading image...",
            NOT_FOUND_TITLE = "Image not found",
            NOT_FOUND_DESC = "This image doesn't exist",
            DATE = "Date",
            LOCATION = "Location",
        },

        BOSS_MENU = {
            PAGE_DASHBOARD_BUTTON_NAVBAR_LABEL = "Dashboard",
            PAGE_DASHBOARD_BUTTON_FIRE_LABEL = "Fire",
            PAGE_DASHBOARD_SELECT_EMPLOYEE_LABEL = "Select an employee from the left to manage.",
            PAGE_DASHBOARD_CHANGE_GRADE_LABEL = "Change grade:",
            PAGE_DASHBOARD_SET_BONUS_LABEL = 'Bonus',
            PAGE_DASHBOARD_SET_GRANT_BONUS_TITLE = 'Grant Bonus:',
            PAGE_DASHBOARD_MANAGE_BUTTON_LABEL = "Manage",

            PAGE_DASHBOARD_EMPLOYEE_ROW = "Employee",
            PAGE_DASHBOARD_GRADE_ROW = "Grade",
            PAGE_DASHBOARD_OPTION_ROW = "Option",

            PAGE_DASHBOARD_EMPLOYEES_TITLE = "Employees",
            PAGE_DASHBOARD_EMPLOYEES_TOTAL = "Total",

            PAGE_DASHBOARD_QUICK_ACTION_TITLE = "Society balance",
            PAGE_DASHBOARD_QUICK_ACTION_DEPOSIT_LABEL = "Deposit",
            PAGE_DASHBOARD_QUICK_ACTION_WIDTHRAW_LABEL = "Widthdraw",

            PAGE_DASHBOARD_DIALOG_BONUS_TITLE = "Job bonus",
            PAGE_DASHBOARD_DIALOG_BONUS_DESC = "For citizen named %s",
            PAGE_DASHBOARD_DIALOG_BONUS_DIALOG_OPTIONS_LABEL = "Confirm bonus",

            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_TITLE = "Change grade",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DESC = "For %s to %s",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DIALOG_OPTIONS_LABEL = "Confirm grade change",

            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_TITLE = "Fire citizen",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DESC = "Kick %s from job",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DIALOG_OPTIONS_LABEL = "Confirm kick of citizen",

            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_TITLE = "Society",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_LABEL = "Deposit Amount",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_PLACE_HOLDER = "Enter amount to deposit",

            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_TITLE = "Society",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_LABEL = "Widthraw amount",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_PLACE_HOLDER = "Enter amount to widthraw",

            PAGE_DASHBOARD_SELECT_GRADE = "Select grade",
            PAGE_DASHBOARD_SET_GRADE_BUTTON = "Select",

            PAGE_GARAGE_TITLE = "Department garage",
            PAGE_GARAGE_BUTTON_NAVBAR_LABEL = "Garage",
            PAGE_GARAGE_STOCK_BALANCE = "Stock balance:",
            PAGE_GARAGE_ORDER_BUTTON_LABEL = "Order",

            PAGE_GARAGE_ORDER_DIALOG_TITLE = "Society",
            PAGE_GARAGE_ORDER_DIALOG_LABEL = 'Order amount',
            PAGE_GARAGE_ORDER_DIALOG_PLACEHOLDER = 'Enter amount to order',


            NAVBAR_TITLE = "TITLE",
            NAVBAR_DESC = "Boss menu management system"
        },

        DIALOG = {
            CANCEL_BUTTON = "Cancel",
            CONFIRM_BUTTON = "Confirm",

            VALIDATION_INPUT_REQUIRED_STRING = "is required",
            VALIDATION_INPUT_LESS_THAN = "must be less than characters",

            VALIDATION_NUMBER_REQUIRED_NAN = "must be greater than 0",
            VALIDATION_NUMBER_REQUIRED = "is required",

            TEXT_AREA_IS_REQUIRED = "is required",
            TEXT_AREA_INPUT_LESS_THAN = "must be less than characters",
        },

        SHOP = {
            BUY = "Buy",
            TAKE = "Grab",
            FREE = "Free",
            NO_ITEMS = "Failed to find any items in store",
            CHECK_BACK_SOON = "Try it later please",
            TITLE = "Department store",
            DESCRIPTION = "Select item that you want to obtain.",
        },

        BOSS_MENU_GARAGE_STOCK = {
            ORDER_NOT_ENOUGH_BUTTON = "Empty stock",
            ORDER_HAS_BUTTON = "Order",
        },

        GARAGE = {
            BUY = "Buy",
            TAKE = "Take",
            FREE = "Free",

            TITLE = "Department garage",
            DESCRIPTION = "Select vehicle that you want to obtain."
        },

        PAY_DIALOG = {
            CONFIRM_FREE = "Submit",
            COMPANY_BUTTON_LABEL = "Company",
            BANK_BUTTON_LABEL = "Bank",
            INPUT_PLACEHOLDER = "0",
        },

        POLICE_RADAR = {
            PAGE_RADAR = "Radar",
            SETTINGS_RADAR = "Settings",

            FRONT_RADAR_TITLE = "Front antenna",
            REAR_RADAR_TITLE = "Rear antenna",
            FAST_LOCK_LABEL = "Fast lock",

            PLATE_READER_FRONT = "Front",
            PLATE_READER_REAR = "Rear",
            PATROL_SPEED = "Patrol speed",

            RECENT_PLATE = "Plate",
            RECENT_MODEL = "Model",
            RECENT_SPEED = "Speed",
            RECENT_LABEL = "Label",

            SPEED_TITLE = "Speed",
        },

        MENU_SETTINGS = {
            TITLE = "Police Radar",
            DESC = "Change your settings",

            RADAR_SCALE = "Radar scale",
            RADAR_SCALE_DESC = "Adjust the size of the radar on screen",

            RESET_RADAR_POSITION = "Radar position",
            RESET_RADAR_POSITION_DESC = "Reset to default position",
            RESET_RADAR_POSITION_BUTTON = "Reset",

            RESET_SCALE_POSITION = "Radar scale",
            RESET_SCALE_POSITION_DESC = "Reset to default scale",
            RESET_SCALE_BUTTON = "Reset",

            MISC_SECTION = "MISC",
            FAST_LIMIT = "Fast Limit",
            FAST_LIMIT_DESC = "Control the speed limit",
            RESET_SETTINGS = "Reset Settings",

            RESET_LABEL = "Reset scanner",
            RESET_DESC = "Allows to reset scanner",
            RESET_RADAR_BUTTON = "Reset",

            RADAR_SECTION = "Radar",
            TOGGLE_RADAR = "Toggle Radar",
            TOGGLE_RADAR_DESC = "Show / Hide the radar",

            TOGGLE_RADAR_MOVEMENT = "Toggle Radar draggable",
            TOGGLE_RADAR_MOVEMENT_DESC = "Allows to drag radar around.",

            RECENT_PLATES_TITLE = "Recent plates",
            RECENT_PLATES_DESC = "History of scanned plates",
            RECENT_PLATES_BUTTON = "Show/Hide",
        },

        RECENT_PLATES = {
            TITLE = "Recent plates",
            DESC = "Recently scanned history of cars",

            NO_HISTORY = "No history for current radar!",
            FILTER_LABEL = "Filter by",

            NEXT_PAGE = "Next",
            PREVIOUS_PAGE = "Previous",
            RETURN_TO_SETTINGS_BUTTON_LABEL = "Back to settings",
        },

        BODYCAMS = {
            TITLE = "BodyCam feed",
            DESC = "Current feed of active cams of your officers!",
            NOT_ACTIVE_TITLE = "No active bodycams!",
            NOT_ACTIVE_DESC = "There are currently no active bodycams available to view the live feed",

            CAMERA_ID = "Camera:",
            OFFICER = "Officer:",
            LOCATION = "Location:",

            VIEW_FEED_BUTTON_TITLE = "View feed",
        },

        REPORTS = {
            FILTER_LABEL = "Filters",
            MAIN_MENU_TITLE = "Reports",
            MAIN_MENU_DESC = "Here you can view all reports from citizens.",

            HEADER_PLAYER = "Citizen",
            HEADER_PHONE = "Phone",
            HEADER_STATUS = "Status",
            HEADER_ACTIONS = "Action",

            ACTIONS_REPORT_OPEN = "Show report",
            ACTIONS_REPORT_CLOSE = "Close report",

            STATE = "Report state",
            STATUS_OPTIONS = "Select report state",
            UPDATE_STATUS = "Update status",
            SAVE_STATUS = "Save status",

            ADD_NOTE = "Add note",
            SAVE_NOTE = "Save note",
            SAVE = "Save",

            NOTE_PLACEHOLDER = "Add your note to report",

            DELETE_REPORT = "Delete report",
            BACK_TO_REPORTS = "Back to reports",

            NO_REPORTS_FOUND = "No results.",

            PREVIOUS_BUTTON = "Previous",
            NEXT_PREVIOUS_BUTTON = "Next",

            REPORT_TITLE = "Report Details:",
            REPORT_PLAYER_NAME = "Citizen name:",
            REPORT_MESSAGE = "Message",
            REPORT_PLAYER_PHONE = "Phone:",
            REPORT_STATUS = "Status:",
            REPORT_NOTE = "Note:",

            STATES_NEW_REPORT = "New report",
            STATES_IN_REVIEW = "In review",
            STATES_RESOLVED = "Resolved",
        },

        RADIAL_MENU = {
            PRESS_LABEL = "Press",
            GO_BACK_LABEL = "Go Back",
        },

        GO_BACK_BUTTON = "◀ Back"
    }
}
