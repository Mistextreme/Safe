Locales['da'] = {
    NO_CITIZEN_NEARBY = 'Ingen borger i nærheden!',
    SELECT_PLAYER_MENU_TITLE = 'Vælg borgere',
    CANNOT_PEFORM_UNDEFINED_ACTION = "Du kan ikke udføre en udefineret handling!",
    YOU_ARE_AREADY_IN_PLACING_MODE = "Du er allerede i gang med en anden opgave!",

    UNLOCKING_VEHICLE = 'Låser køretøj op',

    RELEASE_PLAYER_TACKLE = "Slip borger",
    CUFF_PLAYER_TACKLE = "Sæt håndjern på og eskortér",

    SEARCHING_CITIZEN = "Gennemsøger borger",

    OFFICER_SEARCH = "Du gennemsøger borger",
    SEARCH_TARGET = "Du bliver gennemsøgt!",

    ACTIONS_REQUIRE_HANDSUP = "Borgeren skal have hænderne oppe!",
    ACTIONS_REQUIRE_CUFFED = "Borgeren skal være i håndjern!",
    ACTIONS_REQUIRE_CUFFED_OR_HANDSUP = 'Borgeren skal være i håndjern eller have hænderne oppe!',
    ACTIONS_REQUIRE_CUFFED_OR_DEAD_SEARCH_INV =
    "Borgeren skal være i håndjern eller død – du kan ikke åbne deres inventar",
    ACTION_REQUIRE_ADMIN_RIGHTS = "Du skal have administratorrettigheder for at bruge dette!",

    PLAYER_NAME_INPUT_INVOICE = "Borgerens navn",
    PLAYER_NAME_INPUT = "Målborger",

    MEGAPHONE_NOT_USEABLE_IN_VEHICLE = "Megafon kan ikke bruges i køretøj!",
    CAMERA = {
        TAKE_PHOTO_HELPKEY = "Tag foto",
        EXIT_HELPKEY = "Afslut",

        ZOOM_HELPTEXT = "Brug scroll for at zoome",

        PROCESSING_PHOTO = "Foto behandles!",
        PROCESSING_PHOTO_FINISHED = "Foto er blevet tilføjet til dit inventar!"
    },
    ZIPTIES_INITIATOR = "Du har sat strips på en borger!",
    ZIPTIES_TARGET = "Du får strips påsat af en borger!",

    ZIPTIES_INITIATOR_REMOVE = "Du fjernede strips fra en borger!",
    ZIPTIES_TARGET_REMOVE = "En borger fjernede strips fra dine hænder.",
    INTERACT_TARGET_PREFIX_JOB = "Politi",
    PLAYER_IS_NOT_ZIPTIED = "Borgeren har ikke strips på!",

    PLAYER_IS_NOT_HANDCUFFED = "Borgeren er ikke i håndjern!",
    YOU_DONT_HAVE_ITEM_IN_YOUR_INVENTORY = "Du har ikke genstanden %s i dit inventar!",
    YOU_CANNOT_DO_THAT_WHILE_ESCORTING_PLAYER = "Du kan ikke gøre dette mens du eskorterer en borger!",

    TO_INTERACT_NEED_TO_FACE_TARGET = "Du skal kigge på borgeren for at kunne udføre handlingen!",

    PLAYER_ESCAPED_TACKLE = "Borgeren slap fri fra tackling!",

    SENT_FINE = "Du har givet borgeren en bøde!",

    EMPTY_INVENTORY = "Intet fundet i inventaret",

    CITIZEN_MUST_CUFFED = "Borgeren skal være i håndjern!",
    CITIZEN_NOT_IN_FRONT = "Du skal stå foran borgeren!",

    NOT_MDT_LOADED_STANDALONE = "Kunne ikke åbne dit MDT!",
    NOT_DISPATCH_PANEL_LOADED_STANDALONE = "Kunne ikke åbne dispatch-panelet!",

    STOP_ESCORT_LABEL = "Stop eskortering",
    ATTEMPT_BREAK_LABEL = "Forsøg at slippe fri",
    CUFF_LABEL = 'Sæt håndjern på borger',

    MINIGAME_ESCORT_ESCAPE_FOR_OFFICER = "Borgeren undslap eskortering!",
    MINIGAME_ESCORT_ESCAPE_FOR_TARGET = "Du slap væk fra eskortering – løb!",

    UNDEFINED_ITEM_ERROR = 'Genstanden %s er ikke defineret på serveren!',

    ZIP_TIES = 'Stripstrips',
    HANDCUFFS_KEY = "Nøgle til håndjern",
    PAPERBAG = "Papirpose",
    HANDCUFFS = "Håndjern",
    BARRIER = "Afspærring",
    ZIP_TIES_CUTTER = "Stripstrip-skærer",
    MEGAPHONE = "Megafon",
    SPEEDCAMERA = "Fartkamera",
    SPIKES = "Sømplade",


    INPUT_JAIL_PLAYER = {
        HEADER = 'Fængsel – tid',
        REASON_LABEL = 'Årsag (valgfri)',
        JAIL_TIME_LABEL = 'Varighed',
    },

    SELECT_PLAYERS = {
        PLAYER = 'Borger',
    },

    SPEED_RADAR = {
        RECEIVED_FINE = 'Du modtog en bøde på %s %s for at køre for stærkt i %s.',
    },

    OUTFITS = {
        MENU_TITLE = 'Jobuniformer',
        RESTORE_OUTFIT_LABEL = 'Gendan uniform'
    },

    ESCORT = {
        KEYMAP_DESCRIPTION = 'Håndjern: (kun under eskortering)',
        INITIATOR_PLAYER_RELEASED_FROM_SCORT = 'Du har sluppet borgeren fri fra eskortering!',
        TARGET_PLAYER_RELEASED_FROM_ESCORT = 'Du er blevet sluppet fri fra eskortering!'
    },

    POINTS = {
        STORE_VEHICLE = 'Opbevar køretøj'
    },

    PROP_EDITOR = {
        PROP_FAR_AWAY_BLOCKED = 'Objektet er for langt væk – kan ikke placeres!',
        CAN_PLACE_PROP = 'Du kan placere objektet!'
    },

    ZONES_LABELS = {
        WRITE_REPORT = "Skriv rapport",
        REPORTS = "Rapporter",
        WEAPON_STORAGE = 'Våbenlager',
        WEAPON_SHOP = 'Våbenbutik',
        GARAGE_VEHICLE = 'Jobgarage',
        BOSS_MENU = 'Ledermenu',
        DUTY = 'Vagt',
        JOB_STASH = 'Fælles joblager',
        PERSONAL_LOCKER = 'Personligt skab',
        EVIDENCE_STASH = 'Bevismateriale-lager',
        OUTFIT_ROOM = 'Omklædningsrum',
    },

    NOTIFY = {
        COPY_VALUE = 'Du kopierede værdien: %s'
    },

    VEHICLE_INFO = {
        MENU_TITLE = 'Køretøjsinformation',

        PG_LABEL = 'Behandler køretøjsoplysninger...',

        VEHICLE_PLATE = 'Nummerplade',
        VEHICLE_OWNER_NAME = 'Ejer',
        VEHICLE_NAME = 'Køretøjsnavn',
        OWNER_PHONE_NUMBER = 'Ejers telefonnummer',
        OWNER_IDENTIFIER = 'Stats-ID',
    },

    EVIDENCE = {
        TITLE = 'Bevismateriale-lager',
        INPUT_LABEL = 'Bevisnummer',
        INPUT_PLACEHOLDER = '1'
    },

    JOB_STASH = {
        TITLE = 'Joblager',
        INPUT_LABEL = 'Lagernummer',
        INPUT_PLACEHOLDER = '1'
    },

    STASHES = {
        PERSONAL_LOCKER_LABEL = 'Personligt skab',
        EVIDENCE_STASH_LABEL = 'Bevismateriale-lager: %s',
        JOB_STASH_LABEL = 'Joblager: %s',
    },

    JOB_MENU = {
        MENU_TITLE = 'Jobmenu',
    },

    INTERACTIONS = {
        OFFICER_JAILED_TARGET = 'Du har sendt borgeren i fængsel!'
    },

    MENUS = {
        MAIN_MENU_PROPS_TITLE = 'Objekter',
        MAIN_MENU_VEHICLE_INTERACTIONS_TITLE = 'Køretøjsinteraktioner',
        MAIN_MENU_CITIZEN_TITLE = 'Borgerinteraktioner',

        FROM_VEHICLE = 'Ud af køretøj',
        IN_VEHICLE = 'Ind i køretøj',

        CITIZEN_SUB_MENU_ESCORT_PLAYER_TITLE = 'Eskortér borger',
        CITIZEN_SUB_MENU_CUFF_SOFT_TITLE = 'Sæt håndjern på',
        CITIZEN_SUB_MENU_SENT_TO_JAIL_TITLE = 'Send til fængsel',
        CITIZEN_SUB_MENU_HIRE_CLOSEST_PLAYER_TITLE = 'Ansæt borger',
        CITIZEN_SUB_MENU_SENT_TO_COMS_TITLE = 'Send til COMS',
        CITIZEN_SUB_MENU_INVOICE_TITLE = 'Faktura',
        CITIZEN_SUB_MENU_SEARCH_PLAYER_TITLE = 'Søg borger',
        CITIZEN_SUB_MENU_SHOW_PLAYER_LICENSES = 'Vis borgerens licenser',

        GO_BACK_BUTTON_LABEL = 'Tilbage til forrige menu',
    },

    SEARCH_PLAYER = {
        ITEM_CONSFICATED = 'Genstand (%s) blev konfiskeret af betjent!',
        ITEM_CONFISCATED_BY_OFFICER = 'Du konfiskerede genstanden %s fra borgeren!',
    },

    MENU_INTERACT = {
        NOT_CLOSE_TO_ANY_VEHICLE = 'Du er ikke tæt på et køretøj!'
    },

    INVOICES = {
        INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER = 'Faktura sendt',
        TARGET_SUCCESS_RECEIVED_INVOICE_FROM_PLAYEr = 'Du har modtaget en faktura!',

        INPUT_INVOICE_MENU_TITLE = 'Fakturamenu',
        INPUT_INVOICE_FINE_LABEL = 'Bødebeløb:',
        INPUT_INVOICE_SUBMIT_LABEL = 'Send'
    },

    LICENSES = {
        MENU_TITLE               = "Licenser",
        CONFISCATED              = 'Din licens %s blev konfiskeret!',
        RECEIVED_LICENSE         = 'Du har modtaget licensen: %s',
        YOU_ALREADY_HAVE_LICENSE = 'Kan ikke give dig licensen %s, da du allerede har den!',
        YOU_DONT_HAVE_LICENSE    = 'Kan ikke fjerne licensen %s, da du ikke har den!',
        HAS_LICENSE              = 'Ja',
        NO_LICENSE               = 'Nej',
    },

    DISPATCH = {
        OFFICER_SENT_EMERGENCY_CALL_TITLE = 'Nødsituation',
        OFFICER_SENT_EMERGENCY_CALL = '%s sendte en nødkald – har brug for hjælp!'
    },

    PROPS = {
        FAILED_TO_SPAWN_PROP = 'Kan ikke indlæse %s – ikke defineret!',
        PICKING_UP_PROP = 'Samler op: %s',
        PLACING_OBJECT = "Placerer objekt: %s",
        CANCELING_PLACING = "Du afbrød placering af objekt: %s",
        FAILED_PLACING = "Placering af objekt %s mislykkedes",
        ALREADY_PICKING_UP = 'Nogen er allerede ved at fjerne objektet!',
        CANNOT_PLACE_ON_ANOTHER_OBJECT = 'Der er allerede et objekt her!',
        HELP_TEXT = "Tag objekt",
        YOU_DONT_HAVE_ITEM_IN_INVENTORY = "Du har ikke genstanden %s i dit inventar!",
    },

    CAMERA_SPEED_RADAR = {
        TITLE = "Fartkontrolkamera",
        INPUT_SPEED_LABEL = "Hastighedstype: %s",
        INPUT_SPEED_PLACEHOLDER = "Angiv makshastighed",
        INPUT_FINE_LABEL = "Bøde",
        INPUT_FINE_PLACEHOLDER = "Angiv bødebeløb",
        INPUT_BLIP_LABEL = "Vis blip på kortet:",
    },

    FINES = {
        HEADER_MENU_TITLE = 'Bøder',
        HEADER_MENU_LABEL_PREFIX = "Bødepris: %s",
    },

    WEAPON_SHOP = {
        MENU_TITLE = 'Våbenbutik',
        MENU_WEAPON_LABEL = ('%s: %s %s'),
        MENU_WEAPON_LABEL_FREE = ('%s: Gratis'),

        BUY_WEAPON_FAILED_NOT_ENOUGH_BALANCE = 'Kunne ikke hente genstand: %s – ikke nok penge!',
        BUY_WEAPON_FAILED_NOT_ENOUGH_PERMS = 'Kunne ikke hente genstand: %s – din rang er ikke høj nok!',
        BUY_WEAPON_FAILED_NOT_WEAPON_LICENSE = 'Kunne ikke hente genstand: %s – du har ikke våbentilladelse!',
        BUY_WEAPON_SUCCESS = 'Du har modtaget genstanden: %s fra afdelingens butik!',

        DIALOG_TITLE = 'Genstand: %s',
        DIALOG_INPUT_TITLE = "Angiv antal",
        DIALOG_DSC = 'Er du sikker på, at du vil hente denne genstand fra butikken?',
    },

    GARAGE = {
        MENU_TITLE = 'Jobgarage',
        NOT_FREE_PARKING_SPACE = 'Ingen ledig plads – kan ikke hente køretøj!',
        NOT_ENOUGH_MONEY_IN_SOCIETY_TO_GET_VEHICLE = 'Afdelingen har ikke nok penge (%s %s) til at hente køretøjet!',
        NOT_ENOUGH_MONEY_IN_BANK_TO_GET_VEHICLE = 'Du har ikke nok penge (%s %s) på din konto!',
        NOT_DEPARTMENT_VEHICLE = "Dette køretøj tilhører ikke afdelingens garage – kan ikke gemmes!",
        VEHICLE_WAS_STORED = 'Køretøjet blev gemt i garagen!',
        VEHICLE_BOUGHT = 'Du har købt et afdelingskøretøj for %s %s',
        PAYDIALOG_TITLE = 'Betal for køretøj: %s',
        PAYDIALOG_DESC = 'Vælg betalingsmetode for at hente køretøjet!',
        IMPOUND_ACTION = 'Sender køretøj til beslag',

        GARAGE_ORDER_VEHICLE_SUCC = 'Du har bestilt %s køretøjer for i alt %s %s!',
        GARAGE_ORDER_VEHICLE_FAIL = 'Afdelingen har ikke nok penge til at bestille køretøjer (%s %s)!',

        GARAGE_REQUEST_VEH_SUCC = 'Køretøjet blev hentet fra garagen!',
        GARAGE_REQUEST_VEH_FAILURE = 'Der er ikke flere køretøjer i garagen!',

        INPUT_TITLE = "Bestil køretøj",
        INPUT_LABEL = "Angiv antal",
        INPUT_PLACEHOLDER = "10"
    },

    BOSS_MENU = {
        HEADER_TITLE_MENU = "Afdeling",
        TITLE_MENU = "Ledermenu",
        TITLE_ORDER = 'Bestil køretøjer',
        YOU_HIRED_PLAYER = 'Du ansatte borgeren %s i jobbet!',
        YOU_HIRED_BY_INITIATOR = 'Du blev ansat i jobbet %s af %s'
    },


    IMPOUNDS = {
        VEHICLE_SENT_TO_IMPOUND = "Køretøjet er sendt til beslaglæggelse!",
        VEHICLE_REVOKE_SENT_TO_IMPOUND = "Din handling blev tilbagekaldt!"
    },

    PROGRESS_BAR = {
        CANCEL_ACTION_LABEL = "Annuller"
    },

    PERSONAL_STORAGE = {
        TITLE = 'Personligt lager',
    },

    DUTY = {
        TITLE = 'Vagtstatus',
        ON_DUTY_SERVICE_MSG = 'På vagt',
        OFF_DUTY_SERVICE_MSG = 'Ikke på vagt',

        NEED_TO_BE_ON_DUTY_TO_INTERACT_WITH_ZONE = 'Du skal være på vagt for at kunne interagere her',
        NEED_TO_BE_ON_DUTY_TO_OPEN_MENU = 'Du skal være på vagt for at åbne denne menu!',
        YOU_ARE_IN_SERVICE = 'Du er på vagt!',
        YOU_ARE_OFF_SERVICE = 'Du er ikke på vagt!',
        COOLDOWN = 'Vent venligst lidt før du udfører en ny handling!'
    },

    REPORTS = {
        PLAYER_SUBMITTED_REPORT = 'Din rapport er sendt!',
        PLAYER_REACHED_MAXIMUM_OPEN_REPORT = 'Du har allerede en åben rapport, vent lidt før du åbner en ny!',
        PLAYER_DELETED_REPORT = "Rapporten blev slettet!",

        RECEIVED_NEW_REPORT_OFFICERS = "Ny rapport er modtaget fra en borger!",

        OFFICER_UPDATED_REPORT_NOTE = "Opdaterede notat på rapport (%s) til %s af %s",
        OFFICER_UPDATED_REPORT_STATUS = "Opdaterede status på rapport (%s) til %s af %s",

        INPUT_TITLE = "Rapporter hændelse",
        INPUT_YOUR_NAME = "Dit navn",
        INPUT_PHONE_NUMBER = "Telefonnummer",
        INPUT_DETAILS = "Besked"
    },

    RADIAL_MENU = {
        CUFF_LABEL = "Sæt håndjern",
        ESCORT_LABEL = "Følge",
        LICENCES_LABEL = "Licenser",
        IN_VEHICLE_LABEL = "Sæt ind i køretøj",
        FROM_VEHICLE_LABEL = "Tag ud af køretøj",
        SEARCH_LABEL = "Gennemse",
        JAIL_LABEL = "Fængsel",
        EMERGENCY_LABEL = "Nødopkald",
        FINE_LABEL = "Bøde",
        MDT_LABEL = "MDT",

        PROP_SPEED_RADAR_LABEL = "Fartmåler",

        MAIN_MENU_TITLE = "Hovedmenu",
        POLICE_MENU_TITLE = "Andet",
        DISPATCH_LABEL = "Dispatch",
        IMPOUND_VEHICLE = "Beslaglæg køretøj",
        UNLOCK_VEHICLE = "Lås køretøj op",
        VEHICLE_INFO = "Køretøjsinfo",
        COMS = "COMS",
        RADAR = "Radar",
        MEGAPHONE = "Megafon",
        SPIKES = "Pigge",
        BARRIER = "Barrage",
    },


    DYNAMIC_ACTION = {
        SELECT_KEY = 'Vælg',
        EXIT_KEY = 'Afslut',
    },

    VEHICLE_MENU = {
        UNLOCK_VEHICLE = 'Lås køretøj op',
        IMPOUND_VEHICLE = 'Beslaglæg køretøj',
        VEHICLE_INFORMATION = 'Køretøjsinformation',
        VEHICLE_EXTRAS = 'Køretøjets ekstraudstyr',
    },

    NO_REQUIRED_JOB = "Du er ikke i politiafdelingen og kan derfor ikke udføre denne handling!",
    CURRENCY_SYMBOL = 'kr',

    KEY_MAPPING = {
        EXIT_BODYCAM = "Afslut bodycam",
        RADIAL_MENU = "Åbn radialmenu",
        JOB_MENU = "Åbn jobmenu",
        TACKLE_CUFF_AND_ESCORT_PLAYER = 'Følg & håndjern spiller',
        TACKLE_PLAYER = "Få fat i nærmeste spiller",
        TACKLE_STOP = 'Stop tackle',
        INTERACT_ZONE = "Interager i zone",
        ESCORT_ESCAPE = "Flygt fra følge",
        HANDS_UP = "Hæv hænder",
        STOP_ESCORT = "Stop eskortering",
        MEGAPHONE_STATE = 'Megafon nærhed',
        MEGAPHONE_EXIT = 'Stop med megafon',
    },

    HANDCUFF_INITIATOR = "Du håndjernede borgeren!",
    HANDCUFF_TARGET = "Du bliver håndjernet af en betjent!",

    HANDCUFF_INITIATOR_REMOVE = "Du fjernede håndjern fra borgeren!",
    HANDCUFF_TARGET_REMOVE = "Betjenten fjernede håndjernene fra dine hænder.",

    ESCORT_INITIATOR = "Du eskorterer borgeren!",
    ESCORT_TARGET = "Du bliver eskorteret af en betjent!",

    ESCORT_INITIATOR_PED_REMOVE = "Du stoppede med at eskortere borgeren!",
    ESCORT_TARGET_PED_REMOVE = "Betjenten stoppede med at eskortere dig!",

    NO_LICENCE_FOUND = "Borgeren har ingen gyldige licenser!",

    VEHICLE_UNLOCKED = 'Køretøj låst op',

    TARGET = {
        HANDCUFF = "Håndjern / Fjern håndjern",
        SEARCH_PLAYER = "Visitér borger",
        ESCORT = "Eskortere person",
        PUT_IN_VEHICLE = "Sæt i køretøj",
        FROM_VEHICLE = "Tag borger ud",
    },

    MEGA_PHONE = {
        TURN_STATE = 'Tænd / Sluk',
        EXIT = 'Afslut',
        IS_OFF = 'Nærhed: Inaktiv',
        IS_ON = 'Nærhed: Aktiv',
    },

    BODYCAMS = {
        ACTIVATED = "Bodycam er aktiveret!",
        DEACTIVATED = "Bodycam er slukket!",

        LABEL_OFFICER = "Betjent",
        LABEL_CAMERA_ID = "Bodycam ID",
        LABEL_LOCATION = "Lokation",
        LABEL_EXIT = "Afslut bodycam"
    },

    PAPER_BAG = {
        INITIATOR_ADDED_ON_TARGET = 'Du satte en papirpose på borgeren!',
        INITIATOR_REMOVED_FROM_TARGET = 'Du fjernede papirposen fra borgeren',
    },

    JOB = {
        SET_BUSINESS_JOB_USE_CASE = 'Brug: /setjob [playerID] [jobName] [jobGrade]',
        SET_BUSINESS_INVALID_JOB = 'Du skal vælge en af disse: police',
        SET_BUSINESS_INVALID_GRADE = 'Denne rang findes ikke i jobbet',
        NOT_ENOUGH_PERMS_TO_ACCESS = 'Din rang (%s) har ikke adgang til dette!',

        REMOVED_FROM_PLAYER = 'Du fjernede jobbet fra spilleren: %s.',
        ADD_TO_PLAYER = 'Du tilføjede jobbet til spilleren: %s med rang: %s',
        INVALID_TARGET = 'Angiv venligst en målspiller med playerId',
    },

    BLIPS = {
        GPS_COOLDOWN  = "Vent venligst, før du bruger GPS’en igen!",
        GPS_TURN_ON   = "Du har aktiveret din GPS!",
        GPS_TURN_OFF  = "Din GPS er blevet deaktiveret.",

        SUBSCRIBE_ON  = "Du kan nu se dine kolleger på kortet.",
        SUBSCRIBE_OFF = "Dine kollegers blips er blevet skjult fra kortet.",
    },

    COMMANDS_HELP_TEXT = {
        SHOW_BLIPS = "Kommando brugt til at aktivere/deaktivere visning af kollegers blips.",
        PANIC_BUTTON = "Kommando-bruger for betjentens panikknap",
        SEARCH_PLAYER = 'Kommando til at gennemsøge en spiller.',
        ESCORT_PLAYER = 'Kommando til at følge en spiller.',
        PUT_PLAYER_IN_VEH = 'Kommando til at sætte en spiller i et køretøj.',
        GET_PLAYER_FROM_VEH = 'Kommando til at tage en spiller ud af et køretøj.',

        PRESET_CREATOR = 'Værktøj til at oprette afdelingens prædefinerede indstillinger.',
        SET_PLAYER_JOB = 'Kommando til at sætte en borgers job.',
        REMOVE_PLAYER_JOB = 'Kommando til at fjerne en borgers nuværende job.',
        GRANT_LICENCE = 'Kommando til at tildele en borger en licens.',
        REVOKE_LICENCE = 'Kommando til at fjerne en borgers licens.',
    },


    HELP_MESSAGES = {
        NO_TARGET_NIL = 'Angiv venligst playerId på den ønskede borger!',
        NO_TARGET_OFFLINE = 'Den angivne borger er ikke online med dette playerId!',
        NO_ACCESS = 'Du har ikke adgang til at bruge denne kommando!',
        NO_VALID_LICENCE = 'Ugyldig licens: %s - vælg venligst en af disse: fører, våben, erhverv!'
    },

    SUGGESTIONS = {
        KEY_NUMBER = 'nummer',
        KEY_STRING = 'tekst',

        PRESET_CREATOR = '',
        HELP_PRESET_CREATOR = '',

        HELP_PLAYERID = 'Mål playerId',
        HELP_JOB = 'Angiv borgerens job: police',
        HELP_JOB_GRADE = 'Angiv borgerens rang: 1-4',
        HELP_LICENCE = 'Angiv borgerens licens: fører, erhverv, våben'
    },

    RADAR = {
        LOCK_TOGGLE_OFF = 'Radar-lås deaktiveret',
        LOCK_TOGGLE_ON = 'Radar-lås aktiveret',
    },

    PRESET_CREATOR = {
        HELP_KEY_TITLE = "Oprettelse af afdeling",
        HELP_KEY_REMAINING_COUNT = "Tilbageværende antal",
        HELP_KEY_TASK = "Opgave",
        HELP_KEY_ZONE_OWNER = "Zone ejer",
        HELP_KEY_RESOURCE = "Ressource",
        HELP_KEY_SAVE_POINT = "Gem nuværende punkt",
        HELP_KEY_EXIT = 'Afslut',

        DIALOG_CONFIRM_TITLE = "Definér punkt",
        DIALOG_CONFIRM_DESC = "Bekræft",

        DIALOG_RESOURCE_TITLE = "Vælg ressource",
        DIALOG_ZONE_OWNER = "Zone ejer",
        DIALOG_PRESET_TOOL_TITLE = 'Preset værktøj',

        NOT_ENOUGH_PERMISSION = "Du har ikke adgang til at bruge preset skaberen!",

        CLOSE_POINT = "Placering for tæt på eksisterende punkt. Minimum 2 meter kræves",
    },

    BOSS_MENU_ACTIONS = {
        SET_BONUS = 'Bonus sendt til %s på %s %s.',
        PROMOTE_CITIZEN = '%s er blevet forfremmet til %s!',

        DEPOSIT_SOCIETY_MONEY = 'Du har indsat %s %s i samfundskassen.',
        WIDTHRAW_SOCIETY_MONEY = 'Du har hævet %s %s fra samfundskassen.',
    },

    TITLE_NOTIFY = 'Generelt',

    UI = {
        MONEY_SYMBOL = 'kr',
        VIEW_PHOTO = {
            STATE_LOADING = "Indlæser billede...",
            NOT_FOUND_TITLE = "Billede ikke fundet",
            NOT_FOUND_DESC = "Dette billede findes ikke",
            DATE = "Dato",
            LOCATION = "Placering",
        },
        BOSS_MENU = {
            PAGE_DASHBOARD_BUTTON_NAVBAR_LABEL = "Dashboard",
            PAGE_DASHBOARD_BUTTON_FIRE_LABEL = "Fyret",
            PAGE_DASHBOARD_SELECT_EMPLOYEE_LABEL = "Vælg en medarbejder til venstre for at administrere.",
            PAGE_DASHBOARD_CHANGE_GRADE_LABEL = "Skift rang:",
            PAGE_DASHBOARD_SET_BONUS_LABEL = 'Bonus',
            PAGE_DASHBOARD_SET_GRANT_BONUS_TITLE = 'Tildel bonus:',
            PAGE_DASHBOARD_MANAGE_BUTTON_LABEL = "Administrer",

            PAGE_DASHBOARD_EMPLOYEE_ROW = "Medarbejder",
            PAGE_DASHBOARD_GRADE_ROW = "Rang",
            PAGE_DASHBOARD_OPTION_ROW = "Valgmulighed",

            PAGE_DASHBOARD_EMPLOYEES_TITLE = "Medarbejdere",
            PAGE_DASHBOARD_EMPLOYEES_TOTAL = "Total",

            PAGE_DASHBOARD_QUICK_ACTION_TITLE = "Samfundsbeholdning",
            PAGE_DASHBOARD_QUICK_ACTION_DEPOSIT_LABEL = "Indsæt",
            PAGE_DASHBOARD_QUICK_ACTION_WIDTHRAW_LABEL = "Hæv",

            PAGE_DASHBOARD_DIALOG_BONUS_TITLE = "Jobbonus",
            PAGE_DASHBOARD_DIALOG_BONUS_DESC = "For borger ved navn %s",
            PAGE_DASHBOARD_DIALOG_BONUS_DIALOG_OPTIONS_LABEL = "Bekræft bonus",

            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_TITLE = "Skift rang",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DESC = "Fra %s til %s",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DIALOG_OPTIONS_LABEL = "Bekræft rangændring",

            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_TITLE = "Fyld borger",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DESC = "Smid %s ud af jobbet",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DIALOG_OPTIONS_LABEL = "Bekræft fyring",

            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_TITLE = "Samfund",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_LABEL = "Indsætningsbeløb",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_PLACE_HOLDER = "Indtast beløb til indsætning",

            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_TITLE = "Samfund",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_LABEL = "Beløb til hævning",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_PLACE_HOLDER = "Indtast beløb til hævning",

            PAGE_DASHBOARD_SELECT_GRADE = "Vælg rang",
            PAGE_DASHBOARD_SET_GRADE_BUTTON = "Vælg",

            PAGE_GARAGE_TITLE = "Afdelingsgarage",
            PAGE_GARAGE_BUTTON_NAVBAR_LABEL = "Garage",
            PAGE_GARAGE_STOCK_BALANCE = "Lagerbeholdning:",
            PAGE_GARAGE_ORDER_BUTTON_LABEL = "Bestil",

            PAGE_GARAGE_ORDER_DIALOG_TITLE = "Samfund",
            PAGE_GARAGE_ORDER_DIALOG_LABEL = 'Bestillingsantal',
            PAGE_GARAGE_ORDER_DIALOG_PLACEHOLDER = 'Indtast antal til bestilling',

            NAVBAR_TITLE = "TITEL",
            NAVBAR_DESC = "Bossmenu administrationssystem"
        },

        DIALOG = {
            CANCEL_BUTTON = "Annuller",
            CONFIRM_BUTTON = "Bekræft",

            VALIDATION_INPUT_REQUIRED_STRING = "er påkrævet",
            VALIDATION_INPUT_LESS_THAN = "skal være mindre end antal tegn",

            VALIDATION_NUMBER_REQUIRED_NAN = "skal være større end 0",
            VALIDATION_NUMBER_REQUIRED = "er påkrævet",

            TEXT_AREA_IS_REQUIRED = "er påkrævet",
            TEXT_AREA_INPUT_LESS_THAN = "skal være mindre end antal tegn",
        },

        SHOP = {
            BUY = "Køb",
            TAKE = "Tag",
            FREE = "Gratis",
            NO_ITEMS = "Ingen varer fundet i butikken",
            CHECK_BACK_SOON = "Prøv igen senere, tak",
            TITLE = "Afdelingsbutik",
            DESCRIPTION = "Vælg den vare, du ønsker at anskaffe.",
        },

        BOSS_MENU_GARAGE_STOCK = {
            ORDER_NOT_ENOUGH_BUTTON = "Tomt lager",
            ORDER_HAS_BUTTON = "Bestil",
        },

        GARAGE = {
            BUY = "Køb",
            TAKE = "Tag",
            FREE = "Gratis",

            TITLE = "Afdelingsgarage",
            DESCRIPTION = "Vælg det køretøj, du ønsker at anskaffe."
        },

        PAY_DIALOG = {
            CONFIRM_FREE = "Send",
            COMPANY_BUTTON_LABEL = "Firma",
            BANK_BUTTON_LABEL = "Bank",
            INPUT_PLACEHOLDER = "0",
        },

        POLICE_RADAR = {
            PAGE_RADAR = "Radar",
            SETTINGS_RADAR = "Indstillinger",

            FRONT_RADAR_TITLE = "Forreste antenne",
            REAR_RADAR_TITLE = "Bagerste antenne",
            FAST_LOCK_LABEL = "Hurtig lås",

            PLATE_READER_FRONT = "Foran",
            PLATE_READER_REAR = "Bagved",
            PATROL_SPEED = "Patruljehastighed",

            RECENT_PLATE = "Nummerplade",
            RECENT_MODEL = "Model",
            RECENT_SPEED = "Hastighed",
            RECENT_LABEL = "Mærkat",

            SPEED_TITLE = "Hastighed",
        },

        MENU_SETTINGS = {
            TITLE = "Politi Radar",
            DESC = "Ændr dine indstillinger",

            RADAR_SCALE = "Radarskala",
            RADAR_SCALE_DESC = "Juster størrelsen på radaren på skærmen",

            RESET_RADAR_POSITION = "Radars position",
            RESET_RADAR_POSITION_DESC = "Nulstil til standardposition",
            RESET_RADAR_POSITION_BUTTON = "Nulstil",

            RESET_SCALE_POSITION = "Radarskala",
            RESET_SCALE_POSITION_DESC = "Nulstil til standardskala",
            RESET_SCALE_BUTTON = "Nulstil",

            MISC_SECTION = "Diverse",
            FAST_LIMIT = "Hurtig grænse",
            FAST_LIMIT_DESC = "Indstil hastighedsgrænsen",
            RESET_SETTINGS = "Nulstil indstillinger",

            RESET_LABEL = "Nulstil scanner",
            RESET_DESC = "Tillader nulstilling af scanneren",
            RESET_RADAR_BUTTON = "Nulstil",

            RADAR_SECTION = "Radar",
            TOGGLE_RADAR = "Tænd/sluk radar",
            TOGGLE_RADAR_DESC = "Vis / skjul radaren",

            TOGGLE_RADAR_MOVEMENT = "Tænd/sluk radar flytbar",
            TOGGLE_RADAR_MOVEMENT_DESC = "Tillader at trække radaren rundt.",

            RECENT_PLATES_TITLE = "Seneste nummerplader",
            RECENT_PLATES_DESC = "Historik over scannede nummerplader",
            RECENT_PLATES_BUTTON = "Vis/skjul",
        },

        RECENT_PLATES = {
            TITLE = "Seneste nummerplader",
            DESC = "Seneste scannede biler",

            NO_HISTORY = "Ingen historik for denne radar!",
            FILTER_LABEL = "Filtrer efter",

            NEXT_PAGE = "Næste",
            PREVIOUS_PAGE = "Forrige",
            RETURN_TO_SETTINGS_BUTTON_LABEL = "Tilbage til indstillinger",
        },

        BODYCAMS = {
            TITLE = "BodyCam-feed",
            DESC = "Live-feed af aktive kameraer fra dine betjente!",
            NOT_ACTIVE_TITLE = "Ingen aktive bodycams!",
            NOT_ACTIVE_DESC = "Der er i øjeblikket ingen aktive bodycams tilgængelige for live-visning",

            CAMERA_ID = "Kamera:",
            OFFICER = "Betjent:",
            LOCATION = "Placering:",

            VIEW_FEED_BUTTON_TITLE = "Se feed",
        },

        REPORTS = {
            FILTER_LABEL = "Filtre",
            MAIN_MENU_TITLE = "Rapporter",
            MAIN_MENU_DESC = "Her kan du se alle borgernes rapporter.",

            HEADER_PLAYER = "Borger",
            HEADER_PHONE = "Telefon",
            HEADER_STATUS = "Status",
            HEADER_ACTIONS = "Handling",

            ACTIONS_REPORT_OPEN = "Vis rapport",
            ACTIONS_REPORT_CLOSE = "Luk rapport",

            STATE = "Rapportstatus",
            STATUS_OPTIONS = "Vælg rapportstatus",
            UPDATE_STATUS = "Opdater status",
            SAVE_STATUS = "Gem status",

            ADD_NOTE = "Tilføj note",
            SAVE_NOTE = "Gem note",
            SAVE = "Gem",

            NOTE_PLACEHOLDER = "Tilføj din note til rapporten",

            DELETE_REPORT = "Slet rapport",
            BACK_TO_REPORTS = "Tilbage til rapporter",

            NO_REPORTS_FOUND = "Ingen resultater.",

            PREVIOUS_BUTTON = "Forrige",
            NEXT_PREVIOUS_BUTTON = "Næste",

            REPORT_TITLE = "Rapportdetaljer:",
            REPORT_PLAYER_NAME = "Borgernavn:",
            REPORT_MESSAGE = "Besked",
            REPORT_PLAYER_PHONE = "Telefon:",
            REPORT_STATUS = "Status:",
            REPORT_NOTE = "Note:",

            STATES_NEW_REPORT = "Ny rapport",
            STATES_IN_REVIEW = "Under behandling",
            STATES_RESOLVED = "Løst",
        },

        RADIAL_MENU = {
            PRESS_LABEL = "Tryk",
            GO_BACK_LABEL = "Gå tilbage",
        },

        GO_BACK_BUTTON = "◀ Tilbage"
    },
}
