Locales['es'] = {
    NO_CITIZEN_NEARBY = '¡No hay ciudadanos cerca!',
    SELECT_PLAYER_MENU_TITLE = 'Seleccionar jugadores',
    CANNOT_PEFORM_UNDEFINED_ACTION = "¡No puedes realizar una acción no definida!",
    YOU_ARE_AREADY_IN_PLACING_MODE = "¡Ya estás ocupado con la tarea actual!",

    UNLOCKING_VEHICLE = 'Desbloqueando vehículo',

    RELEASE_PLAYER_TACKLE = "Liberar jugador",
    CUFF_PLAYER_TACKLE = "Esposar jugador y escoltar",

    SEARCHING_CITIZEN = "Buscando ciudadano",

    OFFICER_SEARCH = "Estás buscando a un ciudadano",
    SEARCH_TARGET = "¡Estás siendo registrado!",
    ACTION_REQUIRE_ADMIN_RIGHTS = "¡Necesitas tener derechos de administrador para usar esto!",

    ACTIONS_REQUIRE_HANDSUP = "¡El ciudadano debe tener las manos en alto!",
    ACTIONS_REQUIRE_CUFFED = "¡El ciudadano debe estar esposado!",
    ACTIONS_REQUIRE_CUFFED_OR_HANDSUP = "¡El ciudadano debe estar esposado o tener las manos en alto!",
    ACTIONS_REQUIRE_CUFFED_OR_DEAD_SEARCH_INV =
    "El ciudadano debe estar esposado o muerto para que puedas abrir su inventario.",

    ZIPTIES_INITIATOR = "¡Has esposado a un ciudadano con bridas!",
    ZIPTIES_TARGET = "¡Un ciudadano te ha esposado con bridas!",

    ZIPTIES_INITIATOR_REMOVE = "¡Has quitado las bridas a un ciudadano!",
    ZIPTIES_TARGET_REMOVE = "Un ciudadano te ha quitado las bridas de las manos.",

    PLAYER_IS_NOT_ZIPTIED = "¡El ciudadano no está atado con bridas!",

    PLAYER_NAME_INPUT_INVOICE = "Nombre del jugador",
    PLAYER_NAME_INPUT = "Jugador objetivo",
    MEGAPHONE_NOT_USEABLE_IN_VEHICLE = "El megáfono no se puede usar en un vehículo!",
    INTERACT_TARGET_PREFIX_JOB = "Policía",
    PLAYER_IS_NOT_HANDCUFFED = "¡El ciudadano no está esposado!",
    YOU_DONT_HAVE_ITEM_IN_YOUR_INVENTORY = "¡No tienes un artículo llamado %s para esta acción!",
    YOU_CANNOT_DO_THAT_WHILE_ESCORTING_PLAYER = "¡No puedes realizar esta acción mientras escoltas a un ciudadano!",

    TO_INTERACT_NEED_TO_FACE_TARGET = "¡Necesitas tener al ciudadano a la vista para realizar la acción!",

    PLAYER_ESCAPED_TACKLE = "¡El jugador escapó del agarre!",

    SENT_FINE = "¡Enviaste una multa al ciudadano!",

    EMPTY_INVENTORY = "No se encontró nada en el inventario",

    CITIZEN_MUST_CUFFED = "¡El ciudadano debe estar esposado!",
    CITIZEN_NOT_IN_FRONT = "¡Necesitas estar frente al ciudadano!",

    NOT_MDT_LOADED_STANDALONE = "¡No se pudo abrir tu MDT!",
    NOT_DISPATCH_PANEL_LOADED_STANDALONE = "¡No se pudo abrir el panel de despacho!",

    STOP_ESCORT_LABEL = "Detener escolta",
    ATTEMPT_BREAK_LABEL = "Intentar escapar",
    CUFF_LABEL = 'Esposar ciudadano',

    MINIGAME_ESCORT_ESCAPE_FOR_OFFICER = "¡El ciudadano escapó de la escolta!",
    MINIGAME_ESCORT_ESCAPE_FOR_TARGET = "¡Escapaste de la escolta, corre!",

    ZIP_TIES = 'Bridas',
    HANDCUFFS_KEY = "Llave de esposas",
    PAPERBAG = "Bolsa de papel",
    HANDCUFFS = "Esposas",
    BARRIER = "Barrera",
    ZIP_TIES_CUTTER = "Cortador de bridas",
    MEGAPHONE = "Megáfono",
    SPEEDCAMERA = "Cámara de velocidad",
    SPIKES = "Pinchos",

    INPUT_JAIL_PLAYER = {
        HEADER = 'Encarcelar jugador - tiempo',
        REASON_LABEL = 'Motivo (opcional)',
        JAIL_TIME_LABEL = 'Cantidad',
    },

    DYNAMIC_ACTION = {
        SELECT_KEY = 'Seleccionar',
        EXIT_KEY = 'Salir',
    },

    VEHICLE_MENU = {
        UNLOCK_VEHICLE = 'Desbloquear vehículo',
        IMPOUND_VEHICLE = 'Incautar vehículo',
        VEHICLE_INFORMATION = 'Información del vehículo',
        VEHICLE_EXTRAS = 'Extras del vehículo',
    },


    SELECT_PLAYERS = {
        PLAYER = 'Jugador',
    },

    SPEED_RADAR = {
        RECEIVED_FINE = 'Recibiste una multa de %s %s por exceso de velocidad en %s.',
    },
    CAMERA = {
        TAKE_PHOTO_HELPKEY = "Tomar foto",
        EXIT_HELPKEY = "Salir",

        ZOOM_HELPTEXT = "Usa la rueda del ratón para hacer zoom",

        PROCESSING_PHOTO = "¡La foto se está procesando!",
        PROCESSING_PHOTO_FINISHED = "¡La foto ha sido añadida a tu inventario!"
    },
    OUTFITS = {
        MENU_TITLE = 'Uniformes de trabajo',
        RESTORE_OUTFIT_LABEL = 'Restaurar uniforme'
    },

    ESCORT = {
        KEYMAP_DESCRIPTION = 'Esposar: (solo durante la escolta)',
        INITIATOR_PLAYER_RELEASED_FROM_SCORT = '¡Has liberado al ciudadano de la escolta!',
        TARGET_PLAYER_RELEASED_FROM_ESCORT = '¡Has sido liberado de la escolta!'
    },

    POINTS = {
        STORE_VEHICLE = 'Guardar vehículo'
    },

    PROP_EDITOR = {
        PROP_FAR_AWAY_BLOCKED = '¡El objeto está demasiado lejos, bloqueando la colocación!',
        CAN_PLACE_PROP = '¡Puedes colocar el objeto!'
    },

    ZONES_LABELS = {
        WRITE_REPORT = "Escribir informe",
        REPORTS = "Informes",
        WEAPON_STORAGE = 'Almacén de armas',
        WEAPON_SHOP = 'Tienda de armas',
        GARAGE_VEHICLE = 'Garaje de trabajo',
        BOSS_MENU = 'Menú del jefe',
        DUTY = 'Servicio',
        JOB_STASH = 'Almacén compartido del trabajo',
        PERSONAL_LOCKER = 'Casillero personal',
        EVIDENCE_STASH = 'Almacén de evidencias',
        OUTFIT_ROOM = 'Sala de uniformes',
    },

    NOTIFY = {
        COPY_VALUE = 'Copiaste el valor: %s'
    },

    VEHICLE_INFO = {
        MENU_TITLE = 'Información del vehículo',

        PG_LABEL = 'Procesando información del vehículo.',

        VEHICLE_PLATE = 'Matrícula del vehículo',
        VEHICLE_OWNER_NAME = 'Propietario',
        VEHICLE_NAME = 'Nombre del vehículo',
        OWNER_PHONE_NUMBER = 'Teléfono del propietario',
        OWNER_IDENTIFIER = 'ID estatal',
    },

    EVIDENCE = {
        TITLE = 'Almacén de evidencias',
        INPUT_LABEL = 'Número de evidencia',
        INPUT_PLACEHOLDER = '1'
    },

    JOB_STASH = {
        TITLE = 'Almacén del trabajo',
        INPUT_LABEL = 'Número de almacén',
        INPUT_PLACEHOLDER = '1'
    },

    STASHES = {
        PERSONAL_LOCKER_LABEL = 'Casillero personal',
        EVIDENCE_STASH_LABEL = 'Almacén de evidencias: %s',
        JOB_STASH_LABEL = 'Almacén del trabajo: %s',
    },

    JOB_MENU = {
        MENU_TITLE = 'Menú del trabajo',
    },

    INTERACTIONS = {
        OFFICER_JAILED_TARGET = '¡Enviaste al ciudadano a prisión!'
    },

    MENUS = {
        MAIN_MENU_PROPS_TITLE = 'Objetos',
        MAIN_MENU_VEHICLE_INTERACTIONS_TITLE = 'Interacciones con vehículos',
        MAIN_MENU_CITIZEN_TITLE = 'Interacciones con ciudadanos',

        FROM_VEHICLE = 'Desde el vehículo',
        IN_VEHICLE = 'En el vehículo',


        CITIZEN_SUB_MENU_ESCORT_PLAYER_TITLE = 'Escoltar jugador',
        CITIZEN_SUB_MENU_CUFF_SOFT_TITLE = 'Esposar',
        CITIZEN_SUB_MENU_SENT_TO_JAIL_TITLE = 'Enviar a la cárcel',
        CITIZEN_SUB_MENU_SENT_TO_COMS_TITLE = 'Enviar a COMS',
        CITIZEN_SUB_MENU_INVOICE_TITLE = 'Multa',
        CITIZEN_SUB_MENU_SEARCH_PLAYER_TITLE = 'Registrar jugador',
        CITIZEN_SUB_MENU_SHOW_PLAYER_LICENSES = 'Mostrar licencias del jugador',

        GO_BACK_BUTTON_LABEL = 'Volver al menú anterior',
    },

    SEARCH_PLAYER = {
        ITEM_CONSFICATED = '¡El artículo fue confiscado (%s) por el oficial!',
        ITEM_CONFISCATED_BY_OFFICER = '¡Confiscaste un artículo llamado %s del ciudadano!',
    },

    MENU_INTERACT = {
        NOT_CLOSE_TO_ANY_VEHICLE = '¡No estás cerca de ningún vehículo!'
    },

    INVOICES = {
        INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER = 'Multa enviada con éxito',
        TARGET_SUCCESS_RECEIVED_INVOICE_FROM_PLAYEr = '¡Recibiste una multa!',

        INPUT_INVOICE_MENU_TITLE = 'Menú de multas',
        INPUT_INVOICE_FINE_LABEL = 'Monto de la multa:',
        INPUT_INVOICE_SUBMIT_LABEL = 'Enviar'
    },

    LICENSES = {
        MENU_TITLE               = "Licencias",
        CONFISCATED              = '¡Tu licencia %s fue confiscada!',
        RECEIVED_LICENSE         = 'Obtuviste una licencia llamada: %s',
        YOU_ALREADY_HAVE_LICENSE = '¡No se puede otorgar la licencia %s porque ya la tienes!',
        YOU_DONT_HAVE_LICENSE    = '¡No se puede quitar tu licencia %s porque no la tienes!',
        HAS_LICENSE              = 'Sí',
        NO_LICENSE               = 'No',
    },

    DISPATCH = {
        OFFICER_SENT_EMERGENCY_CALL_TITLE = 'Alerta de emergencia',
        OFFICER_SENT_EMERGENCY_CALL = '%s envió una llamada de emergencia, ¡necesita ayuda!'
    },

    PROPS = {
        FAILED_TO_SPAWN_PROP = '¡No se puede cargar %s porque no está definido!',
        PICKING_UP_PROP = 'Recogiendo objeto: %s',
        PLACING_OBJECT = "Colocando objeto: %s",
        CANCELING_PLACING = "Abandonaste la colocación del objeto: %s",
        FAILED_PLACING = "Fallaste al colocar el objeto: %s",
        ALREADY_PICKING_UP = '¡Alguien ya está retirando el objeto!',
        CANNOT_PLACE_ON_ANOTHER_OBJECT = '¡Ya hay un objeto en este lugar!',
        HELP_TEXT = "Recoger objeto",
        YOU_DONT_HAVE_ITEM_IN_INVENTORY = "¡No tienes este artículo llamado %s en tu inventario!",
    },

    CAMERA_SPEED_RADAR = {
        TITLE = "Radar de cámara",
        INPUT_SPEED_LABEL = "Tipo de velocidad: %s",
        INPUT_SPEED_PLACEHOLDER = "Define la velocidad máxima",
        INPUT_FINE_LABEL = "Multa",
        INPUT_FINE_PLACEHOLDER = "Define la multa",
        INPUT_BLIP_LABEL = "Mostrar marcador en el mapa:",
    },

    FINES = {
        HEADER_MENU_TITLE = 'Multas',
        HEADER_MENU_LABEL_PREFIX = "Precio de la multa: %s",
    },

    WEAPON_SHOP = {
        MENU_TITLE = 'Tienda de armería',
        MENU_WEAPON_LABEL = ('%s: %s %s'),
        MENU_WEAPON_LABEL_FREE = ('%s: Gratis'),
        BUY_WEAPON_FAILED_NOT_ENOUGH_PERMS =
        'No se pudo obtener el objeto: %s, ¡no tienes el rango suficiente para comprarlo!',
        BUY_WEAPON_FAILED_NOT_ENOUGH_BALANCE =
        '¡No se pudo obtener el artículo: %s, no tienes suficiente saldo para comprarlo!',
        BUY_WEAPON_FAILED_NOT_WEAPON_LICENSE = '¡No se pudo obtener el artículo: %s, no tienes licencia de armas!',
        BUY_WEAPON_SUCCESS = '¡Obtuviste un artículo llamado: %s de la tienda del departamento!',

        DIALOG_TITLE = 'Artículo: %s',
        DIALOG_INPUT_TITLE = "Define la cantidad",
        DIALOG_DSC = '¿Estás seguro de que quieres obtener este artículo de la tienda del departamento?',
    },

    GARAGE = {
        MENU_TITLE = 'Garaje del trabajo',
        NOT_FREE_PARKING_SPACE = '¡No se puede recuperar el vehículo del garaje porque no hay espacio libre!',
        NOT_ENOUGH_MONEY_IN_SOCIETY_TO_GET_VEHICLE =
        '¡Tu departamento no tiene suficiente dinero %s %s para sacar un vehículo del garaje!',
        NOT_ENOUGH_MONEY_IN_BANK_TO_GET_VEHICLE = '¡No tienes suficiente dinero %s %s en tu banco!',
        NOT_DEPARTMENT_VEHICLE = "¡No puedes guardar un vehículo que no pertenece al garaje del departamento!",
        VEHICLE_WAS_STORED = '¡El vehículo fue guardado en el garaje!',
        VEHICLE_BOUGHT = 'Compraste con éxito un vehículo del departamento por %s %s',
        PAYDIALOG_TITLE = 'Pagar por el vehículo llamado %s',
        PAYDIALOG_DESC = 'Selecciona la opción de pago para obtener el vehículo del garaje!',
        IMPOUND_ACTION = 'Enviando vehículo al depósito',

        GARAGE_ORDER_VEHICLE_SUCC = '¡Ordenaste %s vehículos por el precio de %s %s!',
        GARAGE_ORDER_VEHICLE_FAIL = '¡No hay suficiente dinero en el departamento para ordenar vehículos %s %s!',

        GARAGE_REQUEST_VEH_SUCC = '¡Vehículo recuperado del garaje!',
        GARAGE_REQUEST_VEH_FAILURE = '¡No hay suficientes vehículos en el garaje!',

        INPUT_TITLE = "Ordenar vehículo",
        INPUT_LABEL = "Define la cantidad",
        INPUT_PLACEHOLDER = "10"
    },

    BOSS_MENU = {
        HEADER_TITLE_MENU = "Departamento",
        TITLE_MENU = "Menú del jefe",
        TITLE_ORDER = 'Ordenar vehículos',
        YOU_HIRED_PLAYER = "¡Has contratado al ciudadano %s para el trabajo!",
        YOU_HIRED_BY_INITIATOR = "¡Has sido contratado para el trabajo llamado %s por %s!"
    },

    IMPOUNDS = {
        VEHICLE_SENT_TO_IMPOUND = "¡El vehículo fue enviado al depósito!",
        VEHICLE_REVOKE_SENT_TO_IMPOUND = "¡Tu acción fue revocada!"
    },

    PROGRESS_BAR = {
        CANCEL_ACTION_LABEL = "Cancelar"
    },

    PERSONAL_STORAGE = {
        TITLE = 'Almacén personal',
    },

    DUTY = {
        TITLE = 'Servicio del departamento',
        ON_DUTY_SERVICE_MSG = 'En servicio',
        OFF_DUTY_SERVICE_MSG = 'Fuera de servicio',

        NEED_TO_BE_ON_DUTY_TO_INTERACT_WITH_ZONE = 'Necesitas estar en servicio para poder interactuar',
        NEED_TO_BE_ON_DUTY_TO_OPEN_MENU = '¡Necesitas estar en servicio para abrir este menú!',
        YOU_ARE_IN_SERVICE = '¡Estás en servicio!',
        YOU_ARE_OFF_SERVICE = '¡Estás fuera de servicio!',
        COOLDOWN = '¡Por favor, espera antes de realizar otra acción!'
    },

    REPORTS = {
        PLAYER_SUBMITTED_REPORT = '¡Tu informe fue enviado!',
        PLAYER_REACHED_MAXIMUM_OPEN_REPORT = '¡Ya abriste un informe, espera un poco antes de abrir otro!',
        PLAYER_DELETED_REPORT = "¡El informe fue eliminado!",

        RECEIVED_NEW_REPORT_OFFICERS = "¡Un ciudadano ha presentado un nuevo informe!",

        OFFICER_UPDATED_REPORT_NOTE = "Nota del informe (%s) actualizada a %s por %s",
        OFFICER_UPDATED_REPORT_STATUS = "Estado del informe (%s) actualizado a %s por %s",

        INPUT_TITLE = "Reportar incidente",
        INPUT_YOUR_NAME = "Tu nombre",
        INPUT_PHONE_NUMBER = "Número de teléfono",
        INPUT_DETAILS = "Mensaje"
    },

    RADIAL_MENU = {
        CUFF_LABEL = "Esposar",
        ESCORT_LABEL = "Escoltar",
        LICENCES_LABEL = "Licencias",
        IN_VEHICLE_LABEL = "Meter en",
        FROM_VEHICLE_LABEL = "Sacar",
        SEARCH_LABEL = "Registrar",
        JAIL_LABEL = "Encarcelar",
        EMERGENCY_LABEL = "Emergencia",
        FINE_LABEL = "Multa",
        MDT_LABEL = "MDT",

        PROP_SPEED_RADAR_LABEL = "Radar de velocidad",

        MAIN_MENU_TITLE = "Menú principal",
        POLICE_MENU_TITLE = "Otros",
        DISPATCH_LABEL = "Despacho",
        IMPOUND_VEHICLE = "Depositar",
        UNLOCK_VEHICLE = "Desbloquear vehículo",
        VEHICLE_INFO = "Información del vehículo",
        COMS = "COMS",
        RADAR = "Radar",
        MEGAPHONE = "Megáfono",
        SPIKES = "Pinchos",
        BARRIER = "Barrera",
    },

    NO_REQUIRED_JOB = "¡No estás en el departamento de policía para realizar esta acción!",
    CURRENCY_SYMBOL = '$',

    KEY_MAPPING = {
        EXIT_BODYCAM = "Salir de la cámara corporal",
        RADIAL_MENU = "Abrir menú radial",
        JOB_MENU = "Abrir menú del trabajo",
        TACKLE_CUFF_AND_ESCORT_PLAYER = 'Escoltar y esposar jugador',
        TACKLE_PLAYER = "Derribar jugador cercano",
        TACKLE_STOP = 'Detener derribo',
        INTERACT_ZONE = "Interactuar con zona",
        ESCORT_ESCAPE = "Escapar de la escolta",
        HANDS_UP = "Manos arriba",
        STOP_ESCORT = "Detener escolta",
        MEGAPHONE_STATE = 'Proximidad del megáfono',
        MEGAPHONE_EXIT = 'Dejar de usar el megáfono'
    },

    HANDCUFF_INITIATOR = "¡Estás esposando a un ciudadano!",
    HANDCUFF_TARGET = "¡Estás siendo esposado por un oficial!",

    HANDCUFF_INITIATOR_REMOVE = "¡Quitaste las esposas al ciudadano!",
    HANDCUFF_TARGET_REMOVE = "El oficial te quitó las esposas.",

    ESCORT_INITIATOR = "¡Estás escoltando a un ciudadano!",
    ESCORT_TARGET = "¡Estás siendo escoltado por un oficial!",

    ESCORT_INITIATOR_PED_REMOVE = "¡Dejaste de escoltar al ciudadano!",
    ESCORT_TARGET_PED_REMOVE = "¡El oficial dejó de escoltarte!",

    NO_LICENCE_FOUND = "¡El ciudadano no tiene ninguna licencia!",

    VEHICLE_UNLOCKED = 'Vehículo desbloqueado',

    TARGET = {
        HANDCUFF = "Esposar/Desesposar",
        SEARCH_PLAYER = "Registrar jugador",
        ESCORT = "Escoltar",
        PUT_IN_VEHICLE = "Meter en vehículo",
        FROM_VEHICLE = "Sacar ciudadano",
    },

    MEGA_PHONE = {
        TURN_STATE = 'Encender / apagar',
        EXIT = 'Salir',
        IS_OFF = 'Proximidad: Inactivo',
        IS_ON = 'Proximidad: Activo',
    },

    BODYCAMS = {
        ACTIVATED = "¡La cámara corporal está activa!",
        DEACTIVATED = "¡La cámara corporal está apagada!",

        LABEL_OFFICER = "Oficial",
        LABEL_CAMERA_ID = "ID de cámara corporal",
        LABEL_LOCATION = "Ubicación",
        LABEL_EXIT = "Salir de la cámara corporal"
    },

    PAPER_BAG = {
        INITIATOR_ADDED_ON_TARGET = '¡Pusiste una bolsa de papel en el ciudadano!',
        INITIATOR_REMOVED_FROM_TARGET = '¡Quitaste la bolsa de papel del ciudadano!',
    },

    JOB = {
        SET_BUSINESS_JOB_USE_CASE = 'Uso: /setjob [ID del jugador] [nombre del trabajo] [grado del trabajo]',
        SET_BUSINESS_INVALID_JOB = 'Necesitas escribir uno de estos: policía',
        SET_BUSINESS_INVALID_GRADE = 'Este grado no existe en este trabajo',
        NOT_ENOUGH_PERMS_TO_ACCESS = '¡Tu rango (%s) no tiene acceso a esto!',

        REMOVED_FROM_PLAYER = 'Quitaste el trabajo a este jugador: %s.',
        ADD_TO_PLAYER = 'Añadiste un trabajo a este jugador: %s con grado: %s',
        INVALID_TARGET = 'Por favor, especifica el ID del jugador objetivo',
    },

    BLIPS = {
        GPS_COOLDOWN  = "¡Por favor espera antes de usar el GPS otra vez!",
        GPS_TURN_ON   = "¡Has activado tu GPS!",
        GPS_TURN_OFF  = "Tu GPS ha sido desactivado.",

        SUBSCRIBE_ON  = "Ahora puedes ver a tus compañeros en el mapa.",
        SUBSCRIBE_OFF = "Los blips de tus compañeros han sido ocultados del mapa.",
    },

    COMMANDS_HELP_TEXT = {
        SHOW_BLIPS = "Comando usado para activar/desactivar la visualización de los blips de compañeros.",
        PANIC_BUTTON = "Usuario del comando del botón de pánico del oficial",
        SEARCH_PLAYER = 'Comando usado para registrar a un jugador.',
        ESCORT_PLAYER = 'Comando usado para escoltar a un jugador.',
        PUT_PLAYER_IN_VEH = 'Comando usado para meter al jugador en un vehículo.',
        GET_PLAYER_FROM_VEH = 'Comando usado para sacar al jugador del vehículo.',
        PRESET_CREATOR = 'Herramienta para crear presets del departamento.',
        SET_PLAYER_JOB = 'Comando usado para asignar un trabajo al ciudadano.',
        REMOVE_PLAYER_JOB = 'Comando usado para quitar el trabajo actual del ciudadano',
        GRANT_LICENCE = 'Comando usado para otorgar una licencia al ciudadano.',
        REVOKE_LICENCE = 'Comando usado para revocar una licencia del ciudadano.'
    },

    HELP_MESSAGES = {
        NO_TARGET_NIL = '¡Por favor, especifica el ID del jugador objetivo!',
        NO_TARGET_OFFLINE = '¡No se encontró a este ciudadano en línea con este ID!',
        NO_ACCESS = '¡No tienes acceso para usar este comando!',
        NO_VALID_LICENCE = 'Licencia inválida: %s - ¡por favor selecciona una de estas: conductor, arma, negocio!'
    },

    SUGGESTIONS = {
        KEY_NUMBER = 'número',
        KEY_STRING = 'texto',

        PRESET_CREATOR = '',
        HELP_PRESET_CREATOR = '',

        HELP_PLAYERID = 'ID del jugador objetivo',
        HELP_JOB = 'Especifica el trabajo del ciudadano: policía',
        HELP_JOB_GRADE = 'Especifica el grado del ciudadano: 1-4',
        HELP_LICENCE = 'Especifica la licencia del ciudadano: conductor, arma, negocio'
    },

    RADAR = {
        LOCK_TOGGLE_OFF = 'Bloqueo del radar desactivado',
        LOCK_TOGGLE_ON = 'Bloqueo del radar activado',
    },

    PRESET_CREATOR = {
        HELP_KEY_TITLE = "Creación de departamento",
        HELP_KEY_REMAINING_COUNT = "Cantidad restante",
        HELP_KEY_TASK = "Tarea",
        HELP_KEY_ZONE_OWNER = "Propietario de la zona",
        HELP_KEY_RESOURCE = "Recurso",
        HELP_KEY_SAVE_POINT = "Guardar punto actual",

        DIALOG_CONFIRM_TITLE = "Definir punto",
        DIALOG_CONFIRM_DESC = "Verificar",

        DIALOG_RESOURCE_TITLE = "Seleccionar recurso",
        DIALOG_ZONE_OWNER = "Propietario de la zona",
        DIALOG_PRESET_TOOL_TITLE = 'Herramienta de preset',

        NOT_ENOUGH_PERMISSION = "¡No tienes acceso para usar el creador de presets!",

        CLOSE_POINT = "Colocación demasiado cerca de un punto existente. ¡Mínimo 2m requerido!",
    },

    BOSS_MENU_ACTIONS = {
        SET_BONUS = 'Bonificación enviada con éxito a %s por un monto de %s %s.',
        PROMOTE_CITIZEN = '¡Promoviste con éxito a %s a %s!',

        DEPOSIT_SOCIETY_MONEY = 'Depositaste con éxito %s %s en la sociedad.',
        WIDTHRAW_SOCIETY_MONEY = 'Retiraste con éxito %s %s de la sociedad.',
    },

    TITLE_NOTIFY = 'General',

    UI = {
        MONEY_SYMBOL = '$',

        VIEW_PHOTO = {
            STATE_LOADING = "Cargando imagen...",
            NOT_FOUND_TITLE = "Imagen no encontrada",
            NOT_FOUND_DESC = "Esta imagen no existe",
            DATE = "Fecha",
            LOCATION = "Ubicación",
        },

        BOSS_MENU = {
            PAGE_DASHBOARD_BUTTON_NAVBAR_LABEL = "Tablero",
            PAGE_DASHBOARD_BUTTON_FIRE_LABEL = "Despedir",
            PAGE_DASHBOARD_SELECT_EMPLOYEE_LABEL = "Selecciona un empleado de la izquierda para gestionar.",
            PAGE_DASHBOARD_CHANGE_GRADE_LABEL = "Cambiar grado:",
            PAGE_DASHBOARD_SET_BONUS_LABEL = 'Bonificación',
            PAGE_DASHBOARD_SET_GRANT_BONUS_TITLE = 'Otorgar bonificación:',
            PAGE_DASHBOARD_MANAGE_BUTTON_LABEL = "Gestionar",

            PAGE_DASHBOARD_EMPLOYEE_ROW = "Empleado",
            PAGE_DASHBOARD_GRADE_ROW = "Grado",
            PAGE_DASHBOARD_OPTION_ROW = "Opción",

            PAGE_DASHBOARD_EMPLOYEES_TITLE = "Empleados",
            PAGE_DASHBOARD_EMPLOYEES_TOTAL = "Total",

            PAGE_DASHBOARD_QUICK_ACTION_TITLE = "Saldo de la sociedad",
            PAGE_DASHBOARD_QUICK_ACTION_DEPOSIT_LABEL = "Depositar",
            PAGE_DASHBOARD_QUICK_ACTION_WIDTHRAW_LABEL = "Retirar",

            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_TITLE = "Cambiar grado",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DESC = "Para %s a %s",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DIALOG_OPTIONS_LABEL = "Confirmar cambio de grado",

            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_TITLE = "Cambiar grado",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DESC = "Expulsar a %s del trabajo",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DIALOG_OPTIONS_LABEL = "Confirmar expulsión del ciudadano",

            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_TITLE = "Sociedad",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_LABEL = "Monto a depositar",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_PLACE_HOLDER = "Ingresa el monto a depositar",

            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_TITLE = "Sociedad",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_LABEL = "Monto a retirar",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_PLACE_HOLDER = "Ingresa el monto a retirar",

            PAGE_GARAGE_TITLE = "Garaje del departamento",
            PAGE_GARAGE_BUTTON_NAVBAR_LABEL = "Garaje",
            PAGE_GARAGE_STOCK_BALANCE = "Saldo de existencias:",
            PAGE_GARAGE_ORDER_BUTTON_LABEL = "Ordenar",

            PAGE_GARAGE_ORDER_DIALOG_TITLE = "Sociedad",
            PAGE_GARAGE_ORDER_DIALOG_LABEL = 'Cantidad a ordenar',
            PAGE_GARAGE_ORDER_DIALOG_PLACEHOLDER = 'Ingresa la cantidad a ordenar',

            NAVBAR_TITLE = "TÍTULO",
            NAVBAR_DESC = "Sistema de gestión del menú del jefe"
        },

        DIALOG = {
            CANCEL_BUTTON = "Cancelar",
            CONFIRM_BUTTON = "Confirmar",

            VALIDATION_INPUT_REQUIRED_STRING = "es requerido",
            VALIDATION_INPUT_LESS_THAN = "debe tener menos caracteres",

            VALIDATION_NUMBER_REQUIRED_NAN = "debe ser mayor a 0",
            VALIDATION_NUMBER_REQUIRED = "es requerido",

            TEXT_AREA_IS_REQUIRED = "es requerido",
            TEXT_AREA_INPUT_LESS_THAN = "debe tener menos caracteres",
        },

        SHOP = {
            BUY = "Comprar",
            TAKE = "Tomar",
            FREE = "Gratis",
            NO_ITEMS = "No se encontraron artículos en la tienda",
            CHECK_BACK_SOON = "Por favor, intenta de nuevo más tarde",
            TITLE = "Tienda del departamento",
            DESCRIPTION = "Selecciona el artículo que deseas obtener.",
        },

        BOSS_MENU_GARAGE_STOCK = {
            ORDER_NOT_ENOUGH_BUTTON = "Existencias vacías",
            ORDER_HAS_BUTTON = "Ordenar",
        },

        GARAGE = {
            BUY = "Comprar",
            TAKE = "Tomar",
            FREE = "Gratis",

            TITLE = "Garaje del departamento",
            DESCRIPTION = "Selecciona el vehículo que deseas obtener."
        },

        PAY_DIALOG = {
            CONFIRM_FREE = "Enviar",
            COMPANY_BUTTON_LABEL = "Compañía",
            BANK_BUTTON_LABEL = "Banco",
            INPUT_PLACEHOLDER = "0",
        },

        POLICE_RADAR = {
            PAGE_RADAR = "Radar",
            SETTINGS_RADAR = "Configuraciones",

            FRONT_RADAR_TITLE = "Antena frontal",
            REAR_RADAR_TITLE = "Antena trasera",
            FAST_LOCK_LABEL = "Bloqueo rápido",

            PLATE_READER_FRONT = "Frontal",
            PLATE_READER_REAR = "Trasero",
            PATROL_SPEED = "Velocidad de patrulla",

            RECENT_PLATE = "Matrícula",
            RECENT_MODEL = "Modelo",
            RECENT_SPEED = "Velocidad",
            RECENT_LABEL = "Etiqueta",

            SPEED_TITLE = "Velocidad",
        },

        MENU_SETTINGS = {
            TITLE = "Radar policial",
            DESC = "Cambia tus configuraciones",

            RADAR_SCALE = "Escala del radar",
            RADAR_SCALE_DESC = "Ajusta el tamaño del radar en la pantalla",

            RESET_RADAR_POSITION = "Posición del radar",
            RESET_RADAR_POSITION_DESC = "Restablecer a la posición predeterminada",
            RESET_RADAR_POSITION_BUTTON = "Restablecer",

            RESET_SCALE_POSITION = "Escala del radar",
            RESET_SCALE_POSITION_DESC = "Restablecer a la escala predeterminada",
            RESET_SCALE_BUTTON = "Restablecer",

            MISC_SECTION = "MISC",
            FAST_LIMIT = "Límite rápido",
            FAST_LIMIT_DESC = "Controla el límite de velocidad",
            RESET_SETTINGS = "Restablecer configuraciones",

            RESET_LABEL = "Restablecer escáner",
            RESET_DESC = "Permite restablecer el escáner",
            RESET_RADAR_BUTTON = "Restablecer",

            RADAR_SECTION = "Radar",
            TOGGLE_RADAR = "Alternar radar",
            TOGGLE_RADAR_DESC = "Mostrar / Ocultar el radar",

            TOGGLE_RADAR_MOVEMENT = "Alternar movimiento del radar",
            TOGGLE_RADAR_MOVEMENT_DESC = "Permite arrastrar el radar por la pantalla.",

            RECENT_PLATES_TITLE = "Matrículas recientes",
            RECENT_PLATES_DESC = "Historial de matrículas escaneadas",
            RECENT_PLATES_BUTTON = "Mostrar/Ocultar",
        },

        RECENT_PLATES = {
            TITLE = "Matrículas recientes",
            DESC = "Historial reciente de autos escaneados",

            NO_HISTORY = "¡No hay historial para el radar actual!",
            FILTER_LABEL = "Filtrar por",

            NEXT_PAGE = "Siguiente",
            PREVIOUS_PAGE = "Anterior",
            RETURN_TO_SETTINGS_BUTTON_LABEL = "Volver a configuraciones",
        },

        BODYCAMS = {
            TITLE = "Transmisión de cámaras corporales",
            DESC = "Transmisión actual de las cámaras activas de tus oficiales!",
            NOT_ACTIVE_TITLE = "¡No hay cámaras corporales activas!",
            NOT_ACTIVE_DESC = "Actualmente no hay cámaras corporales activas disponibles para ver la transmisión en vivo",

            CAMERA_ID = "Cámara:",
            OFFICER = "Oficial:",
            LOCATION = "Ubicación:",

            VIEW_FEED_BUTTON_TITLE = "Ver transmisión",
        },

        REPORTS = {
            FILTER_LABEL = "Filtros",
            MAIN_MENU_TITLE = "Informes",
            MAIN_MENU_DESC = "Aquí puedes ver todos los informes de los ciudadanos.",

            HEADER_PLAYER = "Ciudadano",
            HEADER_PHONE = "Teléfono",
            HEADER_STATUS = "Estado",
            HEADER_ACTIONS = "Acción",

            ACTIONS_REPORT_OPEN = "Mostrar informe",
            ACTIONS_REPORT_CLOSE = "Cerrar informe",

            STATE = "Estado del informe",
            STATUS_OPTIONS = "Seleccionar estado del informe",
            UPDATE_STATUS = "Actualizar estado",
            SAVE_STATUS = "Guardar estado",

            ADD_NOTE = "Añadir nota",
            SAVE_NOTE = "Guardar nota",
            SAVE = "Guardar",

            NOTE_PLACEHOLDER = "Añade tu nota al informe",

            DELETE_REPORT = "Eliminar informe",
            BACK_TO_REPORTS = "Volver a informes",

            NO_REPORTS_FOUND = "Sin resultados.",

            PREVIOUS_BUTTON = "Anterior",
            NEXT_PREVIOUS_BUTTON = "Siguiente",

            REPORT_TITLE = "Detalles del informe:",
            REPORT_PLAYER_NAME = "Nombre del ciudadano:",
            REPORT_MESSAGE = "Mensaje",
            REPORT_PLAYER_PHONE = "Teléfono:",
            REPORT_STATUS = "Estado:",
            REPORT_NOTE = "Nota:",

            STATES_NEW_REPORT = "Informe nuevo",
            STATES_IN_REVIEW = "En revisión",
            STATES_RESOLVED = "Resuelto",
        },

        RADIAL_MENU = {
            PRESS_LABEL = "Presionar",
            GO_BACK_LABEL = "Volver",
        },

        GO_BACK_BUTTON = "◀ Volver"
    }
}
