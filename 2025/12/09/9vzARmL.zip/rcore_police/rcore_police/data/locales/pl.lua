Locales['pl'] = {
    NO_CITIZEN_NEARBY = 'Brak obywatela w pobliżu!',
    SELECT_PLAYER_MENU_TITLE = 'Wybierz graczy',
    CANNOT_PEFORM_UNDEFINED_ACTION = "Nie możesz wykonać niezdefiniowanej akcji!",
    YOU_ARE_AREADY_IN_PLACING_MODE = "Jesteś już zajęty bieżącym zadaniem!",

    UNLOCKING_VEHICLE = 'Odblokowywanie pojazdu',

    RELEASE_PLAYER_TACKLE = "Zwolnij gracza",
    CUFF_PLAYER_TACKLE = "Skrępuj gracza i eskortuj",

    SEARCHING_CITIZEN = "Przeszukiwanie obywatela",

    OFFICER_SEARCH = "Przeszukujesz obywatela",
    SEARCH_TARGET = "Jesteś przeszukiwany!",
    ACTION_REQUIRE_ADMIN_RIGHTS = "Musisz mieć uprawnienia administratora, aby tego użyć!",

    ACTIONS_REQUIRE_HANDSUP = "Obywatel musi mieć podniesione ręce!",
    ACTIONS_REQUIRE_CUFFED = "Obywatel musi być skuty kajdankami!",
    ACTIONS_REQUIRE_CUFFED_OR_HANDSUP = "Obywatel musi być skuty kajdankami lub mieć podniesione ręce!",
    ACTIONS_REQUIRE_CUFFED_OR_DEAD_SEARCH_INV = "Obywatel musi być skute lub martwy, abyś mógł otworzyć jego ekwipunek.",

    INTERACT_TARGET_PREFIX_JOB = "Policja",

    ZIPTIES_INITIATOR = "Zapiąłeś obywatela kajdankami!",
    ZIPTIES_TARGET = "Zostałeś zapięty kajdankami przez obywatela!",

    ZIPTIES_INITIATOR_REMOVE = "Zdjąłeś kajdanki z obywatela!",
    ZIPTIES_TARGET_REMOVE = "Obywatel zdjął kajdanki z twoich rąk.",

    PLAYER_IS_NOT_ZIPTIED = "Obywatel nie jest zakuty w kajdanki!",


    PLAYER_NAME_INPUT_INVOICE = "Nazwa gracza",
    PLAYER_NAME_INPUT = "Gracz docelowy",
    MEGAPHONE_NOT_USEABLE_IN_VEHICLE = "Nie można używać megafonu w pojeździe!",

    PLAYER_IS_NOT_HANDCUFFED = "Obywatel nie jest skuty!",
    YOU_DONT_HAVE_ITEM_IN_YOUR_INVENTORY = "Nie masz przedmiotu o nazwie %s do tej akcji!",
    YOU_CANNOT_DO_THAT_WHILE_ESCORTING_PLAYER = "Nie możesz wykonać tej akcji podczas eskortowania obywatela!",

    TO_INTERACT_NEED_TO_FACE_TARGET = "Musisz widzieć obywatela, aby wykonać akcję!",

    PLAYER_ESCAPED_TACKLE = "Gracz uciekł z chwytu!",

    SENT_FINE = "Wysłałeś mandat obywatelowi!",

    EMPTY_INVENTORY = "Nic nie znaleziono w ekwipunku",

    CITIZEN_MUST_CUFFED = "Obywatel musi być skuty!",
    CITIZEN_NOT_IN_FRONT = "Musisz stanąć twarzą w twarz z obywatelem!",

    NOT_MDT_LOADED_STANDALONE = "Nie udało się otworzyć twojego MDT!",
    NOT_DISPATCH_PANEL_LOADED_STANDALONE = "Nie udało się otworzyć panelu dyspozytorskiego!",

    STOP_ESCORT_LABEL = "Zakończ eskortę",
    ATTEMPT_BREAK_LABEL = "Próba ucieczki",
    CUFF_LABEL = 'Skrępuj obywatela',

    MINIGAME_ESCORT_ESCAPE_FOR_OFFICER = "Obywatel uciekł z eskorty!",
    MINIGAME_ESCORT_ESCAPE_FOR_TARGET = "Uciekłeś z eskorty, uciekaj!",

    ZIP_TIES = 'Opaski zaciskowe',
    HANDCUFFS_KEY = "Klucz do kajdanek",
    PAPERBAG = "Papierowa torba",
    HANDCUFFS = "Kajdanki",
    BARRIER = "Bariera",
    ZIP_TIES_CUTTER = "Nożyce do opasek zaciskowych",
    MEGAPHONE = "Megafon",
    SPEEDCAMERA = "Kamera prędkości",
    SPIKES = "Kolczatki",

    INPUT_JAIL_PLAYER = {
        HEADER = 'Uwięź gracza - czas',
        REASON_LABEL = 'Powód (opcjonalny)',
        JAIL_TIME_LABEL = 'Ilość',
    },

    DYNAMIC_ACTION = {
        SELECT_KEY = 'Wybierz',
        EXIT_KEY = 'Wyjdź',
    },

    CAMERA = {
        TAKE_PHOTO_HELPKEY = "Zrób zdjęcie",
        EXIT_HELPKEY = "Wyjdź",

        ZOOM_HELPTEXT = "Użyj scrolla, aby przybliżyć",

        PROCESSING_PHOTO = "Zdjęcie jest przetwarzane!",
        PROCESSING_PHOTO_FINISHED = "Zdjęcie zostało dodane do twojego ekwipunku!"
    },

    VEHICLE_MENU = {
        UNLOCK_VEHICLE = 'Odblokuj pojazd',
        IMPOUND_VEHICLE = 'Odholuj pojazd',
        VEHICLE_INFORMATION = 'Informacje o pojeździe',
        VEHICLE_EXTRAS = 'Dodatki do pojazdu',
    },

    SELECT_PLAYERS = {
        PLAYER = 'Gracz',
    },

    SPEED_RADAR = {
        RECEIVED_FINE = 'Otrzymałeś mandat %s %s za przekroczenie prędkości w %s.',
    },

    OUTFITS = {
        MENU_TITLE = 'Stroje służbowe',
        RESTORE_OUTFIT_LABEL = 'Przywróć strój'
    },

    ESCORT = {
        KEYMAP_DESCRIPTION = 'Skrępuj: (tylko podczas eskorty)',
        INITIATOR_PLAYER_RELEASED_FROM_SCORT = 'Zwolniłeś obywatela z eskorty!',
        TARGET_PLAYER_RELEASED_FROM_ESCORT = 'Zostałeś zwolniony z eskorty!'
    },

    POINTS = {
        STORE_VEHICLE = 'Schowaj pojazd'
    },

    PROP_EDITOR = {
        PROP_FAR_AWAY_BLOCKED = 'Obiekt jest za daleko, blokuje umieszczanie!',
        CAN_PLACE_PROP = 'Możesz umieścić obiekt!'
    },

    ZONES_LABELS = {
        WRITE_REPORT = "Napisz raport",
        REPORTS = "Raporty",
        WEAPON_STORAGE = 'Magazyn broni',
        WEAPON_SHOP = 'Sklep z bronią',
        GARAGE_VEHICLE = 'Garaż służbowy',
        BOSS_MENU = 'Menu szefa',
        DUTY = 'Służba',
        JOB_STASH = 'Wspólny magazyn służbowy',
        PERSONAL_LOCKER = 'Szafka osobista',
        EVIDENCE_STASH = 'Magazyn dowodów',
        OUTFIT_ROOM = 'Pokój ze strojami',
    },

    NOTIFY = {
        COPY_VALUE = 'Skopiowałeś wartość: %s'
    },

    VEHICLE_INFO = {
        MENU_TITLE = 'Informacje o pojeździe',

        PG_LABEL = 'Przetwarzanie informacji o pojeździe.',

        VEHICLE_PLATE = 'Tablica rejestracyjna pojazdu',
        VEHICLE_OWNER_NAME = 'Właściciel',
        VEHICLE_NAME = 'Nazwa pojazdu',
        OWNER_PHONE_NUMBER = 'Telefon właściciela',
        OWNER_IDENTIFIER = 'ID państwowe',
    },

    EVIDENCE = {
        TITLE = 'Magazyn dowodów',
        INPUT_LABEL = 'Numer dowodu',
        INPUT_PLACEHOLDER = '1'
    },

    JOB_STASH = {
        TITLE = 'Magazyn służbowy',
        INPUT_LABEL = 'Numer magazynu',
        INPUT_PLACEHOLDER = '1'
    },

    STASHES = {
        PERSONAL_LOCKER_LABEL = 'Szafka osobista',
        EVIDENCE_STASH_LABEL = 'Magazyn dowodów: %s',
        JOB_STASH_LABEL = 'Magazyn służbowy: %s',
    },

    JOB_MENU = {
        MENU_TITLE = 'Menu służbowe',
    },

    INTERACTIONS = {
        OFFICER_JAILED_TARGET = 'Wysłałeś obywatela do więzienia!'
    },

    MENUS = {
        MAIN_MENU_PROPS_TITLE = 'Obiekty',
        MAIN_MENU_VEHICLE_INTERACTIONS_TITLE = 'Interakcje z pojazdami',
        MAIN_MENU_CITIZEN_TITLE = 'Interakcje z obywatelami',

        FROM_VEHICLE = 'Z pojazdu',
        IN_VEHICLE = 'W pojeździe',

        CITIZEN_SUB_MENU_ESCORT_PLAYER_TITLE = 'Eskortuj gracza',
        CITIZEN_SUB_MENU_CUFF_SOFT_TITLE = 'Skrępuj',
        CITIZEN_SUB_MENU_SENT_TO_JAIL_TITLE = 'Wyślij do więzienia',
        CITIZEN_SUB_MENU_SENT_TO_COMS_TITLE = 'Wyślij do COMS',
        CITIZEN_SUB_MENU_INVOICE_TITLE = 'Mandat',
        CITIZEN_SUB_MENU_SEARCH_PLAYER_TITLE = 'Przeszukaj gracza',
        CITIZEN_SUB_MENU_SHOW_PLAYER_LICENSES = 'Pokaż licencje gracza',

        GO_BACK_BUTTON_LABEL = 'Wróć do poprzedniego menu',
    },

    SEARCH_PLAYER = {
        ITEM_CONSFICATED = 'Przedmiot został skonfiskowany (%s) przez funkcjonariusza!',
        ITEM_CONFISCATED_BY_OFFICER = 'Skonfiskowałeś przedmiot o nazwie %s obywatelowi!',
    },

    MENU_INTERACT = {
        NOT_CLOSE_TO_ANY_VEHICLE = 'Nie jesteś blisko żadnego pojazdu!'
    },

    INVOICES = {
        INITIATOR_SUCCESS_SENT_INVOICE_TO_PLAYER = 'Mandat wysłany pomyślnie',
        TARGET_SUCCESS_RECEIVED_INVOICE_FROM_PLAYEr = 'Otrzymałeś mandat!',

        INPUT_INVOICE_MENU_TITLE = 'Menu mandatów',
        INPUT_INVOICE_FINE_LABEL = 'Kwota mandatu:',
        INPUT_INVOICE_SUBMIT_LABEL = 'Wyślij'
    },

    LICENSES = {
        MENU_TITLE               = "Licencje",
        CONFISCATED              = 'Twoja licencja %s została skonfiskowana!',
        RECEIVED_LICENSE         = 'Otrzymałeś licencję o nazwie: %s',
        YOU_ALREADY_HAVE_LICENSE = 'Nie można ci dać licencji %s, ponieważ już ją masz!',
        YOU_DONT_HAVE_LICENSE    = 'Nie można usunąć twojej licencji %s, ponieważ jej nie masz!',
        HAS_LICENSE              = 'Tak',
        NO_LICENSE               = 'Nie',
    },

    DISPATCH = {
        OFFICER_SENT_EMERGENCY_CALL_TITLE = 'Alarm ratunkowy',
        OFFICER_SENT_EMERGENCY_CALL = '%s wysłał wezwanie ratunkowe, potrzebna pomoc!'
    },

    PROPS = {
        FAILED_TO_SPAWN_PROP = 'Nie można załadować %s, ponieważ nie jest zdefiniowany!',
        PICKING_UP_PROP = 'Podnoszenie obiektu: %s',
        PLACING_OBJECT = "Umieszczanie obiektu: %s",
        CANCELING_PLACING = "Porzuciłeś umieszczanie obiektu: %s",
        FAILED_PLACING = "Nie udało się umieścić obiektu: %s",
        ALREADY_PICKING_UP = 'Ktoś już usuwa obiekt!',
        CANNOT_PLACE_ON_ANOTHER_OBJECT = 'W tym miejscu znajduje się już inny obiekt!',
        HELP_TEXT = "Podnieś obiekt",
        YOU_DONT_HAVE_ITEM_IN_INVENTORY = "Nie masz tego przedmiotu o nazwie %s w ekwipunku!",
    },

    CAMERA_SPEED_RADAR = {
        TITLE = "Radar prędkości",
        INPUT_SPEED_LABEL = "Typ prędkości: %s",
        INPUT_SPEED_PLACEHOLDER = "Określ maksymalną prędkość",
        INPUT_FINE_LABEL = "Mandat",
        INPUT_FINE_PLACEHOLDER = "Określ mandat",
        INPUT_BLIP_LABEL = "Pokaż znacznik na mapie:",
    },

    FINES = {
        HEADER_MENU_TITLE = 'Mandaty',
        HEADER_MENU_LABEL_PREFIX = "Cena mandatu: %s",
    },

    WEAPON_SHOP = {
        MENU_TITLE = 'Sklep z bronią',
        MENU_WEAPON_LABEL = ('%s: %s %s'),
        MENU_WEAPON_LABEL_FREE = ('%s: Darmowy'),
        BUY_WEAPON_FAILED_NOT_ENOUGH_PERMS =
        'Nie udało się zdobyć przedmiotu: %s, ponieważ nie masz wystarczającej rangi, aby go kupić!',
        BUY_WEAPON_FAILED_NOT_ENOUGH_BALANCE =
        'Nie udało się zdobyć przedmiotu: %s, brak wystarczających środków na zakup!',
        BUY_WEAPON_FAILED_NOT_WEAPON_LICENSE = 'Nie udało się zdobyć przedmiotu: %s, nie masz licencji na broń!',
        BUY_WEAPON_SUCCESS = 'Zdobyłeś przedmiot o nazwie: %s ze sklepu departamentu!',

        DIALOG_TITLE = 'Przedmiot: %s',
        DIALOG_INPUT_TITLE = "Określ ilość",
        DIALOG_DSC = 'Czy na pewno chcesz zdobyć ten przedmiot ze sklepu departamentu?',
    },

    GARAGE = {
        MENU_TITLE = 'Garaż służbowy',
        NOT_FREE_PARKING_SPACE = 'Nie można wyjąć pojazdu z garażu, brak wolnego miejsca!',
        NOT_ENOUGH_MONEY_IN_SOCIETY_TO_GET_VEHICLE =
        'Twój departament nie ma wystarczających środków %s %s, aby wyjąć pojazd z garażu!',
        NOT_ENOUGH_MONEY_IN_BANK_TO_GET_VEHICLE = 'Nie masz wystarczających środków %s %s na koncie bankowym!',
        NOT_DEPARTMENT_VEHICLE = "Nie możesz schować pojazdu, który nie należy do garażu departamentu!",
        VEHICLE_WAS_STORED = 'Pojazd został schowany do garażu!',
        VEHICLE_BOUGHT = 'Pomyślnie kupiłeś pojazd departamentu za %s %s',
        PAYDIALOG_TITLE = 'Zapłać za pojazd o nazwie %s',
        PAYDIALOG_DESC = 'Wybierz opcję płatności, aby wyjąć pojazd z garażu!',
        IMPOUND_ACTION = 'Wysyłanie pojazdu na parking policyjny',

        GARAGE_ORDER_VEHICLE_SUCC = 'Zamówiłeś %s pojazdów za cenę %s %s!',
        GARAGE_ORDER_VEHICLE_FAIL = 'Brak wystarczających środków w departamencie na zamówienie pojazdów %s %s!',

        GARAGE_REQUEST_VEH_SUCC = 'Pojazd wyjęty z garażu!',
        GARAGE_REQUEST_VEH_FAILURE = 'Brak wystarczającej liczby pojazdów w garażu!',

        INPUT_TITLE = "Zamów pojazd",
        INPUT_LABEL = "Określ ilość",
        INPUT_PLACEHOLDER = "10"
    },

    BOSS_MENU = {
        HEADER_TITLE_MENU = "Departament",
        TITLE_MENU = "Menu szefa",
        TITLE_ORDER = "Zamów pojazdy",
        YOU_HIRED_PLAYER = "Zatrudniłeś obywatela %s do pracy!",
        YOU_HIRED_BY_INITIATOR = "Zostałeś zatrudniony na stanowisko %s przez %s"
    },


    IMPOUNDS = {
        VEHICLE_SENT_TO_IMPOUND = "Pojazd został wysłany na parking policyjny!",
        VEHICLE_REVOKE_SENT_TO_IMPOUND = "Twoja akcja została cofnięta!"
    },

    PROGRESS_BAR = {
        CANCEL_ACTION_LABEL = "Anuluj"
    },

    PERSONAL_STORAGE = {
        TITLE = 'Magazyn osobisty',
    },

    DUTY = {
        TITLE = 'Służba departamentu',
        ON_DUTY_SERVICE_MSG = 'Na służbie',
        OFF_DUTY_SERVICE_MSG = 'Poza służbą',

        NEED_TO_BE_ON_DUTY_TO_INTERACT_WITH_ZONE = 'Musisz być na służbie, aby móc wchodzić w interakcje',
        NEED_TO_BE_ON_DUTY_TO_OPEN_MENU = 'Musisz być na służbie, aby otworzyć to menu!',
        YOU_ARE_IN_SERVICE = 'Jesteś na służbie!',
        YOU_ARE_OFF_SERVICE = 'Jesteś poza służbą!',
        COOLDOWN = 'Proszę, odczekaj przed wykonaniem kolejnej akcji!'
    },

    REPORTS = {
        PLAYER_SUBMITTED_REPORT = 'Twój raport został wysłany!',
        PLAYER_REACHED_MAXIMUM_OPEN_REPORT = 'Już otworzyłeś raport, poczekaj chwilę przed otwarciem kolejnego!',
        PLAYER_DELETED_REPORT = "Raport został usunięty!",

        RECEIVED_NEW_REPORT_OFFICERS = "Nowy raport został zgłoszony przez obywatela!",

        OFFICER_UPDATED_REPORT_NOTE = "Zaktualizowano notatkę raportu (%ismodifieds) na %s przez %s",
        OFFICER_UPDATED_REPORT_STATUS = "Zaktualizowano status raportu (%s) na %s przez %s",

        INPUT_TITLE = "Zgłoś incydent",
        INPUT_YOUR_NAME = "Twoje imię",
        INPUT_PHONE_NUMBER = "Numer telefonu",
        INPUT_DETAILS = "Wiadomość"
    },

    RADIAL_MENU = {
        CUFF_LABEL = "Skrępuj",
        ESCORT_LABEL = "Eskortuj",
        LICENCES_LABEL = "Licencje",
        IN_VEHICLE_LABEL = "Włóż do",
        FROM_VEHICLE_LABEL = "Wyciągnij",
        SEARCH_LABEL = "Przeszukaj",
        JAIL_LABEL = "Uwięź",
        EMERGENCY_LABEL = "Nagły wypadek",
        FINE_LABEL = "Mandat",
        MDT_LABEL = "MDT",

        PROP_SPEED_RADAR_LABEL = "Radar prędkości",

        MAIN_MENU_TITLE = "Menu główne",
        POLICE_MENU_TITLE = "Inne",
        DISPATCH_LABEL = "Dyspozytor",
        IMPOUND_VEHICLE = "Odholuj",
        UNLOCK_VEHICLE = "Odblokuj pojazd",
        VEHICLE_INFO = "Informacje o pojeździe",
        COMS = "COMS",
        RADAR = "Radar",
        MEGAPHONE = "Megafon",
        SPIKES = "Kolczatki",
        BARRIER = "Bariera",
    },

    NO_REQUIRED_JOB = "Nie jesteś w departamencie policji, aby wykonać tę akcję!",
    CURRENCY_SYMBOL = '$',

    KEY_MAPPING = {
        EXIT_BODYCAM = "Wyjdź z kamery osobistej",
        RADIAL_MENU = "Otwórz menu radialne",
        JOB_MENU = "Otwórz menu służbowe",
        TACKLE_CUFF_AND_ESCORT_PLAYER = 'Eskortuj i skrępuj gracza',
        TACKLE_PLAYER = "Powal gracza w pobliżu",
        TACKLE_STOP = 'Zatrzymaj powalenie',
        INTERACT_ZONE = "Interakcja z zoną",
        ESCORT_ESCAPE = "Ucieczka z eskorty",
        HANDS_UP = "Ręce do góry",
        STOP_ESCORT = "Zakończ eskortę",
        MEGAPHONE_STATE = 'Bliskość megafonu',
        MEGAPHONE_EXIT = 'Przestań używać megafonu'
    },

    HANDCUFF_INITIATOR = "Skrępujesz obywatela!",
    HANDCUFF_TARGET = "Zostajesz skuty przez funkcjonariusza!",

    HANDCUFF_INITIATOR_REMOVE = "Zdjąłeś kajdanki obywatelowi!",
    HANDCUFF_TARGET_REMOVE = "Funkcjonariusz zdjął kajdanki z twoich rąk.",

    ESCORT_INITIATOR = "Eskortujesz obywatela!",
    ESCORT_TARGET = "Jesteś eskortowany przez funkcjonariusza!",

    ESCORT_INITIATOR_PED_REMOVE = "Przestałeś eskortować obywatela!",
    ESCORT_TARGET_PED_REMOVE = "Funkcjonariusz przestał cię eskortować!",

    NO_LICENCE_FOUND = "Obywatel nie ma żadnej licencji!",

    VEHICLE_UNLOCKED = 'Pojazd odblokowany',

    TARGET = {
        HANDCUFF = "Skrępuj/Zdejmij kajdanki",
        SEARCH_PLAYER = "Przeszukaj gracza",
        ESCORT = "Eskortuj",
        PUT_IN_VEHICLE = "Włóż do pojazdu",
        FROM_VEHICLE = "Wyciągnij obywatela",
    },

    MEGA_PHONE = {
        TURN_STATE = 'Włącz / Wyłącz',
        EXIT = 'Wyjdź',
        IS_OFF = 'Bliskość: Nieaktywna',
        IS_ON = 'Bliskość: Aktywna',
    },

    BODYCAMS = {
        ACTIVATED = "Kamera osobista jest aktywna!",
        DEACTIVATED = "Kamera osobista jest wyłączona!",

        LABEL_OFFICER = "Funkcjonariusz",
        LABEL_CAMERA_ID = "ID kamery osobistej",
        LABEL_LOCATION = "Lokalizacja",
        LABEL_EXIT = "Wyjdź z kamery osobistej"
    },

    PAPER_BAG = {
        INITIATOR_ADDED_ON_TARGET = 'Założyłeś papierową torbę na obywatela!',
        INITIATOR_REMOVED_FROM_TARGET = 'Zdjąłeś papierową torbę z obywatela',
    },

    JOB = {
        SET_BUSINESS_JOB_USE_CASE = 'Użycie: /setjob [ID gracza] [nazwa pracy] [stopień pracy]',
        SET_BUSINESS_INVALID_JOB = 'Musisz wpisać jedno z tych: policja',
        SET_BUSINESS_INVALID_GRADE = 'Ten stopień nie istnieje w tej pracy',
        NOT_ENOUGH_PERMS_TO_ACCESS = 'Twój stopień (%s) nie ma do tego dostępu!',

        REMOVED_FROM_PLAYER = 'Usunąłeś pracę temu graczowi: %s.',
        ADD_TO_PLAYER = 'Dodałeś pracę temu graczowi: %s z stopniem: %s',
        INVALID_TARGET = 'Proszę, określ ID gracza docelowego',
    },

    BLIPS = {
        GPS_COOLDOWN  = "Proszę poczekać przed ponownym użyciem GPS!",
        GPS_TURN_ON   = "Aktywowałeś swój GPS!",
        GPS_TURN_OFF  = "Twój GPS został dezaktywowany.",

        SUBSCRIBE_ON  = "Możesz teraz widzieć swoich kolegów na mapie.",
        SUBSCRIBE_OFF = "Blipy twoich kolegów zostały ukryte z mapy.",
    },

    COMMANDS_HELP_TEXT = {
        SHOW_BLIPS = "Komenda używana do włączania/wyłączania wyświetlania blipów kolegów.",
        PANIC_BUTTON = "Użytkownik polecenia przycisku alarmowego funkcjonariusza",
        SEARCH_PLAYER = 'Komenda używana do przeszukiwania gracza.',
        ESCORT_PLAYER = 'Komenda używana do eskortowania gracza.',
        PUT_PLAYER_IN_VEH = 'Komenda używana do wsadzenia gracza do pojazdu.',
        GET_PLAYER_FROM_VEH = 'Komenda używana do wyciągnięcia gracza z pojazdu.',
        PRESET_CREATOR = 'Narzędzie do tworzenia presetu departamentu.',
        SET_PLAYER_JOB = 'Komenda używana do ustawiania pracy obywatela.',
        REMOVE_PLAYER_JOB = 'Komenda używana do usuwania obecnej pracy obywatela',
        GRANT_LICENCE = 'Komenda używana do przyznawania licencji obywatelowi.',
        REVOKE_LICENCE = 'Komenda używana do cofania licencji obywatela.'
    },

    HELP_MESSAGES = {
        NO_TARGET_NIL = 'Proszę, określ ID obywatela docelowego!',
        NO_TARGET_OFFLINE = 'Ten określony obywatel nie jest online z tym ID!',
        NO_ACCESS = 'Nie masz dostępu do tej komendy!',
        NO_VALID_LICENCE = 'Nieprawidłowa licencja: %s - proszę wybrać jedną z tych: prawo jazdy, broń, biznes!'
    },

    SUGGESTIONS = {
        KEY_NUMBER = 'liczba',
        KEY_STRING = 'ciąg znaków',

        PRESET_CREATOR = '',
        HELP_PRESET_CREATOR = '',

        HELP_PLAYERID = 'ID gracza docelowego',
        HELP_JOB = 'Określ pracę obywatela: policja',
        HELP_JOB_GRADE = 'Określ stopień obywatela: 1-4',
        HELP_LICENCE = 'Określ licencję obywatela: prawo jazdy, biznes, broń'
    },

    RADAR = {
        LOCK_TOGGLE_OFF = 'Blokada radaru wyłączona',
        LOCK_TOGGLE_ON = 'Blokada radaru włączona',
    },

    PRESET_CREATOR = {
        HELP_KEY_TITLE = "Tworzenie departamentu",
        HELP_KEY_REMAINING_COUNT = "Pozostała liczba",
        HELP_KEY_TASK = "Zadanie",
        HELP_KEY_ZONE_OWNER = "Właściciel strefy",
        HELP_KEY_RESOURCE = "Zasób",
        HELP_KEY_SAVE_POINT = "Zapisz obecny punkt",

        DIALOG_CONFIRM_TITLE = "Określ punkt",
        DIALOG_CONFIRM_DESC = "Sprawdź",

        DIALOG_RESOURCE_TITLE = "Wybierz zasób",
        DIALOG_ZONE_OWNER = "Właściciel strefy",
        DIALOG_PRESET_TOOL_TITLE = 'Narzędzie presetowe',

        NOT_ENOUGH_PERMISSION = "Nie masz dostępu do używania kreatora presetów!",

        CLOSE_POINT = "Umieszczenie zbyt blisko istniejącego punktu. Wymagane minimum 2m",
    },

    BOSS_MENU_ACTIONS = {
        SET_BONUS = 'Pomyślnie wysłano premię do %s w wysokości %s %s.',
        PROMOTE_CITIZEN = 'Pomyślnie awansowano %s na %s!',

        DEPOSIT_SOCIETY_MONEY = 'Pomyślnie wpłaciłeś %s %s na konto społeczeństwa.',
        WIDTHRAW_SOCIETY_MONEY = 'Pomyślnie wypłaciłeś %s %s z konta społeczeństwa.',
    },

    TITLE_NOTIFY = 'Ogólne',

    UI = {
        MONEY_SYMBOL = '$',

        VIEW_PHOTO = {
            STATE_LOADING = "Ładowanie obrazu...",
            NOT_FOUND_TITLE = "Nie znaleziono obrazu",
            NOT_FOUND_DESC = "Ten obraz nie istnieje",
            DATE = "Data",
            LOCATION = "Lokalizacja",
        },

        BOSS_MENU = {
            PAGE_DASHBOARD_BUTTON_NAVBAR_LABEL = "Panel",
            PAGE_DASHBOARD_BUTTON_FIRE_LABEL = "Zwolnij",
            PAGE_DASHBOARD_SELECT_EMPLOYEE_LABEL = "Wybierz pracownika z lewej strony do zarządzania.",
            PAGE_DASHBOARD_CHANGE_GRADE_LABEL = "Zmień stopień:",
            PAGE_DASHBOARD_SET_BONUS_LABEL = 'Premia',
            PAGE_DASHBOARD_SET_GRANT_BONUS_TITLE = 'Przyznaj premię:',
            PAGE_DASHBOARD_MANAGE_BUTTON_LABEL = "Zarządzaj",

            PAGE_DASHBOARD_EMPLOYEE_ROW = "Pracownik",
            PAGE_DASHBOARD_GRADE_ROW = "Stopień",
            PAGE_DASHBOARD_OPTION_ROW = "Opcja",

            PAGE_DASHBOARD_EMPLOYEES_TITLE = "Pracownicy",
            PAGE_DASHBOARD_EMPLOYEES_TOTAL = "Razem",

            PAGE_DASHBOARD_QUICK_ACTION_TITLE = "Saldo społeczeństwa",
            PAGE_DASHBOARD_QUICK_ACTION_DEPOSIT_LABEL = "Wpłać",
            PAGE_DASHBOARD_QUICK_ACTION_WIDTHRAW_LABEL = "Wypłać",

            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_TITLE = "Zmień stopień",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DESC = "Dla %s na %s",
            PAGE_DASHBOARD_DIALOG_CHANGE_GRADE_DIALOG_OPTIONS_LABEL = "Potwierdź zmianę stopnia",

            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_TITLE = "Zmień stopień",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DESC = "Zwolnij %s z pracy",
            PAGE_DASHBOARD_DIALOG_FIRE_CITIZEN_DIALOG_OPTIONS_LABEL = "Potwierdź zwolnienie obywatela",

            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_TITLE = "Społeczeństwo",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_LABEL = "Kwota wpłaty",
            PAGE_DASHBOARD_SOCIETY_DEPOSIT_MONEY_CITIZEN_PLACE_HOLDER = "Wprowadź kwotę do wpłaty",

            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_TITLE = "Społeczeństwo",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_LABEL = "Kwota wypłaty",
            PAGE_DASHBOARD_SOCIETY_WIDTHRAW_MONEY_CITIZEN_PLACE_HOLDER = "Wprowadź kwotę do wypłaty",

            PAGE_GARAGE_TITLE = "Garaż departamentu",
            PAGE_GARAGE_BUTTON_NAVBAR_LABEL = "Garaż",
            PAGE_GARAGE_STOCK_BALANCE = "Stan magazynu:",
            PAGE_GARAGE_ORDER_BUTTON_LABEL = "Zamów",

            PAGE_GARAGE_ORDER_DIALOG_TITLE = "Społeczeństwo",
            PAGE_GARAGE_ORDER_DIALOG_LABEL = 'Kwota zamówienia',
            PAGE_GARAGE_ORDER_DIALOG_PLACEHOLDER = 'Wprowadź kwotę do zamówienia',

            NAVBAR_TITLE = "TYTUŁ",
            NAVBAR_DESC = "System zarządzania menu szefa"
        },

        DIALOG = {
            CANCEL_BUTTON = "Anuluj",
            CONFIRM_BUTTON = "Potwierdź",

            VALIDATION_INPUT_REQUIRED_STRING = "jest wymagane",
            VALIDATION_INPUT_LESS_THAN = "musi mieć mniej znaków",

            VALIDATION_NUMBER_REQUIRED_NAN = "musi być większe niż 0",
            VALIDATION_NUMBER_REQUIRED = "jest wymagane",

            TEXT_AREA_IS_REQUIRED = "jest wymagane",
            TEXT_AREA_INPUT_LESS_THAN = "musi mieć mniej znaków",
        },

        SHOP = {
            BUY = "Kup",
            TAKE = "Weź",
            FREE = "Darmowy",
            NO_ITEMS = "Nie znaleziono przedmiotów w sklepie",
            CHECK_BACK_SOON = "Spróbuj ponownie później",
            TITLE = "Sklep departamentu",
            DESCRIPTION = "Wybierz przedmiot, który chcesz zdobyć.",
        },

        BOSS_MENU_GARAGE_STOCK = {
            ORDER_NOT_ENOUGH_BUTTON = "Pusty stan",
            ORDER_HAS_BUTTON = "Zamów",
        },

        GARAGE = {
            BUY = "Kup",
            TAKE = "Weź",
            FREE = "Darmowy",

            TITLE = "Garaż departamentu",
            DESCRIPTION = "Wybierz pojazd, który chcesz zdobyć."
        },

        PAY_DIALOG = {
            CONFIRM_FREE = "Wyślij",
            COMPANY_BUTTON_LABEL = "Firma",
            BANK_BUTTON_LABEL = "Bank",
            INPUT_PLACEHOLDER = "0",
        },

        POLICE_RADAR = {
            PAGE_RADAR = "Radar",
            SETTINGS_RADAR = "Ustawienia",

            FRONT_RADAR_TITLE = "Antena przednia",
            REAR_RADAR_TITLE = "Antena tylna",
            FAST_LOCK_LABEL = "Szybka blokada",

            PLATE_READER_FRONT = "Przód",
            PLATE_READER_REAR = "Tył",
            PATROL_SPEED = "Prędkość patrolu",

            RECENT_PLATE = "Tablica",
            RECENT_MODEL = "Model",
            RECENT_SPEED = "Prędkość",
            RECENT_LABEL = "Etykieta",

            SPEED_TITLE = "Prędkość",
        },

        MENU_SETTINGS = {
            TITLE = "Radar policyjny",
            DESC = "Zmień swoje ustawienia",

            RADAR_SCALE = "Skala radaru",
            RADAR_SCALE_DESC = "Dostosuj rozmiar radaru na ekranie",

            RESET_RADAR_POSITION = "Pozycja radaru",
            RESET_RADAR_POSITION_DESC = "Resetuj do domyślnej pozycji",
            RESET_RADAR_POSITION_BUTTON = "Resetuj",

            RESET_SCALE_POSITION = "Skala radaru",
            RESET_SCALE_POSITION_DESC = "Resetuj do domyślnej skali",
            RESET_SCALE_BUTTON = "Resetuj",

            MISC_SECTION = "RÓŻNE",
            FAST_LIMIT = "Limit szybki",
            FAST_LIMIT_DESC = "Kontroluj limit prędkości",
            RESET_SETTINGS = "Resetuj ustawienia",

            RESET_LABEL = "Resetuj skaner",
            RESET_DESC = "Umożliwia resetowanie skanera",
            RESET_RADAR_BUTTON = "Resetuj",

            RADAR_SECTION = "Radar",
            TOGGLE_RADAR = "Włącz/Wyłącz radar",
            TOGGLE_RADAR_DESC = "Pokaż / Ukryj radar",

            TOGGLE_RADAR_MOVEMENT = "Włącz/Wyłącz przesuwanie radaru",
            TOGGLE_RADAR_MOVEMENT_DESC = "Umożliwia przesuwanie radaru.",

            RECENT_PLATES_TITLE = "Ostatnie tablice",
            RECENT_PLATES_DESC = "Historia zeskanowanych tablic",
            RECENT_PLATES_BUTTON = "Pokaż/Ukryj",
        },

        RECENT_PLATES = {
            TITLE = "Ostatnie tablice",
            DESC = "Historia ostatnio zeskanowanych samochodów",

            NO_HISTORY = "Brak historii dla obecnego radaru!",
            FILTER_LABEL = "Filtruj według",

            NEXT_PAGE = "Następna",
            PREVIOUS_PAGE = "Poprzednia",
            RETURN_TO_SETTINGS_BUTTON_LABEL = "Wróć do ustawień",
        },

        BODYCAMS = {
            TITLE = "Transmisja z kamer osobistych",
            DESC = "Aktualna transmisja z aktywnych kamer twoich funkcjonariuszy!",
            NOT_ACTIVE_TITLE = "Brak aktywnych kamer osobistych!",
            NOT_ACTIVE_DESC = "Obecnie nie ma aktywnych kamer osobistych do oglądania transmisji na żywo",

            CAMERA_ID = "Kamera:",
            OFFICER = "Funkcjonariusz:",
            LOCATION = "Lokalizacja:",

            VIEW_FEED_BUTTON_TITLE = "Obejrzyj transmisję",
        },

        REPORTS = {
            FILTER_LABEL = "Filtry",
            MAIN_MENU_TITLE = "Raporty",
            MAIN_MENU_DESC = "Tutaj możesz zobaczyć wszystkie raporty od obywateli.",

            HEADER_PLAYER = "Obywatel",
            HEADER_PHONE = "Telefon",
            HEADER_STATUS = "Status",
            HEADER_ACTIONS = "Akcja",

            ACTIONS_REPORT_OPEN = "Pokaż raport",
            ACTIONS_REPORT_CLOSE = "Zamknij raport",

            STATE = "Stan raportu",
            STATUS_OPTIONS = "Wybierz stan raportu",
            UPDATE_STATUS = "Aktualizuj status",
            SAVE_STATUS = "Zapisz status",

            ADD_NOTE = "Dodaj notatkę",
            SAVE_NOTE = "Zapisz notatkę",
            SAVE = "Zapisz",

            NOTE_PLACEHOLDER = "Dodaj swoją notatkę do raportu",

            DELETE_REPORT = "Usuń raport",
            BACK_TO_REPORTS = "Wróć do raportów",

            NO_REPORTS_FOUND = "Brak wyników.",

            PREVIOUS_BUTTON = "Poprzedni",
            NEXT_PREVIOUS_BUTTON = "Następny",

            REPORT_TITLE = "Szczegóły raportu:",
            REPORT_PLAYER_NAME = "Imię obywatela:",
            REPORT_MESSAGE = "Wiadomość",
            REPORT_PLAYER_PHONE = "Telefon:",
            REPORT_STATUS = "Status:",
            REPORT_NOTE = "Notatka:",

            STATES_NEW_REPORT = "Nowy raport",
            STATES_IN_REVIEW = "W trakcie przeglądu",
            STATES_RESOLVED = "Rozwiązany",
        },

        RADIAL_MENU = {
            PRESS_LABEL = "Naciśnij",
            GO_BACK_LABEL = "Wróć",
        },

        GO_BACK_BUTTON = "◀ Wróć"
    }
}
