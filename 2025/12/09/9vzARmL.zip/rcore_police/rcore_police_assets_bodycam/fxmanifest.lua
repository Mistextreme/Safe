--[[ FX Information ]]--
fx_version   'cerulean'
lua54        'yes'
game         'gta5'
this_is_a_map 'yes'

--[[ Resource Information ]]--
name         'rcore_police_assets_bodycam'
author       'NewEdit | rcore.cz'
version      '1.0'
description  'Assets for rcore_police.'

data_file 'DLC_ITYP_REQUEST' 'stream/rdesign_bodycam.ytyp'

dependency '/assetpacks'

















































