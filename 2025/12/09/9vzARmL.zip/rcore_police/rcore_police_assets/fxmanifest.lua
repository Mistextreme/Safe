--[[ FX Information ]]--
fx_version   'cerulean'
lua54        'yes'
game         'gta5'
this_is_a_map 'yes'

--[[ Resource Information ]]--
name         'rcore_police_assets'
author       'NewEdit | rcore.cz'
version      '1.0'
description  'Assets for rcore_police.'

files {
    'data/rcore_sounds.dat54.rel',
    'audiodirectory/basic.awc',
    'audiodirectory/basic/rcore_basic_lock_left.wav',
    'audiodirectory/basic/rcore_basic_unlock_left.wav',
    'audiodirectory/basic/rcore_basic_handcuff_left.wav',
}

data_file 'DLC_ITYP_REQUEST' 'stream/rds_police_assets.ytyp'
data_file 'AUDIO_WAVEPACK' 'audiodirectory'
data_file 'AUDIO_SOUNDDATA' 'data/rcore_sounds.dat'

dependency '/assetpacks'

















































