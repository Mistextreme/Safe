This is where you can add custom vehicle thumbnails. But first:

1. You must have this feature enabled in config.lua `Config.ShowVehicleImages = true`
2. All images must be a png and a small file size. Ideally a 16:9 aspect ratio too

Learn more: https://docs.jgscripts.com/dealerships/vehicle-images
