-- Deobfuscated FiveM Lua Script
local fadeInFunction, fadeTime, unusedVariable
fadeInFunction = DoScreenFadeIn
fadeTime = 0
fadeInFunction(fadeTime)

function fadeInFunction(param1, param2)
    -- Function body appears to be incomplete in the original code
end