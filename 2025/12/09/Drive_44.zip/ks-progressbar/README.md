#----------------------EXPORT----------------------#

    exports['ks-progressbar']:start{
        name = "repair_vehicle",
        duration = 8000, -- time in ms (8 seconds)
        label = "Repairing Vehicle...",
        sublabel = "Please wait while the repairs are completed.",
        canCancel = true, -- allow player to cancel with ESC
        controlDisables = {
            disableMovement = true
        },
        animation = {
            animDict = "mini@repair",
            anim = "fixing_a_ped",
            flags = 49
        },
        icon = "fas fa-wrench" -- FontAwesome icon class
    }, 


    exports['ks-progressbar']:cancelprogress()
#-------------------HOW TO MOVE-------------------#

 - Settings menu is opened by using the command /progresssettings
 - The progressbar can be moved using the mouse
 - The 3D angle is adjusted by clicking SHIFT + Moving with the mouse

#-------------------INFORMATION-------------------#
 - TEBEX: https://ks-development-shop.tebex.io
 - DISCORD: https://discord.gg/QjfdGrUcmD
 - DOCS: https://ks-development-1.gitbook.io/docs