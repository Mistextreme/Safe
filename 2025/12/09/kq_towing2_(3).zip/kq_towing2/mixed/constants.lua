local L0_1, L1_1
CONVAR_NAME = "kq_towing_ropes"
