local L0_1, L1_1
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2
  while true do
    L0_2 = 2000
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = GetEntityCoords
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    L3_2 = IsPlayerUnreachable
    L3_2 = L3_2()
    if not L3_2 then
      L3_2 = ROPES
      L3_2 = #L3_2
      if L3_2 > 0 then
        L0_2 = 500
      end
      L3_2 = pairs
      L4_2 = ROPES
      L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
      for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
        L9_2 = vector3
        L10_2 = L8_2.coords1
        L10_2 = L10_2.x
        L11_2 = L8_2.coords1
        L11_2 = L11_2.y
        L12_2 = L8_2.coords1
        L12_2 = L12_2.z
        L9_2 = L9_2(L10_2, L11_2, L12_2)
        L10_2 = L8_2.netId1
        if L10_2 then
          L10_2 = NetworkDoesNetworkIdExist
          L11_2 = L8_2.netId1
          L10_2 = L10_2(L11_2)
          if L10_2 then
            L10_2 = NetworkGetEntityFromNetworkId
            L11_2 = L8_2.netId1
            L10_2 = L10_2(L11_2)
            L11_2 = GetWorldPositionOfEntityBone
            L12_2 = L10_2
            L13_2 = GetEntityBoneIndexByName
            L14_2 = L10_2
            L15_2 = L8_2.bone1
            L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2 = L13_2(L14_2, L15_2)
            L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
            L9_2 = L11_2
          end
        end
        L10_2 = vector3
        L11_2 = L8_2.coords2
        L11_2 = L11_2.x
        L12_2 = L8_2.coords2
        L12_2 = L12_2.y
        L13_2 = L8_2.coords2
        L13_2 = L13_2.z
        L10_2 = L10_2(L11_2, L12_2, L13_2)
        L11_2 = L8_2.netId2
        if L11_2 then
          L11_2 = NetworkDoesNetworkIdExist
          L12_2 = L8_2.netId2
          L11_2 = L11_2(L12_2)
          if L11_2 then
            L11_2 = NetworkGetEntityFromNetworkId
            L12_2 = L8_2.netId2
            L11_2 = L11_2(L12_2)
            L12_2 = GetWorldPositionOfEntityBone
            L13_2 = L11_2
            L14_2 = GetEntityBoneIndexByName
            L15_2 = L11_2
            L16_2 = L8_2.bone2
            L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2 = L14_2(L15_2, L16_2)
            L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
            L10_2 = L12_2
          end
        end
        L11_2 = {}
        L12_2 = L9_2
        L13_2 = L10_2
        L11_2[1] = L12_2
        L11_2[2] = L13_2
        L12_2 = false
        L13_2 = pairs
        L14_2 = L11_2
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          if not L12_2 then
            L19_2 = GetDistanceBetweenCoords
            L20_2 = L2_2
            L21_2 = L18_2
            L22_2 = true
            L19_2 = L19_2(L20_2, L21_2, L22_2)
            L20_2 = 1.5
            if L19_2 < L20_2 then
              L12_2 = true
              L0_2 = 1
              L20_2 = L
              L21_2 = "~w~Hold ~r~[~w~{INPUT}~r~]~w~ to detach the rope"
              L20_2 = L20_2(L21_2)
              L21_2 = L20_2
              L20_2 = L20_2.gsub
              L22_2 = "{INPUT}"
              L23_2 = Config
              L23_2 = L23_2.keybinds
              L23_2 = L23_2.remove
              L23_2 = L23_2.label
              L20_2 = L20_2(L21_2, L22_2, L23_2)
              L21_2 = Config
              L21_2 = L21_2.inputType
              if "top-left" == L21_2 then
                L21_2 = L
                L22_2 = "~w~Hold ~{INPUT}~ to detach the rope"
                L21_2 = L21_2(L22_2)
                L22_2 = L21_2
                L21_2 = L21_2.gsub
                L23_2 = "{INPUT}"
                L24_2 = Config
                L24_2 = L24_2.keybinds
                L24_2 = L24_2.remove
                L24_2 = L24_2.name
                L21_2 = L21_2(L22_2, L23_2, L24_2)
                L20_2 = L21_2
              end
              L21_2 = CreateKQInput
              L22_2 = vector3
              L23_2 = 0.0
              L24_2 = 0.0
              L25_2 = 0.1
              L22_2 = L22_2(L23_2, L24_2, L25_2)
              L22_2 = L18_2 + L22_2
              L23_2 = L20_2
              L24_2 = Config
              L24_2 = L24_2.keybinds
              L24_2 = L24_2.remove
              L24_2 = L24_2.input
              L25_2 = true
              function L26_2()
                local L0_3, L1_3, L2_3
                L0_3 = TriggerServerEvent
                L1_3 = "kq_towing:server:removeRope"
                L2_3 = L7_2
                L0_3(L1_3, L2_3)
              end
              L27_2 = Config
              L27_2 = L27_2.keybinds
              L27_2 = L27_2.remove
              L27_2 = L27_2.duration
              if not L27_2 then
                L27_2 = 5000
              end
              function L28_2()
                local L0_3, L1_3
                L0_3 = PlayRopeUntieAnimation
                L1_3 = L18_2
                L0_3(L1_3)
              end
              function L29_2()
                local L0_3, L1_3
                L0_3 = ClearPedTasks
                L1_3 = L1_2
                L0_3(L1_3)
              end
              L21_2(L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
            end
          end
        end
      end
    end
    L3_2 = Citizen
    L3_2 = L3_2.Wait
    L4_2 = L0_2
    L3_2(L4_2)
  end
end
L0_1(L1_1)
