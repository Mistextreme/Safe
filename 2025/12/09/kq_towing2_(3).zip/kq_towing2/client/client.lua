local L0_1, L1_1, L2_1, L3_1
L0_1 = Config
L1_1 = Config
L1_1 = L1_1.ropeLength
L1_1 = L1_1 + 0.0
L0_1.ropeLength = L1_1
L0_1 = Config
L1_1 = Config
L1_1 = L1_1.winchLength
L1_1 = L1_1 + 0.0
L0_1.winchLength = L1_1
L0_1 = Config
L1_1 = Config
L1_1 = L1_1.maxTowingSpeed
L1_1 = L1_1 + 0.0
L0_1.maxTowingSpeed = L1_1
L0_1 = nil
PLACING_ROPE = false
L1_1 = RegisterNetEvent
L2_1 = "kq_towing:client:startRope"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "kq_towing:client:startRope"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = PLACING_ROPE
  if L2_2 then
    return
  end
  L2_2 = StartRopeCreation
  L3_2 = A0_2
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L2_2 = IsPlayerUnreachable
  L2_2 = L2_2()
  if L2_2 then
    return
  end
  L2_2 = RemoveHandWeapons
  L2_2()
  PLACING_ROPE = true
  L2_2 = WhilePlacing
  L2_2()
  L2_2 = CreateRopeItemModel
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = L
  L4_2 = "~w~Press ~g~[~w~{INPUT}~g~]~w~ to attach the rope"
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2
  L3_2 = L3_2.gsub
  L5_2 = "{INPUT}"
  L6_2 = Config
  L6_2 = L6_2.keybinds
  L6_2 = L6_2.confirm
  L6_2 = L6_2.label
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L4_2 = Config
  L4_2 = L4_2.inputType
  if "top-left" == L4_2 then
    L4_2 = L
    L5_2 = "~w~Press ~{INPUT}~ to attach the rope"
    L4_2 = L4_2(L5_2)
    L5_2 = L4_2
    L4_2 = L4_2.gsub
    L6_2 = "{INPUT}"
    L7_2 = Config
    L7_2 = L7_2.keybinds
    L7_2 = L7_2.confirm
    L7_2 = L7_2.name
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L3_2 = L4_2
  end
  L4_2 = GetLookAt
  L5_2 = 3
  L6_2 = L3_2
  L4_2, L5_2 = L4_2(L5_2, L6_2)
  L6_2 = PLACING_ROPE
  if not L6_2 then
    L6_2 = DeleteObject
    L7_2 = L2_2
    L6_2(L7_2)
    return
  end
  L6_2 = PlayRopeTieAnimation
  L7_2 = L4_2
  L6_2(L7_2)
  L6_2 = DeleteObject
  L7_2 = L2_2
  L6_2(L7_2)
  L6_2 = nil
  if L5_2 then
    L7_2 = GetNearBone
    L8_2 = L5_2
    L9_2 = L4_2
    L7_2 = L7_2(L8_2, L9_2)
    L6_2 = L7_2
  end
  L7_2 = CreateTemporaryRope
  L8_2 = L4_2
  L9_2 = L5_2
  L10_2 = L6_2
  L11_2 = A0_2
  L7_2(L8_2, L9_2, L10_2, L11_2)
  L7_2 = L
  L8_2 = "~w~Press ~g~[~w~{INPUT}~g~]~w~ to tie the rope"
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2
  L7_2 = L7_2.gsub
  L9_2 = "{INPUT}"
  L10_2 = Config
  L10_2 = L10_2.keybinds
  L10_2 = L10_2.confirm
  L10_2 = L10_2.label
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  L3_2 = L7_2
  L7_2 = Config
  L7_2 = L7_2.inputType
  if "top-left" == L7_2 then
    L7_2 = L
    L8_2 = "~w~Press ~{INPUT}~ to tie the rope"
    L7_2 = L7_2(L8_2)
    L8_2 = L7_2
    L7_2 = L7_2.gsub
    L9_2 = "{INPUT}"
    L10_2 = Config
    L10_2 = L10_2.keybinds
    L10_2 = L10_2.confirm
    L10_2 = L10_2.name
    L7_2 = L7_2(L8_2, L9_2, L10_2)
    L3_2 = L7_2
  end
  L7_2 = GetLookAt
  L8_2 = 3
  L9_2 = L3_2
  L7_2, L8_2 = L7_2(L8_2, L9_2)
  L9_2 = PLACING_ROPE
  if not L9_2 then
    L9_2 = DeleteRope
    L10_2 = L0_1
    L9_2(L10_2)
    return
  end
  L9_2 = nil
  if L8_2 then
    L10_2 = GetNearBone
    L11_2 = L8_2
    L12_2 = L7_2
    L10_2 = L10_2(L11_2, L12_2)
    L9_2 = L10_2
  end
  L10_2 = PlayRopeTieAnimation
  L11_2 = L7_2
  L10_2(L11_2)
  L10_2 = L0_1
  if nil ~= L10_2 then
    L10_2 = DeleteRope
    L11_2 = L0_1
    L10_2(L11_2)
  end
  PLACING_ROPE = false
  if L5_2 == L8_2 then
    return
  end
  L10_2 = CreateRope
  L11_2 = L4_2
  L12_2 = L5_2
  L13_2 = L6_2
  L14_2 = L7_2
  L15_2 = L8_2
  L16_2 = L9_2
  L17_2 = A0_2
  L18_2 = A1_2
  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
end
StartRopeCreation = L1_1
function L1_1()
  local L0_2, L1_2
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = PLACING_ROPE
      if not L0_3 then
        break
      end
      L0_3 = DisableInputs
      L0_3()
      L0_3 = Config
      L0_3 = L0_3.inputType
      if "top-left" ~= L0_3 then
        L0_3 = KeybindTip
        L1_3 = L
        L2_3 = "Press ~{INPUT}~ to cancel"
        L1_3 = L1_3(L2_3)
        L2_3 = L1_3
        L1_3 = L1_3.gsub
        L3_3 = "{INPUT}"
        L4_3 = Config
        L4_3 = L4_3.keybinds
        L4_3 = L4_3.cancel
        L4_3 = L4_3.name
        L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3, L3_3, L4_3)
        L0_3(L1_3, L2_3, L3_3, L4_3)
      end
      L0_3 = IsControlJustReleased
      L1_3 = 0
      L2_3 = Config
      L2_3 = L2_3.keybinds
      L2_3 = L2_3.cancel
      L2_3 = L2_3.input
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        PLACING_ROPE = false
      end
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetEntitySpeed
      L2_3 = L0_3
      L1_3 = L1_3(L2_3)
      if L1_3 > 11 then
        L2_3 = true
        PLACING_ROPE = false
        L3_3 = Citizen
        L3_3 = L3_3.CreateThread
        function L4_3()
          local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
          while true do
            L0_4 = L2_3
            if not L0_4 then
              break
            end
            L0_4 = Citizen
            L0_4 = L0_4.Wait
            L1_4 = 100
            L0_4(L1_4)
            L0_4 = GetEntityVelocity
            L1_4 = L0_3
            L0_4 = L0_4(L1_4)
            L1_4 = SetEntityVelocity
            L2_4 = L0_3
            L3_4 = L0_4.x
            L3_4 = L3_4 * 1.15
            L4_4 = L0_4.y
            L4_4 = L4_4 * 1.15
            L5_4 = L0_4.z
            L5_4 = L5_4 * 1.15
            L1_4(L2_4, L3_4, L4_4, L5_4)
            L1_4 = SetPedToRagdoll
            L2_4 = L0_3
            L3_4 = 1000
            L4_4 = 1000
            L5_4 = 0
            L6_4 = true
            L7_4 = true
            L8_4 = true
            L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4)
          end
        end
        L3_3(L4_3)
        L3_3 = Citizen
        L3_3 = L3_3.Wait
        L4_3 = 1000
        L3_3(L4_3)
        L2_3 = false
      end
      L2_3 = Citizen
      L2_3 = L2_3.Wait
      L3_3 = 1
      L2_3(L3_3)
    end
  end
  L0_2(L1_2)
end
WhilePlacing = L1_1
function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L4_2 = PlayerPedId
  L4_2 = L4_2()
  L5_2 = L0_1
  if nil ~= L5_2 then
    L5_2 = DeleteRope
    L6_2 = L0_1
    L5_2(L6_2)
    L5_2 = nil
    L0_1 = L5_2
  end
  L5_2 = RopeLoadTextures
  L5_2()
  while true do
    L5_2 = RopeAreTexturesLoaded
    L5_2 = L5_2()
    if L5_2 then
      break
    end
    L5_2 = Citizen
    L5_2 = L5_2.Wait
    L6_2 = 50
    L5_2(L6_2)
  end
  L5_2 = 1
  if A3_2 then
    L5_2 = 4
  end
  L6_2 = GetMaxLength
  L7_2 = A3_2
  L6_2 = L6_2(L7_2)
  L7_2 = AddRope
  L8_2 = GetEntityCoords
  L9_2 = L4_2
  L8_2 = L8_2(L9_2)
  L9_2 = 0.0
  L10_2 = 0.0
  L11_2 = 0.0
  L12_2 = L6_2 * 0.2
  L13_2 = L5_2
  L14_2 = L6_2 * 0.75
  L15_2 = 0.1
  L16_2 = 10.0
  L17_2 = true
  L18_2 = false
  L19_2 = true
  L20_2 = 1.0
  L21_2 = false
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  L0_1 = L7_2
  if A1_2 then
    L7_2 = AttachEntitiesToRope
    L8_2 = L0_1
    L9_2 = L4_2
    L10_2 = A1_2
    L11_2 = 0.0
    L12_2 = 0.0
    L13_2 = 0.0
    L14_2 = 0.0
    L15_2 = 0.0
    L16_2 = 0.1
    L17_2 = L6_2
    L18_2 = true
    L19_2 = true
    L20_2 = "IK_L_Hand"
    L21_2 = A2_2
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  else
    L7_2 = CreateTemporaryHook
    L8_2 = A0_2
    L9_2 = A1_2
    L7_2 = L7_2(L8_2, L9_2)
    L8_2 = AttachEntitiesToRope
    L9_2 = L0_1
    L10_2 = L7_2
    L11_2 = L4_2
    L12_2 = A0_2.x
    L13_2 = A0_2.y
    L14_2 = A0_2.z
    L14_2 = L14_2 + 0.0
    L15_2 = GetEntityCoords
    L16_2 = L4_2
    L15_2 = L15_2(L16_2)
    L16_2 = L6_2
    L17_2 = false
    L18_2 = false
    L19_2 = "IK_R_Hand"
    L20_2 = nil
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
  end
end
CreateTemporaryRope = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L2_2 = "prop_roadpole_01a"
  L3_2 = DoRequestModel
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = CreateObject
  L4_2 = L2_2
  L5_2 = A0_2
  L6_2 = 0
  L7_2 = 1
  L8_2 = 0
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_2 = SetEntityAsMissionEntity
  L5_2 = L3_2
  L6_2 = 1
  L7_2 = 1
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = SetEntityDynamic
  L5_2 = L3_2
  L6_2 = false
  L4_2(L5_2, L6_2)
  L4_2 = SetEntityCompletelyDisableCollision
  L5_2 = L3_2
  L6_2 = true
  L7_2 = false
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = SetEntityCollision
  L5_2 = L3_2
  L6_2 = false
  L7_2 = false
  L4_2(L5_2, L6_2, L7_2)
  if A1_2 then
    L4_2 = GetOffsetFromEntityGivenWorldCoords
    L5_2 = A1_2
    L6_2 = A0_2
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = AttachEntityToEntity
    L6_2 = L3_2
    L7_2 = A1_2
    L8_2 = 0
    L9_2 = vector3
    L10_2 = L4_2.x
    L11_2 = L4_2.y
    L12_2 = L4_2.z
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    L10_2 = vector3
    L11_2 = 0.0
    L12_2 = 0.0
    L13_2 = 0.0
    L10_2 = L10_2(L11_2, L12_2, L13_2)
    L11_2 = 1
    L12_2 = 0
    L13_2 = false
    L14_2 = 0
    L15_2 = 0
    L16_2 = 1
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  else
    L4_2 = FreezeEntityPosition
    L5_2 = L3_2
    L6_2 = true
    L4_2(L5_2, L6_2)
  end
  L4_2 = SetEntityAlpha
  L5_2 = L3_2
  L6_2 = 0
  L7_2 = 0
  L4_2(L5_2, L6_2, L7_2)
  return L3_2
end
CreateTemporaryHook = L1_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = Config
  L1_2 = L1_2.ropeProps
  L1_2 = L1_2.towing
  if A0_2 then
    L2_2 = Config
    L2_2 = L2_2.ropeProps
    L1_2 = L2_2.winch
  end
  L2_2 = L1_2.prop
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = DoRequestModel
  L5_2 = L2_2
  L4_2(L5_2)
  L4_2 = CreateObject
  L5_2 = L2_2
  L6_2 = GetEntityCoords
  L7_2 = L3_2
  L6_2 = L6_2(L7_2)
  L7_2 = 1
  L8_2 = 1
  L9_2 = 0
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  L5_2 = SetEntityAsMissionEntity
  L6_2 = L4_2
  L7_2 = 1
  L8_2 = 1
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = SetEntityDynamic
  L6_2 = L4_2
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SetEntityCompletelyDisableCollision
  L6_2 = L4_2
  L7_2 = true
  L8_2 = false
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = SetEntityCollision
  L6_2 = L4_2
  L7_2 = false
  L8_2 = false
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = L1_2.bone
  L6_2 = L1_2.offset
  L7_2 = L1_2.rotation
  L8_2 = GetPedBoneIndex
  L9_2 = L3_2
  L10_2 = L5_2
  L8_2 = L8_2(L9_2, L10_2)
  L9_2 = AttachEntityToEntity
  L10_2 = L4_2
  L11_2 = L3_2
  L12_2 = L8_2
  L13_2 = L6_2
  L14_2 = L7_2
  L15_2 = true
  L16_2 = false
  L17_2 = false
  L18_2 = false
  L19_2 = 2
  L20_2 = true
  L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
  return L4_2
end
CreateRopeItemModel = L1_1
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2)
  local L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L8_2 = nil
  L9_2 = nil
  if A1_2 then
    L10_2 = NetworkGetNetworkIdFromEntity
    L11_2 = A1_2
    L10_2 = L10_2(L11_2)
    L8_2 = L10_2
  end
  if A4_2 then
    L10_2 = NetworkGetNetworkIdFromEntity
    L11_2 = A4_2
    L10_2 = L10_2(L11_2)
    L9_2 = L10_2
  end
  L10_2 = GetDistanceBetweenCoords
  L11_2 = A0_2
  L12_2 = A3_2
  L13_2 = true
  L10_2 = L10_2(L11_2, L12_2, L13_2)
  L10_2 = L10_2 + 1.5
  L11_2 = TriggerServerEvent
  L12_2 = "kq_towing:server:createRope"
  L13_2 = A0_2
  L14_2 = L8_2
  L15_2 = A2_2
  L16_2 = A3_2
  L17_2 = L9_2
  L18_2 = A5_2
  L19_2 = L10_2
  L20_2 = A6_2
  L21_2 = A7_2
  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  L11_2 = Citizen
  L11_2 = L11_2.Wait
  L12_2 = 100
  L11_2(L12_2)
  L11_2 = RefreshRopes
  L11_2()
end
CreateRope = L1_1
