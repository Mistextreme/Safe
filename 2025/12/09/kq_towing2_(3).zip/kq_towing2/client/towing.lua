local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = nil
L2_1 = Citizen
L2_1 = L2_1.CreateThread
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  while true do
    L0_2 = 3000
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = IsPedInAnyVehicle
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L0_2 = 2000
      L2_2 = GetVehiclePedIsIn
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      L3_2 = GetPedInVehicleSeat
      L4_2 = L2_2
      L5_2 = -1
      L3_2 = L3_2(L4_2, L5_2)
      if L3_2 == L1_2 then
        L0_2 = 500
        L3_2 = Entity
        L4_2 = L2_2
        L3_2 = L3_2(L4_2)
        L3_2 = L3_2.state
        L4_2 = L3_2.kq_attached_to
        if nil ~= L4_2 then
          L5_2 = DoesEntityExist
          L6_2 = L4_2
          L5_2 = L5_2(L6_2)
          if L5_2 then
            L5_2 = L0_1
            L5_2 = L5_2[L2_2]
            if not L5_2 then
              L5_2 = Config
              L5_2 = L5_2.maxTowingSpeed
              if L5_2 and L5_2 > 0 then
                L6_2 = SetEntityMaxSpeed
                L7_2 = L2_2
                L8_2 = L5_2 / 2.3
                L6_2(L7_2, L8_2)
                L6_2 = L0_1
                L6_2[L2_2] = true
              end
            end
            L5_2 = Config
            L5_2 = L5_2.toweeAutopilot
            if L5_2 then
              L5_2 = L3_2.kq_winch_sub
              if not L5_2 then
                L5_2 = Debug
                L6_2 = "Start autopilot check"
                L7_2 = L4_2
                L5_2(L6_2, L7_2)
                L5_2 = GetPedInVehicleSeat
                L6_2 = L4_2
                L7_2 = -1
                L5_2 = L5_2(L6_2, L7_2)
                if 0 == L5_2 then
                  L5_2 = Debug
                  L6_2 = "Get nearest player to entity"
                  L7_2 = L4_2
                  L5_2(L6_2, L7_2)
                  L5_2 = GetEntityCoords
                  L6_2 = L4_2
                  L5_2 = L5_2(L6_2)
                  L6_2 = GetNearestPlayerToEntity
                  L7_2 = L4_2
                  L6_2 = L6_2(L7_2)
                  if nil ~= L6_2 and L6_2 > 0 then
                    L7_2 = Debug
                    L8_2 = "No near player. Do autopilot logic"
                    L7_2(L8_2)
                    L7_2 = NetworkGetPlayerCoords
                    L7_2 = L7_2()
                    L8_2 = GetDistanceBetweenCoords
                    L9_2 = L5_2
                    L10_2 = L7_2
                    L8_2 = L8_2(L9_2, L10_2)
                    if L8_2 >= 4.0 then
                      L8_2 = Debug
                      L9_2 = "Get player distance"
                      L8_2(L9_2)
                      L8_2 = L1_1
                      if nil == L8_2 then
                        L8_2 = Debug
                        L9_2 = "Create new driver"
                        L8_2(L9_2)
                        L8_2 = CreateDriverPed
                        L9_2 = L2_2
                        L10_2 = L4_2
                        L8_2(L9_2, L10_2)
                      end
                    else
                      L8_2 = L1_1
                      if nil ~= L8_2 then
                        L8_2 = Debug
                        L9_2 = "Delete driver 1"
                        L8_2(L9_2)
                        L8_2 = DeletePed
                        L9_2 = L1_1
                        L8_2(L9_2)
                        L8_2 = nil
                        L1_1 = L8_2
                      end
                    end
                  end
                end
              end
            end
        end
        else
          L5_2 = L1_1
          if nil ~= L5_2 then
            L5_2 = Debug
            L6_2 = "Delete driver 2"
            L5_2(L6_2)
            L5_2 = DeletePed
            L6_2 = L1_1
            L5_2(L6_2)
            L5_2 = nil
            L1_1 = L5_2
          end
          L5_2 = L0_1
          L5_2 = L5_2[L2_2]
          if L5_2 then
            L5_2 = SetEntityMaxSpeed
            L6_2 = L2_2
            L7_2 = 9999.0
            L5_2(L6_2, L7_2)
            L5_2 = L0_1
            L5_2[L2_2] = false
            L5_2 = Citizen
            L5_2 = L5_2.CreateThread
            function L6_2()
              local L0_3, L1_3, L2_3
              L0_3 = Citizen
              L0_3 = L0_3.Wait
              L1_3 = 1000
              L0_3(L1_3)
              L0_3 = SetEntityMaxSpeed
              L1_3 = L2_2
              L2_3 = 9999.0
              L0_3(L1_3, L2_3)
            end
            L5_2(L6_2)
          end
        end
      else
        L3_2 = L1_1
        if nil ~= L3_2 then
          L3_2 = Debug
          L4_2 = "Delete driver 3"
          L3_2(L4_2)
          L3_2 = DeletePed
          L4_2 = L1_1
          L3_2(L4_2)
          L3_2 = nil
          L1_1 = L3_2
        end
      end
    else
      L2_2 = L1_1
      if nil ~= L2_2 then
        L2_2 = Debug
        L3_2 = "Delete driver 4"
        L2_2(L3_2)
        L2_2 = DeletePed
        L3_2 = L1_1
        L2_2(L3_2)
        L2_2 = nil
        L1_1 = L2_2
      end
    end
    L2_2 = Citizen
    L2_2 = L2_2.Wait
    L3_2 = L0_2
    L2_2(L3_2)
  end
end
L2_1(L3_1)
L2_1 = Citizen
L2_1 = L2_1.CreateThread
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  while true do
    L0_2 = 3000
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = IsPedInAnyVehicle
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L0_2 = 2000
      L2_2 = GetVehiclePedIsIn
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      L3_2 = GetPedInVehicleSeat
      L4_2 = L2_2
      L5_2 = -1
      L3_2 = L3_2(L4_2, L5_2)
      if L3_2 == L1_2 then
        L0_2 = 500
        L3_2 = IsVehicleAttached
        L4_2 = L2_2
        L3_2 = L3_2(L4_2)
        if L3_2 then
          L0_2 = 1
          L4_2 = GetVehicleEngineHealth
          L5_2 = L2_2
          L4_2 = L4_2(L5_2)
          L5_2 = GetVehicleBodyHealth
          L6_2 = L2_2
          L5_2 = L5_2(L6_2)
          L4_2 = L4_2 + L5_2
          L5_2 = Debug
          L6_2 = L4_2
          L5_2(L6_2)
          if 2000.0 == L4_2 then
            L5_2 = DeleteRope
            L6_2 = L3_2
            L5_2(L6_2)
            L5_2 = SetVehicleBodyHealth
            L6_2 = L2_2
            L7_2 = GetVehicleBodyHealth
            L8_2 = L2_2
            L7_2 = L7_2(L8_2)
            L7_2 = L7_2 - 0.1
            L5_2(L6_2, L7_2)
            L5_2 = RefreshRopes
            L5_2()
          end
        end
      end
    end
    L2_2 = Citizen
    L2_2 = L2_2.Wait
    L3_2 = L0_2
    L2_2(L3_2)
  end
end
L2_1(L3_1)
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = UseCache
  L2_2 = "IsVehicleAttached_"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = Entity
    L1_3 = A0_2
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    L1_3 = L0_3.kq_rope
    return L1_3
  end
  L4_2 = 500
  return L1_2(L2_2, L3_2, L4_2)
end
IsVehicleAttached = L2_1
L2_1 = Citizen
L2_1 = L2_1.CreateThread
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  while true do
    L0_2 = 2000
    L1_2 = IsPedGettingIntoAVehicle
    L2_2 = PlayerPedId
    L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2()
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
    if L1_2 then
      L0_2 = 100
    end
    L1_2 = L1_1
    if nil ~= L1_2 then
      L1_2 = Debug
      L2_2 = "Driver ped exists, check if outside car or jacked"
      L3_2 = L1_1
      L1_2(L2_2, L3_2)
      L1_2 = IsPedInAnyVehicle
      L2_2 = L1_1
      L1_2 = L1_2(L2_2)
      if L1_2 then
        L1_2 = IsPedBeingJacked
        L2_2 = L1_1
        L1_2 = L1_2(L2_2)
        if not L1_2 then
          goto lbl_35
        end
      end
      L1_2 = Debug
      L2_2 = "Delete driver 5"
      L1_2(L2_2)
      L1_2 = DeletePed
      L2_2 = L1_1
      L1_2(L2_2)
      L1_2 = nil
      L1_1 = L1_2
      goto lbl_56
      ::lbl_35::
      L1_2 = Debug
      L2_2 = "Get driver vehicle"
      L1_2(L2_2)
      L1_2 = GetVehiclePedIsIn
      L2_2 = L1_1
      L1_2 = L1_2(L2_2)
      L0_2 = 1
      L2_2 = SetVehicleEngineOn
      L3_2 = L1_2
      L4_2 = false
      L5_2 = true
      L6_2 = false
      L2_2(L3_2, L4_2, L5_2, L6_2)
      L2_2 = SetVehicleBrake
      L3_2 = L1_2
      L4_2 = false
      L2_2(L3_2, L4_2)
      L2_2 = SetVehicleHandbrake
      L3_2 = L1_2
      L4_2 = false
      L2_2(L3_2, L4_2)
    end
    ::lbl_56::
    L1_2 = Citizen
    L1_2 = L1_2.Wait
    L2_2 = L0_2
    L1_2(L2_2)
  end
end
L2_1(L3_1)
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = Config
  L2_2 = L2_2.toweeAutopilot
  if not L2_2 then
    return
  end
  L2_2 = "a_c_rabbit_01"
  L3_2 = Debug
  L4_2 = "request ped model"
  L3_2(L4_2)
  L3_2 = DoRequestModel
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = Debug
  L4_2 = "vehs"
  L5_2 = A0_2
  L6_2 = A1_2
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = GetPedInVehicleSeat
  L4_2 = A1_2
  L5_2 = -1
  L3_2 = L3_2(L4_2, L5_2)
  if 0 == L3_2 then
    L3_2 = CreatePedInsideVehicle
    L4_2 = A1_2
    L5_2 = 4
    L6_2 = L2_2
    L7_2 = -1
    L8_2 = false
    L9_2 = false
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L1_1 = L3_2
    L3_2 = SetModelAsNoLongerNeeded
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = SetPedConfigFlag
    L4_2 = L1_1
    L5_2 = 429
    L6_2 = true
    L3_2(L4_2, L5_2, L6_2)
    L3_2 = SetEntityVisible
    L4_2 = L1_1
    L5_2 = false
    L6_2 = 0
    L3_2(L4_2, L5_2, L6_2)
    L3_2 = SetPedCanRagdoll
    L4_2 = L1_1
    L5_2 = false
    L3_2(L4_2, L5_2)
    L3_2 = SetEntityInvincible
    L4_2 = L1_1
    L5_2 = true
    L3_2(L4_2, L5_2)
    L3_2 = TaskVehicleFollow
    L4_2 = L1_1
    L5_2 = A1_2
    L6_2 = A0_2
    L7_2 = Config
    L7_2 = L7_2.maxTowingSpeed
    L7_2 = L7_2 * 2
    L8_2 = 16777216
    L9_2 = 8
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L3_2 = Citizen
    L3_2 = L3_2.CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
      L0_3 = 2500
      while L0_3 > 0 do
        L0_3 = L0_3 - 20
        L1_3 = Debug
        L2_3 = "Set vehicle engine off"
        L3_3 = A1_2
        L1_3(L2_3, L3_3)
        L1_3 = SetVehicleEngineOn
        L2_3 = A1_2
        L3_3 = false
        L4_3 = true
        L5_3 = false
        L1_3(L2_3, L3_3, L4_3, L5_3)
        L1_3 = Citizen
        L1_3 = L1_3.Wait
        L2_3 = 20
        L1_3(L2_3)
      end
    end
    L3_2(L4_2)
  end
end
CreateDriverPed = L2_1
