
function AreCoordsOnGround(coords)
    local _, groundZ = GetGroundZFor_3dCoord(
        EasyRound(coords.x),
        EasyRound(coords.y),
        EasyRound(coords.z + 5.0),
        true
    )

    return math.abs(EasyRound(coords.z) - groundZ) < 0.5
end

function EasyRound(num)
    num = num * 10
    local frac = num % 0.1
    num = num - frac
    local frac2 = num % 1
    num = num - frac2
    if frac < 0.5 then
        num = num - (num % 1)
    else
        num = num - (num % 1) + 1
    end
    return num / 10
end


function GetLookAtCoords(distance)
    local camRot = GetGameplayCamRot(0)
    local pitch = camRot.x * math.pi / 180
    local yaw = camRot.z * math.pi / 180

    local playerCoords = GetEntityCoords(PlayerPedId())
    playerCoords = playerCoords + vector3(0.0, 0.0, 0.5)

    distance = distance or 8

    local z = math.sin(pitch) * distance + playerCoords.z
    local absX = math.abs(math.cos(pitch) * distance)
    local x = -math.sin(yaw) * absX + playerCoords.x
    local y = math.cos(yaw) * absX + playerCoords.y

    return vector3(x, y, z)
end


function RayCast(distance)
    return UseCache("raycast", function()
        local camCoords = GetGameplayCamCoord()
        local targetCoords = GetLookAtCoords(distance or 6)
        local rayHandle = StartShapeTestSweptSphere(camCoords, targetCoords, 0.05, 4294967295, PlayerPedId(), 1)
        local _, hit, endCoords, _, entity = GetShapeTestResult(rayHandle)

        if entity and NetworkGetEntityIsNetworked(entity) then
            if not IsEntityAVehicle(entity) then
                entity = nil
                hit = false
            end
        else
            entity = nil
        end

        return hit, endCoords, entity
    end, 10)
end

function GetLookAt(maxDistance, showTip)
    while PLACING_ROPE do
        local playerCoords = GetEntityCoords(PlayerPedId())
        local hit, hitCoords, hitEntity = RayCast(10)

        if hit then
            local distance = GetDistanceBetweenCoords(playerCoords, hitCoords, true)

      
            if maxDistance < distance then
                DrawSphere(hitCoords, 0.03, 255, 100, 100, 0.5)
                if showTip then
                    if Config.inputType == "top-left" then
                        KeybindTip(L("Press ~{INPUT}~ to cancel"):gsub("{INPUT}", Config.keybinds.cancel.name)
                            .. "\n" .. L("~r~Too far"))
                    else
                        Draw3DText(hitCoords, L("~r~Too far"), 0.05)
                    end
                end

            
            elseif not IsEntityAVehicle(hitEntity) then
                if AreCoordsOnGround(hitCoords) then
                    DrawSphere(hitCoords, 0.03, 255, 150, 70, 0.5)
                    if showTip then
                        if Config.inputType == "top-left" then
                            KeybindTip(L("Press ~{INPUT}~ to cancel"):gsub("{INPUT}", Config.keybinds.cancel.name)
                                .. "\n" .. L("~y~You can not tie the rope to the ground"))
                        else
                            Draw3DText(hitCoords, L("~y~You can not tie the rope to the ground"), 0.05)
                        end
                    end
                end

          
            else
                if Contains(Config.blacklistedClasses, GetVehicleClass(hitEntity)) then
                    DrawSphere(hitCoords, 0.03, 255, 100, 100, 0.5)
                    if showTip then
                        if Config.inputType == "top-left" then
                            KeybindTip(L("Press ~{INPUT}~ to cancel"):gsub("{INPUT}", Config.keybinds.cancel.name)
                                .. "\n" .. L("~r~This vehicle can not be towed"))
                        else
                            Draw3DText(hitCoords, L("~r~This vehicle can not be towed"), 0.05)
                        end
                    end
                else
                   
                    DrawSphere(hitCoords, 0.03, 100, 255, 100, 0.5)
                    if showTip then
                        if Config.inputType == "top-left" then
                            KeybindTip(L("Press ~{INPUT}~ to cancel"):gsub("{INPUT}", Config.keybinds.cancel.name)
                                .. "\n\n~w~" .. tostring(showTip))
                        else
                            Draw3DText(hitCoords, "~w~" .. tostring(showTip), 0.05)
                        end
                    end

                    if IsControlJustPressed(0, Config.keybinds.confirm.input) then
                        return hitCoords, hitEntity
                    end
                end
            end
        end

        Citizen.Wait(1)
    end

    return nil, nil
end
