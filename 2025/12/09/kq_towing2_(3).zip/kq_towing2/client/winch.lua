local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = false
L1_1 = Citizen
L1_1 = L1_1.CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  while true do
    L0_2 = 2000
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = false
    L3_2 = IsPedInAnyVehicle
    L4_2 = L1_2
    L5_2 = false
    L3_2 = L3_2(L4_2, L5_2)
    if L3_2 then
      L3_2 = GetVehiclePedIsIn
      L4_2 = L1_2
      L3_2 = L3_2(L4_2)
      L4_2 = GetEntityState
      L5_2 = L3_2
      L4_2 = L4_2(L5_2)
      L5_2 = GetPedInVehicleSeat
      L6_2 = L3_2
      L7_2 = -1
      L5_2 = L5_2(L6_2, L7_2)
      if L5_2 == L1_2 then
        L5_2 = DoesVehicleHaveWinch
        L6_2 = L3_2
        L5_2 = L5_2(L6_2)
        if L5_2 then
          L0_2 = 1000
          L6_2 = GetRopeLength
          L7_2 = L4_2.kq_rope
          L6_2 = L6_2(L7_2)
          if L6_2 > 2 then
            L0_2 = 100
            L2_2 = true
            L7_2 = L0_1
            if not L7_2 then
              L7_2 = SetKeybindTip
              L8_2 = L
              L9_2 = "~w~Hold ~{INPUT}~ to winch"
              L8_2 = L8_2(L9_2)
              L9_2 = L8_2
              L8_2 = L8_2.gsub
              L10_2 = "{INPUT}"
              L11_2 = Config
              L11_2 = L11_2.keybinds
              L11_2 = L11_2.winch
              L11_2 = L11_2.name
              L8_2, L9_2, L10_2, L11_2, L12_2 = L8_2(L9_2, L10_2, L11_2)
              L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
              L7_2 = IsControlPressed
              L8_2 = 0
              L9_2 = Config
              L9_2 = L9_2.keybinds
              L9_2 = L9_2.winch
              L9_2 = L9_2.input
              L7_2 = L7_2(L8_2, L9_2)
              if L7_2 then
                L7_2 = true
                L0_1 = L7_2
                L7_2 = NetworkGetNetworkIdFromEntity
                L8_2 = L3_2
                L7_2 = L7_2(L8_2)
                L8_2 = TriggerServerEvent
                L9_2 = "kq_towing:server:setWinching"
                L10_2 = L4_2.kq_rope_id
                L11_2 = L7_2
                L12_2 = L0_1
                L8_2(L9_2, L10_2, L11_2, L12_2)
                L8_2 = Citizen
                L8_2 = L8_2.Wait
                L9_2 = 100
                L8_2(L9_2)
                L8_2 = StartWinchThread
                L9_2 = L3_2
                L10_2 = L4_2.kq_rope
                L11_2 = L4_2.kq_rope_id
                L8_2(L9_2, L10_2, L11_2)
                L8_2 = SetKeybindTip
                L9_2 = L
                L10_2 = "~w~Release ~{INPUT}~ to stop winching"
                L9_2 = L9_2(L10_2)
                L10_2 = L9_2
                L9_2 = L9_2.gsub
                L11_2 = "{INPUT}"
                L12_2 = Config
                L12_2 = L12_2.keybinds
                L12_2 = L12_2.winch
                L12_2 = L12_2.name
                L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2, L11_2, L12_2)
                L8_2(L9_2, L10_2, L11_2, L12_2)
                L8_2 = Citizen
                L8_2 = L8_2.Wait
                L9_2 = 500
                L8_2(L9_2)
              end
            else
              L7_2 = SetKeybindTip
              L8_2 = L
              L9_2 = "~w~Release ~{INPUT}~ to stop winching"
              L8_2 = L8_2(L9_2)
              L9_2 = L8_2
              L8_2 = L8_2.gsub
              L10_2 = "{INPUT}"
              L11_2 = Config
              L11_2 = L11_2.keybinds
              L11_2 = L11_2.winch
              L11_2 = L11_2.name
              L8_2, L9_2, L10_2, L11_2, L12_2 = L8_2(L9_2, L10_2, L11_2)
              L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
              L7_2 = IsControlPressed
              L8_2 = 0
              L9_2 = Config
              L9_2 = L9_2.keybinds
              L9_2 = L9_2.winch
              L9_2 = L9_2.input
              L7_2 = L7_2(L8_2, L9_2)
              if not L7_2 then
                L7_2 = false
                L0_1 = L7_2
                L7_2 = NetworkGetNetworkIdFromEntity
                L8_2 = L3_2
                L7_2 = L7_2(L8_2)
                L8_2 = TriggerServerEvent
                L9_2 = "kq_towing:server:setWinching"
                L10_2 = L4_2.kq_rope_id
                L11_2 = L7_2
                L12_2 = L0_1
                L8_2(L9_2, L10_2, L11_2, L12_2)
              end
            end
          end
        end
      end
    end
    if not L2_2 then
      L3_2 = ResetKeybindTip
      L3_2()
    end
    L3_2 = Citizen
    L3_2 = L3_2.Wait
    L4_2 = L0_2
    L3_2(L4_2)
  end
end
L1_1(L2_1)
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = Citizen
  L3_2 = L3_2.CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    while true do
      L0_3 = Entity
      L1_3 = A0_2
      L0_3 = L0_3(L1_3)
      L0_3 = L0_3.state
      L0_3 = L0_3.kq_is_winching
      if not L0_3 then
        break
      end
      L0_3 = DoesRopeExist
      L1_3 = A1_2
      L0_3 = L0_3(L1_3)
      if not L0_3 then
        break
      end
      L0_3 = RopeGetDistanceBetweenEnds
      L1_3 = A1_2
      L0_3 = L0_3(L1_3)
      if L0_3 <= 2 then
        L1_3 = NetworkGetNetworkIdFromEntity
        L2_3 = A0_2
        L1_3 = L1_3(L2_3)
        L2_3 = TriggerServerEvent
        L3_3 = "kq_towing:server:setWinching"
        L4_3 = Entity
        L5_3 = A0_2
        L4_3 = L4_3(L5_3)
        L4_3 = L4_3.state
        L4_3 = L4_3.kq_rope_id
        L5_3 = L1_3
        L6_3 = false
        L2_3(L3_3, L4_3, L5_3, L6_3)
      else
        L1_3 = TriggerServerEvent
        L2_3 = "kq_towing:server:setWinchLength"
        L3_3 = A2_2
        L4_3 = L0_3
        L1_3(L2_3, L3_3, L4_3)
      end
      L1_3 = Citizen
      L1_3 = L1_3.Wait
      L2_3 = 500
      L1_3(L2_3)
    end
  end
  L3_2(L4_2)
end
StartWinchThread = L1_1
L1_1 = AddStateBagChangeHandler
L2_1 = "kq_is_winching"
L3_1 = nil
function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = GetEntityFromStateBagName
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if 0 ~= L3_2 then
    L4_2 = DoesEntityExist
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      goto lbl_12
    end
  end
  do return end
  ::lbl_12::
  L4_2 = Entity
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L4_2 = L4_2.state
  L4_2 = L4_2.kq_rope_id
  L5_2 = ROPES
  L5_2 = L5_2[L4_2]
  if L5_2 then
    L5_2 = ROPES
    L5_2 = L5_2[L4_2]
    L5_2 = L5_2.rope
    L6_2 = ROPES
    L6_2 = L6_2[L4_2]
    L6_2.isWinching = A2_2
    L6_2 = SetRopeLengthChangeRate
    L7_2 = L5_2
    L8_2 = 1.0
    L6_2(L7_2, L8_2)
    if A2_2 then
      L6_2 = StartRopeWinding
      L7_2 = L5_2
      L6_2(L7_2)
    else
      L6_2 = StopRopeWinding
      L7_2 = L5_2
      L6_2(L7_2)
    end
  end
end
L1_1(L2_1, L3_1, L4_1)
