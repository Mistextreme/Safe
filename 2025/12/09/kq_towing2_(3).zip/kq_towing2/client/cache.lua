local L0_1, L1_1
L0_1 = {}
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  L4_2 = {}
  L4_2.data = A1_2
  L5_2 = GetGameTimer
  L5_2 = L5_2()
  L6_2 = A2_2 or L6_2
  if not A2_2 then
    L6_2 = 3000
  end
  L5_2 = L5_2 + L6_2
  L4_2.maxAge = L5_2
  L3_2[A0_2] = L4_2
end
SaveCache = L1_1
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  L3_2 = L3_2[A0_2]
  if L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2[A0_2]
    L3_2 = L3_2.maxAge
    L4_2 = GetGameTimer
    L4_2 = L4_2()
    if not (L3_2 < L4_2) then
      goto lbl_27
    end
  end
  L3_2 = {}
  L4_2 = A1_2
  L4_2, L5_2, L6_2, L7_2 = L4_2()
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  L3_2[4] = L7_2
  L4_2 = SaveCache
  L5_2 = A0_2
  L6_2 = L3_2
  L7_2 = A2_2
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = table
  L4_2 = L4_2.unpack
  L5_2 = L3_2
  do return L4_2(L5_2) end
  ::lbl_27::
  L3_2 = table
  L3_2 = L3_2.unpack
  L4_2 = L0_1
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.data
  return L3_2(L4_2)
end
UseCache = L1_1
