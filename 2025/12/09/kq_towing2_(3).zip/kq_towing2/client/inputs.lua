local L0_1, L1_1
L0_1 = {}
L0_1.holding = false
L0_1.timeLeft = 100000
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2)
  local L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L8_2 = A0_2
  L9_2 = type
  L10_2 = A0_2
  L9_2 = L9_2(L10_2)
  if "number" == L9_2 then
    L9_2 = GetEntityCoords
    L10_2 = A0_2
    L9_2 = L9_2(L10_2)
    L8_2 = L9_2
  end
  L9_2 = Config
  L9_2 = L9_2.inputType
  if "top-left" == L9_2 then
    L9_2 = KeybindTip
    L10_2 = A1_2
    L9_2(L10_2)
  else
    L9_2 = Config
    L9_2 = L9_2.inputType
    if "help-text" == L9_2 then
      L9_2 = FloatingText
      L10_2 = L8_2
      L11_2 = A1_2
      L9_2(L10_2, L11_2)
    elseif A3_2 then
      L9_2 = L0_1.holding
      if L9_2 then
        L9_2 = math
        L9_2 = L9_2.floor
        L10_2 = L0_1.timeLeft
        L10_2 = A5_2 - L10_2
        L10_2 = L10_2 / A5_2
        L10_2 = L10_2 * 15
        L9_2 = L9_2(L10_2)
        if L9_2 <= 0 then
          L9_2 = 1
        end
        L10_2 = A1_2
        L11_2 = [[

~r~]]
        L10_2 = L10_2 .. L11_2
        A1_2 = L10_2
        L10_2 = 1
        L11_2 = 15
        L12_2 = 1
        for L13_2 = L10_2, L11_2, L12_2 do
          if L9_2 == L13_2 then
            L14_2 = A1_2
            L15_2 = "~w~"
            L14_2 = L14_2 .. L15_2
            A1_2 = L14_2
          end
          L14_2 = A1_2
          L15_2 = "|"
          L14_2 = L14_2 .. L15_2
          A1_2 = L14_2
        end
      end
      L9_2 = Draw3DText
      L10_2 = L8_2
      L11_2 = A1_2
      L12_2 = 0.042
      L9_2(L10_2, L11_2, L12_2)
    else
      L9_2 = Draw3DText
      L10_2 = L8_2
      L11_2 = A1_2
      L12_2 = 0.042
      L9_2(L10_2, L11_2, L12_2)
    end
  end
  if A3_2 then
    L9_2 = L0_1.holding
    if not L9_2 then
      L0_1.timeLeft = A5_2
    end
    L9_2 = HoldDownInput
    L10_2 = A2_2
    L11_2 = A4_2
    L12_2 = A5_2
    L13_2 = A6_2
    L14_2 = A7_2
    L9_2(L10_2, L11_2, L12_2, L13_2, L14_2)
  else
    L9_2 = IsControlJustReleased
    L10_2 = 0
    L11_2 = A2_2
    L9_2 = L9_2(L10_2, L11_2)
    if L9_2 then
      L9_2 = A4_2
      L9_2()
    end
  end
end
CreateKQInput = L1_1
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2
  L5_2 = IsControlJustPressed
  L6_2 = 0
  L7_2 = A0_2
  L5_2 = L5_2(L6_2, L7_2)
  if L5_2 then
    L5_2 = Citizen
    L5_2 = L5_2.CreateThread
    function L6_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = GetGameTimer
      L0_3 = L0_3()
      L1_3 = A3_2
      L1_3()
      while true do
        L1_3 = IsControlPressed
        L2_3 = 0
        L3_3 = A0_2
        L1_3 = L1_3(L2_3, L3_3)
        if not L1_3 then
          break
        end
        L0_1.holding = true
        L1_3 = A2_2
        L1_3 = L0_3 + L1_3
        L2_3 = GetGameTimer
        L2_3 = L2_3()
        L1_3 = L1_3 - L2_3
        L0_1.timeLeft = L1_3
        L1_3 = Citizen
        L1_3 = L1_3.Wait
        L2_3 = 10
        L1_3(L2_3)
        L1_3 = GetGameTimer
        L1_3 = L1_3()
        L2_3 = A2_2
        L1_3 = L1_3 - L2_3
        if L0_3 < L1_3 then
          L0_1.holding = false
          L1_3 = A1_2
          return L1_3()
        end
      end
      L1_3 = A4_2
      L1_3()
      L0_1.holding = false
    end
    L5_2(L6_2)
  end
end
HoldDownInput = L1_1
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = AddTextEntry
  L3_2 = "KqFloatingHelpNotification"
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
  L2_2 = SetFloatingHelpTextWorldPosition
  L3_2 = 1
  L4_2 = A0_2
  L2_2(L3_2, L4_2)
  L2_2 = SetFloatingHelpTextStyle
  L3_2 = 1
  L4_2 = 1
  L5_2 = 2
  L6_2 = -1
  L7_2 = 3
  L8_2 = 2
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L2_2 = BeginTextCommandDisplayHelp
  L3_2 = "KqFloatingHelpNotification"
  L2_2(L3_2)
  L2_2 = EndTextCommandDisplayHelp
  L3_2 = 2
  L4_2 = false
  L5_2 = false
  L6_2 = -1
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
FloatingText = L1_1
