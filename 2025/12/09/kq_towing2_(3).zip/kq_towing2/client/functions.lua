local L0_1, L1_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = UseCache
  L2_2 = "entity_state_"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = Entity
    L1_3 = A0_2
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    return L0_3
  end
  L4_2 = 500
  return L1_2(L2_2, L3_2, L4_2)
end
GetEntityState = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = UseCache
  L2_2 = "rope_length_"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = DoesRopeExist
    L1_3 = A0_2
    L0_3 = L0_3(L1_3)
    if not L0_3 then
      L0_3 = 0
      return L0_3
    end
    L0_3 = RopeGetDistanceBetweenEnds
    L1_3 = A0_2
    return L0_3(L1_3)
  end
  L4_2 = 500
  return L1_2(L2_2, L3_2, L4_2)
end
GetRopeLength = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = UseCache
  L2_2 = "hasWinch_"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = Entity
    L1_3 = A0_2
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    L0_3 = L0_3.kq_winch
    return L0_3
  end
  L4_2 = 3000
  return L1_2(L2_2, L3_2, L4_2)
end
DoesVehicleHaveWinch = L0_1
function L0_1(A0_2)
  local L1_2
  if A0_2 then
    L1_2 = Config
    L1_2 = L1_2.winchLength
    if L1_2 then
      L1_2 = Config
      L1_2 = L1_2.winchLength
      return L1_2
    end
  end
  L1_2 = Config
  L1_2 = L1_2.ropeLength
  return L1_2
end
GetMaxLength = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = 0
  L4_2 = A0_2.z
  L5_2 = L2_2.z
  L5_2 = L5_2 - 0.2
  if L4_2 > L5_2 then
    L3_2 = 16
  end
  L4_2 = ClearPedTasks
  L5_2 = L1_2
  L4_2(L5_2)
  L4_2 = Citizen
  L4_2 = L4_2.Wait
  L5_2 = 200
  L4_2(L5_2)
  L4_2 = TaskTurnPedToFaceCoord
  L5_2 = L1_2
  L6_2 = A0_2
  L7_2 = 1000
  L8_2 = 1
  L9_2 = 1
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  L4_2 = Citizen
  L4_2 = L4_2.Wait
  L5_2 = 1000
  L4_2(L5_2)
  L4_2 = PlayAnim
  L5_2 = "mp_car_bomb"
  L6_2 = "car_bomb_mechanic"
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = Citizen
  L4_2 = L4_2.Wait
  L5_2 = 2000
  L4_2(L5_2)
  L4_2 = ClearPedTasks
  L5_2 = L1_2
  L4_2(L5_2)
end
PlayRopeTieAnimation = L0_1
function L0_1(A0_2)
  local L1_2, L2_2
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L0_3 = PlayerPedId
    L0_3 = L0_3()
    L1_3 = GetEntityCoords
    L2_3 = L0_3
    L1_3 = L1_3(L2_3)
    L2_3 = 0
    L3_3 = A0_2.z
    L4_3 = L1_3.z
    L4_3 = L4_3 - 0.2
    if L3_3 > L4_3 then
      L2_3 = 16
    end
    L3_3 = ClearPedTasks
    L4_3 = L0_3
    L3_3(L4_3)
    L3_3 = Citizen
    L3_3 = L3_3.Wait
    L4_3 = 200
    L3_3(L4_3)
    L3_3 = TaskTurnPedToFaceCoord
    L4_3 = L0_3
    L5_3 = A0_2
    L6_3 = 1000
    L7_3 = 1
    L8_3 = 1
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    L3_3 = Citizen
    L3_3 = L3_3.Wait
    L4_3 = 1000
    L3_3(L4_3)
    L3_3 = PlayAnim
    L4_3 = "mp_car_bomb"
    L5_3 = "car_bomb_mechanic"
    L6_3 = L2_3
    L3_3(L4_3, L5_3, L6_3)
  end
  L1_2(L2_2)
end
PlayRopeUntieAnimation = L0_1
function L0_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L4_2 = vector3
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = GetGamePool
  L6_2 = "CVehicle"
  L5_2 = L5_2(L6_2)
  L6_2 = -1
  L7_2 = -1
  L8_2 = 1
  L9_2 = #L5_2
  L10_2 = 1
  for L11_2 = L8_2, L9_2, L10_2 do
    L12_2 = GetEntityCoords
    L13_2 = L5_2[L11_2]
    L12_2 = L12_2(L13_2)
    L13_2 = L12_2 - L4_2
    L13_2 = #L13_2
    if -1 == L6_2 or L6_2 > L13_2 and A3_2 >= L13_2 then
      L7_2 = L5_2[L11_2]
      L6_2 = L13_2
    end
  end
  L8_2 = L7_2
  L9_2 = L6_2
  return L8_2, L9_2
end
GetNearestVehicle = L0_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    if L7_2 == A1_2 then
      L8_2 = true
      return L8_2
    end
  end
  L2_2 = false
  return L2_2
end
Contains = L0_1
function L0_1(...)
  local L0_2, L1_2
  L0_2 = Config
  L0_2 = L0_2.debug
  if L0_2 then
    L0_2 = print
    L1_2 = ...
    L0_2(L1_2)
  end
end
Debug = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = GetHashKey
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = RequestModel
  L3_2 = L1_2
  L2_2(L3_2)
  L2_2 = 0
  while true do
    L3_2 = HasModelLoaded
    L4_2 = L1_2
    L3_2 = L3_2(L4_2)
    if not (not L3_2 and L2_2 < 100) then
      break
    end
    L3_2 = Citizen
    L3_2 = L3_2.Wait
    L4_2 = 10
    L3_2(L4_2)
    L2_2 = L2_2 + 1
  end
end
DoRequestModel = L0_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L2_2 = {}
  L3_2 = "attach_male"
  L4_2 = "neon_f"
  L5_2 = "overheat"
  L6_2 = "overheat2"
  L7_2 = "overheat_2"
  L8_2 = "rope_attach_a"
  L9_2 = "rope_attach_b"
  L10_2 = "overheat"
  L11_2 = "engine"
  L12_2 = "bonnet"
  L13_2 = "bumper_f"
  L14_2 = "transmission_f"
  L15_2 = "attach_female"
  L16_2 = "neon_b"
  L17_2 = "tow_arm"
  L18_2 = "tow_mount_a"
  L19_2 = "tow_mount_b"
  L20_2 = "bumper_r"
  L21_2 = "exhaust"
  L22_2 = "boot"
  L23_2 = "petroltank"
  L24_2 = "chassis_dummy"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L2_2[5] = L7_2
  L2_2[6] = L8_2
  L2_2[7] = L9_2
  L2_2[8] = L10_2
  L2_2[9] = L11_2
  L2_2[10] = L12_2
  L2_2[11] = L13_2
  L2_2[12] = L14_2
  L2_2[13] = L15_2
  L2_2[14] = L16_2
  L2_2[15] = L17_2
  L2_2[16] = L18_2
  L2_2[17] = L19_2
  L2_2[18] = L20_2
  L2_2[19] = L21_2
  L2_2[20] = L22_2
  L2_2[21] = L23_2
  L2_2[22] = L24_2
  L3_2 = 999.9
  L4_2 = "chassis_dummy"
  L5_2 = pairs
  L6_2 = L2_2
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = GetWorldPositionOfEntityBone
    L12_2 = A0_2
    L13_2 = GetEntityBoneIndexByName
    L14_2 = A0_2
    L15_2 = L10_2
    L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L13_2(L14_2, L15_2)
    L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
    L12_2 = L11_2.x
    if 0.0 ~= L12_2 then
      L12_2 = L11_2.x
      if 0 ~= L12_2 then
        L12_2 = L11_2.x
        if nil ~= L12_2 then
          L12_2 = L11_2.x
          if not (L12_2 > 20.0) then
            L12_2 = L11_2.x
            if not (L12_2 < -20) then
              L12_2 = L11_2.z
              if not (L12_2 > 20) then
                L12_2 = L11_2.z
                if not (L12_2 < -20) then
                  goto lbl_69
                end
              end
            end
          end
          L12_2 = GetDistanceBetweenCoords
          L13_2 = A1_2
          L14_2 = L11_2
          L15_2 = true
          L12_2 = L12_2(L13_2, L14_2, L15_2)
          if L3_2 > L12_2 then
            L3_2 = L12_2
            L4_2 = L10_2
          end
        end
      end
    end
    ::lbl_69::
  end
  return L4_2
end
GetNearBone = L0_1
function L0_1(A0_2)
  local L1_2
  L1_2 = Locale
  if L1_2 then
    L1_2 = Locale
    L1_2 = L1_2[A0_2]
    if L1_2 then
      L1_2 = Locale
      L1_2 = L1_2[A0_2]
      return L1_2
    end
  end
  return A0_2
end
L = L0_1
