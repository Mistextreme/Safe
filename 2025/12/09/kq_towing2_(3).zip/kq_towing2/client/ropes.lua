local L0_1, L1_1, L2_1
L0_1 = {}
ROPES = L0_1
L0_1 = {}
ROPE_ENTITIES = L0_1
L0_1 = RegisterNetEvent
L1_1 = "kq_towing:client:forceRefresh"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "kq_towing:client:forceRefresh"
function L2_1()
  local L0_2, L1_2
  L0_2 = RefreshRopes
  L0_2()
end
L0_1(L1_1, L2_1)
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2
  while true do
    L0_2 = Debug
    L1_2 = "Count on refresh"
    L0_2(L1_2)
    L0_2 = RefreshRopes
    L0_2()
    L0_2 = Citizen
    L0_2 = L0_2.Wait
    L1_2 = Config
    L1_2 = L1_2.ropeRefreshTime
    L1_2 = 1000 * L1_2
    L0_2(L1_2)
  end
end
L0_1(L1_1)
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = pairs
  L1_2 = ROPES
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.rope
    L7_2 = json
    L7_2 = L7_2.decode
    L8_2 = GetConvar
    L9_2 = CONVAR_NAME
    L10_2 = "{}"
    L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L8_2(L9_2, L10_2)
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    L8_2 = DoesRopeExist
    L9_2 = L6_2
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L8_2 = Debug
      L9_2 = "Start delete rope"
      L8_2(L9_2)
      L8_2 = DeleteRope
      L9_2 = ROPES
      L10_2 = L5_2.ropeId
      L9_2 = L9_2[L10_2]
      L9_2 = L9_2.rope
      L8_2(L9_2)
      L8_2 = pairs
      L9_2 = ROPES
      L10_2 = L5_2.ropeId
      L9_2 = L9_2[L10_2]
      L9_2 = L9_2.hooks
      L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
      for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
        L14_2 = Debug
        L15_2 = "Delete object"
        L14_2(L15_2)
        L14_2 = DeleteObject
        L15_2 = L13_2
        L14_2(L15_2)
      end
      L8_2 = ContainsRopeId
      L9_2 = L7_2
      L10_2 = L5_2.ropeId
      L8_2 = L8_2(L9_2, L10_2)
      if not L8_2 then
        L8_2 = L5_2.netId1
        if L8_2 then
          L8_2 = NetworkDoesNetworkIdExist
          L9_2 = L5_2.netId1
          L8_2 = L8_2(L9_2)
          if L8_2 then
            L8_2 = NetworkDoesEntityExistWithNetworkId
            L9_2 = L5_2.netId1
            L8_2 = L8_2(L9_2)
            if L8_2 then
              L8_2 = NetworkGetEntityFromNetworkId
              L9_2 = L5_2.netId1
              L8_2 = L8_2(L9_2)
              L9_2 = DoesEntityExist
              L10_2 = L8_2
              L9_2 = L9_2(L10_2)
              if L9_2 then
                L9_2 = Debug
                L10_2 = "Change 1 statebags"
                L9_2(L10_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_attached_to"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_rope"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_winch"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_winch_sub"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_rope_id"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
              end
            end
          end
        end
        L8_2 = L5_2.netId2
        if L8_2 then
          L8_2 = NetworkDoesNetworkIdExist
          L9_2 = L5_2.netId2
          L8_2 = L8_2(L9_2)
          if L8_2 then
            L8_2 = NetworkDoesEntityExistWithNetworkId
            L9_2 = L5_2.netId2
            L8_2 = L8_2(L9_2)
            if L8_2 then
              L8_2 = NetworkGetEntityFromNetworkId
              L9_2 = L5_2.netId2
              L8_2 = L8_2(L9_2)
              L9_2 = DoesEntityExist
              L10_2 = L8_2
              L9_2 = L9_2(L10_2)
              if L9_2 then
                L9_2 = Debug
                L10_2 = "Change 2 statebags"
                L9_2(L10_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_attached_to"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_rope"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_winch"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_winch_sub"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
                L9_2 = Entity
                L10_2 = L8_2
                L9_2 = L9_2(L10_2)
                L9_2 = L9_2.state
                L10_2 = L9_2
                L9_2 = L9_2.set
                L11_2 = "kq_rope_id"
                L12_2 = nil
                L9_2(L10_2, L11_2, L12_2)
              end
            end
          end
        end
      end
    end
    L8_2 = Debug
    L9_2 = "Clear table"
    L8_2(L9_2)
    L8_2 = ROPES
    L8_2[L4_2] = nil
  end
end
DeleteRopes = L0_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.ropeId
    if L8_2 == A1_2 then
      L8_2 = true
      return L8_2
    end
  end
  L2_2 = false
  return L2_2
end
ContainsRopeId = L0_1
function L0_1()
  local L0_2, L1_2
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3
    L0_3 = Debug
    L1_3 = "Trigger refresh"
    L0_3(L1_3)
    L0_3 = DeleteRopes
    L0_3()
    L0_3 = {}
    L1_3 = Debug
    L2_3 = "Get convar"
    L1_3(L2_3)
    L1_3 = json
    L1_3 = L1_3.decode
    L2_3 = GetConvar
    L3_3 = CONVAR_NAME
    L4_3 = "{}"
    L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L2_3(L3_3, L4_3)
    L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
    L2_3 = pairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = ROPES
      L9_3 = L7_3.ropeId
      L8_3 = L8_3[L9_3]
      if L8_3 then
        L8_3 = ROPES
        L9_3 = L7_3.ropeId
        L8_3 = L8_3[L9_3]
        L8_3 = L8_3.rope
        L9_3 = DoesRopeExist
        L10_3 = L8_3
        L9_3 = L9_3(L10_3)
        if L9_3 then
          L9_3 = Debug
          L10_3 = "Delete rope"
          L9_3(L10_3)
          L9_3 = DeleteRope
          L10_3 = ROPES
          L11_3 = L7_3.ropeId
          L10_3 = L10_3[L11_3]
          L10_3 = L10_3.rope
          L9_3(L10_3)
          L9_3 = pairs
          L10_3 = ROPES
          L11_3 = L7_3.ropeId
          L10_3 = L10_3[L11_3]
          L10_3 = L10_3.hooks
          L9_3, L10_3, L11_3, L12_3 = L9_3(L10_3)
          for L13_3, L14_3 in L9_3, L10_3, L11_3, L12_3 do
            L15_3 = Debug
            L16_3 = "Delete hook"
            L15_3(L16_3)
            L15_3 = DeleteObject
            L16_3 = L14_3
            L15_3(L16_3)
          end
        end
      end
      L8_3 = {}
      L9_3 = vector3
      L10_3 = L7_3.coords1
      L10_3 = L10_3.x
      L11_3 = L7_3.coords1
      L11_3 = L11_3.y
      L12_3 = L7_3.coords1
      L12_3 = L12_3.z
      L9_3 = L9_3(L10_3, L11_3, L12_3)
      L10_3 = nil
      L11_3 = L7_3.netId1
      if L11_3 then
        L11_3 = NetworkDoesNetworkIdExist
        L12_3 = L7_3.netId1
        L11_3 = L11_3(L12_3)
        if L11_3 then
          L11_3 = NetworkDoesEntityExistWithNetworkId
          L12_3 = L7_3.netId1
          L11_3 = L11_3(L12_3)
          if L11_3 then
            L11_3 = NetworkGetEntityFromNetworkId
            L12_3 = L7_3.netId1
            L11_3 = L11_3(L12_3)
            L12_3 = table
            L12_3 = L12_3.insert
            L13_3 = L0_3
            L14_3 = L11_3
            L12_3(L13_3, L14_3)
            L12_3 = DoesEntityExist
            L13_3 = L11_3
            L12_3 = L12_3(L13_3)
            if L12_3 then
              L10_3 = L11_3
            end
          end
        end
      end
      if not L10_3 then
        L11_3 = L7_3.netId1
        if not L11_3 then
          L11_3 = CreateTemporaryHook
          L12_3 = L9_3
          L13_3 = nil
          L11_3 = L11_3(L12_3, L13_3)
          L10_3 = L11_3
          L11_3 = table
          L11_3 = L11_3.insert
          L12_3 = L8_3
          L13_3 = L10_3
          L11_3(L12_3, L13_3)
        end
      end
      L11_3 = vector3
      L12_3 = L7_3.coords2
      L12_3 = L12_3.x
      L13_3 = L7_3.coords2
      L13_3 = L13_3.y
      L14_3 = L7_3.coords2
      L14_3 = L14_3.z
      L11_3 = L11_3(L12_3, L13_3, L14_3)
      L12_3 = nil
      L13_3 = L7_3.netId2
      if L13_3 then
        L13_3 = NetworkDoesNetworkIdExist
        L14_3 = L7_3.netId2
        L13_3 = L13_3(L14_3)
        if L13_3 then
          L13_3 = NetworkDoesEntityExistWithNetworkId
          L14_3 = L7_3.netId2
          L13_3 = L13_3(L14_3)
          if L13_3 then
            L13_3 = NetworkGetEntityFromNetworkId
            L14_3 = L7_3.netId2
            L13_3 = L13_3(L14_3)
            L14_3 = table
            L14_3 = L14_3.insert
            L15_3 = L0_3
            L16_3 = L13_3
            L14_3(L15_3, L16_3)
            L14_3 = DoesEntityExist
            L15_3 = L13_3
            L14_3 = L14_3(L15_3)
            if L14_3 then
              L12_3 = L13_3
            end
          end
        end
      end
      if not L12_3 then
        L13_3 = L7_3.netId2
        if not L13_3 then
          L13_3 = CreateTemporaryHook
          L14_3 = L11_3
          L15_3 = nil
          L13_3 = L13_3(L14_3, L15_3)
          L12_3 = L13_3
          L13_3 = table
          L13_3 = L13_3.insert
          L14_3 = L8_3
          L15_3 = L12_3
          L13_3(L14_3, L15_3)
        end
      end
      L13_3 = RopeLoadTextures
      L13_3()
      while true do
        L13_3 = RopeAreTexturesLoaded
        L13_3 = L13_3()
        if L13_3 then
          break
        end
        L13_3 = Citizen
        L13_3 = L13_3.Wait
        L14_3 = 50
        L13_3(L14_3)
      end
      L13_3 = 1
      L14_3 = L7_3.isWinch
      if L14_3 then
        L13_3 = 4
      end
      L14_3 = GetMaxLength
      L15_3 = L7_3.isWinch
      L14_3 = L14_3(L15_3)
      L15_3 = DoesEntityExist
      L16_3 = L10_3
      L15_3 = L15_3(L16_3)
      if L15_3 then
        L15_3 = DoesEntityExist
        L16_3 = L12_3
        L15_3 = L15_3(L16_3)
        if L15_3 then
          L15_3 = GetDistanceBetweenCoords
          L16_3 = GetEntityCoords
          L17_3 = L10_3
          L16_3 = L16_3(L17_3)
          L17_3 = GetEntityCoords
          L18_3 = L12_3
          L17_3 = L17_3(L18_3)
          L18_3 = true
          L15_3 = L15_3(L16_3, L17_3, L18_3)
          L16_3 = L14_3 * 1.5
          if L15_3 < L16_3 then
            L15_3 = AddRope
            L16_3 = GetEntityCoords
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L17_3 = 0.0
            L18_3 = 0.0
            L19_3 = 0.0
            L20_3 = 0.0
            L21_3 = L13_3
            L22_3 = L7_3.length
            L23_3 = 0.5
            L24_3 = 1.0
            L25_3 = false
            L26_3 = false
            L27_3 = false
            L28_3 = 1.0
            L29_3 = false
            L15_3 = L15_3(L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3)
            L16_3 = Debug
            L17_3 = "Created rope"
            L18_3 = L15_3
            L16_3(L17_3, L18_3)
            L7_3.rope = L15_3
            L7_3.hooks = L8_3
            L16_3 = ROPES
            L17_3 = L7_3.ropeId
            L16_3[L17_3] = L7_3
            L16_3 = Entity
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_attached_to"
            L19_3 = L12_3
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L12_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_attached_to"
            L19_3 = L10_3
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_rope"
            L19_3 = L15_3
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_winch"
            L19_3 = L7_3.isWinch
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_winch_sub"
            L19_3 = L7_3.isWinch
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_rope_id"
            L19_3 = L7_3.ropeId
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Entity
            L17_3 = L12_3
            L16_3 = L16_3(L17_3)
            L16_3 = L16_3.state
            L17_3 = L16_3
            L16_3 = L16_3.set
            L18_3 = "kq_winch_sub"
            L19_3 = L7_3.isWinch
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = L7_3.isWinch
            if not L16_3 then
              L16_3 = Entity
              L17_3 = L12_3
              L16_3 = L16_3(L17_3)
              L16_3 = L16_3.state
              L17_3 = L16_3
              L16_3 = L16_3.set
              L18_3 = "kq_rope"
              L19_3 = L15_3
              L16_3(L17_3, L18_3, L19_3)
              L16_3 = Entity
              L17_3 = L12_3
              L16_3 = L16_3(L17_3)
              L16_3 = L16_3.state
              L17_3 = L16_3
              L16_3 = L16_3.set
              L18_3 = "kq_rope_id"
              L19_3 = L7_3.ropeId
              L16_3(L17_3, L18_3, L19_3)
            end
            L16_3 = Debug
            L17_3 = "Attach rope to "
            L18_3 = L10_3
            L19_3 = L12_3
            L16_3(L17_3, L18_3, L19_3)
            L16_3 = Debug
            L17_3 = "Entity1 exists"
            L18_3 = DoesEntityExist
            L19_3 = L10_3
            L18_3 = L18_3(L19_3)
            L19_3 = GetEntityCoords
            L20_3 = L10_3
            L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L19_3(L20_3)
            L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
            L16_3 = Debug
            L17_3 = "Entity2 exists"
            L18_3 = DoesEntityExist
            L19_3 = L12_3
            L18_3 = L18_3(L19_3)
            L19_3 = GetEntityCoords
            L20_3 = L12_3
            L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L19_3(L20_3)
            L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
            L16_3 = IsEntityPositionFrozen
            L17_3 = L10_3
            L16_3 = L16_3(L17_3)
            if not L16_3 then
              L16_3 = IsEntityPositionFrozen
              L17_3 = L12_3
              L16_3 = L16_3(L17_3)
              if not L16_3 then
                L16_3 = Debug
                L17_3 = L7_3.bone1
                L18_3 = L7_3.bone2
                L16_3(L17_3, L18_3)
                L16_3 = GetWorldPositionOfEntityBone
                L17_3 = L10_3
                L18_3 = GetEntityBoneIndexByName
                L19_3 = L10_3
                L20_3 = L7_3.bone1
                L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L18_3(L19_3, L20_3)
                L16_3 = L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
                L17_3 = GetWorldPositionOfEntityBone
                L18_3 = L12_3
                L19_3 = GetEntityBoneIndexByName
                L20_3 = L12_3
                L21_3 = L7_3.bone2
                L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L19_3(L20_3, L21_3)
                L17_3 = L17_3(L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
                L18_3 = GetDistanceBetweenCoords
                L19_3 = L16_3
                L20_3 = L17_3
                L21_3 = true
                L18_3 = L18_3(L19_3, L20_3, L21_3)
                L19_3 = L14_3 * 1.5
                if L18_3 < L19_3 then
                  L18_3 = Debug
                  L19_3 = "before attach"
                  L18_3(L19_3)
                  L18_3 = AttachEntitiesToRope
                  L19_3 = L15_3
                  L20_3 = L10_3
                  L21_3 = L12_3
                  L22_3 = 0.0
                  L23_3 = 0.0
                  L24_3 = -0.1
                  L25_3 = 0.0
                  L26_3 = 0.0
                  L27_3 = -0.1
                  L28_3 = L7_3.length
                  L29_3 = false
                  L30_3 = false
                  L31_3 = L7_3.bone1
                  if not L31_3 then
                    L31_3 = nil
                  end
                  L32_3 = L7_3.bone2
                  if not L32_3 then
                    L32_3 = nil
                  end
                  L18_3(L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
                  L18_3 = Debug
                  L19_3 = "after attach"
                  L18_3(L19_3)
                else
                  L18_3 = Debug
                  L19_3 = "distance too great"
                  L18_3(L19_3)
                end
              else
                L16_3 = GetWorldPositionOfEntityBone
                L17_3 = L10_3
                L18_3 = GetEntityBoneIndexByName
                L19_3 = L10_3
                L20_3 = L7_3.bone1
                L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L18_3(L19_3, L20_3)
                L16_3 = L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
                L17_3 = GetDistanceBetweenCoords
                L18_3 = L16_3
                L19_3 = L11_3
                L20_3 = true
                L17_3 = L17_3(L18_3, L19_3, L20_3)
                L18_3 = L14_3 * 1.5
                if L17_3 < L18_3 then
                  L17_3 = AttachEntitiesToRope
                  L18_3 = L15_3
                  L19_3 = L10_3
                  L20_3 = L12_3
                  L21_3 = 0.0
                  L22_3 = 0.0
                  L23_3 = -0.1
                  L24_3 = L11_3
                  L25_3 = L7_3.length
                  L26_3 = false
                  L27_3 = false
                  L28_3 = L7_3.bone1
                  if not L28_3 then
                    L28_3 = nil
                  end
                  L29_3 = L7_3.bone2
                  if not L29_3 then
                    L29_3 = nil
                  end
                  L17_3(L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3)
                end
              end
            else
              L16_3 = IsEntityPositionFrozen
              L17_3 = L12_3
              L16_3 = L16_3(L17_3)
              if not L16_3 then
                L16_3 = GetWorldPositionOfEntityBone
                L17_3 = L12_3
                L18_3 = GetEntityBoneIndexByName
                L19_3 = L12_3
                L20_3 = L7_3.bone2
                L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3 = L18_3(L19_3, L20_3)
                L16_3 = L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3, L30_3, L31_3, L32_3)
                L17_3 = GetDistanceBetweenCoords
                L18_3 = L9_3
                L19_3 = L16_3
                L20_3 = true
                L17_3 = L17_3(L18_3, L19_3, L20_3)
                L18_3 = L14_3 * 1.5
                if L17_3 < L18_3 then
                  L17_3 = AttachEntitiesToRope
                  L18_3 = L15_3
                  L19_3 = L10_3
                  L20_3 = L12_3
                  L21_3 = L9_3
                  L22_3 = 0.0
                  L23_3 = 0.0
                  L24_3 = -0.1
                  L25_3 = L7_3.length
                  L26_3 = false
                  L27_3 = false
                  L28_3 = L7_3.bone1
                  if not L28_3 then
                    L28_3 = nil
                  end
                  L29_3 = L7_3.bone2
                  if not L29_3 then
                    L29_3 = nil
                  end
                  L17_3(L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3, L27_3, L28_3, L29_3)
                end
              else
                L16_3 = GetDistanceBetweenCoords
                L17_3 = L9_3
                L18_3 = L11_3
                L19_3 = true
                L16_3 = L16_3(L17_3, L18_3, L19_3)
                L17_3 = L14_3 * 1.5
                if L16_3 < L17_3 then
                  L16_3 = AttachEntitiesToRope
                  L17_3 = L15_3
                  L18_3 = L10_3
                  L19_3 = L12_3
                  L20_3 = L9_3
                  L21_3 = L11_3
                  L22_3 = L7_3.length
                  L23_3 = false
                  L24_3 = false
                  L25_3 = L7_3.bone1
                  if not L25_3 then
                    L25_3 = nil
                  end
                  L26_3 = L7_3.bone2
                  if not L26_3 then
                    L26_3 = nil
                  end
                  L16_3(L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3, L24_3, L25_3, L26_3)
                end
              end
            end
            L16_3 = Debug
            L17_3 = "Rope attached"
            L16_3(L17_3)
            L16_3 = L7_3.isWinching
            if L16_3 then
              L16_3 = RopeGetDistanceBetweenEnds
              L17_3 = L15_3
              L16_3 = L16_3(L17_3)
              if L16_3 > 2 then
                L17_3 = SetRopeLengthChangeRate
                L18_3 = L15_3
                L19_3 = 1.0
                L17_3(L18_3, L19_3)
                L17_3 = StartRopeWinding
                L18_3 = L15_3
                L17_3(L18_3)
                L17_3 = StartWinchThread
                L18_3 = L10_3
                L19_3 = L15_3
                L20_3 = L7_3.ropeId
                L17_3(L18_3, L19_3, L20_3)
              end
            end
          end
      end
      else
        L15_3 = Debug
        L16_3 = "One of the entities does not exist"
        L15_3(L16_3)
      end
    end
    ROPE_ENTITIES = L0_3
  end
  L0_2(L1_2)
end
RefreshRopes = L0_1
