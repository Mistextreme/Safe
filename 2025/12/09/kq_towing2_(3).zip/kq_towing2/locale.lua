-- Only edit the value on the right. Leave the value between the square brackets as is. <!>

Locale = {
    ['~w~Press ~g~[~w~{INPUT}~g~]~w~ to attach the rope'] = '~w~Press ~g~[~w~{INPUT}~g~]~w~ to attach the rope',
    ['~w~Press ~{INPUT}~ to attach the rope'] = '~w~Press ~{INPUT}~ to attach the rope',

    ['~w~Press ~g~[~w~{INPUT}~g~]~w~ to tie the rope'] = '~w~Press ~g~[~w~{INPUT}~g~]~w~ to tie the rope',
    ['~w~Press ~{INPUT}~ to tie the rope'] = '~w~Press ~{INPUT}~ to tie the rope',

    ['Press ~{INPUT}~ to cancel'] = 'Press ~{INPUT}~ to cancel',

    ['~r~Too far'] = '~r~Too far',
    ['~y~You can not tie the rope to the ground'] = '~y~You can not tie the rope to the ground',
    ['~r~This vehicle can not be towed'] = '~r~This vehicle can not be towed',

    ['~w~Hold ~r~[~w~{INPUT}~r~]~w~ to detach the rope'] = '~w~Hold ~r~[~w~{INPUT}~r~]~w~ to detach the rope',
    ['~w~Hold ~{INPUT}~ to detach the rope'] = '~w~Hold ~{INPUT}~ to detach the rope',

    ['~w~Hold ~{INPUT}~ to winch'] = '~w~Hold ~{INPUT}~ to winch',
    ['~w~Release ~{INPUT}~ to stop winching'] = '~w~Release ~{INPUT}~ to stop winching',

    ['~r~You may not use this item'] = '~r~You may not use this item',

}
