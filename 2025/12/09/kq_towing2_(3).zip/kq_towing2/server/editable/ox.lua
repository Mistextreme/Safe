if Config.oxInventory.enabled then
    
    -- Usable items
    -- Export used for ox_inventory
    exports('UseTowRope', function(event, item, inventory)
        if event == 'usingItem' then
            local player = inventory.id
            TriggerClientEvent('kq_towing:client:startRope', player, false, true)
            return true
        end
    end)
    
    exports('UseWinch', function(event, item, inventory)
        if event == 'usingItem' then
            local player = inventory.id
            TriggerClientEvent('kq_towing:client:startRope', player, true, true)
            return true
        end
    end)
    
    
    function IsPlayerJobWhitelisted(player, jobs)
        return true
    end
    
    function AddPlayerItem(player, item, amount, meta)
        local success, response = exports['ox_inventory']:AddItem(player, item, amount or 1, meta)
        return success
    end
    
    function RemovePlayerItem(player, item, amount)
        local success, response = exports['ox_inventory']:RemoveItem(player, item, amount or 1)
        return success
    end
end
