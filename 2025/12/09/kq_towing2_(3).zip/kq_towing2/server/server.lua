local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = SetConvarReplicated
L2_1 = CONVAR_NAME
L3_1 = json
L3_1 = L3_1.encode
L4_1 = {}
L3_1, L4_1 = L3_1(L4_1)
L1_1(L2_1, L3_1, L4_1)
L1_1 = RegisterNetEvent
L2_1 = "kq_towing:server:createRope"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "kq_towing:server:createRope"
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2)
  local L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L9_2 = source
  if A8_2 then
    L10_2 = false
    if A7_2 then
      L11_2 = RemovePlayerItem
      L12_2 = L9_2
      L13_2 = Config
      L13_2 = L13_2.items
      L13_2 = L13_2.winch
      L14_2 = 1
      L11_2 = L11_2(L12_2, L13_2, L14_2)
      L10_2 = L11_2
    else
      L11_2 = RemovePlayerItem
      L12_2 = L9_2
      L13_2 = Config
      L13_2 = L13_2.items
      L13_2 = L13_2.towingRope
      L14_2 = 1
      L11_2 = L11_2(L12_2, L13_2, L14_2)
      L10_2 = L11_2
    end
    if not L10_2 then
      return
    end
  end
  L10_2 = GetGameTimer
  L10_2 = L10_2()
  L11_2 = "_"
  L12_2 = math
  L12_2 = L12_2.random
  L13_2 = 0
  L14_2 = 99999
  L12_2 = L12_2(L13_2, L14_2)
  L10_2 = L10_2 .. L11_2 .. L12_2
  L11_2 = L0_1
  L12_2 = {}
  L12_2.ropeId = L10_2
  L12_2.coords1 = A0_2
  L12_2.netId1 = A1_2
  L12_2.bone1 = A2_2
  L12_2.coords2 = A3_2
  L12_2.netId2 = A4_2
  L12_2.bone2 = A5_2
  L12_2.length = A6_2
  L12_2.isWinch = A7_2
  L12_2.isWinching = false
  L12_2.isItem = A8_2
  L11_2[L10_2] = L12_2
  L11_2 = NetworkGetEntityFromNetworkId
  L12_2 = A1_2
  L11_2 = L11_2(L12_2)
  L12_2 = SetVehicleBodyHealth
  L13_2 = L11_2
  L14_2 = GetVehicleBodyHealth
  L15_2 = L11_2
  L14_2 = L14_2(L15_2)
  L14_2 = L14_2 - 0.1
  L12_2(L13_2, L14_2)
  L12_2 = NetworkGetEntityFromNetworkId
  L13_2 = A4_2
  L12_2 = L12_2(L13_2)
  L13_2 = SetVehicleBodyHealth
  L14_2 = L12_2
  L15_2 = GetVehicleBodyHealth
  L16_2 = L12_2
  L15_2 = L15_2(L16_2)
  L15_2 = L15_2 - 0.1
  L13_2(L14_2, L15_2)
  L13_2 = SetConvarReplicated
  L14_2 = CONVAR_NAME
  L15_2 = json
  L15_2 = L15_2.encode
  L16_2 = L0_1
  L15_2, L16_2 = L15_2(L16_2)
  L13_2(L14_2, L15_2, L16_2)
  L13_2 = Citizen
  L13_2 = L13_2.Wait
  L14_2 = 25
  L13_2(L14_2)
  L13_2 = TriggerClientEvent
  L14_2 = "kq_towing:client:forceRefresh"
  L15_2 = -1
  L13_2(L14_2, L15_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "kq_towing:server:removeRope"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "kq_towing:server:removeRope"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = source
  L2_2 = L0_1
  L2_2 = L2_2[A0_2]
  if L2_2 then
    L2_2 = L0_1
    L2_2 = L2_2[A0_2]
    L2_2 = L2_2.isItem
    if L2_2 then
      L2_2 = L0_1
      L2_2 = L2_2[A0_2]
      L2_2 = L2_2.isWinch
      if L2_2 then
        L2_2 = AddPlayerItem
        L3_2 = L1_2
        L4_2 = Config
        L4_2 = L4_2.items
        L4_2 = L4_2.winch
        L5_2 = 1
        L2_2(L3_2, L4_2, L5_2)
      else
        L2_2 = AddPlayerItem
        L3_2 = L1_2
        L4_2 = Config
        L4_2 = L4_2.items
        L4_2 = L4_2.towingRope
        L5_2 = 1
        L2_2(L3_2, L4_2, L5_2)
      end
    end
  end
  L2_2 = L0_1
  L2_2[A0_2] = nil
  L2_2 = SetConvarReplicated
  L3_2 = CONVAR_NAME
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = L0_1
  L4_2, L5_2 = L4_2(L5_2)
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Citizen
  L2_2 = L2_2.Wait
  L3_2 = 25
  L2_2(L3_2)
  L2_2 = TriggerClientEvent
  L3_2 = "kq_towing:client:forceRefresh"
  L4_2 = -1
  L2_2(L3_2, L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "kq_towing:server:setWinching"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "kq_towing:server:setWinching"
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = NetworkGetEntityFromNetworkId
  L4_2 = A1_2
  L3_2 = L3_2(L4_2)
  L4_2 = pairs
  L5_2 = L0_1
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = L9_2.ropeId
    if L10_2 == A0_2 then
      L10_2 = L0_1
      L10_2 = L10_2[L8_2]
      L10_2.isWinching = A2_2
    end
  end
  L4_2 = Entity
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L4_2 = L4_2.state
  L4_2.kq_is_winching = A2_2
  L4_2 = SetConvarReplicated
  L5_2 = CONVAR_NAME
  L6_2 = json
  L6_2 = L6_2.encode
  L7_2 = L0_1
  L6_2, L7_2, L8_2, L9_2, L10_2 = L6_2(L7_2)
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "kq_towing:server:setWinchLength"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "kq_towing:server:setWinchLength"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = pairs
  L3_2 = L0_1
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_2.ropeId
    if L8_2 == A0_2 then
      L8_2 = L0_1
      L8_2 = L8_2[L6_2]
      L8_2.length = A1_2
    end
  end
  L2_2 = SetConvarReplicated
  L3_2 = CONVAR_NAME
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = L0_1
  L4_2, L5_2, L6_2, L7_2, L8_2 = L4_2(L5_2)
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = ipairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    if L7_2 == A1_2 then
      L8_2 = true
      return L8_2
    end
  end
  L2_2 = false
  return L2_2
end
Contains = L1_1
function L1_1(A0_2)
  local L1_2
  L1_2 = Locale
  if L1_2 then
    L1_2 = Locale
    L1_2 = L1_2[A0_2]
    if L1_2 then
      L1_2 = Locale
      L1_2 = L1_2[A0_2]
      return L1_2
    end
  end
  return A0_2
end
L = L1_1
